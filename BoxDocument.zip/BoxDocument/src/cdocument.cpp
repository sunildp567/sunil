/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cdocument.cpp
Revision: com_t#8
File Spec: EBX:MA6034.A-DEV_SRC;com_t#8
Originator: LOCHANA.LINGEGOWDA
Last Changed: 13-APR-2009 15:38:41

Outline : 

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
  1:
  	Baseline:      "EBX:SCI_PHASE4_V2249"
  	Creation Date: 23-APR-2009 13:02:24
  	Description:   Baseline SCI_PHASE4_V2249_20090423_1300.AAAA
  
  2:
  	Baseline:      "EBX:SCI_PHASE4_V2249_20090423_1039"
  	Creation Date: 23-APR-2009 10:40:09
  	Description:   Baseline SCI_PHASE4_V2249_20090423_1039.AAAA
  
  3:
  	Baseline:      "EBX:SCI_PHASE4_V2249_PRE"
  	Creation Date: 15-APR-2009 14:23:49
  	Description:   Baseline SCI_PHASE4_V2249_PRE_20090415_1421.AAAA
  
  4:
  	Baseline:      "EBX:SCI_PHASE4_V2249_PRE_20090415_1032"
  	Creation Date: 15-APR-2009 10:33:31
  	Description:   Baseline SCI_PHASE4_V2249_PRE_20090415_1032.AAAA
  
  5:
  	Baseline:      "EBX:SCI_PHASE4_V2249_PRE_20090415_0915"
  	Creation Date: 15-APR-2009 09:17:05
  	Description:   Baseline SCI_PHASE4_V2249_PRE_20090415_0915.AAAA
  
  6:
  	Baseline:      "EBX:SCI_PHASE4_V2249_PRE_20090414_1706"
  	Creation Date: 14-APR-2009 17:08:35
  	Description:   Baseline SCI_PHASE4_V2249_PRE_20090414_1706.AAAA
  
  7:
  	Baseline:      "EBX:SCI_PHASE4_V2249_PRE_20090414_1248"
  	Creation Date: 14-APR-2009 12:49:30
  	Description:   Baseline SCI_PHASE4_V2249_PRE_20090414_1248.AAAA
  
  ------------------------------------------------------------------------------
History:
 * Revision com_t#8 (APPROVED)
 *   Created:  13-APR-2009 17:57:17      SANTOSH.KUMAR
 *     Updated for performance improvement, edit progress, edit
 *     operation and  scan preview functionality
 *   Updated:  13-APR-2009 17:57:17      SANTOSH.KUMAR
 *     Updated for performance improvement, edit progress, edit
 *     operation and  scan preview functionality
 *   Updated:  13-APR-2009 15:38:41      SANTOSH.KUMAR
 *     Item revision com_t#8 created from revision com_t#7 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#7 (APPROVED)
 *   Created:  24-JAN-2009 01:01:38      CHANDRAMOHAN.PUJARI
 *     Added Implementation support for 1)Append page GetPageList fix
 *     2) Insert page Fix, to insert page at correct position
 *     3)LastModifieddate Bug fix 4) Deletepage validations
 *   Updated:  24-JAN-2009 01:01:38      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#7 created from revision com_t#6 with status
 *     $TO_BE_DEFINED
 *   Updated:  24-JAN-2009 01:01:38      CHANDRAMOHAN.PUJARI
 *     Added Implementation support for 1)Append page GetPageList fix
 *     2) Insert page Fix, to insert page at correct position
 *     3)LastModifieddate Bug fix 4) Deletepage validations
 *   Updated:  24-JAN-2009 01:01:38      CHANDRAMOHAN.PUJARI
 *     Added Implementation support for 1)Append page GetPageList fix
 *     2) Insert page Fix, to insert page at correct position
 *     3)LastModifieddate Bug fix 4) Deletepage validations
 * 
 * Revision com_t#6 (APPROVED)
 *   Created:  09-JAN-2009 21:40:42      CHANDRAMOHAN.PUJARI
 *     Added code for Image extension support and Edit Progress related
 *     API's
 *   Updated:  09-JAN-2009 21:40:42      CHANDRAMOHAN.PUJARI
 *     Added code for Image extension support and Edit Progress related
 *     API's
 *   Updated:  09-JAN-2009 21:40:42      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#6 created from revision com_t#5 with status
 *     $TO_BE_DEFINED
 *   Updated:  09-JAN-2009 21:40:42      CHANDRAMOHAN.PUJARI
 *     Added code for Image extension support and Edit Progress related
 *     API's
 * 
 * Revision com_t#5 (UNIT TESTED)
 *   Created:  23-DEC-2008 22:05:40      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:05:40      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:05:40      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#5 created from revision com_t#4 with status
 *     $TO_BE_DEFINED
 *   Updated:  23-DEC-2008 22:05:40      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 * 
 * Revision com_t#4 (APPROVED)
 *   Created:  19-DEC-2008 21:40:13      CHANDRAMOHAN.PUJARI
 *     code added for clipboard limitation,copy jpeg parameter,Invalid
 *     combination requirement
 *   Updated:  19-DEC-2008 21:40:13      CHANDRAMOHAN.PUJARI
 *     code added for clipboard limitation,copy jpeg parameter,Invalid
 *     combination requirement
 *   Updated:  19-DEC-2008 21:40:13      CHANDRAMOHAN.PUJARI
 *     code added for clipboard limitation,copy jpeg parameter,Invalid
 *     combination requirement
 *   Updated:  19-DEC-2008 21:40:13      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#4 created from revision com_t#3 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#3 (APPROVED)
 *   Created:  08-DEC-2008 21:00:01      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,BoxUsuage,ColorMode Information,Error
 *     Codes,LastAccessdate and modified date
 *   Updated:  08-DEC-2008 21:00:01      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#3 created from revision com_t#2 with status
 *     $TO_BE_DEFINED
 *   Updated:  08-DEC-2008 21:00:01      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,BoxUsuage,ColorMode Information,Error
 *     Codes,LastAccessdate and modified date
 *   Updated:  08-DEC-2008 21:00:01      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,BoxUsuage,ColorMode Information,Error
 *     Codes,LastAccessdate and modified date
 * 
 * Revision com_t#2 (APPROVED)
 *   Created:  17-NOV-2008 21:56:01      CHANDRAMOHAN.PUJARI
 *     Changed CutDocument-CutPage flag to cutDocument-cutPage and
 *     Added Implementation for new Interface API s of Document Class
 *   Updated:  17-NOV-2008 21:56:01      CHANDRAMOHAN.PUJARI
 *     Changed CutDocument-CutPage flag to cutDocument-cutPage and
 *     Added Implementation for new Interface API s of Document Class
 *   Updated:  17-NOV-2008 21:56:01      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#2 created from revision com_t#1 with status
 *     $TO_BE_DEFINED
 *   Updated:  17-NOV-2008 21:56:01      CHANDRAMOHAN.PUJARI
 *     Changed CutDocument-CutPage flag to cutDocument-cutPage and
 *     Added Implementation for new Interface API s of Document Class
 * 
 * Revision com_t#1 (APPROVED)
 *   Created:  03-NOV-2008 19:26:53      CHANDRAMOHAN.PUJARI
 *     Added code for Edit and clipboard functionalities such as
 *     copy,cut and paste
 *   Updated:  03-NOV-2008 19:26:53      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#1 created from revision com_m#1.4 with
 *     status $TO_BE_DEFINED
 *   Updated:  03-NOV-2008 19:26:53      CHANDRAMOHAN.PUJARI
 *     Added code for Edit and clipboard functionalities such as
 *     copy,cut and paste
 *   Updated:  03-NOV-2008 19:26:53      CHANDRAMOHAN.PUJARI
 *     Added code for Edit and clipboard functionalities such as
 *     copy,cut and paste
 * 
 * Revision com_m#1.4 (APPROVED)
 *   Updated:  30-SEP-2008 11:38:00      13848
 *     Update WebDAV properties
 *   Created:  30-SEP-2008 11:38:00      13848
 *     Update WebDAV properties
 *   Updated:  30-SEP-2008 11:32:35      13848
 *     Item revision com_m#1.4 created from revision com_m#1.3 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.3 (UNIT TESTED)
 *   Updated:  11-SEP-2008 12:04:35      13848
 *     Item actioned from UNDER WORK to UNIT TESTED
 *   Created:  11-SEP-2008 11:54:37      13848
 *     Fix GetWEPDocument issue
 *   Updated:  11-SEP-2008 11:53:49      13848
 *     Item revision com_m#1.3 created from revision com_m#1.2 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.2 (APPROVED)
 *   Updated:  01-SEP-2008 17:15:58      13848
 *     Updated attribute(s)
 *   Created:  01-SEP-2008 17:14:33      13848
 *     Update for Ph3.5 1st build
 *   Updated:  01-SEP-2008 17:13:13      13848
 *     Item revision com_m#1.2 created from revision com_m#1.1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.1 (UNIT TESTED)
 *   Updated:  01-SEP-2008 16:51:16      13848
 *     Updated attribute(s)
 *   Created:  25-AUG-2008 20:11:38      13848
 *     BoxDocument 2nd release
 *   Updated:  25-AUG-2008 20:07:30      13848
 *     Item revision com_m#1.1 created from revision com_m#1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1 (UNIT TESTED)
 *   Updated:  24-FEB-2009 16:18:53      13848
 *     Updated attribute(s)
 *   Created:  19-AUG-2008 14:33:48      13848
 *     Initial revision
========================== End of Source Header =============================*/
#include <list>
#include <iomanip>
#include <sstream>
#include <cerrno>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include "proputils.h"
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include "cboxdocument.h"
#include "cdocument.h"
#include "cpage.h"
#include "CI/SystemInformation/systeminformation.h"
#include "CI/Codecs/passwordidentifier.h"
#include "comSize.h"
#include "comPar.h"
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <iostream>

using namespace ci::hierarchicaldb;
using namespace std;

namespace ci {
    namespace boxdocument {
        typedef std::map<CString, CString> property_pair;


        namespace blankpagevalues {

#define MAIN_SCAN_PAPER 0
#define SUB_SCAN_PAPER 1
#define MAIN_SCAN_VOID 2
#define SUB_SCAN_VOID 3
#define MAIN_SCAN_PIXEL 4
#define SUB_SCAN_PIXEL 5
#define MAIN_SCAN_TX_PIXEL 6
#define SUB_SCAN_TX_PIXEL 7
#define FILE_SIZE 8

#define SCAN_ARRAY_SIZE 220
#define COPY_ARRAY_SIZE 260
#define PRINT_ARRAY_SIZE 290

#define COLUMN_SIZE 10

#define SCAN_JPEG_JOB 1
#define SCAN_FAX_EMAIL_MMR_JOB 2
#define PRINT_TTEC_JPEG_color_JOB 3
#define PRINT_TTEC_JPEG_mono_JOB 4
#define COPY_Copy_JPEG_JOB 5 
#define COPY_Rector_JOB 6
#define PRINT_RECTOR_JOB 7

#define RESOLUTION_600600 1
#define RESOLUTION_400400 2
#define RESOLUTION_300300 3
#define RESOLUTION_200200 4
#define RESOLUTION_150150 5
#define RESOLUTION_100100 6

#define A3_O 0 
#define A4_O 5
#define A5_O 10
#define A6_O 15
#define A3_WIDE_O 20
#define B4_O 25
#define B5_O 30
#define LETTER_O 35
#define LEDGER_O 40
#define LEGAL_O 45
#define STATEMENT_O 50
#define COMPUTER_O 55
#define FOLIO_O 60
#define LEGAL13_O 65
#define SQUARE8_5_O 70
#define LEDGER_WIDE_R_O 75
#define RECTANGLE13X19_O 80
#define SIZE_8K_O 85
#define SIZE_16K_O 90
#define POSTCARD_O 95
#define SRA3_450_O 100
#define SRA3_460_O 105

#define H_SIZE 0   
#define H_IMG_COORDINATE 1   
#define H_ANGLE 2  
#define H_PAPER_SIZE 3 
#define H_ORIENTATION 4
#define FILE_SIZE_MAX_LEN 20 

#define SCAN 1
#define COPY 2
#define PRINT 3
#define DEFAULT_FPCA_PTR_COPY_HMAIN 3 
#define DEFAULT_FPCA_PTR_COPY_HSUB 3 
            //Columns of the array
            //MAIN_SCAN_PAPER, MAIN_SCAN_PAPER, MAIN_SCAN_VOID, SUB_SCAN_VOID,
            //MAIN_SCAN_PIXEL,SUB_SCAN_PIXEL,MAIN_SCAN_TX_PIXEL,SUB_SCAN_TX_PIXEL,
            //FILE_SIZE
            static int SCAN_JPG_600600_A[] = {
                COM_A3R,              2970, 4200, 10, 10, 6992, 9898, 6992, 9904, 811869, //A3_P   
                COM_B4R,              2570, 3640, 10, 10, 6048, 8575, 6048, 8576, 608184, //B4_P
                COM_A4R,              2100, 2970, 10, 10, 4938, 6992, 4944, 6992, 405459, //A4_P
                COM_B5R,              1820, 2570, 10, 10, 4272, 6048, 4272, 6048, 303138, //B5_P
                COM_A5R,              1480, 2100, 10, 10, 3472, 4938, 3472, 4944, 201519, //A5_P
                COM_A6R,              1050, 1480, 10, 10, 2457, 3472, 2464, 3472, 100614, //A6_P
                COM_POSTCARDR,  1000, 1480, 10, 10, 2336, 3472, 2336, 3472, 95406, //POSTCARD_P
                COM_LDR,               2794, 4318, 10, 10, 6576, 10176, 6576, 10176, 784548, //LEDGER_P
                COM_LGR,               2159, 3556, 10, 10, 5081, 8377, 5088, 8384, 500256, //LEGAL_P
                COM_LTR,                2159, 2794, 10, 10, 5081, 6576, 5088, 6576, 392454, //LETTER_P
                COM_STR,               1397, 2159, 10, 10, 3277, 5081, 3280, 5088, 195930, //STATEMENT
                COM_FOLIOR,          2100, 3300, 10, 10, 4938, 7772, 4944, 7776, 450882, //FOILIO_P
                COM_COMPR,           2570, 3556, 10, 10, 6048, 8377, 6048, 8384, 594576, //COMPUTER_P
                COM_LG13R,            2159, 3300, 10, 10, 5081, 7772, 5088, 7776, 464004, //LEGAL13_P_P
                COM_A3WR,             2970, 4200, 0, 0, 7017, 9920, 7024, 9920, 816900,//A3_WIDE_SRA3_450_460_P  
                COM_SRA3_450R,     2970, 4200, 0, 0, 7017, 9920, 7024, 9920, 816900,//A3_WIDE_SRA3_450_460_P  
                COM_SRA3_460R,     2970, 4200, 0, 0, 7017, 9920, 7024, 9920, 816900,//A3_WIDE_SRA3_450_460_P
                COM_LDWR,             2794, 4318, 0, 0, 6601, 10201, 6608, 10208, 790842,//LEDGER_WIDE_RECTANGLE13X19_P  
                COM_13X19R,           2794, 4318, 0, 0, 6601, 10201, 6608, 10208, 790842,//LEDGER_WIDE_RECTANGLE13X19_P
                COM_SQ85R,            2159, 2159, 10, 10, 5081, 5081, 5088, 5088, 303732, //SQUARE8_5_
                COM_8KR,                2700, 3900, 10, 10, 6352, 9193, 6352, 9200, 685185, //SIZE_8K_P
                COM_16KR,             1950, 2700, 10, 10, 4585, 6352, 4592, 6352, 342177 //SIZE_16K_P
            };

            static int SCAN_JPG_600600_AR[] = {
                COM_A3,             4200, 2970, 10, 10, 9898, 6992, 9904, 6992, 811869,
                COM_B4,             3640, 2570, 10, 10, 8575, 6048, 8576, 6048, 608184,
                COM_A4,             2970, 2100, 10, 10, 6992, 4938, 6992, 4944, 405459,
                COM_B5,             2570, 1820, 10, 10, 6048, 4272, 6048, 4272, 303138,
                COM_A5,             2100, 1480, 10, 10, 4938, 3472, 4944, 3472, 201519,
                COM_A6,             1480, 1050, 10, 10, 3472, 2457, 3472, 2464, 100614,
                COM_POSTCARD,       1480, 1000, 10, 10, 3472, 2336, 3472, 2336, 95406,
                COM_LD,             4318, 2794, 10, 10, 10176, 6576, 10176, 6576, 784548,
                COM_LG,             3556, 2159, 10, 10, 8377, 5081, 8384, 5088, 500256,
                COM_LT,             2794, 2159, 10, 10, 6576, 5081, 6576, 5088, 392454,
                COM_ST,             2159, 1397, 10, 10, 5081, 3277, 5088, 3280, 195930,
                COM_FOLIO,          3300, 2100, 10, 10, 7772, 4938, 7776, 4944, 450882,
                COM_COMP,           3556, 2570, 10, 10, 8377, 6048, 8384, 6048, 594576,
                COM_LG13,           3300, 2159, 10, 10, 7772, 5081, 7776, 5088, 464004,
                COM_A3W,            4200, 2970, 0, 0, 9920, 7017, 9920, 7024, 816900, 
                COM_SRA3_450,       4200, 2970, 0, 0, 9920, 7017, 9920, 7024, 816900,  
                COM_SRA3_460,       4200, 2970, 0, 0, 9920, 7017, 9920, 7024, 816900,
                COM_LDW,            4318, 2794, 0, 0, 10201, 6601, 10208, 6608, 790842, 
                COM_13X19,          4318, 2794, 0, 0, 10201, 6601, 10208, 6608, 790842,
                COM_SQ85,           2159, 2159, 10, 10, 5081, 5081, 5088, 5088, 303732,
                COM_8K,             3900, 2700, 10, 10, 9193, 6352, 9200, 6352, 685185,
                COM_16K,            2700, 1950, 10, 10, 6352, 4585, 6352, 4592, 342177
            };

            static int SCAN_MMR_600600_A[] = {
                COM_A3R,          2970, 4200, 10, 10, 6992, 9904, 6992, 9904, 66856,
                COM_B4R,          2570, 3640, 10, 10, 6048, 8576, 6048, 8576, 57892,
                COM_A4R,          2100, 2970, 10, 10, 4944, 6992, 4944, 6992, 37586,
                COM_B5R,          1820, 2570, 10, 10, 4272, 6048, 4272, 6048, 29488,
                COM_A5R,          1480, 2100, 10, 10, 3472, 4944, 3472, 4944, 24724,
                COM_A6R,          1050, 1480, 10, 10, 2464, 3472, 2464, 3472, 14326,
                COM_POSTCARDR,    1000, 1480, 10, 10, 2336, 3472, 2336, 3472, 14326,
                COM_LDR,          2794, 4318, 10, 10, 6576, 10176, 6576, 10176, 68692,
                COM_LGR,          2159, 3556, 10, 10, 5088, 8384, 5088, 8384, 47164,
                COM_LTR,          2159, 2794, 10, 10, 5088, 6576, 5088, 6576, 36994,
                COM_STR,          1397, 2159, 10, 10, 3280, 5088, 3280, 5088, 25444,
                COM_FOLIOR,       2100, 3300, 10, 10, 4944, 7776, 4944, 7776, 41800,
                COM_COMPR,        2570, 3556, 10, 10, 6048, 8384, 6048, 8384, 56596,
                COM_LG13R,        2159, 3300, 10, 10, 5088, 7776, 5088, 7776, 43744,
                COM_A3WR,         2970, 4200, 0, 0, 7024, 9920, 7024, 9920, 69444,
                COM_SRA3_450R,    2970, 4200, 0, 0, 7024, 9920, 7024, 9920, 69444,
                COM_SRA3_460R,    2970, 4200, 0, 0, 7024, 9920, 7024, 9920, 69444,
                COM_LDWR,         2794, 4318, 0, 0, 6608, 10208, 6608, 10208, 66356, 
                COM_13X19R,       2794, 4318, 0, 0, 6608, 10208, 6608, 10208, 66356,
                COM_SQ85R,        2159, 2159, 10, 10, 5088, 5088, 5088, 5088, 28624,
                COM_8KR,          2700, 3900, 10, 10, 6352, 9200, 6352, 9200, 59804,
                COM_16KR,         1950, 2700, 10, 10, 4592, 6352, 4592, 6352, 35734
            };

            static int SCAN_MMR_600600_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 9904, 6992, 9904, 6992, 60310,
                COM_B4,            3640, 2570, 10, 10, 8576, 6048, 8576, 6048, 49900,
                COM_A4,            2970, 2100, 10, 10, 6992, 4944, 6992, 4944, 33376,
                COM_B5,            2570, 1820, 10, 10, 6048, 4272, 6048, 4272, 28840,
                COM_A5,            2100, 1480, 10, 10, 4944, 3472, 4944, 3472, 18666,
                COM_A6,            1480, 1050, 10, 10, 3472, 2464, 3472, 2464, 12324,
                COM_POSTCARD,      1480, 1000, 10, 10, 3472, 2336, 3472, 2336, 11684,
                COM_LD,            4318, 2794, 10, 10, 10176, 6576, 10176, 6576, 56722,
                COM_LG,            3556, 2159, 10, 10, 8384, 5088, 8384, 5088, 41980,
                COM_LT,            2794, 2159, 10, 10, 6576, 5088, 6576, 5088, 34348,
                COM_ST,            2159, 1397, 10, 10, 5088, 3280, 5088, 3280, 18454,
                COM_FOLIO,         3300, 2100, 10, 10, 7776, 4944, 7776, 4944, 38320,
                COM_COMP,          3556, 2570, 10, 10, 8384, 6048, 8384, 6048, 49900,
                COM_LG13,          3300, 2159, 10, 10, 7776, 5088, 7776, 5088, 39436,
                COM_A3W,           4200, 2970, 0, 0, 9920, 7024, 9920, 7024, 60586, 
                COM_SRA3_450,      4200, 2970, 0, 0, 9920, 7024, 9920, 7024, 60586,
                COM_SRA3_460,      4200, 2970, 0, 0, 9920, 7024, 9920, 7024, 60586,
                COM_LDW,           4318, 2794, 0, 0, 10208, 6608, 10208, 6608, 56998, 
                COM_13X19,         4318, 2794, 0, 0, 10208, 6608, 10208, 6608, 56998,
                COM_SQ85,          2159, 2159, 10, 10, 5088, 5088, 5088, 5088, 28624,
                COM_8K,            3900, 2700, 10, 10, 9200, 6352, 9200, 6352, 52408,
                COM_16K,           2700, 1950, 10, 10, 6352, 4592, 6352, 4592, 29852
            };

            static int SCAN_JPG_400400_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 4665, 6601, 4672, 6608, 362148,
                COM_B4R,           2570, 3640, 10, 10, 4032, 5721, 4032, 5728, 271008,
                COM_A4R,           2100, 2970, 10, 10, 3292, 4665, 3296, 4672, 180816,
                COM_B5R,           1820, 2570, 10, 10, 2848, 4032, 2848, 4032, 134928,
                COM_A5R,           1480, 2100, 10, 10, 2315, 3292, 2320, 3296, 89970,
                COM_A6R,           1050, 1480, 10, 10, 1641, 2315, 1648, 2320, 45165,
                COM_POSTCARDR,     1000, 1480, 10, 10, 1561, 2315, 1568, 2320, 42990,
                COM_LDR,           2794, 4318, 10, 10, 4384, 6784, 4384, 6784, 348888,
                COM_LGR,           2159, 3556, 10, 10, 3385, 5584, 3392, 5584, 222324,
                COM_LTR,           2159, 2794, 10, 10, 3385, 4384, 3392, 4384, 174624,
                COM_STR,           1397, 2159, 10, 10, 2185, 3385, 2192, 3392, 87492,
                COM_FOLIOR,        2100, 3300, 10, 10, 3292, 5182, 3296, 5184, 200592,
                COM_COMPR,         2570, 3556, 10, 10, 4032, 5584, 4032, 5584, 264204,
                COM_LG13R,         2159, 3300, 10, 10, 3385, 5182, 3392, 5184, 206424,
                COM_A3WR,          2970, 4200, 0, 0, 4681, 6617, 4688, 6624, 364266, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 4681, 6617, 4688, 6624, 364266, 
                COM_SRA3_460R,     2970, 4200, 0, 0, 4681, 6617, 4688, 6624, 364266,
                COM_LDWR,          2794, 4318, 0, 0, 4400, 6800, 4400, 6800, 350985, 
                COM_13X19R,        2794, 4318, 0, 0, 4400, 6800, 4400, 6800, 350985,
                COM_SQ85R,         2159, 2159, 10, 10, 3385, 3385, 3392, 3392, 135192,
                COM_8KR,           2700, 3900, 10, 10, 4237, 6126, 4240, 6128, 304845,
                COM_16KR,          1950, 2700, 10, 10, 3056, 4237, 3056, 4240, 152205
            };

            static  int SCAN_JPG_400400_AR[] = {   
                COM_A3,            4200, 2970, 10, 10, 6601, 4665, 6608, 4672, 362148,
                COM_B4,            3640, 2570, 10, 10, 5721, 4032, 5728, 4032, 271008,
                COM_A4,            2970, 2100, 10, 10, 4665, 3292, 4672, 3296, 180816,
                COM_B5,            2570, 1820, 10, 10, 4032, 2848, 4032, 2848, 134928,
                COM_A5,            2100, 1480, 10, 10, 3292, 2315, 3296, 2320, 89970,
                COM_A6,            1480, 1050, 10, 10, 2315, 1641, 2320, 1648, 45165,
                COM_POSTCARD,      1480, 1000, 10, 10, 2315, 1561, 2320, 1568, 42990,
                COM_LD,            4318, 2794, 10, 10, 6784, 4384, 6784, 4384, 348888,
                COM_LG,            3556, 2159, 10, 10, 5584, 3385, 5584, 3392, 222324,
                COM_LT,            2794, 2159, 10, 10, 4384, 3385, 4384, 3392, 174624,
                COM_ST,            2159, 1397, 10, 10, 3385, 2185, 3392, 2192, 87492,
                COM_FOLIO,         3300, 2100, 10, 10, 5182, 3292, 5184, 3296, 200592,
                COM_COMP,          3556, 2570, 10, 10, 5584, 4032, 5584, 4032, 264204,
                COM_LG13,          3300, 2159, 10, 10, 5182, 3385, 5184, 3392, 206424,
                COM_A3W,           4200, 2970, 0, 0, 6617, 4681, 6624, 4688, 364266, 
                COM_SRA3_450,      4200, 2970, 0, 0, 6617, 4681, 6624, 4688, 364266,
                COM_SRA3_460,      4200, 2970, 0, 0, 6617, 4681, 6624, 4688, 364266,
                COM_LDW,           4318, 2794, 0, 0, 6800, 4400, 6800, 4400, 350985, 
                COM_13X19,         4318, 2794, 0, 0, 6800, 4400, 6800, 4400, 350985,
                COM_SQ85,          2159, 2159, 10, 10, 3385, 3385, 3392, 3392, 135192,
                COM_8K,            3900, 2700, 10, 10, 6126, 4237, 6128, 4240, 304845,
                COM_16K,           2700, 1950, 10, 10, 4237, 3056, 4240, 3056, 152205
            };

            static int SCAN_MMR_400400_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 4672, 6608, 4672, 6608, 37174,
                COM_B4R,           2570, 3640, 10, 10, 4032, 5728, 4032, 5728, 30076,
                COM_A4R,           2100, 2970, 10, 10, 3296, 4672, 3296, 4672, 24532,
                COM_B5R,           1820, 2570, 10, 10, 2848, 4032, 2848, 4032, 20164,
                COM_A5R,           1480, 2100, 10, 10, 2320, 3296, 2320, 3296, 12776,
                COM_A6R,           1050, 1480, 10, 10, 1648, 2320, 1648, 2320, 8704,
                COM_POSTCARDR,     1000, 1480, 10, 10, 1568, 2320, 1568, 2320, 8704,
                COM_LDR,           2794, 4318, 10, 10, 4384, 6784, 4384, 6784, 37316,
                COM_LGR,           2159, 3556, 10, 10, 3392, 5584, 3392, 5584, 29320,
                COM_LTR,           2159, 2794, 10, 10, 3392, 4384, 3392, 4384, 23020,
                COM_STR,           1397, 2159, 10, 10, 2192, 3392, 2192, 3392, 13148,
                COM_FOLIOR,        2100, 3300, 10, 10, 3296, 5184, 3296, 5184, 27220,
                COM_COMPR,         2570, 3556, 10, 10, 4032, 5584, 4032, 5584, 29320,
                COM_LG13R,         2159, 3300, 10, 10, 3392, 5184, 3392, 5184, 27220,
                COM_A3WR,          2970, 4200, 0, 0, 4688, 6624, 4688, 6624, 35608, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 4688, 6624, 4688, 6624, 35608, 
                COM_SRA3_460R,     2970, 4200, 0, 0, 4688, 6624, 4688, 6624, 35608,
                COM_LDWR,          2794, 4318, 0, 0, 4400, 6800, 4400, 6800, 37404, 
                COM_13X19R,        2794, 4318, 0, 0, 4400, 6800, 4400, 6800, 37404,
                COM_SQ85R,         2159, 2159, 10, 10, 3392, 3392, 3392, 3392, 17812,
                COM_8KR,           2700, 3900, 10, 10, 4240, 6128, 4240, 6128, 28346,
                COM_16KR,          1950, 2700, 10, 10, 3056, 4240, 3056, 4240, 21734
            };

            static int SCAN_MMR_400400_AR[] = { 
                COM_A3,            4200, 2970, 10, 10, 6608, 4672, 6608, 4672, 30372,
                COM_B4,            3640, 2570, 10, 10, 5728, 4032, 5728, 4032, 26716,
                COM_A4,            2970, 2100, 10, 10, 4672, 3296, 4672, 3296, 18544,
                COM_B5,            2570, 1820, 10, 10, 4032, 2848, 4032, 2848, 14956,
                COM_A5,            2100, 1480, 10, 10, 3296, 2320, 3296, 2320, 12184,
                COM_A6,            1480, 1050, 10, 10, 2320, 1648, 2320, 1648, 6390,
                COM_POSTCARD,      1480, 1000, 10, 10, 2320, 1568, 2320, 1568, 6080,
                COM_LD,            4318, 2794, 10, 10, 6784, 4384, 6784, 4384, 27952,
                COM_LG,            3556, 2159, 10, 10, 5584, 3392, 5584, 3392, 21628,
                COM_LT,            2794, 2159, 10, 10, 4384, 3392, 4384, 3392, 18660,
                COM_ST,            2159, 1397, 10, 10, 3392, 2192, 3392, 2192, 11512,
                COM_FOLIO,         3300, 2100, 10, 10, 5184, 3296, 5184, 3296, 20604,
                COM_COMP,          3556, 2570, 10, 10, 5584, 4032, 5584, 4032, 25708,
                COM_LG13,          3300, 2159, 10, 10, 5184, 3392, 5184, 3392, 21204,
                COM_A3W,           4200, 2970, 0, 0, 6624, 4688, 6624, 4688, 31648,
                COM_SRA3_450,      4200, 2970, 0, 0, 6624, 4688, 6624, 4688, 31648, 
                COM_SRA3_460,      4200, 2970, 0, 0, 6624, 4688, 6624, 4688, 31648,
                COM_LDW,           4318, 2794, 0, 0, 6800, 4400, 6800, 4400, 26954, 
                COM_13X19,         4318, 2794, 0, 0, 6800, 4400, 6800, 4400, 26954,
                COM_SQ85,          2159, 2159, 10, 10, 3392, 3392, 3392, 3392, 17812,
                COM_8K,            3900, 2700, 10, 10, 6128, 4240, 6128, 4240, 28624,
                COM_16K,           2700, 1950, 10, 10, 4240, 3056, 4240, 3056, 14138
            };

            static int SCAN_JPG_300300_A[] = {  
                COM_A3R,           2970, 4200, 10, 10, 3497, 4953, 3504, 4960, 204030,
                COM_B4R,           2570, 3640, 10, 10, 3024, 4288, 3024, 4288, 152316,
                COM_A4R,           2100, 2970, 10, 10, 2473, 3497, 2480, 3504, 102195,
                COM_B5R,           1820, 2570, 10, 10, 2138, 3024, 2144, 3024, 76338,
                COM_A5R,           1480, 2100, 10, 10, 1737, 2473, 1744, 2480, 51045,
                COM_A6R,           1050, 1480, 10, 10, 1229, 1737, 1232, 1744, 25539,
                COM_POSTCARDR,     1000, 1480, 10, 10, 1168, 1737, 1168, 1744, 24231,
                COM_LDR,           2794, 4318, 10, 10, 3289, 5088, 3296, 5088, 196884,
                COM_LGR,           2159, 3556, 10, 10, 2539, 4189, 2544, 4192, 125334,
                COM_LTR,           2159, 2794, 10, 10, 2539, 3289, 2544, 3296, 98622,
                COM_STR,           1397, 2159, 10, 10, 1641, 2539, 1648, 2544, 49491,
                COM_FOLIOR,        2100, 3300, 10, 10, 2473, 3886, 2480, 3888, 113355,
                COM_COMPR,         2570, 3556, 10, 10, 3024, 4189, 3024, 4192, 148914,
                COM_LG13R,         2159, 3300, 10, 10, 2539, 3886, 2544, 3888, 116271,
                COM_A3WR,          2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 204030, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 204030, 
                COM_SRA3_460R,     2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 204030,
                COM_LDWR,          2794, 4318, 0, 0, 3296, 5100, 3296, 5104, 197502, 
                COM_13X19R,        2794, 4318, 0, 0, 3296, 5100, 3296, 5104, 197502,
                COM_SQ85R,         2159, 2159, 10, 10, 2539, 2539, 2544, 2544, 76203,
                COM_8KR,           2700, 3900, 10, 10, 3178, 4592, 3184, 4592, 171699,
                COM_16KR,          1950, 2700, 10, 10, 2288, 3178, 2288, 3184, 85731
            };

            static int SCAN_JPG_300300_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 4953, 3497, 4960, 3504, 204030,
                COM_B4,            3640, 2570, 10, 10, 4288, 3024, 4288, 3024, 152316,
                COM_A4,            2970, 2100, 10, 10, 3497, 2473, 3504, 2480, 102195,
                COM_B5,            2570, 1820, 10, 10, 3024, 2138, 3024, 2144, 76338,
                COM_A5,            2100, 1480, 10, 10, 2473, 1737, 2480, 1744, 51045,
                COM_A6,            1480, 1050, 10, 10, 1737, 1229, 1744, 1232, 25539,
                COM_POSTCARD,      1480, 1000, 10, 10, 1737, 1168, 1744, 1168, 24231,
                COM_LD,            4318, 2794, 10, 10, 5088, 3289, 5088, 3296, 196884,
                COM_LG,            3556, 2159, 10, 10, 4189, 2539, 4192, 2544, 125334,
                COM_LT,            2794, 2159, 10, 10, 3289, 2539, 3296, 2544, 98622,
                COM_ST,            2159, 1397, 10, 10, 2539, 1641, 2544, 1648, 49491,
                COM_FOLIO,         3300, 2100, 10, 10, 3886, 2473, 3888, 2480, 113355,
                COM_COMP,          3556, 2570, 10, 10, 4189, 3024, 4192, 3024, 148914,
                COM_LG13,          3300, 2159, 10, 10, 3886, 2539, 3888, 2544, 116271,
                COM_A3W,           4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 204030, 
                COM_SRA3_450,      4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 204030, 
                COM_SRA3_460,      4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 204030,
                COM_LDW,           4318, 2794, 0, 0, 5100, 3296, 5104, 3296, 197502, 
                COM_13X19,         4318, 2794, 0, 0, 5100, 3296, 5104, 3296, 197502,
                COM_SQ85,          2159, 2159, 10, 10, 2539, 2539, 2544, 2544, 76203,
                COM_8K,            3900, 2700, 10, 10, 4592, 3178, 4592, 3184, 171699,
                COM_16K,           2700, 1950, 10, 10, 3178, 2288, 3184, 2288, 85731
            };

            static int SCAN_MMR_300300_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 3504, 4960, 3504, 4960, 26044,
                COM_B4R,           2570, 3640, 10, 10, 3024, 4288, 3024, 4288, 20908,
                COM_A4R,           2100, 2970, 10, 10, 2480, 3504, 2480, 3504, 14458,
                COM_B5R,           1820, 2570, 10, 10, 2144, 3024, 2144, 3024, 12478,
                COM_A5R,           1480, 2100, 10, 10, 1744, 2480, 1744, 2480, 8684,
                COM_A6R,           1050, 1480, 10, 10, 1232, 1744, 1232, 1744, 6108,
                COM_POSTCARDR,     1000, 1480, 10, 10, 1168, 1744, 1168, 1744, 6108,
                COM_LDR,           2794, 4318, 10, 10, 3296, 5088, 3296, 5088, 26716,
                COM_LGR,           2159, 3556, 10, 10, 2544, 4192, 2544, 4192, 17296,
                COM_LTR,           2159, 2794, 10, 10, 2544, 3296, 2544, 3296, 13600,
                COM_STR,           1397, 2159, 10, 10, 1648, 2544, 1648, 2544, 9544,
                COM_FOLIOR,        2100, 3300, 10, 10, 2480, 3888, 2480, 3888, 16042,
                COM_COMPR,         2570, 3556, 10, 10, 3024, 4192, 3024, 4192, 20440,
                COM_LG13R,         2159, 3300, 10, 10, 2544, 3888, 2544, 3888, 16042,
                COM_A3WR,          2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 26044, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 26044,
                COM_SRA3_460R,     2970, 4200, 0, 0, 3504, 4960, 3504, 4960, 26044,
                COM_LDWR,          2794, 4318, 0, 0, 3296, 5104, 3296, 5104, 26800, 
                COM_13X19R,        2794, 4318, 0, 0, 3296, 5104, 3296, 5104, 26800,
                COM_SQ85R,         2159, 2159, 10, 10, 2544, 2544, 2544, 2544, 10498,
                COM_8KR,           2700, 3900, 10, 10, 3184, 4592, 3184, 4592, 23538,
                COM_16KR,          1950, 2700, 10, 10, 2288, 3184, 2288, 3184, 13138
            };


            static int SCAN_MMR_300300_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 4960, 3504, 4960, 3504, 19714,
                COM_B4,            3640, 2570, 10, 10, 4288, 3024, 4288, 3024, 15880,
                COM_A4,            2970, 2100, 10, 10, 3504, 2480, 3504, 2480, 13024,
                COM_B5,            2570, 1820, 10, 10, 3024, 2144, 3024, 2144, 10456,
                COM_A5,            2100, 1480, 10, 10, 2480, 1744, 2480, 1744, 7198,
                COM_A6,            1480, 1050, 10, 10, 1744, 1232, 1744, 1232, 4316,
                COM_POSTCARD,      1480, 1000, 10, 10, 1744, 1168, 1744, 1168, 4092,
                COM_LD,            4318, 2794, 10, 10, 5088, 3296, 5088, 3296, 18544,
                COM_LG,            3556, 2159, 10, 10, 4192, 2544, 4192, 2544, 13360,
                COM_LT,            2794, 2159, 10, 10, 3296, 2544, 3296, 2544, 13360,
                COM_ST,            2159, 1397, 10, 10, 2544, 1648, 2544, 1648, 6802,
                COM_FOLIO,         3300, 2100, 10, 10, 3888, 2480, 3888, 2480, 13024,
                COM_COMP,          3556, 2570, 10, 10, 4192, 3024, 4192, 3024, 15880,
                COM_LG13,          3300, 2159, 10, 10, 3888, 2544, 3888, 2544, 13360,
                COM_A3W,           4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 19714, 
                COM_SRA3_450,      4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 19714, 
                COM_SRA3_460,      4200, 2970, 0, 0, 4960, 3504, 4960, 3504, 19714,
                COM_LDW,           4318, 2794, 0, 0, 5104, 3296, 5104, 3296, 18544, 
                COM_13X19,         4318, 2794, 0, 0, 5104, 3296, 5104, 3296, 18544,   
                COM_SQ85,          2159, 2159, 10, 10, 2544, 2544, 2544, 2544, 10498,
                COM_8K,            3900, 2700, 10, 10, 4592, 3184, 4592, 3184, 17914,
                COM_16K,           2700, 1950, 10, 10, 3184, 2288, 3184, 2288, 11730
            };


            static int SCAN_JPG_200200_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 2331, 3296, 2336, 3296, 90588,
                COM_B4R,           2570, 3640, 10, 10, 2016, 2859, 2016, 2864, 68022,
                COM_A4R,           2100, 2970, 10, 10, 1646, 2331, 1648, 2336, 45474,
                COM_B5R,           1820, 2570, 10, 10, 1424, 2016, 1424, 2016, 34002,
                COM_A5R,           1480, 2100, 10, 10, 1161, 1646, 1168, 1648, 22917,
                COM_A6R,           1050, 1480, 10, 10, 816, 1161, 816, 1168, 11529,
                COM_POSTCARDR,     1000, 1480, 10, 10, 780, 1161, 784, 1168, 11091,
                COM_LDR,           2794, 4318, 10, 10, 2192, 3392, 2192, 3392, 87492,
                COM_LGR,           2159, 3556, 10, 10, 1693, 2793, 1696, 2800, 56010,
                COM_LTR,           2159, 2794, 10, 10, 1693, 2192, 1696, 2192, 43926,
                COM_STR,           1397, 2159, 10, 10, 1097, 1693, 1104, 1696, 22302,
                COM_FOLIOR,        2100, 3300, 10, 10, 1646, 2591, 1648, 2592, 50418,
                COM_COMPR,         2570, 3556, 10, 10, 2016, 2793, 2016, 2800, 66510,
                COM_LG13R,         2159, 3300, 10, 10, 1693, 2591, 1696, 2592, 51876,
                COM_A3WR,          2970, 4200, 0, 0, 2336, 3308, 2336, 3312, 91026, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 2336, 3308, 2336, 3312, 91026, 
                COM_SRA3_460R,     2970, 4200, 0, 0, 2336, 3308, 2336, 3312, 91026,
                COM_LDWR,          2794, 4318, 0, 0, 2201, 3401, 2208, 3408, 88542, 
                COM_13X19R,        2794, 4318, 0, 0, 2201, 3401, 2208, 3408, 88542,
                COM_SQ85R,         2159, 2159, 10, 10, 1693, 1693, 1696, 1696, 34068,
                COM_8KR,           2700, 3900, 10, 10, 2121, 3065, 2128, 3072, 76968,
                COM_16KR,          1950, 2700, 10, 10, 1529, 2121, 1536, 2128, 38664
            };

            static int SCAN_JPG_200200_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 3296, 2331, 3296, 2336, 90588,
                COM_B4,            3640, 2570, 10, 10, 2859, 2016, 2864, 2016, 68022,
                COM_A4,            2970, 2100, 10, 10, 2331, 1646, 2336, 1648, 45474,
                COM_B5,            2570, 1820, 10, 10, 2016, 1424, 2016, 1424, 34002,
                COM_A5,            2100, 1480, 10, 10, 1646, 1161, 1648, 1168, 22917,
                COM_A6,            1480, 1050, 10, 10, 1161, 816, 1168, 816, 11529,
                COM_POSTCARD,      1480, 1000, 10, 10, 1161, 780, 1168, 784, 11091,
                COM_LD,            4318, 2794, 10, 10, 3392, 2192, 3392, 2192, 87492,
                COM_LG,            3556, 2159, 10, 10, 2793, 1693, 2800, 1696, 56010,
                COM_LT,            2794, 2159, 10, 10, 2192, 1693, 2192, 1696, 43926,
                COM_ST,            2159, 1397, 10, 10, 1693, 1097, 1696, 1104, 22302,
                COM_FOLIO,         3300, 2100, 10, 10, 2591, 1646, 2592, 1648, 50418,
                COM_COMP,          3556, 2570, 10, 10, 2793, 2016, 2800, 2016, 66510,
                COM_LG13,          3300, 2159, 10, 10, 2591, 1693, 2592, 1696, 51876,
                COM_A3W,           4200, 2970, 0, 0, 3308, 2336, 3312, 2336, 91026, 
                COM_SRA3_450,      4200, 2970, 0, 0, 3308, 2336, 3312, 2336, 91026, 
                COM_SRA3_460,      4200, 2970, 0, 0, 3308, 2336, 3312, 2336, 91026,
                COM_LDW,           4318, 2794, 0, 0, 3401, 2201, 3408, 2208, 88542,
                COM_13X19,         4318, 2794, 0, 0, 3401, 2201, 3408, 2208, 88542,
                COM_SQ85,          2159, 2159, 10, 10, 1693, 1693, 1696, 1696, 34068,
                COM_8K,            3900, 2700, 10, 10, 3065, 2121, 3072, 2128, 76968,
                COM_16K,           2700, 1950, 10, 10, 2121, 1529, 2128, 1536, 38664
            };

            static int SCAN_MMR_200200_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 2336, 3296, 2336, 3296, 13600,
                COM_B4R,           2570, 3640, 10, 10, 2016, 2864, 2016, 2864, 11818,
                COM_A4R,           2100, 2970, 10, 10, 1648, 2336, 1648, 2336, 8764,
                COM_B5R,           1820, 2570, 10, 10, 1424, 2016, 1424, 2016, 7060,
                COM_A5R,           1480, 2100, 10, 10, 1168, 1648, 1168, 1648, 5772,
                COM_A6R,           1050, 1480, 10, 10, 816, 1168, 816, 1168, 4384,
                COM_POSTCARDR,     1000, 1480, 10, 10, 784, 1168, 784, 1168, 4092,
                COM_LDR,           2794, 4318, 10, 10, 2192, 3392, 2192, 3392, 13148,
                COM_LGR,           2159, 3556, 10, 10, 1696, 2800, 1696, 2800, 9454,
                COM_LTR,           2159, 2794, 10, 10, 1696, 2192, 1696, 2192, 7402,
                COM_STR,           1397, 2159, 10, 10, 1104, 1696, 1104, 1696, 5940,
                COM_FOLIOR,        2100, 3300, 10, 10, 1648, 2592, 1648, 2592, 9724,
                COM_COMPR,         2570, 3556, 10, 10, 2016, 2800, 2016, 2800, 11554,
                COM_LG13R,         2159, 3300, 10, 10, 1696, 2592, 1696, 2592, 8752,
                COM_A3WR,          2970, 4200, 0, 0, 2336, 3312, 2336, 3312, 13666, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 2336, 3312, 2336, 3312, 13666,  
                COM_SRA3_460R,     2970, 4200, 0, 0, 2336, 3312, 2336, 3312, 13666,
                COM_LDWR,          2794, 4318, 0, 0, 2208, 3408, 2208, 3408, 14062, 
                COM_13X19R,        2794, 4318, 0, 0, 2208, 3408, 2208, 3408, 14062,
                COM_SQ85R,         2159, 2159, 10, 10, 1696, 1696, 1696, 1696, 5728,
                COM_8KR,           2700, 3900, 10, 10, 2128, 3072, 2128, 3072, 11908,
                COM_16KR,          1950, 2700, 10, 10, 1536, 2128, 1536, 2128, 7984
            };

            static int SCAN_MMR_200200_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 3296, 2336, 3296, 2336, 12268,
                COM_B4,            3640, 2570, 10, 10, 2864, 2016, 2864, 2016, 10084,
                COM_A4,            2970, 2100, 10, 10, 2336, 1648, 2336, 1648, 6802,
                COM_B5,            2570, 1820, 10, 10, 2016, 1424, 2016, 1424, 5878,
                COM_A5,            2100, 1480, 10, 10, 1648, 1168, 1648, 1168, 4384,
                COM_A6,            1480, 1050, 10, 10, 1168, 816, 1168, 816, 2860,
                COM_POSTCARD,      1480, 1000, 10, 10, 1168, 784, 1168, 784, 2748,
                COM_LD,            4318, 2794, 10, 10, 3392, 2192, 3392, 2192, 11512,
                COM_LG,            3556, 2159, 10, 10, 2800, 1696, 2800, 1696, 8272,
                COM_LT,            2794, 2159, 10, 10, 2192, 1696, 2192, 1696, 6576,
                COM_ST,            2159, 1397, 10, 10, 1696, 1104, 1696, 1104, 3730,
                COM_FOLIO,         3300, 2100, 10, 10, 2592, 1648, 2592, 1648, 6802,
                COM_COMP,          3556, 2570, 10, 10, 2800, 2016, 2800, 2016, 9832,
                COM_LG13,          3300, 2159, 10, 10, 2592, 1696, 2592, 1696, 7000,
                COM_A3W,           4200, 2970, 0, 0, 3312, 2336, 3312, 2336, 12268, 
                COM_SRA3_450,      4200, 2970, 0, 0, 3312, 2336, 3312, 2336, 12268, 
                COM_SRA3_460,      4200, 2970, 0, 0, 3312, 2336, 3312, 2336, 12268,
                COM_LDW,           4318, 2794, 0, 0, 3408, 2208, 3408, 2208, 11044, 
                COM_13X19,         4318, 2794, 0, 0, 3408, 2208, 3408, 2208, 11044,
                COM_SQ85,          2159, 2159, 10, 10, 1696, 1696, 1696, 1696, 5728,
                COM_8K,            3900, 2700, 10, 10, 3072, 2128, 3072, 2128, 10910,
                COM_16K,           2700, 1950, 10, 10, 2128, 1536, 2128, 1536, 5956
            };

            static int SCAN_JPG_150150_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 1753, 2475, 1760, 2480, 51510,
                COM_B4R,           2570, 3640, 10, 10, 1513, 2144, 1520, 2144, 38550,
                COM_A4R,           2100, 2970, 10, 10, 1232, 1753, 1232, 1760, 25770,
                COM_B5R,           1820, 2570, 10, 10, 1069, 1513, 1072, 1520, 19455,
                COM_A5R,           1480, 2100, 10, 10, 873, 1232, 880, 1232, 13065,
                COM_A6R,           1050, 1480, 10, 10, 617, 873, 624, 880, 6795,
                COM_POSTCARDR,     1000, 1480, 10, 10, 585, 873, 592, 880, 6465,
                COM_LDR,           2794, 4318, 10, 10, 1645, 2544, 1648, 2544, 49491,
                COM_LGR,           2159, 3556, 10, 10, 1273, 2095, 1280, 2096, 31800,
                COM_LTR,           2159, 2794, 10, 10, 1273, 1645, 1280, 1648, 25080,
                COM_STR,           1397, 2159, 10, 10, 816, 1273, 816, 1280, 12600,
                COM_FOLIOR,        2100, 3300, 10, 10, 1232, 1945, 1232, 1952, 28542,
                COM_COMPR,         2570, 3556, 10, 10, 1513, 2095, 1520, 2096, 37695,
                COM_LG13R,         2159, 3300, 10, 10, 1273, 1945, 1280, 1952, 29640,
                COM_A3WR,          2970, 4200, 0, 0, 1754, 2480, 1760, 2480, 51510, 
                COM_SRA3_450R,     2970, 4200, 0, 0, 1754, 2480, 1760, 2480, 51510, 
                COM_SRA3_460R,     2970, 4200, 0, 0, 1754, 2480, 1760, 2480, 51510,
                COM_LDWR,          2794, 4318, 0, 0, 1648, 2553, 1648, 2560, 49800, 
                COM_13X19R,        2794, 4318, 0, 0, 1648, 2553, 1648, 2560, 49800,
                COM_SQ85R,         2159, 2159, 10, 10, 1273, 1273, 1280, 1280, 19560,
                COM_8KR,           2700, 3900, 10, 10, 1593, 2298, 1600, 2304, 43560,
                COM_16KR,          1950, 2700, 10, 10, 1146, 1593, 1152, 1600, 21960
            };

            static int SCAN_JPG_150150_AR[] = {
                COM_A3,            4200, 2970, 10, 10, 2475, 1753, 2480, 1760, 51510,
                COM_B4,            3640, 2570, 10, 10, 2144, 1513, 2144, 1520, 38550,
                COM_A4,            2970, 2100, 10, 10, 1753, 1232, 1760, 1232, 25770,
                COM_B5,            2570, 1820, 10, 10, 1513, 1069, 1520, 1072, 19455,
                COM_A5,            2100, 1480, 10, 10, 1232, 873, 1232, 880, 13065,
                COM_A6,            1480, 1050, 10, 10, 873, 617, 880, 624, 6795,
                COM_POSTCARD,      1480, 1000, 10, 10, 873, 585, 880, 592, 6465,
                COM_LD,            4318, 2794, 10, 10, 2544, 1645, 2544, 1648, 49491,
                COM_LG,            3556, 2159, 10, 10, 2095, 1273, 2096, 1280, 31800,
                COM_LT,            2794, 2159, 10, 10, 1645, 1273, 1648, 1280, 25080,
                COM_ST,            2159, 1397, 10, 10, 1273, 816, 1280, 816, 12600,
                COM_FOLIO,         3300, 2100, 10, 10, 1945, 1232, 1952, 1232, 28542,
                COM_COMP,          3556, 2570, 10, 10, 2095, 1513, 2096, 1520, 37695,
                COM_LG13,          3300, 2159, 10, 10, 1945, 1273, 1952, 1280, 29640,
                COM_A3W,           4200, 2970, 0, 0, 2480, 1754, 2480, 1760, 51510, 
                COM_SRA3_450,      4200, 2970, 0, 0, 2480, 1754, 2480, 1760, 51510, 
                COM_SRA3_460,      4200, 2970, 0, 0, 2480, 1754, 2480, 1760, 51510,
                COM_LDW,           4318, 2794, 0, 0, 2553, 1648, 2560, 1648, 49800, 
                COM_13X19,         4318, 2794, 0, 0, 2553, 1648, 2560, 1648, 49800,
                COM_SQ85,          2159, 2159, 10, 10, 1273, 1273, 1280, 1280, 19560,
                COM_8K,            3900, 2700, 10, 10, 2298, 1593, 2304, 1600, 43560,
                COM_16K,           2700, 1950, 10, 10, 1593, 1146, 1600, 1152, 21960
            };

            static int SCAN_MMR_150150_A[] = {
                COM_A3,        2970, 4200, 10, 10, 1760, 2480, 1760, 2480, 9304,
                COM_B4,        2570, 3640, 10, 10, 1520, 2144, 1520, 2144, 8044,
                COM_A4,        2100, 2970, 10, 10, 1232, 1760, 1232, 1760, 6164,
                COM_B5,        1820, 2570, 10, 10, 1072, 1520, 1072, 1520, 5704,
                COM_A5,        1480, 2100, 10, 10, 880, 1232, 880, 1232, 4624,
                COM_A6,        1050, 1480, 10, 10, 624, 880, 624, 880, 3194,
                COM_POSTCARD,  1000, 1480, 10, 10, 592, 880, 592, 880, 2974,
                COM_LD,        2794, 4318, 10, 10, 1648, 2544, 1648, 2544, 9544,
                COM_LG,        2159, 3556, 10, 10, 1280, 2096, 1280, 2096, 7864,
                COM_LT,        2159, 2794, 10, 10, 1280, 1648, 1280, 1648, 6184,
                COM_ST,        1397, 2159, 10, 10, 816, 1280, 816, 1280, 4804,
                COM_FOLIO,     2100, 3300, 10, 10, 1232, 1952, 1232, 1952, 6836,
                COM_COMP,      2570, 3556, 10, 10, 1520, 2096, 1520, 2096, 7864,
                COM_LG13,      2159, 3300, 10, 10, 1280, 1952, 1280, 1952, 7324,
                COM_A3W,       2970, 4200, 0, 0, 1760, 2480, 1760, 2480, 9304,
                COM_SRA3_450,  2970, 4200, 0, 0, 1760, 2480, 1760, 2480, 9304,
                COM_SRA3_460,  2970, 4200, 0, 0, 1760, 2480, 1760, 2480, 9304,
                COM_LDW,       2794, 4318, 0, 0, 1648, 2560, 1648, 2560, 9604,
                COM_13X19,     2794, 4318, 0, 0, 1648, 2560, 1648, 2560, 9604,
                COM_SQ85,      2159, 2159, 10, 10, 1280, 1280, 1280, 1280, 4804,
                COM_8K,        2700, 3900, 10, 10, 1600, 2304, 1600, 2304, 8644,
                COM_16K,       1950, 2700, 10, 10, 1152, 1600, 1152, 1600, 6004
            };

            static int SCAN_MMR_150150_AR[] = {
                COM_A3,           4200, 2970, 10, 10, 2480, 1760, 2480, 1760, 7264,
                COM_B4,           3640, 2570, 10, 10, 2144, 1520, 2144, 1520, 6274,
                COM_A4,           2970, 2100, 10, 10, 1760, 1232, 1760, 1232, 4624,
                COM_B5,           2570, 1820, 10, 10, 1520, 1072, 1520, 1072, 4024,
                COM_A5,           2100, 1480, 10, 10, 1232, 880, 1232, 880, 3084,
                COM_A6,           1480, 1050, 10, 10, 880, 624, 880, 624, 2344,
                COM_POSTCARD,     1480, 1000, 10, 10, 880, 592, 880, 592, 2224,
                COM_LD,           4318, 2794, 10, 10, 2544, 1648, 2544, 1648, 6802,
                COM_LG,           3556, 2159, 10, 10, 2096, 1280, 2096, 1280, 5284,
                COM_LT,           2794, 2159, 10, 10, 1648, 1280, 1648, 1280, 4804,
                COM_ST,           2159, 1397, 10, 10, 1280, 816, 1280, 816, 3064,
                COM_FOLIO,        3300, 2100, 10, 10, 1952, 1232, 1952, 1232, 4932,
                COM_COMP,         3556, 2570, 10, 10, 2096, 1520, 2096, 1520, 6274,
                COM_LG13,         3300, 2159, 10, 10, 1952, 1280, 1952, 1280, 5124,
                COM_A3W,          4200, 2970, 0, 0, 2480, 1760, 2480, 1760, 7264,
                COM_SRA3_450,     4200, 2970, 0, 0, 2480, 1760, 2480, 1760, 7264,
                COM_SRA3_460,     4200, 2970, 0, 0, 2480, 1760, 2480, 1760, 7264,
                COM_LDW,          4318, 2794, 0, 0, 2560, 1648, 2560, 1648, 6802,
                COM_13X19,        4318, 2794, 0, 0, 2560, 1648, 2560, 1648, 6802,
                COM_SQ85,         2159, 2159, 10, 10, 1280, 1280, 1280, 1280, 4804,
                COM_8K,           3900, 2700, 10, 10, 2304, 1600, 2304, 1600, 6604,
                COM_16K,          2700, 1950, 10, 10, 1600, 1152, 1600, 1152, 4324,
            };

            static int SCAN_JPG_100100_A[] = {
                COM_A3R,           2970, 4200, 10, 10, 1166, 1648, 1168, 1648, 22917,                     
                COM_B4R,           2570, 3640, 10, 10, 1008, 1433, 1008, 1440, 17370,
                COM_A4R,           2100, 2970, 10, 10, 825, 1166, 832, 1168, 11748,
                COM_B5R,           1820, 2570, 10, 10, 713, 1008, 720, 1008, 8865,
                COM_A5R,           1480, 2100, 10, 10, 576, 825, 576, 832, 5976,
                COM_A6R,           1050, 1480, 10, 10, 410, 576, 416, 576, 3168,
                COM_POSTCARDR,     1000, 1480, 10, 10, 393, 576, 400, 576, 3060,
                COM_LDR,           2794, 4318, 10, 10, 1097, 1696, 1104, 1696, 22302,
                COM_LGR,           2159, 3556, 10, 10, 847, 1401, 848, 1408, 14352,
                COM_LTR,           2159, 2794, 10, 10, 847, 1097, 848, 1104, 11331,
                COM_STR,           1397, 2159, 10, 10, 544, 847, 544, 848, 5766,
                COM_FOLIOR,        2100, 3300, 10, 10, 825, 1296, 832, 1296, 12996,
                COM_COMPR,         2570, 3556, 10, 10, 1008, 1401, 1008, 1408, 16992,
                COM_LG13R,         2159, 3300, 10, 10, 847, 1296, 848, 1296, 13239,
                COM_A3WR,          2970, 4200, 0, 0, 1168, 1657, 1168, 1664, 23136,
                COM_SRA3_450R,     2970, 4200, 0, 0, 1168, 1657, 1168, 1664, 23136,
                COM_SRA3_460R,     2970, 4200, 0, 0, 1168, 1657, 1168, 1664, 23136,
                COM_LDWR,          2794, 4318, 0, 0, 1100, 1696, 1104, 1696, 22302,
                COM_13X19R,        2794, 4318, 0, 0, 1100, 1696, 1104, 1696, 22302,
                COM_SQ85R,         2159, 2159, 10, 10, 847, 847, 848, 848, 8787,
                COM_8KR,           2700, 3900, 10, 10, 1056, 1532, 1056, 1536, 19368,
                COM_16KR,          1950, 2700, 10, 10, 764, 1056, 768, 1056, 9864  
            };

            static int SCAN_JPG_100100_AR[] = {
                COM_A3,           4200, 2970, 10, 10, 1648, 1166, 1648, 1168, 22917, 
                COM_B4,           3640, 2570, 10, 10, 1433, 1008, 1440, 1008, 17370,
                COM_A4,           2970, 2100, 10, 10, 1166, 825, 1168, 832, 11748,
                COM_B5,           2570, 1820, 10, 10, 1008, 713, 1008, 720, 8865,
                COM_A5,           2100, 1480, 10, 10, 825, 576, 832, 576, 5976,
                COM_A6,           1480, 1050, 10, 10, 576, 410, 576, 416, 3168,
                COM_POSTCARD,     1480, 1000, 10, 10, 576, 393, 576, 400, 3060,
                COM_LD,           4318, 2794, 10, 10, 1696, 1097, 1696, 1104, 22302,
                COM_LG,           3556, 2159, 10, 10, 1401, 847, 1408, 848, 14352,
                COM_LT,           2794, 2159, 10, 10, 1097, 847, 1104, 848, 11331,
                COM_ST,           2159, 1397, 10, 10, 847, 544, 848, 544, 5766,
                COM_FOLIO,        3300, 2100, 10, 10, 1296, 825, 1296, 832, 12996,
                COM_COMP,         3556, 2570, 10, 10, 1401, 1008, 1408, 1008, 16992,
                COM_LG13,         3300, 2159, 10, 10, 1296, 847, 1296, 848, 13239,
                COM_A3W,          4200, 2970, 0, 0, 1657, 1168, 1664, 1168, 23136,
                COM_SRA3_450,     4200, 2970, 0, 0, 1657, 1168, 1664, 1168, 23136,
                COM_SRA3_460,     4200, 2970, 0, 0, 1657, 1168, 1664, 1168, 23136,
                COM_LDW,          4318, 2794, 0, 0, 1696, 1100, 1696, 1104, 22302,
                COM_13X19,        4318, 2794, 0, 0, 1696, 1100, 1696, 1104, 22302,
                COM_SQ85,         2159, 2159, 10, 10, 847, 847, 848, 848, 8787,
                COM_8K,           3900, 2700, 10, 10, 1532, 1056, 1536, 1056, 19368,
                COM_16K,          2700, 1950, 10, 10, 1056, 764, 1056, 768, 9864
            };

            static int SCAN_MMR_100100_A[] = {
                COM_A3R,          2970, 4200, 10, 10, 1168, 1648, 1168, 1648, 5772,
                COM_B4R,          2570, 3640, 10, 10, 1008, 1440, 1008, 1440, 5404,
                COM_A4R,          2100, 2970, 10, 10, 832, 1168, 832, 1168, 4384,
                COM_B5R,          1820, 2570, 10, 10, 720, 1008, 720, 1008, 3532,
                COM_A5R,          1480, 2100, 10, 10, 576, 832, 576, 832, 3020,
                COM_A6R,          1050, 1480, 10, 10, 416, 576, 416, 576, 2092,
                COM_POSTCARDR,    1000, 1480, 10, 10, 400, 576, 400, 576, 1948,
                COM_LDR,          2794, 4318, 10, 10, 1104, 1696, 1104, 1696, 5940,
                COM_LGR,          2159, 3556, 10, 10, 848, 1408, 848, 1408, 4932,
                COM_LTR,          2159, 2794, 10, 10, 848, 1104, 848, 1104, 3868,
                COM_STR,          1397, 2159, 10, 10, 544, 848, 544, 848, 3078,
                COM_FOLIOR,       2100, 3300, 10, 10, 832, 1296, 832, 1296, 4864,
                COM_COMPR,        2570, 3556, 10, 10, 1008, 1408, 1008, 1408, 5284,
                COM_LG13R,        2159, 3300, 10, 10, 848, 1296, 848, 1296, 4540,
                COM_A3WR,         2970, 4200, 0, 0, 1168, 1664, 1168, 1664, 5828,
                COM_SRA3_450R,    2970, 4200, 0, 0, 1168, 1664, 1168, 1664, 5828,
                COM_SRA3_460R,    2970, 4200, 0, 0, 1168, 1664, 1168, 1664, 5828,
                COM_LDWR,         2794, 4318, 0, 0, 1104, 1696, 1104, 1696, 5940,
                COM_13X19R,       2794, 4318, 0, 0, 1104, 1696, 1104, 1696, 5940,
                COM_SQ85R,        2159, 2159, 10, 10, 848, 848, 848, 848, 2972,
                COM_8KR,          2700, 3900, 10, 10, 1056, 1536, 1056, 1536, 5764,
                COM_16KR,         1950, 2700, 10, 10, 768, 1056, 768, 1056, 3964
            };

            static int SCAN_MMR_100100_AR[] = {
                COM_A3,           4200, 2970, 10, 10, 1648, 1168, 1648, 1168, 4384,
                COM_B4,           3640, 2570, 10, 10, 1440, 1008, 1440, 1008, 3784,
                COM_A4,           2970, 2100, 10, 10, 1168, 832, 1168, 832, 2916,
                COM_B5,           2570, 1820, 10, 10, 1008, 720, 1008, 720, 2704,
                COM_A5,           2100, 1480, 10, 10, 832, 576, 832, 576, 2164,
                COM_A6,           1480, 1050, 10, 10, 576, 416, 576, 416, 1512,
                COM_POSTCARD,     1480, 1000, 10, 10, 576, 400, 576, 400, 1454,
                COM_LD,           4318, 2794, 10, 10, 1696, 1104, 1696, 1104, 3730,
                COM_LG,           3556, 2159, 10, 10, 1408, 848, 1408, 848, 3184,
                COM_LT,           2794, 2159, 10, 10, 1104, 848, 1104, 848, 2972,
                COM_ST,           2159, 1397, 10, 10, 848, 544, 848, 544, 1908,
                COM_FOLIO,        3300, 2100, 10, 10, 1296, 832, 1296, 832, 2916,
                COM_COMP,         3556, 2570, 10, 10, 1408, 1008, 1408, 1008, 3784,
                COM_LG13,         3300, 2159, 10, 10, 1296, 848, 1296, 848, 2972,
                COM_A3W,          4200, 2970, 0, 0, 1664, 1168, 1664, 1168, 3946,
                COM_SRA3_450,     4200, 2970, 0, 0, 1664, 1168, 1664, 1168, 3946,
                COM_SRA3_460,     4200, 2970, 0, 0, 1664, 1168, 1664, 1168, 3946,
                COM_LDW,          4318, 2794, 0, 0, 1696, 1104, 1696, 1104, 3730,
                COM_13X19,        4318, 2794, 0, 0, 1696, 1104, 1696, 1104, 3730,
                COM_SQ85,         2159, 2159, 10, 10, 848, 848, 848, 848, 2972,
                COM_8K,           3900, 2700, 10, 10, 1536, 1056, 1536, 1056, 3964,
                COM_16K,          2700, 1950, 10, 10, 1056, 768, 1056, 768, 2884    
            };

            static int PRINT_TJP_600600_A[] = {
                COM_A3R,       	2970, 4200, 0, 0, 6818, 9726, 6824, 9728, 226913, //A3_P                      
                COM_B4R,          2570, 3640, 0, 0, 5876, 8400, 5880, 8400, 168835, //B4_P
                COM_A4R,          2100, 2970, 0, 0, 4758, 6818, 4760, 6824, 111038, //A4_P
                COM_B5R,       	1820, 2570, 0, 0, 4100, 5876, 4104, 5880, 82496, //B5_P 
                COM_A5R,       	1480, 2100, 0, 0, 3300, 4758, 3304, 4760, 53770, //A5_P
                COM_A6R,       	1050, 1480, 0, 0, 2284, 3300, 2288, 3304, 25853, //A6_P
                COM_POSTCARDR, 	1000, 1480, 0, 0, 2158, 3300, 2160, 3304, 24408, //POSTCARD_P
                COM_LDR,          2794, 4318, 0, 0, 6400, 10000, 6400, 10000, 218765, //POSTCARD_P
                COM_LGR,       	2159, 3556, 0, 0, 4900, 8200, 4904, 8200, 137460, //LEGAL_P
                COM_LTR,       	2159, 2794, 0, 0, 4900, 6400, 4904, 6400, 107290, //LETTER_P
                COM_STR,       	1397, 2159, 0, 0, 3100, 4900, 3104, 4904, 52043, //STATEMENT_P
                COM_FOLIOR,       2100, 3300, 0, 0, 4758, 7592, 4760, 7592, 123533, //FOILIO_P
                COM_COMPR,     	2570, 3556, 0, 0, 5876, 8200, 5880, 8200, 164816, //COMPUTER_P
                COM_LG13R,        2159, 3302, 0, 0, 4900, 7600, 4904, 7600, 127404, //LEGAL13_P_P 
                COM_A3WR,      	3050, 4570, 0, 0, 7104, 10592, 7104, 10592, 257202, //A3_WIDE_PRINT 
                COM_LDWR,      	3050, 4570, 0, 0, 7104, 10592, 7104, 10592, 257202, //LEDGER_WIDE_PRINT         
                COM_SRA3_450R, 	3200, 4500, 0, 0, 7296, 10434, 7296, 10440, 260362, //SRA3_450_BP_PRINT         
                COM_SRA3_450R, 	3200, 4500, 0, 0, 7200, 10434, 7200, 10440, 256937, //SRA3_450_MASH_PRINT       
                COM_SRA3_460R, 	3200, 4600, 0, 0, 7296, 10668, 7296, 10672, 266148, //SRA3_460_BP_PRINT         
                COM_SRA3_460R, 	3200, 4600, 0, 0, 7200, 10668, 7200, 10672, 262646, //SRA3_460_MASH_PRINT       
                COM_13X19R,    	3302, 4826, 0, 0, 7296, 10800, 7296, 10800, 269340, //RECTANGLE13X19_BP_PRINT    
                COM_13X19R,       3302, 4826, 0, 0, 7200, 10800, 7200, 10800, 265796, //RECTANGLE13X19_MASH_PRINT  
                COM_SQ85R,        2159, 2159, 0, 0, 4900, 4900, 4904, 4904, 82213, //SQUARE8_5_PRINT 
                COM_8KR,          2700, 3900, 0, 0, 6176, 9018, 6176, 9024, 190506, //SIZE_8K_PRINT 
                COM_16KR,         1950, 2700, 0, 0, 4408, 6176, 4408, 6176, 93065, //SIZE_16K_PRINT 
                COM_A4,           2970, 2100, 0, 0, 6818, 4758, 6824, 4760, 107290, //A4_R_PRINT 
                COM_B5,           2570, 1820, 0, 0, 5876, 4100, 5880, 4104, 111038, //B5_R_PRINT 
                COM_LT,           2794, 2159, 0, 0, 6400, 4900, 6400, 4904, 82496, //LETTER_R_PRINT 
                COM_16K,          2700, 1950, 0, 0, 6176, 4408, 6176, 4408, 93065 //SIZE_16K_R_PRINT 
            };
            static int PRINT_RK1_600600_A[] = {
                COM_A3R,        2970,  4200,  0,  0,  6818,  9726,  6912,  9726,  28736,
                COM_B4R,        2570,  3640,  0,  0,  5876,  8400,  5888,  8400,  21152,
                COM_A4R,        2100,  2970,  0,  0,  4758,  6818,  4864,  6818,  14176,
                COM_B5R,        1820,  2570,  0,  0,  4100,  5876,  4224,  5876,  10624,
                COM_A5R,        1480,  2100,  0,  0,  3300,  4758,  3328,  4758,  6784,
                COM_A6R,        1050,  1480,  0,  0,  2284,  3300,  2304,  3300,  3264,
                COM_POSTCARDR,  1000,  1480,  0,  0,  2158,  3300,  2176,  3300,  3104,
                COM_LDR,        2794,  4318,  0,  0,  6400,  10000, 6400,  10000, 27360,
                COM_LGR,        2159,  3556,  0,  0,  4900,  8200,  4992,  8200,  17504,
                COM_LTR,        2159,  2794,  0,  0,  4900,  6400,  4992,  6400,  13664,
                COM_STR,        1397,  2159,  0,  0,  3100,  4900,  3200,  4900,  6720,
                COM_FOLIOR,     2100,  3300,  0,  0,  4758,  7592,  4864,  7592,  15808,
                COM_COMPR,      2570,  3556,  0,  0,  5876,  8200,  5888,  8200,  20640,
                COM_LG13R,      2159,  3302,  0,  0,  4900,  7600,  4992,  7600,  16224,
                COM_A3WR,       3050,  4570,  0,  0,  7104,  10592, 7168,  10592, 257202,
                COM_LDWR,       3050,  4570,  0,  0,  7104,  10592, 7168,  10592, 257202,
                COM_SRA3_450R,  3200,  4500,  0,  0,  7296,  10434, 7296,  10434, 260362,
                COM_SRA3_450R,  3200,  4500,  0,  0,  7200,  10434, 7296,  10434, 256937,
                COM_SRA3_460R,  3200,  4600,  0,  0,  7296,  10668, 7296,  10668, 266148,
                COM_SRA3_460R,  3200,  4600,  0,  0,  7200,  10668, 7296,  10668, 262646,
                COM_13X19R,     3302,  4826,  0,  0,  7296,  10800, 7296,  10800, 269340,
                COM_13X19R,     3302,  4826,  0,  0,  7200,  10800, 7296,  10800, 265796,
                COM_SQ85R,      2159,  2159,  0,  0,  4900,  4900,  4992,  4900,  10464,
                COM_8KR,        2700,  3900,  0,  0,  6176,  9018,  6272,  9018,  24192,
                COM_16KR,       1950,  2700,  0,  0,  4408,  6176,  4480,  6176,  11840,
                COM_A4,         2970,  2100,  0,  0,  6818,  4758,  6912,  4758,  107290,
                COM_B5,         2570,  1820,  0,  0,  5876,  4100,  5888,  4100,  111038,
                COM_LT,         2794,  2159,  0,  0,  6400,  4900,  6400,  4900,  82496,
                COM_16K,        2700,  1950,  0,  0,  6176,  4408,  6272,  4408,  93065
            };

            static int COPY_CJP_600600_A[] = {
                COM_A3R,         	2970, 4200, 40, 40, 6922, 9827, 6928, 9832, 7450200, //A3_P
                COM_B4R,         	2570, 3640, 40, 40, 5977, 8504, 5984, 8504, 5565868, //B4_P
                COM_A4R,         	2100, 2970, 40, 40, 4867, 6922, 4872, 6928, 3691760, //A4_P
                COM_B5R,         	1820, 2570, 40, 40, 4205, 5977, 4208, 5984, 2754136, //B5_P
                COM_A5R,         	1480, 2100, 40, 40, 3402, 4867, 3408, 4872, 1816040, //A5_P
                COM_A6R,         	1050, 1480, 40, 40, 2386, 3402, 2392, 3408, 891620, //A6_P
                COM_POSTCARDR,   	1000, 1480, 40, 40, 2268, 3402, 2272, 3408, 846888, //POSTCARD_P
                COM_LDR,         	2794, 4318, 40, 40, 6506, 10106, 6512, 10112, 7202272, //LEDGER_P
                COM_LGR,         	2159, 3556, 40, 40, 5006, 8306, 5008, 8312, 4552900, //LEGAL_P
                COM_LTR,         	2159, 2794, 40, 40, 5006, 6506, 5008, 6512, 3566948, //LETTER_P
                COM_STR,         	1397, 2159, 40, 40, 3206, 5006, 3208, 5008, 1757184, //STATEMENT_P
                COM_FOLIOR,       2100, 3300, 40, 40, 4867, 7701, 4872, 7704, 4105272, //FOILIO_P
                COM_COMPR,       	2570, 3556, 40, 40, 5977, 8306, 5984, 8312, 5440204, //COMPUTER_P
                COM_LG13R,        2159, 3300, 40, 40, 5006, 7701, 5008, 7704, 4219868, //LEGAL13_P_P
                COM_A3WR,        	2970, 4200, 0, 0, 7016, 9922, 7016, 9928, 7618500, //A3_WIDE_SRA3_450_460_P
                COM_SRA3_450R,    2970, 4200, 0, 0, 7016, 9922, 7016, 9928, 7618500, //A3_WIDE_SRA3_450_460_P1
                COM_SRA3_460R,    2970, 4200, 0, 0, 7016, 9922, 7016, 9928, 7618500, //A3_WIDE_SRA3_450_460_P2
                COM_LDWR,        	2794, 4318, 0, 0, 6600, 10200, 6600, 10200, 7363128, //LEDGER_WIDE_RECTANGLE13X19_P
                COM_13X19R,       2794, 4318, 0, 0, 6600, 10200, 6600, 10200, 7363128, //LEDGER_WIDE_RECTANGLE13X19_P1
                COM_SQ85R,        2159, 2159, 40, 40, 5006, 5006, 5008, 5008, 2743132, //SIZE_8_5_P
                COM_8KR,          2700, 3900, 40, 40, 6284, 9119, 6288, 9120, 6272280, //SIZE_8K_P
                COM_16KR,         1950, 2700, 40, 40, 4512, 6284, 4512, 6288, 3103128, //SIZE_16K_P
                COM_A4,           2970, 2100, 40, 40, 6922, 4867, 6928, 4872, 3691760, //A4_R_COPY 
                COM_B5,           2570, 1820, 40, 40, 5977, 4205, 5984, 4208, 2754136, //B5_R_COPY 
                COM_LT,           2794, 2159, 40, 40, 6506, 5006, 6512, 5008, 3566948, //LETTER_R_COPY 
                COM_16K,          2700, 1950, 40, 40, 6284, 4512, 6288, 4512, 3103128 //SIZE_16K_R_COPY 
            };

            static int COPY_RK1_600600_A[] = {
                COM_A3R,            2970, 4200, 40, 40, 6922, 9827, 7168, 9827, 30112,
                COM_B4R,            2570, 3640, 40, 40, 5977, 8504, 6144, 8504, 22336,
                COM_A4R,            2100, 2970, 40, 40, 4867, 6922, 5120, 6922, 15152,
                COM_B5R,            1820, 2570, 40, 40, 4205, 5977, 4352, 5977, 11120,
                COM_A5R,            1480, 2100, 40, 40, 3402, 4867, 3584, 4867, 7472,
                COM_A6R,            1050, 1480, 40, 40, 2386, 3402, 2560, 3402, 3728,
                COM_POSTCARDR,      1000, 1480, 40, 40, 2268, 3402, 2304, 3402, 3360,
                COM_LDR,            2794, 4318, 40, 40, 6506, 10106, 6656, 10106, 2875,
                COM_LGR,            2159, 3556, 40, 40, 5006, 8306, 5120, 8306, 18176,
                COM_LTR,            2159, 2794, 40, 40, 5006, 6506, 5120, 6506, 14240,
                COM_STR,            1397, 2159, 40, 40, 3206, 5006, 3328, 5006, 7136,
                COM_FOLIOR,         2100, 3300, 40, 40, 4867, 7701, 5120, 7701, 16864,
                COM_COMPR,          2570, 3556, 40, 40, 5977, 8306, 6144, 8306, 21808,
                COM_LG13R,          2159, 3300, 40, 40, 5006, 7701, 5120, 7701, 16864,
                COM_A3WR,           2970, 4200, 0, 0, 7016, 9922, 7168, 9922, 30400,
                COM_SRA3_450R,      2970, 4200, 0, 0, 7016, 9922, 7168, 9922, 30400,
                COM_SRA3_460R,      2970, 4200, 0, 0, 7016, 9922, 7168, 9922, 30400,
                COM_LDWR,           2794, 4318, 0, 0, 6600, 10200, 6656, 10200, 29024,
                COM_13X19R,         2794, 4318, 0, 0, 6600, 10200, 6656, 10200, 29024,
                COM_SQ85R,          2159, 2159, 40, 40, 5006, 5006, 5120, 5006, 10960,
                COM_8KR,            2700, 3900, 40, 40, 6284, 9119, 6400, 9119, 24944,
                COM_16KR,           1950, 2700, 40, 40, 4512, 6284, 4608, 6284, 12384,
                COM_A4,             2970, 2100, 40, 40, 6922, 4867, 7168, 4867, 14912,
                COM_B5,             2570, 1820, 40, 40, 5977, 4205, 6144, 4205, 11056,
                COM_LT,             2794, 2159, 40, 40, 6506, 5006, 6656, 5006, 14256,
                COM_16K,            2700, 1950, 40, 40, 6284, 4512, 6400, 4512, 12352
            };

            static int THUMBNAIL_PNG_A[] = {
                0, 0, 0, 0, 166, 233, 0, 0, 1365,
                0, 0, 0, 0, 141, 203, 0, 0, 1299,
                0, 0, 0, 0, 116, 166, 0, 0, 1222,
                0, 0, 0, 0, 101, 141, 0, 0, 1185,
                0, 0, 0, 0, 80, 116, 0, 0, 1164,
                0, 0, 0, 0, 55, 80, 0, 0, 1128,
                0, 0, 0, 0, 53, 80, 0, 0, 1128,
                0, 0, 0, 0, 153, 243, 0, 0, 1361,
                0, 0, 0, 0, 120, 200, 0, 0, 1242,
                0, 0, 0, 0, 120, 153, 0, 0, 1214,
                0, 0, 0, 0, 76, 120, 0, 0, 1152,
                0, 0, 0, 0, 116, 184, 0, 0, 1233,
                0, 0, 0, 0, 141, 200, 0, 0, 1295,
                0, 0, 0, 0, 120, 184, 0, 0, 1233,
                0, 0, 0, 0, 168, 235, 0, 0, 1367,
                0, 0, 0, 0, 155, 245, 0, 0, 1363,
                0, 0, 0, 0, 120, 120, 0, 0, 1193,
                0, 0, 0, 0, 150, 217, 0, 0, 1325,
                0, 0, 0, 0, 108, 150, 0, 0, 1213
            };
            static int THUMBNAIL_PNG_AR[] = {
                0, 0, 0, 0, 233, 166, 0, 0, 1295,
                0, 0, 0, 0, 203, 141, 0, 0, 1270,
                0, 0, 0, 0, 166, 116, 0, 0, 1235,
                0, 0, 0, 0, 141, 101, 0, 0, 1210,
                0, 0, 0, 0, 116, 80, 0, 0, 1168,
                0, 0, 0, 0, 80, 55, 0, 0, 1141,
                0, 0, 0, 0, 80, 53, 0, 0, 1137,
                0, 0, 0, 0, 243, 153, 0, 0, 1282,
                0, 0, 0, 0, 200, 120, 0, 0, 1246,
                0, 0, 0, 0, 153, 120, 0, 0, 1233,
                0, 0, 0, 0, 120, 76, 0, 0, 1166,
                0, 0, 0, 0, 184, 116, 0, 0, 1235,
                0, 0, 0, 0, 200, 141, 0, 0, 1270,
                0, 0, 0, 0, 184, 120, 0, 0, 1239,
                0, 0, 0, 0, 235, 168, 0, 0, 1297,
                0, 0, 0, 0, 245, 155, 0, 0, 1284,
                0, 0, 0, 0, 120, 120, 0, 0, 1193,
                0, 0, 0, 0, 217, 150, 0, 0, 1279,
                0, 0, 0, 0, 150, 108, 0, 0, 1221
            };


            //Columns of the array
            //H_SIZE, H_IMG_COORDINATE, H_ANGLE, H_PAPER_SIZE, H_ORIENTATION

            static int SCAN_ORIENT[] = {
                COM_A3R,       COM_IC_180, COM_RT_NOTHING, COM_A3R,       COM_IO_PORTRAIT, //A3_O
                COM_A4R,       COM_IC_270, COM_RT_NOTHING, COM_A4,        COM_IO_PORTRAIT, //A4_O
                COM_A5R,       COM_IC_180, COM_RT_NOTHING, COM_A5R,       COM_IO_PORTRAIT, //A5_O
                COM_A6R,       COM_IC_180, COM_RT_NOTHING, COM_A6R,       COM_IO_PORTRAIT, //A6_O
                COM_A3WR,      COM_IC_180, COM_RT_NOTHING, COM_A3WR,      COM_IO_PORTRAIT, //A3_WIDE_O
                COM_B4R,       COM_IC_180, COM_RT_NOTHING, COM_B4R,       COM_IO_PORTRAIT, //B4_O
                COM_B5R,       COM_IC_270, COM_RT_NOTHING, COM_B5,        COM_IO_PORTRAIT, //B5_O
                COM_LTR,       COM_IC_270, COM_RT_NOTHING, COM_LT,        COM_IO_PORTRAIT, //LETTER_O
                COM_LDR,       COM_IC_180, COM_RT_NOTHING, COM_LDR,       COM_IO_PORTRAIT, //LEDGER_O
                COM_LGR,       COM_IC_180, COM_RT_NOTHING, COM_LGR,       COM_IO_PORTRAIT, //LEGAL_O
                COM_STR,       COM_IC_180, COM_RT_NOTHING, COM_STR,       COM_IO_PORTRAIT, //STATEMENT_O
                COM_COMPR,     COM_IC_180, COM_RT_NOTHING, COM_COMPR,     COM_IO_PORTRAIT, //COMPUTER_O
                COM_FOLIOR,    COM_IC_180, COM_RT_NOTHING, COM_FOLIOR,    COM_IO_PORTRAIT, //FOLIO_O
                COM_LG13R,     COM_IC_180, COM_RT_NOTHING, COM_LG13R,     COM_IO_PORTRAIT, //LEGAL13_O
                COM_SQ85R,     COM_IC_180, COM_RT_NOTHING, COM_SQ85R,     COM_IO_PORTRAIT, //SQUARE8_5_O
                COM_LDWR,      COM_IC_180, COM_RT_NOTHING, COM_LDWR,      COM_IO_PORTRAIT, //LEDGER_WIDE_R_O
                COM_13X19R,    COM_IC_180, COM_RT_NOTHING, COM_13X19R,    COM_IO_PORTRAIT, //RECTANGLE13X19_O
                COM_8KR,       COM_IC_180, COM_RT_NOTHING, COM_8KR,       COM_IO_PORTRAIT, //SIZE_8K_O
                COM_16KR,      COM_IC_270, COM_RT_NOTHING, COM_16K,       COM_IO_PORTRAIT, //SIZE_16K_O
                COM_POSTCARDR, COM_IC_180, COM_RT_NOTHING, COM_POSTCARDR, COM_IO_PORTRAIT, //POSTCARD_O
                COM_SRA3_450R, COM_IC_180, COM_RT_NOTHING, COM_SRA3_450R, COM_IO_PORTRAIT, //SRA3_450_O
                COM_SRA3_460R, COM_IC_180, COM_RT_NOTHING, COM_SRA3_460R, COM_IO_PORTRAIT  //SRA3_460_O
            };



            static int SCAN_ORIENT_R[] = {
                COM_A3,       COM_IC_270, COM_RT_NOTHING, COM_A3R,       COM_IO_LANDSCAPE,
                COM_A4,       COM_IC_270, COM_RT_NOTHING, COM_A4R,       COM_IO_LANDSCAPE,
                COM_A5,       COM_IC_270, COM_RT_NOTHING, COM_A5R,       COM_IO_LANDSCAPE,
                COM_A6,       COM_IC_270, COM_RT_NOTHING, COM_A6R,       COM_IO_LANDSCAPE,
                COM_A3W,      COM_IC_270, COM_RT_NOTHING, COM_A3WR,      COM_IO_LANDSCAPE,
                COM_B4,       COM_IC_270, COM_RT_NOTHING, COM_B4R,       COM_IO_LANDSCAPE,
                COM_B5,       COM_IC_270, COM_RT_NOTHING, COM_B5R,       COM_IO_LANDSCAPE,
                COM_LT,       COM_IC_270, COM_RT_NOTHING, COM_LTR,       COM_IO_LANDSCAPE,
                COM_LD,       COM_IC_270, COM_RT_NOTHING, COM_LDR,       COM_IO_LANDSCAPE,
                COM_LG,       COM_IC_270, COM_RT_NOTHING, COM_LGR,       COM_IO_LANDSCAPE,
                COM_ST,       COM_IC_270, COM_RT_NOTHING, COM_STR,       COM_IO_LANDSCAPE,
                COM_COMP,     COM_IC_270, COM_RT_NOTHING, COM_COMPR,     COM_IO_LANDSCAPE,
                COM_FOLIO,    COM_IC_270, COM_RT_NOTHING, COM_FOLIOR,    COM_IO_LANDSCAPE,
                COM_LG13,     COM_IC_270, COM_RT_NOTHING, COM_LG13R,     COM_IO_LANDSCAPE,
                COM_SQ85,     COM_IC_270, COM_RT_NOTHING, COM_SQ85R,     COM_IO_LANDSCAPE,
                COM_LDW,      COM_IC_270, COM_RT_NOTHING, COM_LDWR,      COM_IO_LANDSCAPE,
                COM_13X19,    COM_IC_270, COM_RT_NOTHING, COM_13X19R,    COM_IO_LANDSCAPE,
                COM_8K,       COM_IC_270, COM_RT_NOTHING, COM_8KR,       COM_IO_LANDSCAPE,
                COM_16K,      COM_IC_270, COM_RT_NOTHING, COM_16KR,      COM_IO_LANDSCAPE,
                COM_POSTCARD, COM_IC_270, COM_RT_NOTHING, COM_POSTCARDR, COM_IO_LANDSCAPE,
                COM_SRA3_450, COM_IC_270, COM_RT_NOTHING, COM_SRA3_450R, COM_IO_LANDSCAPE,
                COM_SRA3_460, COM_IC_270, COM_RT_NOTHING, COM_SRA3_460R, COM_IO_LANDSCAPE
            };


            static int PRINT_ORIENT[] = {
                COM_A3R,       COM_IC_180, COM_RT_NOTHING, COM_A3R,       COM_IO_PORTRAIT,
                COM_A4R,       COM_IC_270, COM_RT_NOTHING, COM_A4,        COM_IO_PORTRAIT,
                COM_A5R,       COM_IC_180, COM_RT_NOTHING, COM_A5R,       COM_IO_PORTRAIT,
                COM_A6R,       COM_IC_180, COM_RT_NOTHING, COM_A6R,       COM_IO_PORTRAIT,
                COM_A3WR,      COM_IC_180, COM_RT_NOTHING, COM_A3WR,      COM_IO_PORTRAIT,
                COM_B4R,       COM_IC_180, COM_RT_NOTHING, COM_B4R,       COM_IO_PORTRAIT,
                COM_B5R,       COM_IC_270, COM_RT_NOTHING, COM_B5,        COM_IO_PORTRAIT,
                COM_LTR,       COM_IC_270, COM_RT_NOTHING, COM_LT,        COM_IO_PORTRAIT,
                COM_LDR,       COM_IC_180, COM_RT_NOTHING, COM_LDR,       COM_IO_PORTRAIT,
                COM_LGR,       COM_IC_180, COM_RT_NOTHING, COM_LGR,       COM_IO_PORTRAIT,
                COM_STR,       COM_IC_180, COM_RT_NOTHING, COM_STR,       COM_IO_PORTRAIT,
                COM_COMPR,     COM_IC_180, COM_RT_NOTHING, COM_COMPR,     COM_IO_PORTRAIT,
                COM_FOLIOR,    COM_IC_180, COM_RT_NOTHING, COM_FOLIOR,    COM_IO_PORTRAIT,
                COM_LG13R,     COM_IC_180, COM_RT_NOTHING, COM_LG13R,     COM_IO_PORTRAIT,
                COM_SQ85R,     COM_IC_180, COM_RT_NOTHING, COM_SQ85R,     COM_IO_PORTRAIT,
                COM_LDWR,      COM_IC_180, COM_RT_NOTHING, COM_LDWR,      COM_IO_PORTRAIT,
                COM_13X19R,    COM_IC_180, COM_RT_NOTHING, COM_13X19R,    COM_IO_PORTRAIT,
                COM_8KR,       COM_IC_180, COM_RT_NOTHING, COM_8KR,       COM_IO_PORTRAIT,
                COM_16KR,      COM_IC_270, COM_RT_NOTHING, COM_16K,       COM_IO_PORTRAIT,
                COM_POSTCARDR, COM_IC_180, COM_RT_NOTHING, COM_POSTCARDR, COM_IO_PORTRAIT,
                COM_SRA3_450R, COM_IC_180, COM_RT_NOTHING, COM_SRA3_450R, COM_IO_PORTRAIT,
                COM_SRA3_460R, COM_IC_180, COM_RT_NOTHING, COM_SRA3_460R, COM_IO_PORTRAIT
            };


            static int PRINT_ORIENT_R[] = {
                COM_A3R,       COM_IC_0, COM_RT_270, COM_A3R,       COM_IO_LANDSCAPE, 
                COM_A4R,       COM_IC_0, COM_RT_270, COM_A4R,       COM_IO_LANDSCAPE,
                COM_A5R,       COM_IC_0, COM_RT_270, COM_A5R,       COM_IO_LANDSCAPE,
                COM_A6R,       COM_IC_0, COM_RT_270, COM_A6R,       COM_IO_LANDSCAPE,
                COM_A3WR,      COM_IC_0, COM_RT_270, COM_A3WR,      COM_IO_LANDSCAPE,
                COM_B4R,       COM_IC_0, COM_RT_270, COM_B4R,       COM_IO_LANDSCAPE,
                COM_B5R,       COM_IC_0, COM_RT_270, COM_B5R,       COM_IO_LANDSCAPE,
                COM_LTR,       COM_IC_0, COM_RT_270, COM_LTR,       COM_IO_LANDSCAPE,
                COM_LDR,       COM_IC_0, COM_RT_270, COM_LDR,       COM_IO_LANDSCAPE,
                COM_LGR,       COM_IC_0, COM_RT_270, COM_LGR,       COM_IO_LANDSCAPE,
                COM_STR,       COM_IC_0, COM_RT_270, COM_STR,       COM_IO_LANDSCAPE,
                COM_COMPR,     COM_IC_0, COM_RT_270, COM_COMPR,     COM_IO_LANDSCAPE,
                COM_FOLIOR,    COM_IC_0, COM_RT_270, COM_FOLIOR,    COM_IO_LANDSCAPE,
                COM_LG13R,     COM_IC_0, COM_RT_270, COM_LG13R,     COM_IO_LANDSCAPE,
                COM_SQ85R,     COM_IC_0, COM_RT_270, COM_SQ85R,     COM_IO_LANDSCAPE,
                COM_LDWR,      COM_IC_0, COM_RT_270, COM_LDWR,      COM_IO_LANDSCAPE,
                COM_13X19R,    COM_IC_0, COM_RT_270, COM_13X19R,    COM_IO_LANDSCAPE,
                COM_8KR,       COM_IC_0, COM_RT_270, COM_8KR,       COM_IO_LANDSCAPE,
                COM_16KR,      COM_IC_0, COM_RT_270, COM_16KR,      COM_IO_LANDSCAPE,
                COM_POSTCARDR, COM_IC_0, COM_RT_270, COM_POSTCARDR, COM_IO_LANDSCAPE,
                COM_SRA3_450R, COM_IC_0, COM_RT_270, COM_SRA3_450R, COM_IO_LANDSCAPE,
                COM_SRA3_460R, COM_IC_0, COM_RT_270, COM_SRA3_460R, COM_IO_LANDSCAPE
            };


            static int COPY_ORIENT[] = {
                COM_A3R,       COM_IC_0, COM_RT_180, COM_A3R,       COM_IO_PORTRAIT,
                COM_A4,        COM_IC_0, COM_RT_270, COM_A4,        COM_IO_PORTRAIT,
                COM_A5R,       COM_IC_0, COM_RT_180, COM_A5R,       COM_IO_PORTRAIT,
                COM_A6R,       COM_IC_0, COM_RT_180, COM_A6R,       COM_IO_PORTRAIT,
                COM_A3R,       COM_IC_0, COM_RT_180, COM_A3WR,      COM_IO_PORTRAIT,
                COM_B4R,       COM_IC_0, COM_RT_180, COM_B4R,       COM_IO_PORTRAIT,
                COM_B5,        COM_IC_0, COM_RT_270, COM_B5,        COM_IO_PORTRAIT,
                COM_LT,        COM_IC_0, COM_RT_270, COM_LT,        COM_IO_PORTRAIT,
                COM_LDR,       COM_IC_0, COM_RT_180, COM_LDR,       COM_IO_PORTRAIT,
                COM_LGR,       COM_IC_0, COM_RT_180, COM_LGR,       COM_IO_PORTRAIT,
                COM_STR,       COM_IC_0, COM_RT_180, COM_STR,       COM_IO_PORTRAIT,
                COM_COMPR,     COM_IC_0, COM_RT_180, COM_COMPR,     COM_IO_PORTRAIT,
                COM_FOLIOR,    COM_IC_0, COM_RT_180, COM_FOLIOR,    COM_IO_PORTRAIT,
                COM_LG13R,     COM_IC_0, COM_RT_180, COM_LG13R,     COM_IO_PORTRAIT,
                COM_SQ85R,     COM_IC_0, COM_RT_180, COM_SQ85R,     COM_IO_PORTRAIT,
                COM_LDR,       COM_IC_0, COM_RT_180, COM_LDWR,      COM_IO_PORTRAIT,
                COM_LDR,       COM_IC_0, COM_RT_180, COM_13X19R,    COM_IO_PORTRAIT,
                COM_8KR,       COM_IC_0, COM_RT_180, COM_8KR,       COM_IO_PORTRAIT,
                COM_16K,       COM_IC_0, COM_RT_270, COM_16K,       COM_IO_PORTRAIT,
                COM_POSTCARDR, COM_IC_0, COM_RT_180, COM_POSTCARDR, COM_IO_PORTRAIT,
                COM_A3R,       COM_IC_0, COM_RT_180, COM_SRA3_450R, COM_IO_PORTRAIT,
                COM_A3R,       COM_IC_0, COM_RT_180, COM_SRA3_460R, COM_IO_PORTRAIT
            };



            static int COPY_ORIENT_R[] = {
                COM_A3R,       COM_IC_0, COM_RT_270, COM_A3R,       COM_IO_LANDSCAPE,
                COM_A4R,       COM_IC_0, COM_RT_270, COM_A4R,       COM_IO_LANDSCAPE,
                COM_A5R,       COM_IC_0, COM_RT_270, COM_A5R,       COM_IO_LANDSCAPE,
                COM_A6R,       COM_IC_0, COM_RT_270, COM_A6R,       COM_IO_LANDSCAPE,
                COM_A3R,       COM_IC_0, COM_RT_270, COM_A3WR,      COM_IO_LANDSCAPE,
                COM_B4R,       COM_IC_0, COM_RT_270, COM_B4R,       COM_IO_LANDSCAPE,
                COM_B5R,       COM_IC_0, COM_RT_270, COM_B5R,       COM_IO_LANDSCAPE,
                COM_LTR,       COM_IC_0, COM_RT_270, COM_LTR,       COM_IO_LANDSCAPE,
                COM_LDR,       COM_IC_0, COM_RT_270, COM_LDR,       COM_IO_LANDSCAPE,
                COM_LGR,       COM_IC_0, COM_RT_270, COM_LGR,       COM_IO_LANDSCAPE,
                COM_STR,       COM_IC_0, COM_RT_270, COM_STR,       COM_IO_LANDSCAPE,
                COM_COMPR,     COM_IC_0, COM_RT_270, COM_COMPR,     COM_IO_LANDSCAPE,
                COM_FOLIOR,    COM_IC_0, COM_RT_270, COM_FOLIOR,    COM_IO_LANDSCAPE,
                COM_LG13R,     COM_IC_0, COM_RT_270, COM_LG13R,     COM_IO_LANDSCAPE,
                COM_SQ85R,     COM_IC_0, COM_RT_270, COM_SQ85R,     COM_IO_LANDSCAPE,
                COM_LDR,       COM_IC_0, COM_RT_270, COM_LDWR,      COM_IO_LANDSCAPE,
                COM_LDR,       COM_IC_0, COM_RT_270, COM_13X19R,    COM_IO_LANDSCAPE,
                COM_8KR,       COM_IC_0, COM_RT_270, COM_8KR,       COM_IO_LANDSCAPE,
                COM_16KR,      COM_IC_0, COM_RT_270, COM_16KR,      COM_IO_LANDSCAPE,
                COM_POSTCARDR, COM_IC_0, COM_RT_270, COM_POSTCARDR, COM_IO_LANDSCAPE,
                COM_A3R,       COM_IC_0, COM_RT_270, COM_SRA3_450R, COM_IO_LANDSCAPE,
                COM_A3R,       COM_IC_0, COM_RT_270, COM_SRA3_460R, COM_IO_LANDSCAPE
            };


        }
        using namespace blankpagevalues;

        const CString WEP_FILENAME = "wep.xml";

        Status CDocument::CreatePage(PageRef &page) { 
            page = new CPage(0 ,"" , m_BoxBasePath);
            return STATUS_OK;
        }


        // constructor
        CDocument::CDocument(CString sessionID, CString boxbasepath, CString boxnumber, CString foldername, CString documentname) :
            m_sessionID(sessionID),
            m_BoxBasePath(boxbasepath),
            m_BoxBasePathOrg(boxbasepath),
            m_BoxNumber(boxnumber), 
            m_FolderName(foldername),
            m_DocumentName(documentname)

        {
            if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCDocument::CDocument: Failed to increment the count\n ");

            typedef std::map<CString, CString> property_pair;
            m_WebDAVProperties.insert(property_pair::value_type("documentName", documentname));
            m_WebDAVProperties.insert(property_pair::value_type("jobType", ""));
            m_WebDAVProperties.insert(property_pair::value_type("mixpaperSize", ""));  // TBD
            m_WebDAVProperties.insert(property_pair::value_type("mixresolution", "")); // TBD
            m_WebDAVProperties.insert(property_pair::value_type("mixcolorMono", ""));  // TBD
            m_WebDAVProperties.insert(property_pair::value_type("totalSize", "0"));
            m_WebDAVProperties.insert(property_pair::value_type("totalPages", "0"));

            CString local = Utility::GetUnixTime();

            m_WebDAVProperties.insert(property_pair::value_type("creationDate", local));
            m_WebDAVProperties.insert(property_pair::value_type("lastModifiedDate", local));			
            m_WebDAVProperties.insert(property_pair::value_type("lastAccessDate", local));	 	 						
            m_WebDAVProperties.insert(property_pair::value_type("lastArchiveDate", ""));
            m_WebDAVProperties.insert(property_pair::value_type("from", ""));    
            m_WebDAVProperties.insert(property_pair::value_type("receptionTime",""));
            m_WebDAVProperties.insert(property_pair::value_type("receptionNumber",""));
            m_WebDAVProperties.insert(property_pair::value_type("cutDocument",""));	
            m_WebDAVProperties.insert(property_pair::value_type("mixpaperSize","none"));							
            m_WebDAVProperties.insert(property_pair::value_type("mixresolution","none"));	
            m_WebDAVProperties.insert(property_pair::value_type("mixcolorMono","none"));						
            m_WebDAVProperties.insert(property_pair::value_type("StatusOfReceivedData","Unused"));							
            m_WebDAVProperties.insert(property_pair::value_type("StatusOfHardCopy","false"));	
            m_WebDAVProperties.insert(property_pair::value_type("StatusOfRelayReport","0"));
            m_WebDAVProperties.insert(property_pair::value_type("duplex","Simplex"));
            m_WebDAVProperties.insert(property_pair::value_type("paperType","Plain"));
            m_WebDAVProperties.insert(property_pair::value_type("paperSource","Auto"));
            m_WebDAVProperties.insert(property_pair::value_type("staple","Non-Staple"));
            m_WebDAVProperties.insert(property_pair::value_type("holePunch","Unused"));
            m_WebDAVProperties.insert(property_pair::value_type("faxDuplex","Simplex"));
            m_WebDAVProperties.insert(property_pair::value_type("WorkspaceDocName",""));
            m_WebDAVProperties.insert(property_pair::value_type("statusOfPollingTransmission","Unused"));
            m_WebDAVProperties.insert(property_pair::value_type("faxPreview","false"));
            m_WebDAVProperties.insert(property_pair::value_type("inputTime",""));
            m_WebDAVProperties.insert(property_pair::value_type("StatusOfForcedStorage","false"));

            CString val, val2;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","cutDocument", val) != STATUS_OK)
            {
                DEBUGL2("CDocument::CDocument : unable to get the property\n");							
            }
            if(proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","cutDocument", val) != STATUS_OK)	
            {
                DEBUGL2("CDocument::CDocument : unable to set the property\n");						
            }
            //for internal use. not returned by GetWebDAVProperty
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalDocSize", val) != STATUS_OK)
            {
                DEBUGL2("CDocument::CDocument : unable to get the property\n");							
            }
            m_TotalDocSize = val.length() ? atoi(val.c_str()) : 0;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","docWEPSize", val2) != STATUS_FAILED)
                m_TotalDocSize -= (val2.length() ? atoi(val2.c_str()) : 0);


            iSSetsysfileInvoked = false;
            m_insertblankpage = false;
            m_bLink = false;
            m_JobVal = "";
            m_jobColorType = 1;

            m_prgShmid = NULL;

            memset((FL_FILE_MAN_FILE *)&(m_SystemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));
            memset((FL_FILE_MAN_FILE *)&(m_SubsamplingSystemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));			
            memset((FL_FILE_MAN_FILE *)&(m_ThumbnailSystemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));

        }

        // destructor
        CDocument::~CDocument()
        {					
            if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCDocument::~CDocument: Failed to decrement the count\n ");

        }

        Status CDocument::GetStatus(DocStatus &st) {
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            DEBUGL8("CDocument::GetStatus path = (%s)\n",path.c_str());
            if(Utility::ResourceExist(path + statusfilename::CREATING)) {
                st = CREATING;
            } else if(Utility::ResourceExist(path + statusfilename::READY)) {
                st = READY;
            } else if(Utility::ResourceExist(path + statusfilename::USING)) {
                st = USING;
            } else if(Utility::ResourceExist(path + statusfilename::EDITING)) {
                st = EDITING;
            } else if(Utility::ResourceExist(path + statusfilename::DELETING)) {
                st = DELETING;
            } else if(Utility::ResourceExist(path + statusfilename::WAITING)) {
                st = WAITING;								
            } else if(Utility::ResourceExist(path + statusfilename::RESERVING)) {
                st = RESERVING;								
            } else {
                // if file is not found, document status is considered as CREATING.
                st = CREATING;

                if(Utility::CreateFile(path, statusfilename::CREATING) != STATUS_OK) {
                    DEBUGL1("CDocument::GetStatus::creating status file is failed\n");
                    return STATUS_FAILED;
                }
            }
            return STATUS_OK;
        }

        Status CDocument::ChangeStatus(DocStatus st) {
            DocStatus current;
            if(GetStatus(current) != STATUS_OK) {
                DEBUGL1("CDocument::ChangeStatus::getting document status is failed\n");
                return STATUS_FAILED;
            }
            //update the last access date according to the given requirement
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            //update the other properties 
            typedef  std::map<CString, CString> pair;
            PropertyMap.insert(pair::value_type("lastAccessDate", Utility::GetUnixTime()));
            CString oPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/";
            Status sdf = Utility::SetProperties(oPath,"documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                    DEBUGL1("CDocument::ChangeStatus::SetProperties for the document is failed because Disk is Full\n");

				else
					DEBUGL1("CDocument::ChangeStatus::SetProperties for the document is failed\n");						
                return sdf;
            }

            // rename status file
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            CString from = path + GetStatusFileName(current);
            CString to = GetStatusFileName(st);
            to = path + to;

            Status ds = ci::operatingenvironment::File::MoveFile(from, to);
            if(ds != STATUS_OK) {
                DEBUGL1("CDocument::ChangeStatus::changing status is failed\n");
                return ds;
            }						
            DEBUGL8("Document::ChangeStatus::MoveFile is completed\n");
          
            //Added for [Request]<BoxDocument>fsync after updating status file 
            int fd=open(path.c_str(),O_RDONLY); 
            if(fd < 0)
            {
                DEBUGL1("CDocument::ChangeStatus::open on directory failed with errno %d\n",errno);
                return STATUS_FAILED;
            }
            else { 
                if(fsync(fd) < 0)
                {
                    DEBUGL1("CDocument::ChangeStatus::fsync on directory failed with errno %d\n",errno);
                    if(errno == ENOSPC)
                    {
                        
                        DEBUGL1("CDocument::ChangeStatus::no space left on the device\n");
                        close(fd);
                        return STATUS_DISK_FULL;
                    }
                    close(fd);
                    return STATUS_FAILED;
                }
            }
            close(fd);
            DEBUGL4("Document::ChangeStatus::Exit\n");
            return STATUS_OK;
        }

        Status CDocument::InitializeStatus() 
        {
            DocStatus current;
            if(GetStatus(current) != STATUS_OK) 
            {
                DEBUGL1("CDocument::InitializeStatus::getting document status is failed\n");
                return STATUS_FAILED;
            }

            if((current==CREATING)||(current==DELETING))
            {
                if(ChangeStatus(WAITING)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::InitializeStatus: Change status to Waiting failed for Document<%s>",m_DocumentName.c_str());
                    return STATUS_FAILED;																		
                }							
            }
            else if(current==EDITING)
            {	
                if(ChangeStatus(READY)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::InitializeStatus: Change status to Ready failed for Document<%s>",m_DocumentName.c_str());
                    return STATUS_FAILED;																									
                }
            }	
            else if(current == RESERVING) { //On Initialize, change status from RESERVING to READY. Request: GB6104
                if(ChangeStatus(READY) != STATUS_OK)
                {
                    DEBUGL1("CDocument::InitializeStatus:ChangeStatus from Reserving to Ready failed for Document<%s>",m_DocumentName.c_str());
                    return STATUS_FAILED;																									
                }
            }
            else 			
            {
                while(current==USING)
                {	
                    if(EndUsing()!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::InitializeStatus:EndUsing failed for Document<%s>",m_DocumentName.c_str());
                        return STATUS_FAILED;																		
                    }
                    if(GetStatus(current) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::InitializeStatus::getting document status is failed\n");
                        return STATUS_FAILED;
                    }
                }
            }				
            return STATUS_OK;
        }

        Status CDocument::EndCreating() {
            DEBUGL4("CDocument:: Enter EndCreating\n");
            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::EndCreating::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st != CREATING) {
                DEBUGL1("CDocument::EndCreating::Document is NOT CREATING\n");
                return STATUS_FAILED;
            }
            if(ChangeStatus(READY) != STATUS_OK) {
                DEBUGL1("CDocument::EndCreating::ChangeStatus to Ready failed\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CDocument::Use() {
            DEBUGL4("CDocument:: Enter Use\n");					

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            Status sdf;

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::Use::Document is NOT USING\n");						
                return STATUS_FAILED;
            }
            if(st == READY || st == RESERVING)//Use() can be used to change from RESERVING to USING. Request: GB6104 
            {
				Status stat = ChangeStatus(USING);
                if(stat != STATUS_OK) 
                {
                    DEBUGL1("CDocument::Use::ChangeStatus failed\n");						
                    return stat;
                }
                // count user
                CString path = Utility::GetResourcePath(m_BoxBasePath, 
                        m_BoxNumber,
                        m_FolderName,
                        m_DocumentName) + "/";
                PropertyMap.clear();
                PropertyMap.insert(pair::value_type("count","1"));
                sdf = Utility::SetProperties(path, "documentproperties.xml", PropertyMap);
                if(sdf != STATUS_OK)
					 {
						 Status stat = ChangeStatus(READY);
						 if(stat != STATUS_OK) 
						 {
							 DEBUGL1("CDocument::Use::Changing Document status to Ready Failed\n");
							 return stat;
						 }
						 return sdf;
					 }
            } else if(st == USING) {
                // get users
                CString path = Utility::GetResourcePath(m_BoxBasePath, 
                        m_BoxNumber,
                        m_FolderName,
                        m_DocumentName) + "/";
                CString value;
                if(Utility::GetProperty(path, "documentproperties.xml", "count",value) != STATUS_OK) {
                    DEBUGL1("CDocument::Use::Getting property to %s is failed\n", path.c_str());
                    return STATUS_FAILED;
                }
                // TODO: error check
                int count;
                std::istringstream iss(value);
                iss >> count;
                count++;
                std::ostringstream oss;
                oss << count;
                PropertyMap.clear();
                PropertyMap.insert(pair::value_type("count",oss.str()));
                sdf = Utility::SetProperties(path, "documentproperties.xml", PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                        DEBUGL1("CDocument::Use::Setting property to %s is failed because disk is Full\n", path.c_str());

					else
						DEBUGL1("CDocument::Use::Setting property to %s is failed\n", path.c_str());
                    return sdf;
                }
            } else {
                DEBUGL1("CDocument::Use::Document is NOT READY, RESERVING or USING\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument:: Exit Use\n");						
            return STATUS_OK;
        }

        Status CDocument::EndUsing() {
            DEBUGL4("CDocument:: Enter EndUsing\n");				

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            Status sdf;

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::EndUsing::Document is NOT USING\n");						
                return STATUS_FAILED;
            }
            if(st != USING) {
                DEBUGL1("CDocument::EndUsing::Document is NOT USING\n");
                return STATUS_FAILED;
            }
            // get users
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            DEBUGL8("CDocument:: EndUsing path = (%s)\n",path.c_str());						
            CString value;
            if(Utility::GetProperty(path, "documentproperties.xml", "count",value) != STATUS_OK) {
                DEBUGL1("CDocument::EndUsing::Setting property to %s is failed\n", path.c_str());
                return STATUS_FAILED;
            }
            // TODO: error check
            int count;
            std::istringstream iss(value);
            iss >> count;
            count--;
            DEBUGL8("CDocument:: EndUsing count = (%d)\n",count);						
            if(count > 0) 
            {
                std::ostringstream oss;
                oss << count;
                PropertyMap.clear();
                PropertyMap.insert(pair::value_type("count",oss.str()));
                sdf = Utility::SetProperties(path, "documentproperties.xml", PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::EndUsing::Setting property to %s is failed because Disk is Full\n", path.c_str());
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::EndUsing::Setting property to %s is failed\n", path.c_str());
                    return STATUS_FAILED;
                }
            } 
            else if(count == 0) 
            {
                PropertyMap.clear();
                PropertyMap.insert(pair::value_type("count","0"));
                sdf = Utility::SetProperties(path, "documentproperties.xml", PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::EndUsing::Setting property to %s is failed because Disk is Full\n", path.c_str());
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::EndUsing::Setting property to %s is failed\n", path.c_str());
                    return STATUS_FAILED;
                }						
                if(ChangeStatus(READY) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::EndUsing::Changing Document status to Ready Failed\n");
                    return STATUS_FAILED;
                }
            } else if(value != ""){
                DEBUGL1("CDocument::EndUsing::Document count is invalid\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument:: Exit EndUsing\n");						
            return STATUS_OK;
        }

        Status CDocument::Reserve() {
            DEBUGL4("CDocument:: Enter Reserve\n");					

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::Reserve::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st == READY) 
            {
                if(ChangeStatus(RESERVING) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::Reserve::ChangeStatus to RESERVING failed\n");						
                    return STATUS_FAILED;
                }
            } else if(st == RESERVING) {
                DEBUGL1("CDocument::Reserve::Document is already in RESERVING\n");
                return STATUS_FAILED;
            } else {
                DEBUGL1("CDocument::Reserve::Document is NOT READY or USING\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument:: Exit Reserve\n");						
            return STATUS_OK;
        }

        Status CDocument::EndReserving() {
            DEBUGL4("CDocument:: Enter EndReserving\n");				

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::EndReserving::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st != RESERVING) {
                DEBUGL1("CDocument::EndReserving::Document is NOT in RESERVING state\n");
                return STATUS_FAILED;
            }
            if(ChangeStatus(READY) != STATUS_OK) 
            {
                DEBUGL1("CDocument::EndReserving::ChangeStatus to to READY Failed\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument:: Exit EndReserving\n");						
            return STATUS_OK;
        }

        Status CDocument::Edit() 
        {
            DEBUGL4("CDocument::Edit: Enter\n");
            DEBUGL8("CDocument::Edit: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());
            Status sdf;
            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::Edit::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st == EDITING) 
            {
                DEBUGL1("CDocument::Edit: Document is being used\n");
                return STATUS_USER_EDITING;
            }						
            if(st != READY) 
            {
                DEBUGL1("CDocument::Edit: Document is NOT in READY state\n");
                return STATUS_FAILED;
            }

            if(ChangeStatus(EDITING) != STATUS_OK) 
            {
                DEBUGL1("CDocument::Edit: ChangeStatus to EDITING failed\n");
                return STATUS_FAILED;
            }				

            //Original doc path 
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";

            //check if the session-id property if set read it and use it else set it to the document.
            CString val;
            CString resourceKey=from;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", val)!=STATUS_OK)
            {
                DEBUGL2("CDocument::Edit: GetProperty of sessionID failed\n");
                val.clear();
            }	
            if(val.empty())
            {
                sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", m_sessionID);
                if(sdf != STATUS_OK)
                {	
                    if(ChangeStatus(READY) != STATUS_OK)
                        DEBUGL1("CDocument::Edit: ChangeStatus to READY failed\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::Edit: SetProperty of sessionID failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::Edit: SetProperty of sessionID failed\n");

                    return STATUS_FAILED;
                }	
            }
            /*Read the UUID from documentproperties.xml*/
            CString WorkspaceDocName("");
            if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName, "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
            {
                DEBUGL1("CDocument::Edit: GetProperty of WorkspaceDocName failed\n");
                return STATUS_FAILED;
            }


            //Workspace doc path
            CString newDocName;
            Status rst;
            newDocName = m_sessionID + "_" + WorkspaceDocName;
            CString to = WORKSPACE_PATH + newDocName+"/";
            Status ds;
            DEBUGL8("CDocument::Edit: to (%s)\n", to.c_str());
            if(Utility::ResourceExist(to)) 
            {
                DEBUGL8("CDocument::Edit: Work space document already exists.. so removing\n");
                if(ci::operatingenvironment::Folder::Remove(to, true) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::Edit: Failed to remove workspace document\n");
                    if(ChangeStatus(READY) != STATUS_OK) 
                        DEBUGL1("CDocument::Edit: ChangeStatus to READY failed\n");															
                    return STATUS_FAILED;
                }
            }
            ds = ci::operatingenvironment::Folder::CopyDir(from.c_str(),to.c_str());
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::Edit:Copying document to Workspace returned %d Error\n",ds);
                if(ChangeStatus(READY) != STATUS_OK) 
                    DEBUGL1("CDocument::Edit: ChangeStatus to READY failed\n");							
                //remove the partially created Document in work space upon failure
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Edit: Failed to remove half created folder\n");
                return ds;							
            }

            resourceKey = WORKSPACE_PATH + newDocName+"/";
            //Save the source document path
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
            PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
            PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
            PropertyMap.insert(pair::value_type("srcDocumentName",m_DocumentName));
            sdf = Utility::SetProperties(resourceKey, "documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                //remove the created item upon failure
                rst = Utility::RemoveResource(resourceKey);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Edit: Failed to remove half created folder\n");
                if(ChangeStatus(READY) != STATUS_OK)
                    DEBUGL1("CDocument::Edit: ChangeStatus to READY failed\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::Edit: SetProperties failed because Disk is Full\n");

                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::Edit: SetProperties failed\n");

                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        void CDocument::WorkSpaceInit()
        {
            CString wrkpath=WORKSPACE_PATH;
            wrkpath = wrkpath;

            CString clippath=CLIPBOARD_PATH;
            clippath = clippath;

            DEBUGL8("CDocument::WorkSpaceInit::m_BoxBasePath<%s>,wrkpath<%s>,clipPath<%s>\n",m_BoxBasePath.c_str(),wrkpath.c_str(),clippath.c_str());
            size_t w=m_BoxBasePath.find(wrkpath);
            size_t c=m_BoxBasePath.find(clippath);
            /*Read UUID from documentproperties.xml*/
            CString WorkspaceDocName("");
            if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName, "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
            {
                DEBUGL1("CDocument::WorkSpaceInit: GetProperty of WorkspaceDocName failed\n");
            }

            if((w==CString::npos)&&(c==CString::npos))
            {
		    //Workspace doc path
                CString newDocName;
                newDocName = m_sessionID + "_" + WorkspaceDocName;
                //Update the document path to the Workspace. So that any further operations happen on 
                //the delta document
                m_BoxBasePath = wrkpath;
                m_BoxNumber = "";
                m_FolderName = "";
                m_DocumentName = newDocName;						
                DEBUGL8("CDocument::WorkSpaceInit::m_BoxBasePath<%s>,m_BoxNumber<%s>,m_FolderName<%s>,m_DocumentName<%s>\n",m_BoxBasePath.c_str(),m_BoxNumber.c_str(),m_FolderName.c_str(),m_DocumentName.c_str());						
            }
        }

        void CDocument::RevertPaths(CString basepath,CString boxNumber,CString folderName,CString docName)
        {
            DEBUGL8(" CDocument::RevertPaths:: basepath (%s) boxnumber (%s) foldername(%s) docname (%s)\n",
                    basepath.c_str(),boxNumber.c_str(), folderName.c_str(), docName.c_str());
            CString wrkpath=WORKSPACE_PATH;
            DEBUGL8(" CDocument::RevertPaths:: m_basepath (%s) m_boxnumber (%s) m_foldername(%s) m_docname (%s)\n",
                    m_BoxBasePath.c_str(),m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());					
            if(m_BoxBasePath == wrkpath)
            {
                m_BoxBasePath = basepath;
                m_BoxNumber = boxNumber;
                m_FolderName = folderName;
                m_DocumentName = docName;						
                DEBUGL8("CDocument::RevertPaths: Paths reverted to original\n");						
            }
        }

        void CDocument::ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid)
        {
            DEBUGL1("/n CDocument::ErrorFileCreation: Entered \n");
            Status retStatus;
	    CString sCurrDirPath = Utility::GetTmpPath();
            FilePtr fPtr = NULL;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> binFolder = NULL;

            //Create a file indicating the Status to be not Status Ok
            binFolder= ci::operatingenvironment::Folder::Bind(sCurrDirPath);
            if(!binFolder)
                DEBUGL2("CDocument::ErrorFileCreation::Folder Binding Failed\n");
            fPtr = File::CreateFile(filename,binFolder,"w");
            if(fPtr)
                DEBUGL8(" CDocument::ErrorFileCreation::File Created Successfully\n");

            if(shmpid) {
                retStatus = shmpid->Destroy();
                if(retStatus!=STATUS_OK)
                    DEBUGL2(" CDocument::ErrorFileCreation: Failed to Destroy Shared Segment Cut Prog Name \n");
            }
        }

        Status CDocument::Save() 
        {
            DEBUGL4("CDocument::Save: Enter\n");
            DEBUGL8("CDocument::Save: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Create a temporary save opertion in respective box/folder. This indicates that the save is in progress.
            CString savepath;
            if(m_FolderName.empty())
                savepath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber);
            else
                savepath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber, m_FolderName);

            DEBUGL8("CDocument::Save::savepath = (%s)\n", savepath.c_str());

            if(Utility::CreateUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::Save: Unable to create the file\n");

            //Initialize WorkSpace
            WorkSpaceInit();

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::Save::GetStatus failed\n");
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to delete the file\n");

                return STATUS_FAILED;
            }
            if(st != EDITING) 
            {
                DEBUGL1("CDocument::Save: Document is NOT EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to delete the file\n");

                return STATUS_FAILED;
            }


            //Workspace Doc path
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString curBoxBasePath(m_BoxBasePath);
            CString curBoxNumber(m_BoxNumber);
            CString curFolderName(m_FolderName);
            CString curDocumentName(m_DocumentName);

            //Original Document Path
            CString resourceKey = from;
            CString val;
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxBasePath", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                return STATUS_FAILED;
            }
            m_BoxBasePath = val;
            val.clear();
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxNumber", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                return STATUS_FAILED;
            }
            m_BoxNumber = val;
            val.clear();	
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcFolderName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                return STATUS_FAILED;
            }
            m_FolderName = val;
            val.clear();		
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcDocumentName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                return STATUS_FAILED;
            }
            m_DocumentName = val;
            val.clear();	
            //BoxDocument copies workspace Document (WD) to the Box/Folder of original Document (OD). Add suffix to the folder name of WD. 
            //The status of WD should be creating.
            //OD : folder name=original status=editing
            //WD : folder name=original_suffix status=creating					
            Status rst;
            CString wtoos = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "_original_suffix/" ;
            Status status=ci::operatingenvironment::Folder::CopyDir(resourceKey,wtoos);						
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::Save: Moving document from Workspace failed\n");
                rst = Utility::RemoveResource(wtoos);
                if(rst != STATUS_OK)
                    DEBUGL2("CDocument::Save: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }
            status = ci::operatingenvironment::File::MoveFile(wtoos + "/editing.sts", wtoos + "/creating.sts");
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::Save: Failed to move to deleting\n");
                rst = Utility::RemoveResource(wtoos);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Save: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            //BoxDocument changes the folder name of OD.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original_suffix status=creating
            CString origDoc = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString otoos =  Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "_original_suffix_2";
            status=ci::operatingenvironment::Folder::MoveDir(origDoc, otoos);	
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::Save: Moving document from Workspace failed\n");
                rst = Utility::RemoveResource(otoos);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Save: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            //BoxDocument changes the folder name of WD to original folder name.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original status=creating
            CString originalDoc = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName);
            status=ci::operatingenvironment::Folder::MoveDir(wtoos,originalDoc);	
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::Save: Moving document from Workspace failed\n");
                rst = Utility::RemoveResource(originalDoc);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Save: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            //BoxDocument changes the status of WD to ready.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original status=ready
            status = ci::operatingenvironment::File::MoveFile(originalDoc + "/creating.sts", originalDoc + "/ready.sts");
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::Save: Failed to move to deleting\n");
                rst = Utility::RemoveResource(originalDoc);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::Save: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            //BoxDocument deletes OD.
            //OD : folder name=original_suffix_2 status=deleting
            //WD : folder name=original status=ready
            status = ci::operatingenvironment::Folder::Remove(otoos, true);
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::Save: Failed to move to deleting\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::Save: Unable to create the file\n");


                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            // Dont delete clipboard documents after Save Change - done for Fixing FR-545	
            //Remove the properties
            resourceKey= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/";
	    CString key[9] = {"srcBoxBasePath","srcBoxNumber","srcFolderName","srcDocumentName","IsImagedataPresent","IsSubsamplingdataPresent","IsThumbnaildataPresent","sessionID","cutDocument"};

	    std::map<CString, CString> WebDAVPropertyMap;
		typedef std::map<CString, CString> pair;
		for(int i=0;i<9;i++)
		{
			WebDAVPropertyMap.insert(pair::value_type(key[i].c_str(),""));
		}
		//Update ModifiedDate
		WebDAVPropertyMap.insert(pair::value_type("lastModifiedDate",Utility::GetUnixTime()));
		WebDAVPropertyMap.insert(pair::value_type("lastAccessDate",Utility::GetUnixTime()));
		if(SetWebDAVProperties(WebDAVPropertyMap) != STATUS_OK)
		{
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
				rst = Utility::RemoveResource(originalDoc);
				if(rst != STATUS_OK)
					DEBUGL1("CDocument::Save: Failed to remove half created folder\n");

				if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
					DEBUGL2("CDocument::Save: Unable to create the file\n");

				return STATUS_FAILED;
		}
            //To Fix FR_5121. Change the clipboard document properties srcBoxBasePath to /storage/box/EFiling
            //and set srcDocument name to orginal document name.
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();						
            CString clipbrdDocName = CLIPBOARD_PATH + curDocumentName +"/";
            if(Utility::ResourceExist(clipbrdDocName))
            {

                DEBUGL8("CDocument::Save: clipbrdDocName (%s) m_BoxBasePath (%s) m_DocumentName(%s)\n", 
                        clipbrdDocName.c_str(), m_BoxBasePath.c_str(), m_DocumentName.c_str());
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
                PropertyMap.insert(pair::value_type("srcDocumentName",m_DocumentName));

                Status sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
                if(sdf != STATUS_OK)
                {
                    rst = Utility::RemoveResource(originalDoc);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::Save: Failed to remove half created folder\n");
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::Save: Unable to create the file\n");
                    //revert back to original
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::Save: SetProperties failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::Save: SetProperties failed\n");

                    return STATUS_FAILED;
                }		
            }
            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

            if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::Save: Unable to create the file\n");													

            DEBUGL4("CDocument::Save: Exit\n");								
            return STATUS_OK;
        }

        Status CDocument::SaveAs(CString new_name, CString resourcebasepath) 
        {
            DEBUGL4("CDocument::SaveAs: Enter\n");
            DEBUGL8("CDocument::SaveAs: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());
            Status sdf;

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Create a temporary save opertion in respective box/folder. This indicates that the save is in progress.
            CString savepath;
            if(m_FolderName.empty())
                savepath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber);
            else
                savepath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber, m_FolderName);

            DEBUGL8("CDocument::SaveAs::savepath = (%s)\n", savepath.c_str());

            if(Utility::CreateUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::SaveAs: Unable to create the file\n");

            //Initialize WorkSpace
            WorkSpaceInit();

            // check current status
            DocStatus st;
            Status rst;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::SaveAs::GetStatus failed\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }
            if(st != EDITING) 
            {
                DEBUGL1("CDocument::SaveAs: Document is NOT EDITING\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }

            //Workspace Doc path
            CString resourceKey = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString curBoxBasePath(m_BoxBasePath);
            CString curBoxNumber(m_BoxNumber);
            CString curFolderName(m_FolderName);
            CString curDocumentName(m_DocumentName);

            //Properties set on Workspace Doc
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","srcBoxBasePath", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }		
            m_BoxBasePath = val;
            val.clear();
            if(proputils::GetProperty(curBoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","srcBoxNumber", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }		
            m_BoxNumber = val;
            val.clear();	
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,m_FolderName,m_DocumentName,"","srcFolderName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }		
            m_FolderName = val;
            val.clear();		
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,m_DocumentName,"","srcDocumentName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }		
            m_DocumentName = val;
            val.clear();	

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            Status status;
            //New document 
            CString oldDocName = m_DocumentName;						
            m_DocumentName = new_name;
            CString to = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            if(!Utility::ResourceExist(to))
            {
               if(new_name != oldDocName)
               {
                  m_DocumentName = oldDocName;
            //Change the original document state to READY
            if(this->ChangeStatus(READY) != STATUS_OK) 
            {
                DEBUGL1("CDocument::SaveAs: ChangeStatus failed\n");						

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		

            //Remove the properties
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath", ""));						
            PropertyMap.insert(pair::value_type("srcBoxNumber", ""));						
            PropertyMap.insert(pair::value_type("srcFolderName", ""));						
            PropertyMap.insert(pair::value_type("srcDocumentName", ""));						
            PropertyMap.insert(pair::value_type("IsImagedataPresent", ""));						
            PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent", ""));
            PropertyMap.insert(pair::value_type("IsThumbnaildataPresent", ""));
            PropertyMap.insert(pair::value_type("sessionID", ""));
            PropertyMap.insert(pair::value_type("cutDocument", ""));
            PropertyMap.insert(pair::value_type("lastAccessDate", Utility::GetUnixTime()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", Utility::GetUnixTime()));						
            CString oPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/";

            sdf = Utility::SetProperties(oPath,"documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }

                return STATUS_FAILED;
            }		

            //Set New Document name on the WorkSpace Doc
            sdf = proputils::SetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcDocumentName", new_name);
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to delete the file\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }

                return STATUS_FAILED;
            }	
               }
            CString oldDocName = m_DocumentName;						
            m_DocumentName = new_name;
            CString to = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            }
            //Folder::MoveDir will not work on interdevice (i.e /work to /storage). 
            //So remove original document then move the workspace document to storage
            //Status status;
            else if(Utility::ResourceExist(to))
            {
                DEBUGL8("CDocument::SaveAs: New name = (%s), oldname = (%s)\n", new_name.c_str(), oldDocName.c_str());

                if(new_name == oldDocName)
                {
                    status=ci::operatingenvironment::Folder::Remove(to,true);	
                    if((status!=STATUS_OK)) 
                    {
                        DEBUGL1("CDocument::SaveAs: Deleting document from Workspace failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                        if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                            DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                        return status;
                    }
                }
                else
                {
                    DEBUGL1("CDocument::SaveAs: Document with same name exist\n");

                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                    return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
                }
            }


            status=ci::operatingenvironment::Folder::MoveDir(resourceKey,to);	
            if((status!=STATUS_OK)) 
            {
                DEBUGL1("CDocument::SaveAs: Moving document from Workspace failed\n");
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::SaveAs: Failed to remove half created folder\n");	

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return status;
            }

            //Change the state to READY
            if(this->ChangeStatus(READY) != STATUS_OK) 
            {
                DEBUGL1("CDocument::SaveAs: ChangeStatus failed\n");						
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::SaveAs: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            //Set the new name
            sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","documentName",new_name);
            if(sdf != STATUS_OK)
            {	
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::SaveAs: Failed to remove half created folder\n");

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");

                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SaveAs: Setting the new name on document failed\n");

                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::SaveAs: Setting the new name on document failed\n");

                return STATUS_FAILED;							
            }
            //Set new WorkspaceDocName
            CString WorkspaceDocName = CUUID().toString();
            sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","WorkspaceDocName",WorkspaceDocName);
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::SaveAs: Failed to remove half created folder\n");
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SaveAs: Setting the WorkspaceDocName on document failed because Disk is Full\n");

                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::SaveAs: Setting the WorkspaceDocName on document failed\n");
                return STATUS_FAILED;
            }

            //Remove the properties
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath", ""));						
            PropertyMap.insert(pair::value_type("srcBoxNumber", ""));						
            PropertyMap.insert(pair::value_type("srcFolderName", ""));						
            PropertyMap.insert(pair::value_type("srcDocumentName", ""));						
            PropertyMap.insert(pair::value_type("IsImagedataPresent", ""));						
            PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent", ""));
            PropertyMap.insert(pair::value_type("IsThumbnaildataPresent", ""));
            PropertyMap.insert(pair::value_type("sessionID", ""));
            PropertyMap.insert(pair::value_type("cutDocument", ""));
            PropertyMap.insert(pair::value_type("lastAccessDate", Utility::GetUnixTime()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", Utility::GetUnixTime()));						
            resourceKey= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/";

            sdf = Utility::SetProperties(resourceKey,"documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SaveAs: SetProperties failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::SaveAs: Unable to create the file\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::SaveAs: SetProperties failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

                return STATUS_FAILED;
            }		

            //To Fix FR_5121. Change the clipboard document properties srcBoxBasePath to /storage/box/EFiling
            //and set srcDocument name to orginal document name.
            PropertyMap.clear();						
            CString clipbrdDocName = CLIPBOARD_PATH + curDocumentName +"/";
            if(Utility::ResourceExist(clipbrdDocName))
            {
                DEBUGL8("CDocument::SaveAs: clipbrdDocName (%s) m_BoxBasePath (%s) m_DocumentName(%s)\n", 
                        clipbrdDocName.c_str(), m_BoxBasePath.c_str(), m_DocumentName.c_str());
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
                PropertyMap.insert(pair::value_type("srcDocumentName",m_DocumentName));

                sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
                if(sdf != STATUS_OK)
                {
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::SaveAs: Failed to remove half created folder\n");

                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::SaveAs: Unable to create the file\n");
                    //revert back to original
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::SaveAs: SetProperties failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::SaveAs: SetProperties failed\n");

                    return STATUS_FAILED;
                }		
            }	
            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);						

            if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::SaveAs: Unable to create the file\n");													

            DEBUGL4("CDocument::SaveAs: Exit\n");	
            return STATUS_OK;
        }

        Status CDocument::CancelEdit() 
        {

            DEBUGL4("CDocument::CancelEdit: Enter\n");	 
            DEBUGL8("CDocument::CancelEdit: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Initialize WorkSpace
            WorkSpaceInit();

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::CancelEdit::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st != EDITING) 
            {
                DEBUGL1("CDocument::CancelEdit:Document is NOT EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }

            //Workspace Doc path
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString curBoxBasePath(m_BoxBasePath);
            CString curBoxNumber(m_BoxNumber);
            CString curFolderName(m_FolderName);
            CString curDocumentName(m_DocumentName);

            //Original Document Path
            CString resourceKey = from;
            CString val;
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxBasePath", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            m_BoxBasePath = val;
            val.clear();
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxNumber", val) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            m_BoxNumber = val;
            val.clear();	
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcFolderName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            m_FolderName = val;
            val.clear();		
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcDocumentName",val ) != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            m_DocumentName = val;
            val.clear();	

            if(ChangeStatus(READY) != STATUS_OK) 
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		
            Status st1 = ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true);
            if(st1 !=STATUS_OK) 
            {
                DEBUGL1("CDocument::CancelEdit: DeleteResource <%s> is failed\n", resourceKey.c_str());
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return st1;
            }

            // Dont delete clipboard documents after CancelEdit Change - done for Fixing FR-545	
            //Remove the properties
            resourceKey= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/";
            SetWebDAVProperty("srcBoxBasePath", "");						
            SetWebDAVProperty("srcBoxNumber", "");						
            SetWebDAVProperty("srcFolderName", "");						
            SetWebDAVProperty("srcDocumentName", "");						
            SetWebDAVProperty("IsImagedataPresent", "");						
            SetWebDAVProperty("IsSubsamplingdataPresent", "");
            SetWebDAVProperty("IsThumbnaildataPresent", "");

            Status sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", "");
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }

                return STATUS_FAILED;
            }
            sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","cutDocument", "");
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }
                return STATUS_FAILED;
            }		

            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);						

            DEBUGL4("CDocument::CancelEdit: Exit\n");
            return STATUS_OK;
        }


        Status CDocument::ReCreate()
        {
            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::ReCreate::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            if(st != READY) 
            {
                DEBUGL1("CDocument::ReCreate: Document is NOT READY\n");
                return STATUS_FAILED;
            }
            if(ChangeStatus(CREATING) != STATUS_OK)
                return STATUS_FAILED;

            return STATUS_OK;

        }
        Status CDocument::GetPage(int pageno, PageRef &page) {
				DEBUGL4("CDocument::GetPage: Enter\n");
		//For PageLogBox PAGE_LIMIT
		CString boxbasepath_new("");
		int pos;
		pos =  m_BoxBasePathOrg.rfind("/");
		boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
std::ostringstream oss;
			oss << pageno;

			//make a local copy of the member variables
			CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			boxbasepath_org = m_BoxBasePath;
			boxnumber_org = m_BoxNumber;
			folderName_org = m_FolderName;
			docName_org = m_DocumentName;

			DocStatus st;
		if(!m_insertblankpage)	    
		{
			DEBUGL1("CDocument::GetPage:: pageno = (%d) (%s)\n", pageno, boxbasepath_new.c_str());
			if(boxbasepath_new == "PageLogBoxes")
			{
				DEBUGL8("CDocument::GetPage::Entered in the check\n");
				if((static_cast<unsigned>(pageno) > CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
				{
					DEBUGL1("CDocument::GetPage::Page Limit reached for PAGELOGBOXES\n");
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}
				else
					DEBUGL8("CDocument::GetPage::Entered in the check1\n");

			}
			else if((pageno <= 0) || (static_cast<unsigned>(pageno) > CBoxDocument::PAGE_LIMIT)) {
				DEBUGL1("CDocument::GetPage::Invalid page number %d\n", pageno);
				return STATUS_FAILED;
			}
			if(this->GetStatus(st) != STATUS_OK) {
				DEBUGL1("CDocument::GetPage::Getting document status is failed\n");
				return STATUS_FAILED;
			}
			if(st == DELETING) {
				DEBUGL1("CDocument::GetPage::Document is deleting\n");
				return STATUS_FAILED;
			}

			if(st == EDITING)
			{	
				//check if the session-id property set on the document is same as the current sessionID
				CString val;
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", val)!=STATUS_OK)
				{
					DEBUGL2("CDocument::GetPage: GetProperty of sessionID failed\n");
					val.clear();
				}	
				DEBUGL8("CDocument::GetPage: val = (%s),  m_sessionID = (%s)\n",val.c_str(),(m_sessionID).c_str());
				if(val==m_sessionID)
				{	
					//Initialize WorkSpace
					DEBUGL8("CDocument::GetPage: sessionIDs are same.. call WorkSpaceInit\n");
					WorkSpaceInit();
				}	
			}
		}
		else 
			WorkSpaceInit();
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);

            FL_PAGE_MAN_TBL systemfile;
            FL_PAGE_MAN_TBL thumbnail;
            FL_PAGE_MAN_TBL subsampling;
            memset((FL_PAGE_MAN_TBL *)&(systemfile),'\0',sizeof(FL_PAGE_MAN_TBL));
            memset((FL_PAGE_MAN_TBL *)&(subsampling),'\0',sizeof(FL_PAGE_MAN_TBL));			
            memset((FL_PAGE_MAN_TBL *)&(thumbnail),'\0',sizeof(FL_PAGE_MAN_TBL));

            DEBUGL8("CDocument::GetPage: m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());						

            // check SystemFile
            CString systemfilepath = Utility::GetResourcePath(path + "/Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(m_SystemDataFile, systemfilepath) != STATUS_OK) {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            DEBUGL8("CDocument::GetPage:m_SystemDataFile.sFileMan.hFlPageNum<%d>,pageno<%d>",m_SystemDataFile.sFileMan.hFlPageNum,pageno);						
            if(m_SystemDataFile.sFileMan.hFlPageNum < pageno) {
                DEBUGL1("CDocument::GetPage::Page %d doesn't exist\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            systemfile = m_SystemDataFile.sPageManTbl[pageno - 1];

            systemfilepath = Utility::GetResourcePath(path + "/Thumbnail/" + SYSTEMFILE);
            if(Utility::ResourceExist(systemfilepath)) {
                systemfilepath = Utility::GetResourcePath(systemfilepath);
                if(OpenSystemDataFile(m_ThumbnailSystemDataFile, systemfilepath) != STATUS_OK) {
                    DEBUGL1("CDocument::GetPage::OpenSystemDataFile Failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return STATUS_FAILED;
                }
            }

            if(m_ThumbnailSystemDataFile.sFileMan.hFlPageNum >= pageno) {
                thumbnail = m_ThumbnailSystemDataFile.sPageManTbl[pageno - 1];
            }

            systemfilepath = Utility::GetResourcePath(path + "/Subsampling/" + SYSTEMFILE);
            if(Utility::ResourceExist( systemfilepath)) {
                systemfilepath = Utility::GetResourcePath(systemfilepath);
                if(OpenSystemDataFile(m_SubsamplingSystemDataFile, systemfilepath) != STATUS_OK) {
                    DEBUGL1("CDocument::GetPage::OpenSystemDataFile Failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return STATUS_FAILED;
                }
            }

            if(m_SubsamplingSystemDataFile.sFileMan.hFlPageNum >= pageno) {
                subsampling = m_SubsamplingSystemDataFile.sPageManTbl[pageno - 1];
            }

            Status ret;
            try
            {
                page = new CPage(pageno, path, m_BoxBasePath);

                if(!page)
                {
                    DEBUGL1("CDocument::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CPage*>(page.operator->())->LoadProperties(systemfile,subsampling,thumbnail);
                if(ret != STATUS_OK) {
                    DEBUGL1("CDocument::GetPage::Loading Page is failed\n");
                    page = NULL; // release
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return ret;
                }	
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
            }
            catch(exception& e)
            {
                DEBUGL8("CDocument::GetPage::Loadin Page failed because an exception  was caught:(%s)\n",e.what());
                page = NULL;
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
				DEBUGL4("CDocument::GetPage: Exit\n");
            return STATUS_OK;
        }
        Status CDocument::copySystemFile(FL_FILE_MAN_FILE system,CString pageType)
        {
            DEBUGL4("CDocument::copySystemFile: Enter\n");
            // Write SystemDataFile
            //changed the $EB2/tmp path to "/work/CI/tmp/"

            CString tmppath = Utility::GetCITmpPath();
            tmppath += m_sessionID +"_" + m_DocumentName + "_"+pageType+"_" + CString(SYSTEMFILE);

            DEBUGL4("CDocument::copySystemFile: tmppath (%s)\n", tmppath.c_str());

            ByteStreamRef bs = File::Open(tmppath, "w");
            if(bs)
            {
                bs->WriteN(&system, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
            }
            else
            {
                DEBUGL1("CDocument::copySystemFile bs for %s is empty\n",pageType.c_str());
                return STATUS_FAILED;
            }

            CString uri;
            if(m_FolderName.empty())
            {
                uri = m_BoxBasePath+"/"+ 
                    m_BoxNumber+"/"+
                    m_DocumentName;
            }
            else
            {

                uri = m_BoxBasePath+"/"+ 
                    m_BoxNumber+"/"+
                    m_FolderName+"/"+
                    m_DocumentName;
            }

            CString uriPathToLock = uri + "/";

            uri += "/"+pageType+"/" + CString(SYSTEMFILE);
            DEBUGL6("CDocument::copySystemFile : uri (%s)\n", uri.c_str());
            DEBUGL6("CDocument::copySystemFile : tmppath (%s)\n", tmppath.c_str());
            DEBUGL6("CDocument::copySystemFile : uriPathToLock (%s)\n", uriPathToLock.c_str());

	    int FD = -1;
	    CString locktypefile = pageType + "_systemfilelock";
	    uriPathToLock = uriPathToLock + "." + locktypefile;
	    bool flockType = false;
	    //Skip critical section if the /work/ci/insertblankpageflag exists
	    if(!m_insertblankpage)	    
	    {
		    if(Utility::AcquireLockforSystemfile(uriPathToLock, FD, flockType) != STATUS_OK)
		    {
		   	 DEBUGL1("CDocument::copySystemFile::AcquireLockforSystemfile failed\n");
			 return STATUS_FAILED;
		    }
	    }

            Status ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
	    if(!m_insertblankpage)	    
	    {
		    if(Utility::ReleaseLockforSystemfile(FD) != STATUS_OK){
		    	DEBUGL1("CDocument::copySystemFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
		    	return STATUS_FAILED;
		    }
	    }
            if(ds!= STATUS_OK)
            {
                if(ds == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::copySystemFile::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }
                else
                {
                    DEBUGL1("CDocument::copySystemFile::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CDocument::copySystemFile File::DeleteFile(tmppath) \n");
            File::DeleteFile(tmppath);
            DEBUGL4("CDocument::copySystemFile: Exit\n");
            return STATUS_OK;
        }

        Status CDocument::AppendPageByLink(PageRef page) 
        {
            DEBUGL4("CDocument::AppendPageByLink Enter\n");
            m_bLink = true;
            Status status =  AppendPage(page);
            m_bLink = false;
            DEBUGL4("CDocument::AppendPageByLink Exit\n");						
            return status;
        }		

        Status CDocument::AppendPage(PageRef page) 
        {
            DEBUGL4("CDocument::AppendPage Enter\n");

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;
            DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 1 \n");	
            int total=0;
            if(iSSetsysfileInvoked)
            {
                if(GetPageList(m_PageList) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::AppendPage::GetPageList Failed\n");
                    return STATUS_FAILED;
                }
            }					
                if(this->GetTotalPage(total)!=STATUS_OK)
                {	
                    DEBUGL1("CDocument::AppendPage::Getting total pages failed\n");
                    return STATUS_FAILED;
                }

                DEBUGL8("CDocument::AppendPage::Total pages in the document are %d\n",total);

            uint32 count = 0;
            uint32 pos = 0;
            std::vector<CString> docVec1;
            std::vector<CString> docVec;
            CString boxbasepath_new("");
            pos = m_BoxBasePathOrg.rfind("/");
            boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
            CString resourceKey("");
            CString doctype("");
            CString pagecnt("");
            resourceKey = m_BoxBasePathOrg+ "/" + boxnumber_org +"/";
	    dom::DocumentRef domDocRef;
	    ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
	    pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
	    if (!pHDB)
	    {
		    DEBUGL1("CDocument::AppendPage: Failed to Acquire HierarchicalDB\n");
		    return STATUS_FAILED;
	    }

            if(boxbasepath_new == "ITUTBoxes")
            {
                if(Utility::GetProperty(resourceKey,"boxproperties.xml","documentType",doctype) != STATUS_OK)
                {
                    DEBUGL1("CDocument::AppendPage::Getting documentType property failed\n");
                    return STATUS_FAILED;
                }
                if(doctype == "Confidential" || doctype == "BulletinBoard")
                {

                    if(Utility::GetProperty(resourceKey,"boxproperties.xml","BoxPageCount",pagecnt) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage::Getting confidentialPageCount property failed\n");
                        return STATUS_FAILED;
                    }
                    std::istringstream totalPageSizeStr(pagecnt);
                    totalPageSizeStr >> count;
                    if(count >= CBoxDocument::PAGE_LIMIT)
                    {
                        DEBUGL1("CDocument::AppendPage::Page Limit reached\n");
                        return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                    }
                    count+=1;
                }
            }
            DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 2 \n");	
            //For PageLogBox PAGE_LIMIT   
            if(boxbasepath_new == "PageLogBoxes")
            {
                if((static_cast<unsigned>(total) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
                {
                    DEBUGL1("CDocument::AppendPage::Page Limit reached for PAGELOGBOXES\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }
            }	
            else if(static_cast<unsigned>(total) >= CBoxDocument::PAGE_LIMIT) 
            {
                DEBUGL1("CDocument::AppendPage::Page Limit reached\n");
                return STATUS_MAX_ALLOWED_RESOURCES_REACHED;						
            }

            DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 3 \n");
            DocStatus st;
            Status ret;
            FL_PAGE_MAN_TBL pgsystemfile;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::AppendPage::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!page) {
                DEBUGL1("CDocument::AppendPage::PageRef Is Null Exiting\n");
                return STATUS_FAILED;
            }
            if(st == EDITING)
            {	
                //Initialize WorkSpace
                WorkSpaceInit();
            }
            if(!(st == CREATING || st == EDITING)) {
                DEBUGL1("CDocument::AppendPage::Document is NOT CREATING or EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 4\n");	
            int pageno = total + 1;
            DEBUGL8("CDocument::AppendPage::PAGE LIST COUNT : %d \n, PAGE NO %d\n",total, pageno);
            CString imagepath("");
            int imagepageno=pageno;
            uint64 imgsize;

            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName)+"/";
            std::ostringstream strm;
            CString pageNum = Utility::GetHexadecimalPageNo(pageno);
            CString toXmlFilePath;
            try
            {
                if(m_insertblankpage)
                {
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    toXmlFilePath  = dynamic_cast<CPage*>(page.operator->())->GetBlankPropertyFile();
                    m_insertblankpage = false;
                }
                else
                    toXmlFilePath = path + "/Image/" + "pageproperties_" + pageNum + ".xml";

		CString todomFilePath = path + "/Image/" + "pageproperties_" + pageNum + "_dom";
		if(ci::operatingenvironment::File::Exists(todomFilePath))
		{
			ci::operatingenvironment::File::DeleteFile(todomFilePath);
                        DEBUGL1("CDocument::AppendPage:: Page deleted dom file\n");
		}
		Status ds = pHDB->CreateDocumentFromFile(path+"/Image/", "pageproperties_" + pageNum + "_dom", domDocRef, Utility::GetEB2ROOTPath() + "/bin/pageproperties.xml");
                if((ds==STATUS_DISK_FULL) || ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::AppendPage:Creation of %s Failed\n", path.c_str());
                    return ds;
                }
                DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 5\n");	
                if(m_bLink)
                {
                    DEBUGL8("CDocument::AppendPage:: AddToDocument with file link\n");
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->AddToDocument(pageno, path, m_bLink);
                    m_bLink = false;
                }
                else
                {
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->AddToDocument(pageno, path, false);
                }
                if(ret != STATUS_OK) {
                    DEBUGL1("CDocument::AppendPage:: AddToDocument failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return ret;
                }
                DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 6\n");								

                DEBUGL8("CDocument::AppendPage::IS SYSTEM FILE INVOKED ? %s\n", iSSetsysfileInvoked? "YES" : "NO");
                if(!(iSSetsysfileInvoked))
                {
                    // Update the Image file
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetImage(imagepath);
                    FL_FILE_MAN_FILE systemfile;
                    memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));
                    CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
                    Status openStatus = STATUS_OK;
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 7\n");									
                    openStatus = OpenSystemDataFile(systemfile, systemfilepath);
                    if(!(openStatus == STATUS_OK || openStatus == STATUS_INVALID_URI))	
                    {
                        DEBUGL1("CDocument::AppendPage::OpenSystemDataFile Failed for Image\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                        return openStatus;									
                    }
                    systemfile.sFileMan.hFlPageNum = imagepageno;
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pgsystemfile);	
                    systemfile.sPageManTbl[imagepageno - 1]=pgsystemfile;
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetFileSize(imgsize);
                    systemfile.sFileMan.liFlSize += imgsize;
                    // Update Image file name
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->UpdateImageName(systemfile.sPageManTbl[imagepageno - 1]);
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 8\n");									
                    Status ret=copySystemFile(systemfile,"Image");
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage::copying SystemFile Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 9\n");									
                    m_SystemDataFile = systemfile;

                    // document property
                    m_TotalPage = systemfile.sFileMan.hFlPageNum;
                    SetWebDAVProperty("totalPages", m_TotalPage);

                    m_TotalSize = systemfile.sFileMan.liFlSize;
                    std::ostringstream st;
                    st << m_TotalSize;
                    DEBUGL8("CDocument::AppendPage: totalSize = (%s)\n", st.str().c_str());
                    Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st.str());
                    if(sd != STATUS_OK)
                        DEBUGL1("CDocument::AppendPage: Failed to set the totalSize for the document\n");

                    m_TotalDocSize = m_TotalSize;
                    //Add size of Image, Thumbnail, Subsampling sys data files
                    m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));

                    //Set the following properties on Page
                    int value = systemfile.sPageManTbl[imagepageno-1].sPageComAtr.hInPgMLen;		
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageWidth",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage - SetWebDAVProperty of adjustedImageWidth Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[imagepageno-1].sPageComAtr.hInPgSLen;
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageHeight",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage - SetWebDAVProperty of adjustedImageHeight Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[imagepageno-1].sPageComAtr.hOrientation;								
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("orientation",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage - SetWebDAVProperty of orientation Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[imagepageno-1].sPageComAtr.hAngle;								
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("angle",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage - SetWebDAVProperty of angle Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }							
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 10\n");	
                    //update Subsampling
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetSubsamplingImage(imagepath);
                    FL_FILE_MAN_FILE subsamplingsystemfile;
						  memset(&subsamplingsystemfile, '\0', sizeof(FL_FILE_MAN_FILE));
                    CString subsamplingsystemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
                    openStatus = OpenSystemDataFile(subsamplingsystemfile, subsamplingsystemfilepath) ;
                    if(!(openStatus == STATUS_OK || openStatus == STATUS_INVALID_URI))	
                    {
                        DEBUGL1("CDocument::AppendPage::OpenSystemDataFile Failed for Subsampling\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                        return openStatus;									
                    }
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 11\n");									
                    DEBUGL8("CDocument::AppendPage: Imagepath = (%s)\n",imagepath.c_str());
                    if(!imagepath.empty())
                    {
                        subsamplingsystemfile.sFileMan.hFlPageNum = imagepageno;
                        if(!page)
                        {
                            DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pgsystemfile);	
                        subsamplingsystemfile.sPageManTbl[imagepageno - 1]=pgsystemfile;
                    }
                    //Update Subsampling file name
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->UpdateSubsamplingName(subsamplingsystemfile.sPageManTbl[imagepageno - 1]);
                    ret=copySystemFile(subsamplingsystemfile,"Subsampling");
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage::copying Subsampling SystemFile Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 12\n");									
                    m_SubsamplingSystemDataFile = subsamplingsystemfile;

                    //update Thumbnail
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetThumbnailImage(imagepath);
                    FL_FILE_MAN_FILE thumbnailsystemfile;
						  memset(&thumbnailsystemfile, '\0', sizeof(FL_FILE_MAN_FILE));
                    CString thumbnailsystemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
                    openStatus = OpenSystemDataFile(thumbnailsystemfile, thumbnailsystemfilepath);
                    if(!(openStatus == STATUS_OK || openStatus == STATUS_INVALID_URI))
                    {
                        DEBUGL1("CDocument::AppendPage::OpenSystemDataFile Failed for Thumbnail\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                        return openStatus;									
                    }
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 13\n");									
                    thumbnailsystemfile.sFileMan.hFlPageNum = imagepageno;
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pgsystemfile);	
                    thumbnailsystemfile.sPageManTbl[imagepageno - 1]=pgsystemfile;

                    //Update Thumbnail file name
                    if(!page)
                    {
                        DEBUGL1("CDocument::AppendPage:: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->UpdateThumbnailName(thumbnailsystemfile.sPageManTbl[imagepageno - 1]);
                    ret=copySystemFile(thumbnailsystemfile,"Thumbnail");
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::AppendPage::copying Thumbnail SystemFile Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }
                    DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 14\n");									
                    m_ThumbnailSystemDataFile = thumbnailsystemfile;

                    //Commented to improve performance
                    //SetAllSize(m_TotalDocSize - orgdocsize);
                }
                DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 15\n");								
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::AppendPage::exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }	
            if(UpdateMixedInfoData(page,true)!=STATUS_OK)
            {
                DEBUGL1("CDocument::AppendPage - UpdateMixedInfoData Failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::AppendPage: PERF_APPEND_PAGE 16\n");								

            if(iSSetsysfileInvoked)
                m_PageList.push_back(page);

            //Update ModifiedDate
            SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());
            SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());

            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							

            if(boxbasepath_new == "ITUTBoxes")
            {
                if(doctype == "Confidential" || doctype == "BulletinBoard") {
                    std::map<CString,CString> PropertyMap;
                    typedef  std::map<CString, CString> pair;
                    PropertyMap.clear();
                    CString xmlfile("boxproperties.xml");
                    std::ostringstream oss;
                    oss << count;
                    PropertyMap.insert(pair::value_type("BoxPageCount",oss.str()));
                    Status sdf = Utility::SetProperties(resourceKey,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::AppendPage::SetProperty failed because Disk is Full\n");
                            return STATUS_DISK_FULL;
                        }
                        DEBUGL1("CDocument::AppendPage::SetProperty Failed\n");
                        return STATUS_FAILED;
                    }
                }
            }
            DEBUGL4("CDocument::AppendPage Exit\n");
            return STATUS_OK;
        }

        void CDocument::SetAllSize()
        {
            DEBUGL8("CDocument::SetAllSize Enter\n");
            ostringstream docsize;	
            uint64 wepsize = 0;	
            CString valu;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            if(Utility::GetProperty(propertypath, "documentproperties.xml","docWEPSize", valu) != STATUS_FAILED) 
            {
                wepsize = valu.length()? atoi(valu.c_str()): 0;
            }

            docsize << (m_TotalDocSize + wepsize);
            DEBUGL8("CDocument::SetAllSize::Total Doc Size: %s\n",docsize.str().c_str());
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            PropertyMap.insert(pair::value_type("totalDocSize",docsize.str()));
            if(Utility::SetProperties(propertypath, "documentproperties.xml", PropertyMap) != STATUS_OK)
                //if(SetWebDAVProperty("paperSizeMap", val) != STATUS_OK)
            {
                DEBUGL1("CDocument::SetAllSize - totalDocSize property settting failed\n");
                //return STATUS_FAILED;
            }

        }


        Status CDocument::UpdateMixedInfoData(PageRef page,bool increment)
        {
            if(!page)
            {
                DEBUGL1("CDocument::UpdateMixedInfoData - Empty PageRef\n");
                return STATUS_FAILED;
            }

            //Get the Paper size.
            //If Increment, insert the enum if not present else increment the count
            //If Decrement, decrement the count or remove the enum
            PaperSize eSize;
            try
            {
                if(!page)
                {
                    DEBUGL1("CDocument::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                if(dynamic_cast<CPage*>(page.operator->())->GetPaperSize(eSize)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData - GetPaperSize Failed\n");
                    return STATUS_FAILED;
                }

                CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
                CString val = "";
                std::map<CString, CString> PropertyMap;
		  		CString mapArray[6] = { 
		  						"paperSizeMap", 
								"jobTypeColorMap", 
								"jobTypeMap", 
								"colorModeMap", 
								"horizontalResolutionMap", 
								"verticalResolutionMap" 
							    };
                if((Utility::GetPropertyMaps(propertypath, "documentproperties.xml", PropertyMap, mapArray, 6)) != STATUS_OK)
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData::Getting property maps failed..\n");
                    return STATUS_FAILED;
                }
                val = PropertyMap["paperSizeMap"];
                DEBUGL8("CDocument::UpdateMixedInfoData:Get VAL for paperSizeMap <%s>\n", val.c_str());

                m_PaperSizeMap.clear();
                size_t found1 = val.find_first_of(";");
                while (found1!=string::npos)
                {
                    CString minp = val.substr(0,found1);
                    size_t nf = minp.find(",");
                    string first = minp.substr(0,nf);
                    string second = minp.substr(nf+1);
                    PaperSize eVal;
                    int abc = atoi(first.c_str());
                    eVal = (PaperSize)abc;
                    m_PaperSizeMap.insert(make_pair(eVal,atoi(second.c_str())));
                    val = val.substr(found1+1);
                    found1=val.find_first_of(";");
                }

                std::map<PaperSize,int>::iterator iter = m_PaperSizeMap.find(eSize);
                if(iter != m_PaperSizeMap.end())
                {
                    int count=m_PaperSizeMap[eSize];
                    if(increment)
                        m_PaperSizeMap[eSize]=count+1;
                    else
                    {
                        if(count==1)
                            m_PaperSizeMap.erase(eSize);
                        else
                            m_PaperSizeMap[eSize]=count-1;
                    }
                }
                else
                {
                    if(increment)
                        m_PaperSizeMap.insert(make_pair(eSize,1));
                    else
                        DEBUGL2("CDocument::UpdateMixedInfoData - PaperSize enum not found");
                }

                std::map<PaperSize,int>::iterator paperSizeIter;
                val.clear();
                for(paperSizeIter=m_PaperSizeMap.begin();paperSizeIter!=m_PaperSizeMap.end();paperSizeIter++)
                {
                    std::ostringstream oss1;
                    oss1<<paperSizeIter->first;
                    std::ostringstream oss2;
                    oss2<<paperSizeIter->second;

                    val.append(oss1.str());
                    val.append(",");
                    val.append(oss2.str());
                    val.append(";");
                }

                DEBUGL8("CDocument::UpdateMixedInfoData::Set VAL for paperSizeMap <%s>\n", val.c_str());
                PropertyMap["paperSizeMap"] = val;

                //For mixpaperSize
                if(m_PaperSizeMap.size() > 1)
                    PropertyMap["mixpaperSize"] = "mix";
                else if(m_PaperSizeMap.size() == 1)
                    PropertyMap["mixpaperSize"] = "";

                //Get the JobType
                //and ColorMode.
                //If Increment, insert the enum if not present else increment the count
                //If Decrement, decrement the count or remove the enum
                CString key = "jobType";
                CString jobVal("");
                if(page->GetWebDAVProperty(key,jobVal)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData - GetWebDAVProperty of jobVal Failed\n");
                    return STATUS_FAILED;

                }
                key = "colorMode";
                CString colorVal("");
                if(page->GetWebDAVProperty(key, colorVal)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData - GetWebDAVProperty of colorVal Failed\n");
                    return STATUS_FAILED;
                }

                JobTypeColor eVal;
                if((jobVal=="Copy") && (colorVal =="Color"))
                    eVal = CopyColor;
                else if((jobVal=="Copy") && (colorVal =="Gray"))
                    eVal = CopyGray;
                else if((jobVal=="Copy") && (colorVal =="Mono"))
                    eVal = CopyMono;
                else if((jobVal=="Print") && (colorVal =="Color"))
                    eVal = PrintColor;
                else if((jobVal=="Print") && (colorVal =="Gray"))
                    eVal = PrintMono;
                else if((jobVal=="Print") && (colorVal =="Mono"))
                    eVal = PrintMono;
                else if((jobVal=="Scan") && (colorVal =="Color"))
                    eVal = ScanColor;
                else if((jobVal=="Scan") && (colorVal =="Gray"))
                    eVal = ScanGray;
                else if((jobVal=="Scan") && (colorVal =="Mono"))
                    eVal = ScanMono;
                else if((jobVal=="Fax") && (colorVal =="Mono"))
                    eVal = FaxMono;
                else
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData - Invalid Combination of JobType<%s> and ColorMode<%s>\n",jobVal.c_str(),colorVal.c_str());
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::UpdateMixedInfoData - Valid Combination of JobType<%s> and ColorMode<%s>\n",jobVal.c_str(),colorVal.c_str());

                val.clear();
                val = PropertyMap["jobTypeColorMap"];
                DEBUGL8("CDocument::UpdateMixedInfoData:Get VAL for jobTypeColorMap <%s>\n", val.c_str());

                m_JobTypeColorMap.clear();
                size_t found2 = val.find_first_of(";");
                while (found2!=string::npos)
                {
                    CString minp = val.substr(0,found2);
                    size_t nf = minp.find(",");
                    string first = minp.substr(0,nf);
                    string second = minp.substr(nf+1);
                    JobTypeColor eVal;
                    int abc = atoi(first.c_str());
                    eVal = (JobTypeColor)abc;
                    m_JobTypeColorMap.insert(make_pair(eVal,atoi(second.c_str())));
                    val = val.substr(found2+1);
                    found2=val.find_first_of(";");
                }

                std::map<JobTypeColor,int>::iterator jcIter = m_JobTypeColorMap.find(eVal);
                if(jcIter != m_JobTypeColorMap.end())
                {
                    int count=m_JobTypeColorMap[eVal];
                    if(increment)
                        m_JobTypeColorMap[eVal]=count+1;
                    else
                    {
                        if(count==1)
                            m_JobTypeColorMap.erase(eVal);
                        else
                            m_JobTypeColorMap[eVal]=count-1;
                    }
                }
                else
                {
                    if(increment)
                        m_JobTypeColorMap.insert(make_pair(eVal,1));
                    else
                        DEBUGL2("CDocument::UpdateMixedInfoData - JobTypeColor enum not found");

                }
                std::map<JobTypeColor,int>::iterator jobTypeColorIter;
                val.clear();
                for(jobTypeColorIter=m_JobTypeColorMap.begin();jobTypeColorIter!=m_JobTypeColorMap.end();jobTypeColorIter++)
                {
                    std::ostringstream oss1;
                    oss1<<jobTypeColorIter->first;
                    std::ostringstream oss2;
                    oss2<<jobTypeColorIter->second;

                    val.append(oss1.str());
                    val.append(",");
                    val.append(oss2.str());
                    val.append(";");
                }
                DEBUGL8("CDocument::UpdateMixedInfoData::Set VAL for jobTypeColorMap <%s>\n", val.c_str());
                //Setting changed value in the map 
                PropertyMap["jobTypeColorMap"] = val;

                CString mixval[4] = {"jobType", "colorMode", "horizontalResolution", "verticalResolution"};

                if(UpdateMap(page, increment, PropertyMap, mixval) != STATUS_OK)
                {
                    DEBUGL1("CDocument::UpdateMixedInfoData::Failed to update maps..\n");
                    return STATUS_FAILED;
                }
                //Write the updated maps to documentproperties.xml
                Status sdf = Utility::SetProperties(propertypath, "documentproperties.xml", PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(STATUS_DISK_FULL == sdf)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData::Failed to set property maps because Disk is Full..\n");
                        return STATUS_DISK_FULL;
                    }
                    return STATUS_FAILED;
                }
                if(increment)
                {
                    //FileFormat Validation
                    FileFormat format;
                    if(!page)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->GetFileFormat(format)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData - Invalid Image File Format\n");
                        return STATUS_FAILED;
                    }
                    if(!page)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->GetSubsamplingFileFormat(format)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData - Invalid Subsampling File Format\n");
                        return STATUS_FAILED;
                    }
                    if(!page)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->GetThumbnailFileFormat(format)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::UpdateMixedInfoData - Invalid Thumbnail File Format\n");
                        return STATUS_FAILED;
                    }
                }
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::UpdateMixedInfoData::Exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }
            return STATUS_OK;           
        }


        Status CDocument::UpdateMap(PageRef page,bool increment,std::map<CString,CString> &PropertyMap,CString* key)
        {
            CString keyVal("");
            CString mapName("");
            CString mapVal("");
            for(int i = 0; i < 4; i++)
            {
                if(increment)
                {
                    if(page->GetWebDAVProperty(key[i], keyVal)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::UpdateMap - GetWebDAVProperty of %s Failed\n",key[i].c_str());
                        return STATUS_FAILED;
                    }
                }
                else
                {
                    CString resourceKey = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/Image/";
                    try
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::UpdateMap - Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        resourceKey+=dynamic_cast<CPage*>(page.operator->())->GetPageNo();
                        if(!page)
                        {
                            DEBUGL1("CDocument::UpdateMap - Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        resourceKey+= dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);
                    }
                    catch(exception& e)
                    {
                        DEBUGL1("CDocument::UpdateMap::Exception caught:(%s)\n",e.what());
                        return STATUS_FAILED;
                    }
                    if(page->GetWebDAVProperty(key[i],keyVal) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::UpdateMap - GetWebDAVProperty of %s Failed\n",key[i].c_str());
                        return STATUS_FAILED;
                    }
                }
                mapName = key[i] + "Map";
                mapVal = "";
                mapVal = PropertyMap[mapName];    
                DEBUGL8("CDocument::UpdateMap:Get VAL for %s <%s>\n",mapName.c_str(), mapVal.c_str());

                std::map<CString,int> mapType;

                size_t found = mapVal.find_first_of(";");
                while (found!=string::npos)
                {
                    CString minp = mapVal.substr(0,found);
                    size_t nf = minp.find(",");
                    string first = minp.substr(0,nf);
                    string second = minp.substr(nf+1);
                    mapType.insert(make_pair(first,atoi(second.c_str())));
                    mapVal = mapVal.substr(found+1);
                    found=mapVal.find_first_of(";");
                }

                std::map<CString,int>::iterator readIter = mapType.find(keyVal);
                if(readIter != mapType.end())
                {
                    int count=mapType[keyVal];
                    if(increment)
                        mapType[keyVal]=count+1;
                    else
                    {
                        if(count==1)
                            mapType.erase(keyVal);
                        else
                            mapType[keyVal]=count-1;
                    }
                }
                else
                {
                    if(increment)
                        mapType.insert(make_pair(keyVal,1));
                    else
                        DEBUGL2("CDocument::UpdateMap - %s not found",key[i].c_str());
                }
                std::map<CString,int>::iterator writeIter;
                mapVal.clear();
                CString jobtype;
                for(writeIter=mapType.begin();writeIter!=mapType.end();writeIter++)
                {
                    std::ostringstream oss1;
                    oss1<<writeIter->first;
                    std::ostringstream oss2;
                    oss2<<writeIter->second;

                    if(mapName == "jobTypeMap")
                    {
                        jobtype = writeIter->first;
                        DEBUGL8("CDocument::UpdateMap::writeIter job type (%s)\n",jobtype.c_str());
                        DEBUGL8("CDocument::UpdateMap::writeIter second (%d)>\n",writeIter->second);
                    }

                    mapVal.append(oss1.str());
                    mapVal.append(",");
                    mapVal.append(oss2.str());
                    mapVal.append(";");
                }
		DEBUGL4("CDocument::UpdateMap::Before setting:mapName =  <%s>, mapVal = <%s>..\n",mapName.c_str(),mapVal.c_str());
                PropertyMap[mapName] = mapVal; 
		DEBUGL4("CDocument::UpdateMap::After setting:mapName =  <%s>, mapVal = <%s>..\n",mapName.c_str(),mapVal.c_str());
                DEBUGL8("CDocument::UpdateMap:: job type = (%s)\n",jobtype.c_str());
                if(mapType.size()>1)
                {
                    if(key[i] == "jobType")
                        PropertyMap[key[i]] = "Compound"; 
                    else if(key[i] == "colorMode")
                        PropertyMap["mixcolorMono"] = "mix";
                    else if(key[i] == "horizontalResolution" || key[i] == "verticalResolution")
                        PropertyMap["mixresolution"] = "mix"; 
                }
                else if(mapType.size() == 1 && increment == false)
                {
                    if(mapName == "jobTypeMap")
                    {
                        PropertyMap[key[i]] = jobtype;                
                    }
                    else if(mapName == "horizontalResolutionMap" || mapName == "verticalResolutionMap" || mapName == "colorModeMap")
		    {
                        PropertyMap["mixcolorMono"] = "";
			PropertyMap["mixresolution"] = "";
		    }
                }
            }
            return STATUS_OK;
        }

	Status CDocument::OpenSystemDataFile(FL_FILE_MAN_FILE &system, CString path) {
		DEBUGL4("CDocument::OpenSystemDataFile: Enter\n");
		int len = path.rfind("/");
		CString systemFileName = path.substr(len+1,path.length());
		int len1 = path.rfind("/", len - 1);
		CString pagetype = path.substr(len1 + 1, (len - (len1 + 1))); 
		CString docpath = path.substr(0,len1+1);
		DEBUGL8("CDocument::OpenSytemDataFile: critical section for %s:%s\n", pagetype.c_str(), systemFileName.c_str());
		CString pLockpath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/"+pagetype+"/";
		DEBUGL8("CDocument::OpenSystemDataFile: pLockpath is  [%s]\n", pLockpath.c_str());
		int fdescLockfile;
		CString locktypefile = pagetype + "_systemfilelock";
		CString uriPathToLock = docpath + "." + locktypefile;
		bool flockType = true;
		//Skip critical section if the /work/ci/insertblankpageflag exists
		if(!m_insertblankpage)
		{
			if(Utility::AcquireLockforSystemfile(uriPathToLock, fdescLockfile, flockType) != STATUS_OK)
			{
				DEBUGL1("CDocument::copySystemFile::AcquireLockforSystemfile failed\n");
				return STATUS_FAILED;
			}
		}

		DEBUGL8("CDocument::OpenSystemDataFile: Enter -- Opening %s systemfile\n",path.c_str());
		int FD;
		int errnum = 0;
		FD = open(path.c_str(),O_RDONLY);
		errnum=errno;

		if(FD==-1)
		{
			DEBUGL1("CDocument::OpenSystemDataFile:file open error is %d\n", errnum);
			if(!m_insertblankpage)
				if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK)
					DEBUGL1("CDocument::OpenSystemDataFile::ReleaseLockforSystemfile failed\n");
			if( errnum == ENOENT) {
				DEBUGL1("CDocument::OpenSystemDataFile:: File doesn't exist\n");
				return STATUS_INVALID_URI;
			}							
			return STATUS_FAILED;
		}

		if(read(FD,&system, sizeof(FL_FILE_MAN_FILE) ) == -1) {
			DEBUGL1("CDocument::OpenSystemDataFile::Reading system data file is failed\n");
			close(FD);
			if(!m_insertblankpage)
				if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK)
					DEBUGL1("CDocument::OpenSystemDataFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
			return STATUS_FAILED;
		}
		close(FD);
		if(!m_insertblankpage)
		{
			if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK){
				DEBUGL1("CDocument::OpenSystemDataFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
				return STATUS_FAILED;
			}
		}
		DEBUGL4("CDocument::OpenSystemDataFile: Exit\n");
		return STATUS_OK;
	}

        Status CDocument::OverwriteImage(int pageno, CString src, CString dst, CString name, CString ext, FL_PAGE_MAN_TBL &pageinfo, FL_FILE_MAN_FILE &systemfile) {
            // Put resource
            CString target = dst + name + ext;
            DEBUGL8("CDocument::OverwriteImage::PutResource from path = %s to path=%s\n",src.c_str(),target.c_str());
            Status ds;
            if(m_bLink)
            {
                DEBUGL8("CDocument::OverwriteImage:: with file link\n");
                ds =ci::operatingenvironment::File::SymbolicLink(src,target);

                //Since File::SymbolicLink doesnt overwrite the existing file
                //If target exist, then delete the target and try to link the file again
                if(ds == STATUS_ALREADY_EXISTS)
                {
                    DEBUGL8("CDocument::OverwriteImage:: Deleting existing file (%s)\n", target.c_str());
                    ds = ci::operatingenvironment::File::DeleteFile(target);
                    if(ds!=STATUS_OK)
                    {
                        if(ds == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::OverwriteImage::Deleting of target file failed STATUS_DISK_FULL\n");
                            return STATUS_DISK_FULL;
                        }
                        else
                        {
                            DEBUGL1("CDocument::OverwriteImage::Deleting of target file failed\n ");
                            return STATUS_FAILED;
                        }
                    }
                    //Try to link the file again
                    ds =ci::operatingenvironment::File::SymbolicLink(src,target);
                }

                m_bLink = false;
            }
            else						
                ds =ci::operatingenvironment::File::CopyFile(src,target);

            if(ds!=STATUS_OK)
            {
                if(ds == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::OverwriteImage::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }
                else
                {
                    DEBUGL1("CDocument::OverwriteImage::PutResource %s to %s is failed\n",src.c_str(), target.c_str());
                    return STATUS_FAILED;
                }
            }

            // Refresh SystemFile
            systemfile.sPageManTbl[pageno-1] = pageinfo;
            // Rename file name
            strncpy(systemfile.sPageManTbl[pageno-1].sPageMan.aPgStr, name.c_str(), 5);
            DEBUGL8("CDocument::OverwriteImage page name argument %s & in systemfile %s\n", name.c_str(), systemfile.sPageManTbl[pageno-1].sPageMan.aPgStr);
            //update the extension for images.
            if(dst.find("Image"))
                systemfile.sPageManTbl[pageno-1].sPageComAtr.hCType = pageinfo.sPageComAtr.hCType;
            else if(dst.find("Subsampling"))
                systemfile.sPageManTbl[pageno-1].sPageComAtr.sPageThumInfo.hCType = pageinfo.sPageComAtr.sPageThumInfo.hCType;
            else if(dst.find("Thumbnail"))
                systemfile.sPageManTbl[pageno-1].sPageComAtr.sPageThumInfo.hCType = pageinfo.sPageComAtr.sPageThumInfo.hCType;

            // Add Page number
            systemfile.sFileMan.hFlPageNum++;
            systemfile.sFileMan.hFlPageNumE++;
            std::ostringstream strm;
            strm << std::hex << std::setfill('0') << std::setw(3) << systemfile.sFileMan.hFlPageNum;
            strncpy(systemfile.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

            // Add Page Size
            m_TotalDocSize = (systemfile.sFileMan.liFlSize += pageinfo.sPageMan.liPgDataSize);

            return STATUS_OK;
        }

        Status CDocument::InsertPageByLink(int pageno, PageRef page) 
        {
            DEBUGL4("CDocument::InsertPageByLink:Enter\n");				
            PageList list;
            list.push_back(page);
            m_bLink = true;
            Status st = InsertPage(pageno, list);
            m_bLink = false;						
            DEBUGL4("CDocument::InsertPageByLink:Exit\n");										
            return st;
        }

        Status CDocument::InsertPage(int pageno, PageRef page) {
            PageList list;
            list.push_back(page);
            return InsertPage(pageno, list);
        }

        Status CDocument::InsertPage(int pageno, PageList pages) 
        {
            DEBUGL4("CDocument::InsertPage:Enter\n");

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            DocStatus st;
            Status ds;						
            if(this->GetStatus(st) != STATUS_OK) 
            {
                DEBUGL1("CDocument::InsertPage::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == CREATING || st == EDITING)) 
            {
                DEBUGL1("CDocument::InsertPage::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            if(st == EDITING)
            {	
                //Initialize WorkSpace
                WorkSpaceInit();
            }

            int total;
            if(iSSetsysfileInvoked)
            {						
                if(GetPageList(m_PageList) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::InsertPage::Getting PageList failed\n");
                    return STATUS_FAILED;
                }
            }

            Status ret;
            uint64 tempdocsize = m_TotalDocSize;
            // check total page size
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::InsertPage::Getting total pages failed\n");
                return STATUS_FAILED;
            }

            DEBUGL8("CDocument::InsertPage::Total pages in the document are %d\n",total);

            CString val;						
            CString srcpath,dstpath, dstname;
            CString sExt("");
            PageRef pageRef=NULL;


            CString boxbasepath_new("");
            int pos = m_BoxBasePathOrg.rfind("/");
            boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
            if(boxbasepath_new == "PageLogBoxes")
            {
                if(total + pages.size() > CBoxDocument::PAGELOGBOX_PAGE_LIMIT) 
                {
                    DEBUGL1("CDocument::InsertPage::Page Limit reached for PAGELOGBOXES\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }
            }
            else if(total + pages.size() > CBoxDocument::PAGE_LIMIT) 
            {
                DEBUGL1("CDocument::InsertPage::Page Limit reached\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
            }

            if((pageno > total) || (pageno <= 0)) 
            {
                DEBUGL1("CDocument::InsertPage::Invalid insert point %d\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            // open each SystemFiles
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            FL_FILE_MAN_FILE systemfile;
            memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));			
            CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::InsertPage::OpenSystemDataFile Failed to open Image systemfile\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            if(GetPage(1,pageRef) != STATUS_OK)
            {
                DEBUGL1("CDocument::InsertPage::getting page 1 details failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            bool subsampling_exists = false;
            FL_FILE_MAN_FILE subsampling;
				memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));			
            //check if subsampling Images exist then proceed.
            //use page number 1 to verify it as systemfile will be always present.
            try
            {
                if(!pageRef)
                {
                    DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
                srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(1)+sExt;

                //control never enters in below if since subsampling files are not present
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::InsertPage::Subsampling File Exits\n");
                    subsampling_exists=true;
                }
                if(subsampling_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
                    if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::InsertPage::OpenSystemDataFile Failed to open subsampling systemfile\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                //use page number 1 to verify it as systemfile will be always present.
                bool thumbnail_exists = false;
                FL_FILE_MAN_FILE thumbnail;
					 memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));			
                if(!pageRef)
                {
                    DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(THUMBNAILPAGETYPE);
                srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(1)+sExt;
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::InsertPage::Thumbnail File Exits\n");
                    thumbnail_exists=true;
                }

                if(thumbnail_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
                    if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::InsertPage::OpenSystemDataFile Failed to open thumbnail systemfile\n");			
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                DEBUGL8("CDocument::InsertPage::Slide Page information in SystemFiles\n");

                // Slide Page information in SystemFiles
                for(int i = total; i >= pageno; i--) 
                {
                    int to = i + pages.size();

                    PageRef pageRef=NULL;
                    if(GetPage(i,pageRef) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage::getting page %d is failed\n", pageno);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }

                    if(thumbnail_exists) 
                    {
                        thumbnail.sPageManTbl[to-1] = thumbnail.sPageManTbl[i-1];
                        if(!pageRef)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(i)+sExt;
                        dstname = Utility::GetHexadecimalPageNo(to);
                        dstpath = path+"Thumbnail/"+ dstname+ sExt;
                        // set the new thumbnail path & name of the page
                        dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage(dstpath, dstname);
                        // Update Thumbnail Image file name with the dstname set above in SetThumbnailImage
                        dynamic_cast<CPage*>(pageRef.operator->())->UpdateThumbnailName(thumbnail.sPageManTbl[to-1]);

                        DEBUGL8("CDocument::InsertPage::Moving Thumbnail Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                        ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ds;
                        }

                    }
                    if(subsampling_exists) 
                    {
                        subsampling.sPageManTbl[to-1] = subsampling.sPageManTbl[i-1];
                        if(!pageRef)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);								
                        srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(i)+sExt;
                        dstname = Utility::GetHexadecimalPageNo(to);
                        dstpath = path+"Subsampling/"+ dstname +sExt;
                        // set the new subsampling image path & name of the page
                        dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage(dstpath, dstname); 
                        // Update subsampling Image file name with the dstname set above in SetSubsamplingImage
                        dynamic_cast<CPage*>(pageRef.operator->())->UpdateSubsamplingName(subsampling.sPageManTbl[to-1]);

                        DEBUGL8("CDocument::InsertPage::Moving Subsampling Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                        ds = ci::operatingenvironment::File::MoveFile(srcpath, dstpath);
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ds;
                        }
                    }

                    systemfile.sPageManTbl[to-1] = systemfile.sPageManTbl[i-1];
                    // Now move the existing Images before inserting the requested images.
                    //convert the integer value to 3 digit string for page.
                    srcpath = path+"Image/"+Utility::GetHexadecimalPageNo(i);
                    dstname = Utility::GetHexadecimalPageNo(to);
                    dstpath = path+"Image/"+ dstname;
                    if(!pageRef)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(IMAGEPAGETYPE);															
                    CString srcpathExt = srcpath + sExt;
                    CString dstpathExt = dstpath + sExt;							
                    // set the new image path & name of the page
                    if(!pageRef)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;   
                    }
                    dynamic_cast<CPage*>(pageRef.operator->())->SetImage(dstpathExt,dstname);
                    // Update Image file name with the dstname set above in SetImage
                    if(!pageRef)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(pageRef.operator->())->UpdateImageName(systemfile.sPageManTbl[to-1]);
                    DEBUGL8("CDocument::InsertPage::Moving Image from srcpath-%s to dstpath -%s\n",srcpathExt.c_str(),dstpathExt.c_str());
                    if(!m_bLink) {
                        ds =  ci::operatingenvironment::File::MoveFile(srcpathExt, dstpathExt);
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ds;
                        }
                    } else {
                        Ref<ci::systeminformation::SystemInformation> spSysInfo =  ci::systeminformation::SystemInformation::Acquire();					
                        if(spSysInfo)
                        {
                            CString command = "mv " + srcpathExt + " " + dstpathExt;
                            int ret;
                            if(spSysInfo->RunCmd(command, ret) != STATUS_OK)
                            {
                                DEBUGL1("CDocument::InsertPage: Moving of image failed\n");
                                return STATUS_FAILED;
                            }
                        }							
                    }

                    //Move page property files
                    CString srcPagePropertyFile  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i) + ".xml";
                    CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(to) + ".xml";

                    ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFile, dstPagePropertyFile);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ds;
                    }
                    //Move page property dom files
                    CString srcPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i) + "_dom";
                    CString dstPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(to) + "_dom";

                    ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFiledom, dstPagePropertyFiledom);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ds;
                    }
                    srcpathExt = srcpath + ".cjd"; 
                    dstpathExt = dstpath + ".cjd";
                    //Copy Jpeg parameter file
                    if(Utility::ResourceExist(srcpathExt))
                    {
                        ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ds;
                        }
                    }

                    DEBUGL8("CDocument::InsertPage::Moving Images successfull\n");
                }

                // Copy Image and Page Information
                PageRef page;
                FL_PAGE_MAN_TBL pageinfo; // Page Information in SystemFile
                CString imagename;
                CString source, target;
                PageList::iterator it = pages.begin();

                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    page = (*it);
                    imagename =Utility::GetHexadecimalPageNo(i);
                    page->GetImage(source);
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pageinfo);
                    sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);

                    //Overwrite PageProperty filesgetpage
                    CString srcPagePropertyFile;
                    if(m_insertblankpage)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        srcPagePropertyFile  = dynamic_cast<CPage*>(page.operator->())->GetBlankPropertyFile();
                        m_insertblankpage = false;
                    }
                    else
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        srcPagePropertyFile  = dynamic_cast<CPage*>(page.operator->())->GetPropertyFile();
                    }
                    CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + imagename + ".xml";
                    ds =  ci::operatingenvironment::File::CopyFile(srcPagePropertyFile, dstPagePropertyFile);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFile.c_str(),dstPagePropertyFile.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ds;
                    }

                    dstname = imagename;
                    dstpath = path+"Image/"+ dstname+sExt; 
                    // set the Image file name & path for the page
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->SetImage(dstpath, dstname);

                    ret=this->OverwriteImage(i, source, path + "Image/", imagename, sExt, pageinfo, systemfile);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage::Overwrite Image Failed for page %d\n",i);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    // Set the WebDAV properties of each new page. 
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetProperties(i, path);
                    if(ret != STATUS_OK) {
                        DEBUGL1("CDocument::InsertPage:: SetProperties failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    //Set the following properties on Page
                    int value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgMLen;							
                    if(!page)
                    {  
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageWidth",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage - SetWebDAVProperty of adjustedImageWidth Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgSLen;
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageHeight",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage - SetWebDAVProperty of adjustedImageHeight Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hOrientation;					
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }			
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("orientation",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage - SetWebDAVProperty of orientation Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hAngle;
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }								
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("angle",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage - SetWebDAVProperty of angle Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }

                    //Copy Jpeg parameter file
                    if(!page)
                    {
                        DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->IsCopyJpegParameterSet()==STATUS_OK)
                    {  
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }	
                        Status ret = dynamic_cast<CPage*>(page.operator->())->UploadCopyJpegParameter(imagename,path);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage - UploadCopyJpegParameter failed\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                    if(subsampling_exists) 
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetSubsamplingImage(source);
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);										
                        ret = this->OverwriteImage(i, source, path + "Subsampling/", imagename, sExt, pageinfo, subsampling);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Overwrite Subsampling Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }        
                    }

                    if(thumbnail_exists) 
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::InsertPage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetThumbnailImage(source);
                        dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        //imagename +=sExt;
                        ret=this->OverwriteImage(i, source, path + "Thumbnail/", imagename, sExt, pageinfo, thumbnail);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::InsertPage::Overwrite ThumbNail Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                    //Update the page list		
                    if(iSSetsysfileInvoked)								
                        m_PageList.push_back(page);		

                    DEBUGL8("CDocument::InsertPage::PAGE LIST COUNT : %d, PAGE NO %d\n", total, i);
                }

                // Save updated SystemFile
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                CString tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
                ByteStreamRef bs = File::Open(tmppath, "w");
                bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                CString uri = path + "Image/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
                if(ds!=STATUS_OK)
                {
                    if(ds == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::InsertPage::PutResource returned DISKFULL Error\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_DISK_FULL;
                    }
                    else
                    {
                        DEBUGL1("CDocument::InsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }
                DEBUGL8("CDocument::InsertPage::Image systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_SystemDataFile = systemfile;

                if(subsampling_exists) {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Subsampling/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
                    if(ds != STATUS_OK)
                    {
                        if(ds == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::InsertPage::PutResource returned DISKFULL Error\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_DISK_FULL;
                        }
                        else
                        {
                            DEBUGL1("CDocument::InsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }
                    DEBUGL8("CDocument::InsertPage::Subsampling systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_SubsamplingSystemDataFile = subsampling;
                }

                if(thumbnail_exists) 
                {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Thumbnail/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile( tmppath,uri);
                    if(ds != STATUS_OK)
                    {
                        if(ds == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::InsertPage::PutResource returned DISKFULL Error\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_DISK_FULL;
                        }
                        else
                        {
                            DEBUGL1("CDocument::InsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }
                    DEBUGL8("CDocument::InsertPage::Thumbnail systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_ThumbnailSystemDataFile = thumbnail;
                }

                it = pages.begin();
                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    DEBUGL8("CDocument::InsertPage::Updating Newly added Page number %d by GetPage call\n",i);
                    if(UpdateMixedInfoData((*it),true)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::InsertPage - UpdateMixedInfoData of PageNum<%d> Failed\n",pageno);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                //Update ModifiedDate
                SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
                SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());

                //After Inserting update total number of pages and size of the file.
                m_TotalPage = systemfile.sFileMan.hFlPageNum;
                SetWebDAVProperty("totalPages", m_TotalPage);

                m_TotalSize = systemfile.sFileMan.liFlSize;
                std::ostringstream st1;
                st1 << m_TotalSize;
                DEBUGL8("CDocument::InertPage: totalSize = (%s)\n", st1.str().c_str());
                Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st1.str());
                if(sd != STATUS_OK)
                    DEBUGL1("CDocument::InsertPage: Failed to set the totalSize for the document\n");

                //SetWebDAVProperty("totalSize", m_TotalSize);

                m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));	
                SetAllSize();
                //revert back to original
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::InsertPage::Exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }

            DEBUGL4("CDocument::InsertPage:Exit\n");						
            return STATUS_OK;
        }
        Status CDocument::FasterInsertPage(int pageno, PageRef page) {
            PageList list;
            list.push_back(page);
            //return InsertPage(pageno, list);
            return FasterInsertPage(pageno, list);
        }
		Status CDocument::FasterInsertPage(int pageno, PageList pages)
		{
            DEBUGL4("CDocument::FasterInsertPage: Enter\n");

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            DocStatus st;
            Status ds;						
            if(this->GetStatus(st) != STATUS_OK) 
            {
                DEBUGL1("CDocument::FasterInsertPage::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == CREATING || st == EDITING)) 
            {
                DEBUGL1("CDocument::FasterInsertPage::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            if(st == EDITING)
            {	
                //Initialize WorkSpace
                WorkSpaceInit();
            }

            int total;
            if(iSSetsysfileInvoked)
            {						
                if(GetPageList(m_PageList) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::FasterInsertPage::Getting PageList failed\n");
                    return STATUS_FAILED;
                }
            }

            Status ret;
            uint64 tempdocsize = m_TotalDocSize;
            // check total page size
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::FasterInsertPage::Getting total pages failed\n");
                return STATUS_FAILED;
            }

            DEBUGL8("CDocument::FasterInsertPage::Total pages in the document are %d\n",total);

            CString val;						
            CString srcpath,dstpath, dstname;
            CString sExt("");
            PageRef pageRef=NULL;


            CString boxbasepath_new("");
            int pos = m_BoxBasePathOrg.rfind("/");
            boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
            if(boxbasepath_new == "PageLogBoxes")
            {
                if(total + pages.size() > CBoxDocument::PAGELOGBOX_PAGE_LIMIT) 
                {
                    DEBUGL1("CDocument::FasterInsertPage::Page Limit reached for PAGELOGBOXES\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }
            }
            else if(total + pages.size() > CBoxDocument::PAGE_LIMIT) 
            {
                DEBUGL1("CDocument::FasterInsertPage::Page Limit reached\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
            }

            if((pageno > total) || (pageno <= 0)) 
            {
                DEBUGL1("CDocument::FasterInsertPage::Invalid insert point %d\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            // open each SystemFiles
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            FL_FILE_MAN_FILE systemfile;
            memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));			
            CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::FasterInsertPage::OpenSystemDataFile Failed to open Image systemfile\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            if(GetPage(1,pageRef) != STATUS_OK)
            {
                DEBUGL1("CDocument::FasterInsertPage::getting page 1 details failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            bool subsampling_exists = false;
            FL_FILE_MAN_FILE subsampling;
            memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));			
            //check if subsampling Images exist then proceed.
            //use page number 1 to verify it as systemfile will be always present.
            try
            {
                if(!pageRef)
                {
                    DEBUGL1("CDocument::FasterInsertPage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
                srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(1)+sExt;

                //control never enters in below if since subsampling files are not present
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::FasterInsertPage::Subsampling File Exits\n");
                    subsampling_exists=true;
                }
                if(subsampling_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
                    if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::FasterInsertPage::OpenSystemDataFile Failed to open subsampling systemfile\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                //use page number 1 to verify it as systemfile will be always present.
                bool thumbnail_exists = false;
                FL_FILE_MAN_FILE thumbnail;
					 memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));			
                if(!pageRef)
                {
                    DEBUGL1("CDocument::FasterInsertPage Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(THUMBNAILPAGETYPE);
                srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(1)+sExt;
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::FasterInsertPage::Thumbnail File Exits\n");
                    thumbnail_exists=true;
                }

                if(thumbnail_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
                    if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::FasterInsertPage::OpenSystemDataFile Failed to open thumbnail systemfile\n");			
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                // Copy Image and Page Information
                PageRef page;
                FL_PAGE_MAN_TBL pageinfo; // Page Information in SystemFile
                CString imagename;
                CString source, target;
                PageList::iterator it = pages.begin();

                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    page = (*it);
                    imagename =Utility::GetHexadecimalPageNo(i);
                    page->GetImage(source);
                    if(!page)
                    {
                        DEBUGL1("CDocument::FasterInsertPage: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pageinfo);
                    sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);

                    //Overwrite PageProperty filesgetpage
                    CString srcPagePropertyFile;
                    if(m_insertblankpage)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::FasterInsertPage: Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        srcPagePropertyFile  = dynamic_cast<CPage*>(page.operator->())->GetBlankPropertyFile();
                        m_insertblankpage = false;
                    }
                    else
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::FasterInsertPage: Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        srcPagePropertyFile  = dynamic_cast<CPage*>(page.operator->())->GetPropertyFile();
                    }
                    CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + imagename + ".xml";
                    ds =  ci::operatingenvironment::File::CopyFile(srcPagePropertyFile, dstPagePropertyFile);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFile.c_str(),dstPagePropertyFile.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ds;
                    }

                    dstname = imagename;
                    dstpath = path+"Image/"+ dstname+sExt; 
                    // set the Image file name & path for the page
                    if(!page)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->SetImage(dstpath, dstname);

                    ret=this->OverwriteImage(i, source, path + "Image/", imagename, sExt, pageinfo, systemfile);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::Overwrite Image Failed for page %d\n",i);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    // Set the WebDAV properties of each new page. 
                    if(!page)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetProperties(i, path);
                    if(ret != STATUS_OK) {
                        DEBUGL1("CDocument::FasterInsertPage:: SetProperties failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    //Set the following properties on Page
                    int value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgMLen;							
                    if(!page)
                    {  
                        DEBUGL1("CDocument::FasterInsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageWidth",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::FasterInsertPage:: - SetWebDAVProperty of adjustedImageWidth Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgSLen;
                    if(!page)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageHeight",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::FasterInsertPage:: - SetWebDAVProperty of adjustedImageHeight Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hOrientation;					
                    if(!page)
                    {
                        DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                        return STATUS_FAILED;
                    }			
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("orientation",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument:FasterInsertPage:ReplacePage - SetWebDAVProperty of orientation Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hAngle;
                    if(!page)
                    {
                        DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                        return STATUS_FAILED;
                    }								
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("angle",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument:FasterInsertPage:ReplacePage - SetWebDAVProperty of angle Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }

                    //Copy Jpeg parameter file
                    if(!page)
                    {
                        DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->IsCopyJpegParameterSet()==STATUS_OK)
                    {  
                        if(!page)
                        {
                            DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }	
                        Status ret = dynamic_cast<CPage*>(page.operator->())->UploadCopyJpegParameter(imagename,path);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::FasterInsertPage - UploadCopyJpegParameter failed\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                    if(subsampling_exists) 
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetSubsamplingImage(source);
                        if(!page)
                        {
                            DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);										
                        ret = this->OverwriteImage(i, source, path + "Subsampling/", imagename, sExt, pageinfo, subsampling);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::FasterInsertPage::Overwrite Subsampling Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }        
                    }

                    if(thumbnail_exists) 
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument:FasterInsertPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetThumbnailImage(source);
                        dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        //imagename +=sExt;
                        ret=this->OverwriteImage(i, source, path + "Thumbnail/", imagename, sExt, pageinfo, thumbnail);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::FasterInsertPage::Overwrite ThumbNail Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                    //Update the page list		
                    if(iSSetsysfileInvoked)								
                        m_PageList.push_back(page);		

                    DEBUGL8("CDocument::FasterInsertPage::PAGE LIST COUNT : %d, PAGE NO %d\n", total, i);
                }

                // Save updated SystemFile
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                CString tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
                ByteStreamRef bs = File::Open(tmppath, "w");
                bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                CString uri = path + "Image/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
                if(ds!=STATUS_OK)
                {
                    if(ds == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::FasterInsertPage::PutResource returned DISKFULL Error\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_DISK_FULL;
                    }
                    else
                    {
                        DEBUGL1("CDocument::FasterInsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }
                DEBUGL8("CDocument::FasterInsertPage::Image systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_SystemDataFile = systemfile;

                if(subsampling_exists) {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Subsampling/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
                    if(ds != STATUS_OK)
                    {
                        if(ds == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::FasterInsertPage::PutResource returned DISKFULL Error\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_DISK_FULL;
                        }
                        else
                        {
                            DEBUGL1("CDocument::FasterInsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }
                    DEBUGL8("CDocument::FasterInsertPage::Subsampling systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_SubsamplingSystemDataFile = subsampling;
                }

                if(thumbnail_exists) 
                {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Thumbnail/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile( tmppath,uri);
                    if(ds != STATUS_OK)
                    {
                        if(ds == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CDocument::FasterInsertPage:PutResource returned DISKFULL Error\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_DISK_FULL;
                        }
                        else
                        {
                            DEBUGL1("CDocument::FasterInsertPage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }
                    DEBUGL8("CDocument::FasterInsertPage::Thumbnail systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_ThumbnailSystemDataFile = thumbnail;
                }

                it = pages.begin();
                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    DEBUGL8("CDocument::FasterInsertPage::Updating Newly added Page number %d by GetPage call\n",i);
                    if(UpdateMixedInfoData((*it),true)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::FasterInsertPage - UpdateMixedInfoData of PageNum<%d> Failed\n",pageno);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                //Update ModifiedDate
                SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
                SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());

                //After Inserting update total number of pages and size of the file.
                m_TotalPage = systemfile.sFileMan.hFlPageNum;
                SetWebDAVProperty("totalPages", m_TotalPage);
                DEBUGL8("CDocument::FasterInsertPage: totalpages = (%d)\n", m_TotalPage);

                m_TotalSize = systemfile.sFileMan.liFlSize;
                std::ostringstream st1;
                st1 << m_TotalSize;
                DEBUGL8("CDocument::FasterInsertPage: totalSize = (%s)\n", st1.str().c_str());
                Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st1.str());
                if(sd != STATUS_OK)
                    DEBUGL1("CDocument::FasterInsertPage: Failed to set the totalSize for the document\n");


                m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));	
                SetAllSize();
                //revert back to original
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::FasterInsertPage::Exception caught:(%s)\n",e.what());
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            DEBUGL4("CDocument::FasterInsertPage:Exit\n");						
            return STATUS_OK;
        }

        Status CDocument::InsertBlankPage(int pageno,PaperSize size) 
	{
		DEBUGL4("CDocument::InsertBlankPage : Enter : Paper size to insert = <%d>\n",(int)size);
		m_insertblankpage = true;
		//Insert blank page doesn't support for weiss ssd model
		CString subProduct = Utility::GetSubProduct();
		if(subProduct == "WEISS_L_SSD" || subProduct == "WEISS_LL")
		{
			DEBUGL1("CDocument::InsertBlankPage: Weiss SSD model doesn't support insert blank page"); 
			 m_insertblankpage = false;
			return STATUS_FAILED;
		}
		//make a local copy of the member variables
		CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
		boxbasepath_org = m_BoxBasePath;
		boxnumber_org = m_BoxNumber;
		folderName_org = m_FolderName;
		docName_org = m_DocumentName;

		DocStatus st;
		if(this->GetStatus(st) != STATUS_OK) 
		{
			DEBUGL1("CDocument::InsertBlankPage::Getting document status is failed\n");
			 m_insertblankpage = false;
			return STATUS_FAILED;
		}
		if(!(st == EDITING)) 
		{
			DEBUGL1("CDocument::InsertBlankPage::Document is NOT CREATING or EDITING\n");
			 m_insertblankpage = false;
			return STATUS_FAILED;
		}
			//Initialize WorkSpace
			WorkSpaceInit();

		int totalPages;
		if(GetTotalPage(totalPages) != STATUS_OK) 
		{
			DEBUGL1("CDocument::InsertBlankPage::Getting total pages failed\n");
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
			 m_insertblankpage = false;
			return STATUS_FAILED;
		}
		CString boxbasepath_new("");
		int pos;
		pos = m_BoxBasePathOrg.rfind("/");
		boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
		DEBUGL8("CDocument::InsertBlankPage:: boxbasepath_new = (%s)\n", boxbasepath_new.c_str());
		if(boxbasepath_new == "PageLogBoxes")
		{
			if((static_cast<unsigned>(totalPages) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
			{
				DEBUGL1("CDocument::InsertBlankPage::Page Limit reached for PAGELOGBOXES\n");
				m_insertblankpage = false;
				return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
			}
		}
		else if(static_cast<unsigned>(totalPages) >= CBoxDocument::PAGE_LIMIT) 
		{
			DEBUGL1("CDocument::InsertBlankPage::Page Limit reached\n");
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
			m_insertblankpage = false;
			return STATUS_MAX_ALLOWED_RESOURCES_REACHED;						
		}

		PageRef blankPage = NULL;
		//Create blank page
		if(CreatePage(blankPage) != STATUS_OK)
		{
			DEBUGL1("CDocument::InsertBlankPage : Getting blank page failed\n");
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);						
			m_insertblankpage = false;
			return STATUS_FAILED;
		}

		try
		{
		if(GetBlankPage(blankPage, size, pageno,totalPages) != STATUS_OK)
		{
			DEBUGL1("CDocument::InsertBlankPage : Getting blank page failed\n");
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
			m_insertblankpage = false;
			return STATUS_FAILED;
		}

		if(pageno == totalPages + 1)
		{
			Status st1;
				if(!blankPage)
				{
					DEBUGL1("CDocument::Page object is NULL\n");
					m_insertblankpage = false;
					return STATUS_FAILED;
				}
				st1 = dynamic_cast<CPage*>(blankPage.operator->())->SetBlankPropertyFile(pageno,m_BoxBasePath + "/" + m_DocumentName + "/");
			if(st1 != STATUS_OK)
			{
				DEBUGL1("CDocument::InsertBlankPage : setpageproperties faile\n");
				m_insertblankpage = false;
				return STATUS_FAILED;
			}

			DEBUGL8("CDocument::InsertBlankPage::Calling Append page\n");													
			if(AppendPage(blankPage) != STATUS_OK)
			{
				DEBUGL1("CDocument::InsertBlankPage : AppendPage failed\n");
				m_insertblankpage = false;
				return STATUS_FAILED;
			}
		}
		else
		{
			Status st1;
				if(!blankPage)
				{
					DEBUGL1("CDocument::InsertBlankPage :Page object is NULL\n");
					m_insertblankpage = false;
					return STATUS_FAILED;
				}
				st1 = dynamic_cast<CPage*>(blankPage.operator->())->SetBlankPropertyFile(pageno);

			if(st1 != STATUS_OK)
			{
				DEBUGL1("CDocument::InsertBlankPage : setpageproperties faile\n");
				m_insertblankpage = false;
				return STATUS_FAILED;
			}

			DEBUGL8("CDocument::InsertBlankPage::Calling insert page\n");						
			if(InsertPage(pageno,blankPage) != STATUS_OK)
			{
				DEBUGL1("CDocument::InsertBlankPage : InsertPage failed\n");
				m_insertblankpage = false;
				return STATUS_FAILED;
			}	
			}
		}
		catch(exception& e)
		{
			DEBUGL1("CDocument::InsertBlankPage::Exception caught:(%s)\n",e.what());
			m_insertblankpage = false;
			return STATUS_FAILED;
		}
		//Copy JPEG file
		if(m_jobColorType == COPY_Copy_JPEG_JOB)
		{						
			CString dstPath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);
			dstPath += "/Image/00";
			std::ostringstream str;
			str << m_blankPageNumber;
			dstPath+= str.str();
			dstPath+= ".cjd";
			DEBUGL8("CDocument::InsertBlankPage::UploadCopyJpegParameter - dstPath<%s>\n",dstPath.c_str());					
			CString imgPath = m_blankCopyJpegPath;	
			Status ds = ci::operatingenvironment::File::CopyFile(imgPath,dstPath);
			if(ds != STATUS_OK)
			{
				if(ds == STATUS_DISK_FULL)
				{
					DEBUGL1("CDocument::InsertBlankPage::UploadCopyJpegParameter - PutResource returned DISKFULL Error\n");
					m_insertblankpage = false;
					return STATUS_DISK_FULL;
				}
				else 						
				{
					DEBUGL1("CDocument::InsertBlankPage::UploadCopyJpegParameter - PutResource %s to %s is failed\n",imgPath.c_str(), dstPath.c_str());
					m_insertblankpage = false;
					return STATUS_FAILED;
				}
			}					
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);				
			DEBUGL8("CDocument::InsertBlankPage : InserBlankPage successful\n");					
			return STATUS_OK;
		}
		RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);				
		DEBUGL8("CDocument::InsertBlankPage : InserBlankPage successful\n");					
		return STATUS_OK;

	}

        void CDocument::SetBlankFileName(int jobType)
        {
            //Set copy map
            typedef std::map<CString, CString> blank_page_pair;
            switch(jobType)
            {
                case COPY:
                    m_blankFileNames.insert(blank_page_pair::value_type("A3", "A3R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4","B4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A4", "A4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5", "B5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5", "A5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6", "A6R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard", "JPCR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER", "LDR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL", "LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER", "LTR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT",  "STR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO", "FLOR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER", "CMPR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL", "13LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ", "85SQR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8K", "8KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K", "16KR"));

                    m_blankFileNames.insert(blank_page_pair::value_type("A3-R", "A3R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A4-R", "A4"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5-R", "A5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6-R", "A6R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide-R", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4-R", "B4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5-R", "B5"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER-R", "LT"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER-R", "LDR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL-R", "LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT-R", "STR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER-R", "CMPR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO-R", "FLOR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ-R", "85SQR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide-R", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch-R", "LDWR")); 
                    m_blankFileNames.insert(blank_page_pair::value_type("8K-R", "8KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K-R", "16KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard-R", "JPCR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3-R", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm-R", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL-R", "13LGR"));
                    break;
                case SCAN:
                    //Set scan map
                    m_blankFileNames.insert(blank_page_pair::value_type("A3", "A3R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4", "B4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A4", "A4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5", "B5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5", "A5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6", "A6R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard", "JPCR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER", "LDR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL", "LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER", "LTR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT", "STR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO", "FLOR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER", "CMPR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL", "13LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ", "85SQR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8K", "8KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K", "16KR"));

                    m_blankFileNames.insert(blank_page_pair::value_type("A3-R", "A3"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4-R", "B4"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A4-R", "A4"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5-R", "B5"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5-R", "A5"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6-R", "A6"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard-R", "JPC"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER-R", "LD"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL-R", "LG"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER-R", "LT"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT-R", "ST"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO-R", "FLO"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER-R", "CMP"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL-R", "13LG"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide-R", "A3W"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3-R", "A3W"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm-R", "A3W"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide-R", "LDW"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch-R", "LDW"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ", "85SQ"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8K-R", "8K"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K-R", "16K"));					
                    break;
                case PRINT:
                    m_blankFileNames.insert(blank_page_pair::value_type("A3", "A3R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3-R", "A3R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4", "B4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B4-R", "B4R"));
		    if(BOX_PRODUCT == "LOIRE" || BOX_PRODUCT == "ALABAMA")
		    {
			    m_blankFileNames.insert(blank_page_pair::value_type("A4", "A4R"));
		    }
		    else
                    	m_blankFileNames.insert(blank_page_pair::value_type("A4", "A4"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A4-R", "A4R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5", "B5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("B5-R", "B5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5", "A5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A5-R", "A5R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6", "A6R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A6-R", "A6R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard", "JPCR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("Postcard-R", "JPCR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER", "LDR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGER-R", "LDR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL", "LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEGAL-R", "LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER", "LTR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LETTER-R", "LTR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT", "STR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("STATEMENT-R", "STR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO", "FLOR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("FOLIO-R", "FLOR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER", "CMPR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("COMPUTER-R", "CMPR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL", "13LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13inchLEGAL-R", "13LGR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("A3Wide-R", "A3WR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3", "320X450R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("SRA3-R", "320X450R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm", "320X460R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("320x460mm-R", "320X460R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("LEDGERWide-R", "LDWR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch", "13X19R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("13x19inch-R", "13X19R"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ", "85SQR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8.5SQ-R", "85SQR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8K", "8KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("8K-R", "8KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K", "16KR"));
                    m_blankFileNames.insert(blank_page_pair::value_type("16K-R", "16KR"));
                    break;
	    }
	 }

        Status CDocument::GetBlankPage(PageRef blankPage, PaperSize papersize, int pageno, int totalPages)
        {
            DEBUGL4("CDocument::GetBlankPage: Enter \n");


            PageRef basePage;
            int basePageNumber = pageno;

            //Determine the base page
            pageno > totalPages? basePageNumber-- : basePageNumber;

            m_blankPageNumber = pageno;

            //get the base page
            DEBUGL4("CDocument::GetBlankPage: Enter GetPage\n");					
            if(GetPage(basePageNumber, basePage) != STATUS_OK)
            {
                DEBUGL1("CDocument::GetBlankPage:getting base page details failed\n");
                return STATUS_FAILED;
            }

            //Determine the image attribute
            CString jobTypeVal, colorMode;
            if(basePage->GetWebDAVProperty("jobType",jobTypeVal) != STATUS_OK)
            {
                DEBUGL1("CDocument::GetBlankPage:getting job type is failed\n");
                return STATUS_FAILED;					
            }
            m_JobVal = jobTypeVal;	
            if(basePage->GetWebDAVProperty("colorMode",colorMode) != STATUS_OK)
            {
                DEBUGL1("CDocument::GetBlankPage:getting job type is failed\n");
                return STATUS_FAILED;					
            }

            DEBUGL8("CDocument::GetBlankPage: jobTypeVal = %s\n",jobTypeVal.c_str());										
            DEBUGL8("CDocument::GetBlankPage: colorMode = %s\n", colorMode.c_str());							
            DEBUGL8("CDocument::GetBlankPage: calling FillBlankPageProperties\n");										
            if(((jobTypeVal == "Scan") && (colorMode == "Color")) ||
                    ((jobTypeVal == "Scan") && (colorMode == "Gray")))
            {
                //SCAN (JPEG)
                if (FillBlankPageProperties(SCAN_JPEG_JOB,papersize,basePage,blankPage,basePageNumber) != STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }
            }
            else if(((jobTypeVal == "Fax") && (colorMode == "Mono")) ||
                    ((jobTypeVal == "Scan") && (colorMode == "Mono")))

            {
                //SCAN, FAX, EMAIL (MMR)
                DEBUGL8("CDocument::GetBlankPage: In SCAN, FAX, EMAIL (MMR)\n"); 					      
                if (FillBlankPageProperties(SCAN_FAX_EMAIL_MMR_JOB,papersize,basePage,blankPage,basePageNumber)!= STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }

            }
            else if((jobTypeVal == "Print") && (colorMode == "Color"))
            {
                //PRINT (TTEC-JPEG color)
                DEBUGL8("CDocument::GetBlankPage: In PRINT (TTEC-JPEG color)\n");					      
                if (FillBlankPageProperties(PRINT_TTEC_JPEG_color_JOB,papersize,basePage,blankPage,basePageNumber) != STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }

            }
            else if((jobTypeVal == "Print") && (colorMode == "Gray"))
            {
                //PRINT (TTEC-JPEG Mono)
                DEBUGL8("CDocument::GetBlankPage: In PRINT (TTEC-JPEG Mono)\n");					      
                if (FillBlankPageProperties(PRINT_TTEC_JPEG_mono_JOB,papersize,basePage,blankPage,basePageNumber) != STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }

            }
            else if((jobTypeVal == "Print") && (colorMode == "Mono"))
            {
               //PRINT (RECTOR-RK1)
               DEBUGL8("CDocument::GetBlankPage: In PRINT (RECTOR MONO)\n");
               if(FillBlankPageProperties(PRINT_RECTOR_JOB, papersize, basePage, blankPage, basePageNumber) != STATUS_OK)
               {
                  DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                  return STATUS_FAILED;
               }
            }
            else if(((jobTypeVal == "Copy") && (colorMode == "Color")) || 
                    ((jobTypeVal == "Copy") && (colorMode == "Gray")))
            {
                //COPY (Copy-JPEG)
                DEBUGL8("CDocument::GetBlankPage: In COPY (Copy-JPEG)\n");					      
                if (FillBlankPageProperties(COPY_Copy_JPEG_JOB,papersize,basePage,blankPage,basePageNumber) != STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }

            }
            else if((jobTypeVal == "Copy") && (colorMode == "Mono"))
            {
                //COPY (Rector)
                DEBUGL8("CDocument::GetBlankPage: In COPY (Rector)\n");					      
                if (FillBlankPageProperties(COPY_Rector_JOB,papersize,basePage,blankPage,basePageNumber) != STATUS_OK)
                {
                    DEBUGL1("CDocument::GetBlankPage: failed to update the page properties\n");	
                    return STATUS_FAILED;
                }

            }
            else
            {
                DEBUGL1("CDocument::GetBlankPage: JobType and ColorMode are not matching with any of the image attribute\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CDocument::FillBlankPageProperties(int jobColorType, PaperSize paperSize, 
                PageRef basePage, PageRef blankPage, 
                int basePageNumber)
        {
            DEBUGL4("CDocument::FillBlankPageProperties: Enter\n");

            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName)+"/";
            //Create new empty system file
            FL_PAGE_MAN_TBL blankSystemTbl;
            memset((FL_PAGE_MAN_TBL *)&(blankSystemTbl),'\0',sizeof(FL_PAGE_MAN_TBL));


            FL_FILE_MAN_FILE basesystemfile;
            memset(&basesystemfile, '\0', sizeof(FL_FILE_MAN_FILE));			
            CString basesystemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
            Status openStatus = STATUS_OK;
            openStatus = OpenSystemDataFile(basesystemfile, basesystemfilepath);
            if(!(openStatus == STATUS_OK || openStatus == STATUS_INVALID_URI))	
            {
                DEBUGL1("CDocument::FillBlankPageProperties::OpenSystemDataFile Failed for Image\n");
                return openStatus;									
            }

            FL_PAGE_MAN_TBL blankSystemThumbnailSystemTbl;
            memset((FL_PAGE_MAN_TBL *)&(blankSystemThumbnailSystemTbl),'\0',sizeof(FL_PAGE_MAN_TBL));

            FL_FILE_MAN_FILE baseThumbnailSystemfile;
				memset(&baseThumbnailSystemfile, '\0', sizeof(FL_FILE_MAN_FILE));			
            CString baseThumbnailSystemFilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
            openStatus = STATUS_OK;
            openStatus = OpenSystemDataFile(baseThumbnailSystemfile, baseThumbnailSystemFilepath);
            if(!(openStatus == STATUS_OK || openStatus == STATUS_INVALID_URI))	
            {
                DEBUGL1("CDocument::FillBlankPageProperties::OpenSystemDataFile Failed for Image\n");
                return openStatus;									
            }					
            //Set paper size
            CString blankPaperSize;
            CPage c;
            c.SetPaperSize(paperSize);
            c.GetPaperSize(blankPaperSize);

            //Find the resolution
            CString horizontalRes;
            DEBUGL4("CDocument::FillBlankPageProperties: Calling GetWebDAVProperty\n");					
            if(basePage->GetWebDAVProperty("horizontalResolution",horizontalRes) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties:getting job type is failed\n");
                return STATUS_FAILED;					
            }

            //Get $EB2 and PRODUCT from systeminformation
            CString eb2path;
            CString productName;
            Ref<ci::systeminformation::SystemInformation> spSysInfo =  ci::systeminformation::SystemInformation::Acquire();

            if(spSysInfo)
            {
                CString objeb2root = "System/Environment:eb2root";
                CString objproduct = "System/Environment:product";
                CString eb2root = "eb2root";
                CString product = "PRODUCT";

                if ( spSysInfo->Get(objeb2root, eb2path) != STATUS_OK)
                {
                    DEBUGL1("CDocument::FillBlankPageProperties: getting of eb2path FAILED\n");
                    return STATUS_FAILED;
                }

                if ( spSysInfo->Get(objproduct, productName) != STATUS_OK)
                {
                    DEBUGL1("CDocument::FillBlankPageProperties:getting of objproduct FAILED\n");
                    return STATUS_FAILED;
                }

            }
            else
            {
                DEBUGL1("CDocument::FillBlankPageProperties: SystemInformation Acquire FAILED\n");
                return STATUS_FAILED;
            }

            DEBUGL4("CDocument::FillBlankPageProperties: eb2path = %s\n", eb2path.c_str());
            DEBUGL4("CDocument::FillBlankPageProperties: product = %s\n", productName.c_str());
            BOX_PRODUCT = productName;
            BOX_EB2ROOT = eb2path;

            //form the image file path
            CString resultion = horizontalRes+horizontalRes;
            CString blankImagePath;
            CString blankCopyJPEGpath;
            CString blankThumbnailPath;

            blankImagePath = eb2path;
            blankImagePath += "/NoBuildItems/CI/";
            blankImagePath += productName +"/BLANK/";

            //Get thumbnail path				
            blankThumbnailPath = blankImagePath;
            switch(paperSize)
            {
                case ci::boxdocument::A3_R:
                    blankThumbnailPath += "/THUMBNAIL/A3LAND.PNG";
                    break;												
                case ci::boxdocument::B4_R:						
                    blankThumbnailPath += "/THUMBNAIL/B4LAND.PNG";				
                    break;
                case ci::boxdocument::A4_R:
                    blankThumbnailPath += "/THUMBNAIL/A4LAND.PNG";										
                    break;												
                case ci::boxdocument::B5_R: 
                    blankThumbnailPath += "/THUMBNAIL/B5LAND.PNG";										
                    break;									
                case ci::boxdocument::A5_R:
                    blankThumbnailPath += "/THUMBNAIL/A5LAND.PNG";										
                    break;									
                case ci::boxdocument::A6_R:
                    blankThumbnailPath += "/THUMBNAIL/A6LAND.PNG";										
                    break;									
                case ci::boxdocument::POSTCARD_R: 
                    blankThumbnailPath += "/THUMBNAIL/JPCLAND.PNG";
                    break;									
                case ci::boxdocument::LEDGER_R:
                    blankThumbnailPath += "/THUMBNAIL/LDLAND.PNG";
                    break;									
                case ci::boxdocument::LEGAL_R: 
                    blankThumbnailPath += "/THUMBNAIL/LGLAND.PNG";
                    break;									
                case ci::boxdocument::LETTER_R:
                    blankThumbnailPath += "/THUMBNAIL/LTLAND.PNG";
                    break;									
                case ci::boxdocument::STATEMENT_R:
                    blankThumbnailPath += "/THUMBNAIL/STLAND.PNG";
                    break;									
                case ci::boxdocument::FOLIO_R: 
                    blankThumbnailPath += "/THUMBNAIL/FLOLAND.PNG";
                    break;									
                case ci::boxdocument::COMPUTER_R:
                    blankThumbnailPath += "/THUMBNAIL/CMPLAND.PNG";
                    break;
                case ci::boxdocument::LEGAL13_R:
                    blankThumbnailPath += "/THUMBNAIL/13LGLAND.PNG";
                    break;									
                case ci::boxdocument::A3_WIDE_R:
                case ci::boxdocument::SRA3_450_R:
                case ci::boxdocument::SRA3_460_R:
                    blankThumbnailPath += "/THUMBNAIL/A3WLAND.PNG";
                    break;									
                case ci::boxdocument::LEDGER_WIDE_R: 	
                case ci::boxdocument::RECTANGLE13X19_R:
                    blankThumbnailPath += "/THUMBNAIL/LDWLAND.PNG";
                    break;									
                case ci::boxdocument::SQUARE8_5_R: 
                    blankThumbnailPath += "/THUMBNAIL/85SQLAND.PNG";
                    break;									
                case ci::boxdocument::SIZE_8K_R:
                    blankThumbnailPath += "/THUMBNAIL/8KLAND.PNG";
                    break;
                case ci::boxdocument::SIZE_16K_R: 
                    blankThumbnailPath += "/THUMBNAIL/16KLAND.PNG";
                    break;									
                case ci::boxdocument::A3:
                    blankThumbnailPath += "/THUMBNAIL/A3PORT.PNG";
                    break;												
                case ci::boxdocument::B4:						
                    blankThumbnailPath += "/THUMBNAIL/B4PORT.PNG";				
                    break;
                case ci::boxdocument::A4:
                    blankThumbnailPath += "/THUMBNAIL/A4PORT.PNG";										
                    break;												
                case ci::boxdocument::B5: 
                    blankThumbnailPath += "/THUMBNAIL/B5PORT.PNG";										
                    break;									
                case ci::boxdocument::A5:
                    blankThumbnailPath += "/THUMBNAIL/A5PORT.PNG";										
                    break;									
                case ci::boxdocument::A6:
                    blankThumbnailPath += "/THUMBNAIL/A6PORT.PNG";										
                    break;									
                case ci::boxdocument::POSTCARD: 
                    blankThumbnailPath += "/THUMBNAIL/JPCPORT.PNG";
                    break;									
                case ci::boxdocument::LEDGER:
                    blankThumbnailPath += "/THUMBNAIL/LDPORT.PNG";
                    break;									
                case ci::boxdocument::LEGAL: 
                    blankThumbnailPath += "/THUMBNAIL/LGPORT.PNG";
                    break;									
                case ci::boxdocument::LETTER:
                    blankThumbnailPath += "/THUMBNAIL/LTPORT.PNG";
                    break;									
                case ci::boxdocument::STATEMENT:
                    blankThumbnailPath += "/THUMBNAIL/STPORT.PNG";
                    break;									
                case ci::boxdocument::FOLIO: 
                    blankThumbnailPath += "/THUMBNAIL/FLOPORT.PNG";
                    break;									
                case ci::boxdocument::COMPUTER:
                    blankThumbnailPath += "/THUMBNAIL/CMPPORT.PNG";
                    break;
                case ci::boxdocument::LEGAL13:
                    blankThumbnailPath += "/THUMBNAIL/13LGPORT.PNG";
                    break;									
                case ci::boxdocument::A3_WIDE:
                case ci::boxdocument::SRA3_450:
                case ci::boxdocument::SRA3_460:
                    blankThumbnailPath += "/THUMBNAIL/A3WPORT.PNG";
                    break;									
                case ci::boxdocument::LEDGER_WIDE: 	
                case ci::boxdocument::RECTANGLE13X19:
                    blankThumbnailPath += "/THUMBNAIL/LDWPORT.PNG";
                    break;									
                case ci::boxdocument::SQUARE8_5: 
                    blankThumbnailPath += "/THUMBNAIL/85SQPORT.PNG";
                    break;									
                case ci::boxdocument::SIZE_8K:
                    blankThumbnailPath += "/THUMBNAIL/8KPORT.PNG";
                    break;
                case ci::boxdocument::SIZE_16K: 
                    blankThumbnailPath += "/THUMBNAIL/16KPORT.PNG";
                    break;	
                case ci::boxdocument::A1: //Do nothing
                case ci::boxdocument::A2: //Do nothing
                case ci::boxdocument::A7: //Do nothing
                case ci::boxdocument::B1: //Do nothing
                case ci::boxdocument::B2: //Do nothing
                case ci::boxdocument::B3: //Do nothing
                case ci::boxdocument::B6: //Do nothing
                case ci::boxdocument::B7: //Do nothing
                case ci::boxdocument::A1_R: //Do nothing
                case ci::boxdocument::A2_R: //Do nothing
                case ci::boxdocument::A7_R: //Do nothing
                case ci::boxdocument::B1_R: //Do nothing
                case ci::boxdocument::B2_R: //Do nothing
                case ci::boxdocument::B3_R: //Do nothing
                case ci::boxdocument::B6_R: //Do nothing
                case ci::boxdocument::B7_R: //Do nothing
                case ci::boxdocument::UNDEF_SIZE: //Do nothing		
                case ci::boxdocument::SPECIAL_SIZE: //Do nothing
                case ci::boxdocument::SPECIAL_LONG800: //Do nothing
                case ci::boxdocument::SPECIAL_LONG1200: //Do nothing
		    case ci::boxdocument::LEGAL135_R: //Do nothing
		    case ci::boxdocument::LEGAL135: //Do nothing
		    case ci::boxdocument::EXECTIVE_R: //Do nothing
		    case ci::boxdocument::EXECTIVE: //Do nothing
		    case ci::boxdocument::DOUBLEPOSTCARD: //Do nothing
		    case ci::boxdocument::DOUBLEPOSTCARD_R://Do nothing
                    break;

            }

            //Set the class level variable
            m_jobColorType = jobColorType;
            m_basePageNumber= basePageNumber;
            m_basePageRef = basePage;
            m_blankPageRef = blankPage;

            //Get color mode of base page property
            CString colormode;
            basePage->GetWebDAVProperty("colorMode",	colormode);

            //The structure blank_page_data is filled with the values of blank paper
            blank_page_data bpData;					
            if(GetBlankPageData(jobColorType, paperSize, bpData,resultion) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: Failed to get GetBlankPage data\n");					
                return STATUS_FAILED;
            }

            CString blankPaperName;
            switch(jobColorType)
            {						
                //SCAN(JPEG)
                case SCAN_JPEG_JOB:
                    SetBlankFileName(SCAN);							
                    blankImagePath += "SCAN/";
                    blankImagePath += horizontalRes;
                    blankImagePath += horizontalRes+"/";
                    blankPaperName = m_blankFileNames[blankPaperSize];
                    blankImagePath += blankPaperName+".JPG";
                    break;
                    //SCAN, FAX, EMAIL (MMR)
                case SCAN_FAX_EMAIL_MMR_JOB:
                    SetBlankFileName(SCAN);							
                    blankImagePath += "SCAN/";
                    blankImagePath += horizontalRes;
                    blankImagePath += horizontalRes+"/";
                    blankPaperName = m_blankFileNames[blankPaperSize];							
                    blankImagePath += blankPaperName+".MMR";							
                    break;
                    //PRINT (TTEC-JPEG color)
                case PRINT_TTEC_JPEG_color_JOB:
                    //PRINT (TTEC-JPEG Mono)
                case PRINT_TTEC_JPEG_mono_JOB:
                    SetBlankFileName(PRINT);							
                    blankImagePath +=  "PRINT/";
                    blankImagePath += horizontalRes;
                    blankImagePath += horizontalRes+"/";
                    blankPaperName = m_blankFileNames[blankPaperSize];
                    blankImagePath += blankPaperName+".TJP";
                    break;
                    //PRINT (RECTOR-RK1)
                case PRINT_RECTOR_JOB:
                    SetBlankFileName(PRINT);
                    blankImagePath += "PRINT/";
                    blankImagePath += horizontalRes;
                    blankImagePath += horizontalRes+"/";
                    blankPaperName = m_blankFileNames[blankPaperSize];
                    blankImagePath += blankPaperName+".RK1";
                    break;
                    //COPY (Copy-JPEG)
                case COPY_Copy_JPEG_JOB:
                    SetBlankFileName(COPY);							
                    blankImagePath +=  "COPY/";
                    blankImagePath += horizontalRes;
                    blankImagePath += horizontalRes+"/";
                    blankPaperName = m_blankFileNames[blankPaperSize];
                    blankCopyJPEGpath = blankImagePath + blankPaperName + ".CJD";
                    blankImagePath += blankPaperName + ".CJP";
                    break;
                    //COPY (Rector)
                case COPY_Rector_JOB:
                    SetBlankFileName(COPY);							
                    blankImagePath +=  "COPY/";
		    blankImagePath+=horizontalRes;
		    blankImagePath+=horizontalRes+"/";
		    blankPaperName = m_blankFileNames[blankPaperSize];
		    blankImagePath+=blankPaperName+".RK1";
		    break;
		    //default: //none
	    }
	    if(blankPaperName == CString(""))
	    {
		    DEBUGL1("CDocument::FillBlankPageProperties: Input paper size is wrong\n");
		    return STATUS_FAILED;
	    }

            DEBUGL4("CDocument::FillBlankPageProperties: blankThumbnailPath %s\n", blankThumbnailPath.c_str());
            DEBUGL4("CDocument::FillBlankPageProperties: blankImagePath %s\n", blankImagePath.c_str());
            if(jobColorType == COPY_Copy_JPEG_JOB)
            {
                DEBUGL4("CDocument::FillBlankPageProperties: blankCopyJPEGpath %s\n", blankCopyJPEGpath.c_str());
                m_blankCopyJpegPath = blankCopyJPEGpath;
            }

            if(FillBlankPagePropertiesImage(paperSize, blankSystemTbl, basesystemfile,												
                        bpData, horizontalRes) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: FillBlankPagePropertiesImage failed\n");					
                return STATUS_FAILED;
            }
            if(FillBlankPagePropertiesThumbnail(paperSize, blankSystemThumbnailSystemTbl, 
                        baseThumbnailSystemfile,
                        bpData, horizontalRes) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: FillBlankPagePropertiesImage failed\n");					
                return STATUS_FAILED;
            }
            //Copy the CJP file
            if(blankPage->PutImage(blankImagePath) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: PutImage failed\n");
                return STATUS_FAILED;
            }
            if(blankPage->PutThumbnailImage(blankThumbnailPath) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: PutThumbnailImage failed\n");
                return STATUS_FAILED;						
            }
            DEBUGL8("CDocument::FillBlankPageProperties: FileSize = %d\n",blankSystemTbl.sPageComAtr.hInPgSLen);					
            DEBUGL8("CDocument::FillBlankPageProperties: hPgMLen = %d\n",blankSystemTbl.sPageComAtr.hPgMLen);
            DEBUGL8("CDocument::FillBlankPageProperties: hPgSLen = %d\n",blankSystemTbl.sPageComAtr.hPgSLen);					
            DEBUGL8("CDocument::FillBlankPageProperties: hInPgMLen = %d\n",blankSystemTbl.sPageComAtr.hInPgMLen);
            DEBUGL8("CDocument::FillBlankPageProperties: hInPgSLen = %d\n",blankSystemTbl.sPageComAtr.hInPgSLen);					
            DEBUGL8("blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = %d\n", blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode );

            DEBUGL8("CDocument::FillBlankPageProperties: Thumb hPgMLen = %d\n",blankSystemThumbnailSystemTbl.sPageComAtr.hPgMLen);
            DEBUGL8("CDocument::FillBlankPageProperties: Thumb hPgSLen = %d\n",blankSystemThumbnailSystemTbl.sPageComAtr.hPgSLen);					
            DEBUGL8("CDocument::FillBlankPageProperties: Thumb hInPgMLen = %d\n",blankSystemThumbnailSystemTbl.sPageComAtr.hInPgMLen);
            DEBUGL8("CDocument::FillBlankPageProperties: Thumb hInPgSLen = %d\n",blankSystemThumbnailSystemTbl.sPageComAtr.hInPgSLen);					


            DEBUGL8("CDocument::FillBlankPageProperties: bpData.fileSize = %s\n",bpData.fileSize.c_str());					
            uint32 ifiles = atoi((char *)(bpData.fileSize.c_str()));

            CString jobtype, verticalRes;
            basePage->GetWebDAVProperty("jobType",jobtype);
            DEBUGL8("CDocument::FillBlankPageProperties: jobtype %s\n",jobtype.c_str());					
            blankPage->SetWebDAVProperty("jobType",jobtype);

            //Horizontal resolution
            DEBUGL8("CDocument::FillBlankPageProperties: horizontalRes %s\n",horizontalRes.c_str());						
            blankPage->SetWebDAVProperty("horizontalResolution",horizontalRes);

            //Vertical resolution
            basePage->GetWebDAVProperty("verticalResolution",verticalRes);
            DEBUGL8("CDocument::FillBlankPageProperties: verticalRes %s\n",verticalRes.c_str());						
            blankPage->SetWebDAVProperty("verticalResolution",verticalRes);

            blankSystemTbl.sPageMan.liPgDataSize = ifiles;
            if(blankPage->SetSystemFile(&blankSystemTbl) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: SetSystemFile failed\n");					
                return STATUS_FAILED;						
            }

            //Update prepority FileSize
            DEBUGL8("CDocument::FillBlankPageProperties: ifiles %u\n",ifiles);
            try
            {
                if(!blankPage)
                {
                    DEBUGL1("CDocument::FillBlankPageProperties:Page object is NULL\n");
                    return STATUS_FAILED;
                }
                dynamic_cast<CPage*>((blankPage).operator->())->SetFileSize(ifiles);
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::FillBlankPageProperties::Exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }
            if(blankPage->SetThumbnailSystemFile(&blankSystemThumbnailSystemTbl) != STATUS_OK)
            {
                DEBUGL1("CDocument::FillBlankPageProperties: SetSystemFile failed\n");					
                return STATUS_FAILED;						
            }	
            return STATUS_OK;
        }


        Status CDocument::FillBlankPagePropertiesImage(PaperSize paperSize, 
                FL_PAGE_MAN_TBL &blankSystemTbl,
                FL_FILE_MAN_FILE &basesystemfile, 
                blank_page_data bpData, CString horizontalResolution)
        {
            DEBUGL4("CDocument::FillBlankPagePropertiesImage: Enter\n");

            int basePageIndex = m_basePageNumber - 1;

            //Get color mode of base page property
            CString colormode;
            m_basePageRef->GetWebDAVProperty("colorMode",	colormode);

            switch(m_jobColorType)
            {						
                //SCAN(JPEG)
                case SCAN_JPEG_JOB:
                    //Color Mode, sEngColorInfo.hColorMode, sEngColorinfo.hDataBit,  
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = COM_CB_MONO;//basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= COM_DT_8BIT;
                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= COM_YCC_INVALID;
                    blankSystemTbl.sPageComAtr.hJobColorMode = COM_CB_GRAYSCALE;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemTbl.sPageComAtr.hPaperType= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPaperType;					
                    blankSystemTbl.sPageComAtr.hPDL= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemTbl.sPageComAtr.hSmoothing= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemTbl.sPageComAtr.hValidity= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hValidity;										
                    blankSystemTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					

                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain = COM_RES_600_PRT;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = COM_RES_600_PRT;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemTbl.sPageOutAtr.hCassette=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCassette;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hWhitePaperFlag;
                    //Changes for Alabama and LOIRE
                    if(BOX_PRODUCT == "ALABAMA" || BOX_PRODUCT == "LOIRE")
                    {
                        blankSystemTbl.sPageOutAtr.hMoff= 53;
                        blankSystemTbl.sPageOutAtr.hSoff= 53;
                        blankSystemTbl.sPageOutAtr.hActMoff = 53;
                        blankSystemTbl.sPageOutAtr.hActSoff = 53;
                        blankSystemTbl.sPageComAtr.hAlignmentAddInfo = COM_ALIGN_NOTHING;
                    }
                    blankSystemTbl.sPageOutAtr.hMoff= 0;
                    blankSystemTbl.sPageOutAtr.hSoff= 0;
                    blankSystemTbl.sPageOutAtr.hActMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hActSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hPrnDuplex; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //SCAN, FAX, EMAIL (MMR)
                case SCAN_FAX_EMAIL_MMR_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);						
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemTbl.sPageComAtr.hJobColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemTbl.sPageComAtr.hPaperType= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPaperType;					
                    blankSystemTbl.sPageComAtr.hPDL= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= COM_SM_MNL;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemTbl.sPageComAtr.hSmoothing= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemTbl.sPageComAtr.hValidity= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hValidity;										
                    blankSystemTbl.sPageComAtr.hScanMethod= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain = COM_RES_600_PRT;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = COM_RES_600_PRT;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemTbl.sPageOutAtr.hCassette=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCassette;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hWhitePaperFlag;							
                    blankSystemTbl.sPageOutAtr.hMoff= 0;
                    blankSystemTbl.sPageOutAtr.hSoff= 0;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hPrnDuplex; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    blankSystemTbl.sPageOutAtr.hActMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hActSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    break;
                    //PRINT (TTEC-JPEG color)
                case PRINT_TTEC_JPEG_color_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");							
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemTbl.sPageComAtr.hJobColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;										
                    blankSystemTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemTbl.sPageComAtr.hPDL= COM_PDL_INVALID;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;					
                    blankSystemTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;					
                    blankSystemTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemTbl.sPageComAtr.hScanMethod= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;							
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemTbl.sPageOutAtr.hMoff  = 56;
                        blankSystemTbl.sPageOutAtr.hSoff = 56;					
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemTbl.sPageOutAtr.hActMoff = 54;
                    else 
                        blankSystemTbl.sPageOutAtr.hActMoff = 53;
                    
                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemTbl.sPageOutAtr.hActSoff = 53;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;		
                    //PRINT (TTEC-JPEG Mono)
                case PRINT_TTEC_JPEG_mono_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);		
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemTbl.sPageComAtr.hJobColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;										
                    blankSystemTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemTbl.sPageComAtr.hPDL= COM_PDL_INVALID;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;					
                    blankSystemTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;					
                    blankSystemTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemTbl.sPageComAtr.hScanMethod= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;							
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemTbl.sPageOutAtr.hMoff  = 56;
                        blankSystemTbl.sPageOutAtr.hSoff = 56;					
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemTbl.sPageOutAtr.hActMoff = 54;
                    else
                        blankSystemTbl.sPageOutAtr.hActMoff = 53;

                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemTbl.sPageOutAtr.hActSoff = 53;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //Changes for Alabama and Loire
                    //PRINT (RECTOR-RK1)
                case PRINT_RECTOR_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode", colormode);
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode,
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemTbl.sPageComAtr.hJobColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;       
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;       
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;
                    blankSystemTbl.sPageComAtr.hCenterCorner= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;                           
                    blankSystemTbl.sPageComAtr.hPaperType= COM_PT_THIN;
                    blankSystemTbl.sPageComAtr.hPDL= COM_PDL_INVALID;
                    blankSystemTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;
                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;
                    blankSystemTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;
                    blankSystemTbl.sPageComAtr.hValidity= COM_VA_VALID;
                    blankSystemTbl.sPageComAtr.hScanMethod= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemTbl.sPageOutAtr.hMoff  = 53;
                        blankSystemTbl.sPageOutAtr.hSoff = 53;
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemTbl.sPageOutAtr.hActMoff = 54;
                    else
                        blankSystemTbl.sPageOutAtr.hActMoff = 53;
                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemTbl.sPageOutAtr.hActSoff = 53;

                    blankSystemTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX;

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //COPY (Copy-JPEG)
                case COPY_Copy_JPEG_JOB:
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");	
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = COM_CB_MONO;
                    DEBUGL8(" PAR_TBL_COLOR_INFO.hColorMode = %d\n", blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode);

                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= COM_DT_8BIT;//basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    DEBUGL8(" PAR_TBL_COLOR_INFO.hDataBit = %d\n", blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit);

                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    DEBUGL8(" hYccForm = %d\n", blankSystemTbl.sPageComAtr.hYccForm);
                    
                    /*Commented as per request for STFR-7743*/
                    //blankSystemTbl.sPageComAtr.hJobColorMode = COM_CB_HQMONO_PPC;
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemTbl.sPageComAtr.hJobColorMode = COM_CB_GRAYSCALE;

                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= COM_RGB_NORMAL;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= COM_RGB_NORMAL;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= COM_RGB_NORMAL;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= COM_1TCH_INVALID;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemTbl.sPageComAtr.hPDL= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemTbl.sPageComAtr.hSmoothing= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=100;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=100;
                    blankSystemTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag = COM_VA_INVALID;							
                    blankSystemTbl.sPageOutAtr.hMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMoff;
                    blankSystemTbl.sPageOutAtr.hSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSoff;
                    blankSystemTbl.sPageOutAtr.hActMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hActSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                   
					//hCenteringCopy
					blankSystemTbl.sPageOutAtr.hCenteringCopy = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCenteringCopy;
		    break;
                    //COPY (Rector)
                case COPY_Rector_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);	
                    blankSystemTbl.sPageComAtr.sEngColorInf.hColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemTbl.sPageComAtr.sEngColorInf.hDataBit= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemTbl.sPageComAtr.hYccForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemTbl.sPageComAtr.hJobColorMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorR= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorG= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemTbl.sPageComAtr.sRGBBalanceInfo.hColorB= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemTbl.sPageComAtr.hOneTouchMode= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemTbl.sPageComAtr.hPDL= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemTbl.sPageComAtr.hPrintScreen= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemTbl.sPageComAtr.hTonerSave= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemTbl.sPageComAtr.hSmoothing= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hMain =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemTbl.sPageOutAtr.sPrnResolution.hSub = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemTbl.sPageOutAtr.hMainMagnification=100;
                    blankSystemTbl.sPageOutAtr.hSubMagnification=100;
                    blankSystemTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    //hWhitePaperFlag, hMoff, hSoff, hPrnDuplex
                    blankSystemTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;					
                    blankSystemTbl.sPageOutAtr.hMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMoff;
                    blankSystemTbl.sPageOutAtr.hSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSoff;
                    blankSystemTbl.sPageOutAtr.hActMoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hActSoff = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 

                    blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
               
					//hCenteringCopy
					blankSystemTbl.sPageOutAtr.hCenteringCopy = basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCenteringCopy;
					break;
                    //default: //none
            }

            DEBUGL8("CDocument::FillBlankPagePropertiesImage: mainScanPixel = %d\n",bpData.mainScanPixel);
            DEBUGL8("CDocument::FillBlankPagePropertiesImage: subScanPixel = %d\n",bpData.subScanPixel);					
            DEBUGL8("CDocument::FillBlankPagePropertiesImage: mainScanPixel = %d\n",bpData.mainScanTransferPixel);
            DEBUGL8("CDocument::FillBlankPagePropertiesImage: subScanPixel = %d\n",bpData.subScanTransferPixel);					

            DEBUGL8("CDocument::FillBlankPagePropertiesImage: basePageIndex = %d\n",basePageIndex);
            DEBUGL8("CDocument::FillBlankPagePropertiesImage: basesystemfile.sPageManTbl.hMain = %d\n",basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hMain);					
            DEBUGL8("CDocument::FillBlankPagePropertiesImage: basesystemfile.sPageManTbl.hSub = %d\n",basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hSub);					

            //hCType, hKPara, hPgMLen, hPgSlen, sResolution.hMain, sResolution.hSub
            blankSystemTbl.sPageComAtr.hCType = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCType;
            DEBUGL8(" hCType = %d\n", blankSystemTbl.sPageComAtr.hCType);

            blankSystemTbl.sPageComAtr.hKPara= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hKPara;
            blankSystemTbl.sPageComAtr.hPgMLen = bpData.mainScanPixel;
            blankSystemTbl.sPageComAtr.hPgSLen = bpData.subScanPixel;
            //blankSystemTbl.sPageComAtr.sResolution = (bpData.mainScanPixel / bpData.subScanPixel);
            blankSystemTbl.sPageComAtr.sResolution.hMain = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hMain;
            blankSystemTbl.sPageComAtr.sResolution.hSub= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hSub;
			blankSystemTbl.sPageComAtr.sCopyResolution.hMain = DEFAULT_FPCA_PTR_COPY_HMAIN; 
			blankSystemTbl.sPageComAtr.sCopyResolution.hSub = DEFAULT_FPCA_PTR_COPY_HSUB; 
            //Orientation
            blankSystemTbl.sPageComAtr.hSize = bpData.hSize;
            blankSystemTbl.sPageComAtr.hImgCoordinate = bpData.hImgCoordinate;

            //hInPgMLen, hPgSLen, sEngColorinfo.hPlane, sEngColorinfo.hDataForm
            blankSystemTbl.sPageComAtr.hInPgMLen =bpData.mainScanTransferPixel;
            blankSystemTbl.sPageComAtr.hInPgSLen=bpData.subScanTransferPixel;
            blankSystemTbl.sPageComAtr.sEngColorInf.hPlane= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hPlane;
            DEBUGL8(" PAR_TBL_COLOR_INFO.hPlane = %d\n", blankSystemTbl.sPageComAtr.sEngColorInf.hPlane);

            blankSystemTbl.sPageComAtr.sEngColorInf.hDataForm= basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataForm;
            DEBUGL8("PAR_TBL_COLOR_INFO.hDataForm = %d\n", blankSystemTbl.sPageComAtr.sEngColorInf.hDataForm);
            //sTwoColor.hMode, sTwoColor.hTwoColors1, sTwoColor.hTwoColors2, sTwoColor.hBoundaryValue
            blankSystemTbl.sPageComAtr.sEngTwoColors.hMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hMode;
            blankSystemTbl.sPageComAtr.sEngTwoColors.hTwoColors1 = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hTwoColors1;
            blankSystemTbl.sPageComAtr.sEngTwoColors.hTwoColors2 = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hTwoColors2;
            blankSystemTbl.sPageComAtr.sEngTwoColors.hBoundaryValue = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hBoundaryValue;

            //Orientaton
            blankSystemTbl.sPageComAtr.hAngle = bpData.hAngle;
            blankSystemTbl.sPageComAtr.hOrientation = bpData.hOrientation;

            //sPageThumInfo.hCType, sPageThumInfo.hPgMLen, sPageThumInfo.hPgSLen, sResolution.hMain, sResolution.hSub
            blankSystemTbl.sPageComAtr.sPageThumInfo.hCType= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hInPgMLen= 0;		
            blankSystemTbl.sPageComAtr.sPageThumInfo.hPgSLen= 0;				
            blankSystemTbl.sPageComAtr.sPageThumInfo.sResolution.hMain= 0;		
            blankSystemTbl.sPageComAtr.sPageThumInfo.sResolution.hSub= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hSize= 0;		
            blankSystemTbl.sPageComAtr.sPageThumInfo.hInPgMLen= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hInPgSLen= 0;							
            blankSystemTbl.sPageComAtr.sPageThumInfo.sColorinf.hColorMode= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataBit= 0;		
            blankSystemTbl.sPageComAtr.sPageThumInfo.sColorinf.hPlane= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= 0;		
            blankSystemTbl.sPageComAtr.sPageThumInfo.hYccForm= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hAngle= 0;		

            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[0]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[1]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[2]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[3]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[4]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[5]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[6]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[7]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[8]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[9]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[10]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[11]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[12]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[13]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[14]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[15]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[16]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[17]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[18]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[19]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[20]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[21]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[22]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[23]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[24]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[25]= 0;					
            blankSystemTbl.sPageComAtr.sPageThumInfo.hReserved[26]= 0;					

            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorY=COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorM= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorC= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorBK= COM_CB_NORMAL;

            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorY=COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorM= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorC= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorBK= COM_CB_NORMAL;					

            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorY=COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorM= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorC= COM_CB_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorBK= COM_CB_NORMAL;					

            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_Y = COM_HUE_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_M = COM_HUE_NORMAL; 
            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_C = COM_HUE_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_R = COM_HUE_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_G = COM_HUE_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_B = COM_HUE_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_Y = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_M = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_C = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_R = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_G = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_B = COM_CRM_NORMAL;
            blankSystemTbl.sPageComAtr.hMonoColor = COM_VA_INVALID;
            blankSystemTbl.sPageComAtr.hSharpness = COM_SHR_NORMAL;					
            blankSystemTbl.sPageComAtr.hImageQType= COM_IQT_GENERAL;
	    blankSystemTbl.sPageComAtr.hDFScanNoiseReduction= COM_DF_NOISE_REDUCTION_DISABLE;
            blankSystemTbl.sPageComAtr.hExtraImageQType= COM_EIQT_INVALID;
            blankSystemTbl.sPageComAtr.hReserved[0] = 0;					
            blankSystemTbl.sPageComAtr.hReserved[1] = 0;	
            blankSystemTbl.sPageComAtr.hReserved[2] = 0;	
            blankSystemTbl.sPageComAtr.hReserved[3] = 0;	
            //hMixImg, hMixTransparent, hMixFlg, hSharpnessFlg, hSmartCMMFlg
            //hNegaposiReverse, hDensityType, hDensityVal, hBackground
            //hEditMode, hOriginalSize, hAlignmentAddInfo
            blankSystemTbl.sPageComAtr.hMixImg = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixImg;
            blankSystemTbl.sPageComAtr.hMixTransparent = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixTransparent;
            blankSystemTbl.sPageComAtr.hMixFlg = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixFlg;
            blankSystemTbl.sPageComAtr.hSharpnessFlg = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSharpnessFlg;
            blankSystemTbl.sPageComAtr.hSmartCMMFlg = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmartCMMFlg;
            blankSystemTbl.sPageComAtr.hNegaposiReverse = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hNegaposiReverse;
            blankSystemTbl.sPageComAtr.hDensityType = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hDensityType;
            blankSystemTbl.sPageComAtr.hDensityVal = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hDensityVal;
            blankSystemTbl.sPageComAtr.hBackground = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hBackground;
            blankSystemTbl.sPageComAtr.hEditMode = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hEditMode;
            blankSystemTbl.sPageComAtr.hOriginalSize = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalSize;
            //blankSystemTbl.sPageComAtr.hAlignmentAddInfo = basesystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;

            blankSystemTbl.sPageOutAtr.hCopies =basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCopies;
            blankSystemTbl.sPageOutAtr.hPaperSize = bpData.hPaperSize;
            blankSystemTbl.sPageOutAtr.hSFBPaperSize= bpData.hPaperSize;
            blankSystemTbl.sPageOutAtr.hInsReverse=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsReverse;
            blankSystemTbl.sPageOutAtr.hTabPaperFlag=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabPaperFlag;
            blankSystemTbl.sPageOutAtr.hTabMoff=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabMoff;
            blankSystemTbl.sPageOutAtr.hTabSoff=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabSoff;
            blankSystemTbl.sPageOutAtr.hTabWidth=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabWidth; 
            blankSystemTbl.sPageOutAtr.hMirror=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMirror;
            blankSystemTbl.sPageOutAtr.hInsPaperSize=basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsPaperSize;
            blankSystemTbl.sPageOutAtr.hInsPaperType= basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsPaperType;
            blankSystemTbl.sPageOutAtr.hSpFeed= 432;
            blankSystemTbl.sPageOutAtr.hSpWidth= 297;
            blankSystemTbl.sPageOutAtr.hForceFrontSide= basesystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hForceFrontSide;
            //Updated newly added structure field
#if 0
            blankSystemTbl.sPageOutAtr.hReserved[0]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[1]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[2]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[3]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[4]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[5]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[6]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[7]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[8]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[9]= 0; 
#endif
            //blankSystemTbl.sPageOutAtr.hActMoff = 0;
            //blankSystemTbl.sPageOutAtr.hActSoff = 0;

            blankSystemTbl.sPageOutAtr.aTSINo[0] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[1] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[2] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[3] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[4] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[5] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[6] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[7] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[8] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[9] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[10] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[11] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[12] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[13] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[14] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[15] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[16] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[17] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[18] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[19] = 0;
            blankSystemTbl.sPageOutAtr.aTSINo[20] = 0;		
            blankSystemTbl.sPageOutAtr.hExpandPrnArea = 0;
	    blankSystemTbl.sPageOutAtr.hReserved[0]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[1]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[2]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[3]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[4]= 0; 
            blankSystemTbl.sPageOutAtr.hReserved[5]= 0;  
            return STATUS_OK;
        }

        Status CDocument::FillBlankPagePropertiesThumbnail(PaperSize paperSize, 
                FL_PAGE_MAN_TBL &blankSystemThumbnailTbl,
                FL_FILE_MAN_FILE  &baseThumbnailSystemfile,
                blank_page_data bpData, CString horizontalResolution)
        {
            DEBUGL4("CDocument::FillBlankPagePropertiesThumbnail: Enter\n");				

            int basePageIndex = m_basePageNumber - 1;

            //Get color mode of base page property
            CString colormode;
            m_basePageRef->GetWebDAVProperty("colorMode",	colormode);

            switch(m_jobColorType)
            {						
                //SCAN(JPEG)
                case SCAN_JPEG_JOB:
                    //Color Mode, sEngColorInfo.hColorMode, sEngColorinfo.hDataBit,  
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= COM_DT_8BIT;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= COM_YCC_INVALID;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = COM_CB_GRAYSCALE;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPaperType;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hValidity;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					

                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain = COM_RES_600_PRT;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = COM_RES_600_PRT;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCassette;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hWhitePaperFlag;
                    //Changes for Alabama and Loire
                    if(BOX_PRODUCT == "ALABAMA" || BOX_PRODUCT == "LOIRE")
                    {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff= 53;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff= 53;
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 53;
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 53;
                        blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = COM_ALIGN_NOTHING;
                    }
                    blankSystemThumbnailTbl.sPageOutAtr.hMoff= 0;
                    blankSystemThumbnailTbl.sPageOutAtr.hSoff= 0;
                    blankSystemThumbnailTbl.sPageOutAtr.hActMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hPrnDuplex; 
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;
                    //Changes for Alabama and Loire
                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //SCAN, FAX, EMAIL (MMR)
                case SCAN_FAX_EMAIL_MMR_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);						
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPaperType;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= COM_SM_MNL;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hValidity;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain = COM_RES_600_PRT;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = COM_RES_600_PRT;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCassette;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hWhitePaperFlag;							
                    blankSystemThumbnailTbl.sPageOutAtr.hMoff= 0;
                    blankSystemThumbnailTbl.sPageOutAtr.hSoff= 0;
                    blankSystemThumbnailTbl.sPageOutAtr.hActMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hPrnDuplex; 
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;
                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //PRINT (TTEC-JPEG color)
                case PRINT_TTEC_JPEG_color_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");							
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= COM_PDL_INVALID;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;							
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 56;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 56;					
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 54;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 53;

                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 53;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;

                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;		
                    //PRINT (TTEC-JPEG Mono)
                case PRINT_TTEC_JPEG_mono_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);		
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= COM_PDL_INVALID;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;							
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 56;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 56;					
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 54;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 53;

                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 53;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;
                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //PRINT RECTOR-RK1
               case PRINT_RECTOR_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode", colormode);
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode,
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalType;
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCenterCorner;
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= COM_PT_THIN;
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= COM_PDL_INVALID;
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= COM_SCRN_AUTO;
                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= COM_VA_INVALID;
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= COM_SZ_NOTHING;
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= COM_VA_VALID;
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hScanMethod;
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMainMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSubMagnification;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;
                    if((paperSize == ci::boxdocument::A3_WIDE) ||  (paperSize == ci::boxdocument::LEDGER_WIDE)) {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 0;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 0;
                    }
                    else
                    {
                        blankSystemThumbnailTbl.sPageOutAtr.hMoff  = 53;
                        blankSystemThumbnailTbl.sPageOutAtr.hSoff = 53;
                    }
                    if((paperSize == ci::boxdocument::A3_WIDE) || (paperSize == ci::boxdocument::LEDGER_WIDE))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 5;
                    else if((paperSize == ci::boxdocument::SRA3_450) || (paperSize == ci::boxdocument::SRA3_460) || (paperSize == ci::boxdocument::RECTANGLE13X19))
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 54;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 53;

                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 53;
                    if(paperSize == ci::boxdocument::RECTANGLE13X19)
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 253;
                    else
                        blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 53;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX;
                    //Added as per request for STFR-7743
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;
                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //COPY (Copy-JPEG)
                case COPY_Copy_JPEG_JOB:
                    m_blankPageRef->SetWebDAVProperty("colorMode","Gray");	
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = COM_CB_MONO;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    /*Commented as per request for STFR-7743*/
                    //blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = COM_CB_HQMONO_PPC;					
                    
                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = COM_CB_GRAYSCALE;

                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= COM_RGB_NORMAL;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= COM_RGB_NORMAL;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= COM_RGB_NORMAL;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= COM_1TCH_INVALID;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=100;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=100;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag = COM_VA_INVALID;							
                    blankSystemThumbnailTbl.sPageOutAtr.hMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 
        	    
					//hCenteringCopy
					blankSystemThumbnailTbl.sPageOutAtr.hCenteringCopy = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCenteringCopy;

                    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;
                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //COPY (Rector)
                case COPY_Rector_JOB:
                    //Color Mode
                    m_blankPageRef->SetWebDAVProperty("colorMode",	colormode);	
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hColorMode;
                    blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataBit;
                    //hYccForm, hJobColorMode, 					
                    blankSystemThumbnailTbl.sPageComAtr.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hYccForm;
                    blankSystemThumbnailTbl.sPageComAtr.hJobColorMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hJobColorMode;					
                    //sRGBBalanceInfo.hColorR, sRGBBalanceInfo.hColorG, sRGBBalanceInfo.hColorB
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorR= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorR;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorG= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorG;					
                    blankSystemThumbnailTbl.sPageComAtr.sRGBBalanceInfo.hColorB= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sRGBBalanceInfo.hColorB;

                    //hOriginalType, hOneTouchMode, hCenterCorner, hPaperType, hPDL, hPrintScreen, hTonerSave
                    blankSystemThumbnailTbl.sPageComAtr.hOriginalType= COM_OT_STANDARD;					
                    blankSystemThumbnailTbl.sPageComAtr.hOneTouchMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOneTouchMode;					
                    blankSystemThumbnailTbl.sPageComAtr.hCenterCorner= COM_CC_CORNER;										
                    blankSystemThumbnailTbl.sPageComAtr.hPaperType= COM_PT_THIN;					
                    blankSystemThumbnailTbl.sPageComAtr.hPDL= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPDL;					
                    blankSystemThumbnailTbl.sPageComAtr.hPrintScreen= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hPrintScreen;					

                    //hTonerSave, hSmoothing, hValidity, hScanMethod
                    blankSystemThumbnailTbl.sPageComAtr.hTonerSave= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hTonerSave;					
                    blankSystemThumbnailTbl.sPageComAtr.hSmoothing= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmoothing;					
                    blankSystemThumbnailTbl.sPageComAtr.hValidity= COM_VA_VALID;										
                    blankSystemThumbnailTbl.sPageComAtr.hScanMethod= COM_SM_MNL;					
                    //sPrnResolution.hMain, sPrnResolution.hSub
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hMain =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hMain;
                    blankSystemThumbnailTbl.sPageOutAtr.sPrnResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.sPrnResolution.hSub;

                    //hMainMagnification, hSubMagnification, hCassette
                    blankSystemThumbnailTbl.sPageOutAtr.hMainMagnification=100;
                    blankSystemThumbnailTbl.sPageOutAtr.hSubMagnification=100;
                    blankSystemThumbnailTbl.sPageOutAtr.hCassette=COM_PS_AUTO;

                    //hWhitePaperFlag, hMoff, hSoff, hPrnDuplex
                    blankSystemThumbnailTbl.sPageOutAtr.hWhitePaperFlag=COM_VA_INVALID;					
                    blankSystemThumbnailTbl.sPageOutAtr.hMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActMoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hActSoff = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hActSoff;
                    blankSystemThumbnailTbl.sPageOutAtr.hPrnDuplex = COM_BD_SIMPLEX; 
                   
					//hCenteringCopy
                    blankSystemThumbnailTbl.sPageOutAtr.hCenteringCopy = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCenteringCopy;

		    /*Added as per request for STFR-7743*/
                    blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;

                    blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;
                    break;
                    //default: //none
            }

            //hCType, hKPara, hPgMLen, hPgSlen, sResolution.hMain, sResolution.hSub
            blankSystemThumbnailTbl.sPageComAtr.hCType = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hCType;
            blankSystemThumbnailTbl.sPageComAtr.hKPara= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hKPara;
            blankSystemThumbnailTbl.sPageComAtr.hPgMLen = 0;
            blankSystemThumbnailTbl.sPageComAtr.hPgMLen = 0;
            //blankSystemThumbnailTbl.sPageComAtr.sResolution = (bpData.mainScanPixel / bpData.subScanPixel);
            blankSystemThumbnailTbl.sPageComAtr.sResolution.hMain = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hMain;
            blankSystemThumbnailTbl.sPageComAtr.sResolution.hSub= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sResolution.hSub;

            //Orientation
            blankSystemThumbnailTbl.sPageComAtr.hSize = bpData.hSize;
            blankSystemThumbnailTbl.sPageComAtr.hImgCoordinate = bpData.hImgCoordinate;

            //hInPgMLen, hPgSLen, sEngColorinfo.hPlane, sEngColorinfo.hDataForm
            blankSystemThumbnailTbl.sPageComAtr.hInPgMLen = 0;
            blankSystemThumbnailTbl.sPageComAtr.hInPgSLen = 0;
            blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hPlane= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hPlane;
            blankSystemThumbnailTbl.sPageComAtr.sEngColorInf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngColorInf.hDataForm;

            //sTwoColor.hMode, sTwoColor.hTwoColors1, sTwoColor.hTwoColors2, sTwoColor.hBoundaryValue
            blankSystemThumbnailTbl.sPageComAtr.sEngTwoColors.hMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hMode;
            blankSystemThumbnailTbl.sPageComAtr.sEngTwoColors.hTwoColors1 = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hTwoColors1;
            blankSystemThumbnailTbl.sPageComAtr.sEngTwoColors.hTwoColors2 = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hTwoColors2;
            blankSystemThumbnailTbl.sPageComAtr.sEngTwoColors.hBoundaryValue = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sEngTwoColors.hBoundaryValue;

            //Orientaton
            blankSystemThumbnailTbl.sPageComAtr.hAngle = bpData.hAngle;
            blankSystemThumbnailTbl.sPageComAtr.hOrientation = bpData.hOrientation;

            //sPageThumInfo.hCType, sPageThumInfo.hPgMLen, sPageThumInfo.hPgSLen, sResolution.hMain, sResolution.hSub
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hCType = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.hCType;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hPgMLen = bpData.mainThumbnailScanPixel;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hPgSLen = bpData.mainThumbnailSubScanPixel;				
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sResolution.hMain = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sResolution.hMain;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sResolution.hSub = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sResolution.hSub;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hSize= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.hSize;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hInPgMLen= bpData.mainScanTransferPixel;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hInPgSLen= bpData.subScanTransferPixel;							
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hColorMode= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hColorMode;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataBit= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataBit;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hPlane= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hPlane;					
            /*Commented as per request for STFR-7743*/
            //blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.sColorinf.hDataForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.sColorinf.hDataForm;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hYccForm= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.hYccForm;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hAngle= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.sPageThumInfo.hAngle;		
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[0]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[1]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[2]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[3]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[4]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[5]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[6]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[7]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[8]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[9]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[10]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[11]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[12]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[13]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[14]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[15]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[16]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[17]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[18]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[19]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[20]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[21]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[22]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[23]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[24]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[25]= 0;					
            blankSystemThumbnailTbl.sPageComAtr.sPageThumInfo.hReserved[26]= 0;					

            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorY=COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorM= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorC= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[0].hColorBK= COM_CB_NORMAL;

            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorY=COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorM= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorC= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[1].hColorBK= COM_CB_NORMAL;					

            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorY=COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorM= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorC= COM_CB_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sColorBalance[2].hColorBK= COM_CB_NORMAL;					

            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_Y = COM_HUE_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_M = COM_HUE_NORMAL; 
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_C = COM_HUE_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_R = COM_HUE_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_G = COM_HUE_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sHueinfo.hHue_B = COM_HUE_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_Y = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_M = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_C = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_R = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_G = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.sAllColorInfo.sSaturationInfo.hSaturation_B = COM_CRM_NORMAL;
            blankSystemThumbnailTbl.sPageComAtr.hMonoColor = COM_VA_INVALID;
            blankSystemThumbnailTbl.sPageComAtr.hSharpness = COM_SHR_NORMAL;					
            blankSystemThumbnailTbl.sPageComAtr.hImageQType= COM_IQT_GENERAL;					
	    blankSystemThumbnailTbl.sPageComAtr.hDFScanNoiseReduction= COM_DF_NOISE_REDUCTION_DISABLE;
	    blankSystemThumbnailTbl.sPageComAtr.hExtraImageQType= COM_EIQT_INVALID;
            blankSystemThumbnailTbl.sPageComAtr.hReserved[0] = 0;					
            blankSystemThumbnailTbl.sPageComAtr.hReserved[1] = 0;	
            blankSystemThumbnailTbl.sPageComAtr.hReserved[2] = 0;	
            blankSystemThumbnailTbl.sPageComAtr.hReserved[3] = 0;	
            //hMixImg, hMixTransparent, hMixFlg, hSharpnessFlg, hSmartCMMFlg
            //hNegaposiReverse, hDensityType, hDensityVal, hBackground
            //hEditMode, hOriginalSize, hAlignmentAddInfo
            blankSystemThumbnailTbl.sPageComAtr.hMixImg = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixImg;
            blankSystemThumbnailTbl.sPageComAtr.hMixTransparent = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixTransparent;
            blankSystemThumbnailTbl.sPageComAtr.hMixFlg = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hMixFlg;
            blankSystemThumbnailTbl.sPageComAtr.hSharpnessFlg = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSharpnessFlg;
            blankSystemThumbnailTbl.sPageComAtr.hSmartCMMFlg = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hSmartCMMFlg;
            blankSystemThumbnailTbl.sPageComAtr.hNegaposiReverse = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hNegaposiReverse;
            blankSystemThumbnailTbl.sPageComAtr.hDensityType = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hDensityType;
            blankSystemThumbnailTbl.sPageComAtr.hDensityVal = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hDensityVal;
            blankSystemThumbnailTbl.sPageComAtr.hBackground = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hBackground;
            blankSystemThumbnailTbl.sPageComAtr.hEditMode = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hEditMode;
            blankSystemThumbnailTbl.sPageComAtr.hOriginalSize = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hOriginalSize;
            //blankSystemThumbnailTbl.sPageComAtr.hAlignmentAddInfo = baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageComAtr.hAlignmentAddInfo;

            blankSystemThumbnailTbl.sPageOutAtr.hCopies =baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hCopies;
            blankSystemThumbnailTbl.sPageOutAtr.hPaperSize = bpData.hPaperSize;
            blankSystemThumbnailTbl.sPageOutAtr.hSFBPaperSize= bpData.hPaperSize;
            blankSystemThumbnailTbl.sPageOutAtr.hInsReverse=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsReverse;
            blankSystemThumbnailTbl.sPageOutAtr.hTabPaperFlag=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabPaperFlag;
            blankSystemThumbnailTbl.sPageOutAtr.hTabMoff=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabMoff;
            blankSystemThumbnailTbl.sPageOutAtr.hTabSoff=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabSoff;
            blankSystemThumbnailTbl.sPageOutAtr.hTabWidth=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hTabWidth; 
            blankSystemThumbnailTbl.sPageOutAtr.hMirror=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hMirror;
            blankSystemThumbnailTbl.sPageOutAtr.hInsPaperSize=baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsPaperSize;
            blankSystemThumbnailTbl.sPageOutAtr.hInsPaperType= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hInsPaperType;
            blankSystemThumbnailTbl.sPageOutAtr.hSpFeed= 432;
            blankSystemThumbnailTbl.sPageOutAtr.hSpWidth= 297;
            blankSystemThumbnailTbl.sPageOutAtr.hForceFrontSide= baseThumbnailSystemfile.sPageManTbl[basePageIndex].sPageOutAtr.hForceFrontSide;

            //Updated newly added structure field
#if 0
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[0]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[1]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[2]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[3]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[4]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[5]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[6]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[7]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[8]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[9]= 0; 
#endif
            //blankSystemThumbnailTbl.sPageOutAtr.hActMoff = 0;
            //blankSystemThumbnailTbl.sPageOutAtr.hActSoff = 0;

            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[0] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[1] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[2] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[3] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[4] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[5] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[6] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[7] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[8] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[9] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[10] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[11] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[12] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[13] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[14] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[15] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[16] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[17] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[18] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[19] = 0;
            blankSystemThumbnailTbl.sPageOutAtr.aTSINo[20] = 0;		
	    blankSystemThumbnailTbl.sPageOutAtr.hExpandPrnArea = 0;
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[0]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[1]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[2]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[3]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[4]= 0; 
            blankSystemThumbnailTbl.sPageOutAtr.hReserved[5]= 0;  

            return STATUS_OK;
        }
        Status CDocument::GetBlankPageData(int jobColorType, PaperSize paperSize, blank_page_data &bpData, CString resolution)
        {
            DEBUGL4("CDocument::GetBlankPageData: Enter\n");				
            int *bPtr = NULL;
            int *bPtr_o = NULL;
            int *bPtrRev_o = NULL;
            int *bPtrRev = NULL;
            int *bThPtr = NULL;
            int *bThPtrRev = NULL;
            int resn = 0;
	    //Added to get the SUB_PRODUCT_MODEL for Weiss2H
	    char *subProductModel = NULL;
	    CString SUBPRODUCT_MODEL = "";
	    if(BOX_PRODUCT == "WEISS")
	    {
		    subProductModel = getenv("SUB_PRODUCT_MODEL");
		    SUBPRODUCT_MODEL = CString(subProductModel);
	    }
	    
            if(resolution == "600600") 
                resn = RESOLUTION_600600;
            else if(resolution == "400400") 
                resn = RESOLUTION_400400;
            else if(resolution == "300300")
                resn = RESOLUTION_300300;
            else if(resolution == "200200") 
                resn = RESOLUTION_200200;
            else if(resolution == "150150") 
                resn = RESOLUTION_150150;
            else if(resolution == "100100") 
                resn = RESOLUTION_100100;

            switch(jobColorType)
            {
                //SCAN(JPEG)
                case SCAN_JPEG_JOB:
                    switch(resn)
                    {
                        case RESOLUTION_600600:
                            bPtr = SCAN_JPG_600600_A;
                            bPtrRev = SCAN_JPG_600600_AR;
                            break;
                        case RESOLUTION_400400:
                            bPtr = SCAN_JPG_400400_A;
                            bPtrRev = SCAN_JPG_400400_AR;
                            break;
                        case RESOLUTION_300300:
                            bPtr = SCAN_JPG_300300_A;
                            bPtrRev= SCAN_JPG_300300_AR;
                            break;
                        case RESOLUTION_200200:
                            bPtr = SCAN_JPG_200200_A;
                            bPtrRev= SCAN_JPG_200200_AR;
                            break;
                        case RESOLUTION_150150:
                            bPtr = SCAN_JPG_150150_A;
                            bPtrRev= SCAN_JPG_150150_AR;
                            break;
                        case RESOLUTION_100100:
                            bPtr = SCAN_JPG_100100_A;
                            bPtrRev= SCAN_JPG_100100_AR;
                            break;
                    }
                    break;
                    //SCAN, FAX, EMAIL (MMR)
                case SCAN_FAX_EMAIL_MMR_JOB:
                    switch(resn)
                    {
                        case RESOLUTION_600600:
                            bPtr = SCAN_MMR_600600_A;
                            bPtrRev = SCAN_MMR_600600_AR;
                            break;
                        case RESOLUTION_400400:
                            bPtr = SCAN_MMR_400400_A;
                            bPtrRev = SCAN_MMR_400400_AR;
                            break;
                        case RESOLUTION_300300:
                            bPtr = SCAN_MMR_300300_A;
                            bPtrRev= SCAN_MMR_300300_AR;
                            break;
                        case RESOLUTION_200200:
                            bPtr = SCAN_MMR_200200_A;
                            bPtrRev= SCAN_MMR_200200_AR;
                            break;
                        case RESOLUTION_150150:
                            bPtr = SCAN_MMR_150150_A;
                            bPtrRev= SCAN_MMR_150150_AR;
                            break;
                        case RESOLUTION_100100:
                            bPtr = SCAN_MMR_100100_A;
                            bPtrRev= SCAN_MMR_100100_AR;
                            break;
                    }
                    break;
                    //PRINT (TTEC-JPEG color)
                case PRINT_TTEC_JPEG_color_JOB:
                    //PRINT (TTEC-JPEG Mono)
                case PRINT_TTEC_JPEG_mono_JOB:
                    bPtr = PRINT_TJP_600600_A;
                    bPtrRev = PRINT_TJP_600600_A;
                    break;
                case PRINT_RECTOR_JOB:
                    bPtr = PRINT_RK1_600600_A;
                    bPtrRev = PRINT_RK1_600600_A;
                    break;

                    //COPY (Copy-JPEG)
                case COPY_Copy_JPEG_JOB:
                    bPtr = COPY_CJP_600600_A;
                    bPtrRev = COPY_CJP_600600_A;
                    break;
                    //COPY (Rector)
                case COPY_Rector_JOB:
                    bPtr = COPY_RK1_600600_A;	
                    bPtrRev = COPY_RK1_600600_A;
                    break;

            }	
            bThPtr = THUMBNAIL_PNG_A;
            bThPtrRev = THUMBNAIL_PNG_AR;

            DEBUGL8("CDocument::GetBlankPageData: m_JobVal = (%s)\n", m_JobVal.c_str());
            if(m_JobVal == "Scan"|| m_JobVal=="Fax")
            {
                bPtr_o = SCAN_ORIENT;
                bPtrRev_o = SCAN_ORIENT_R;
            }
            else if(m_JobVal=="Print")
            {
                bPtr_o = PRINT_ORIENT;
                bPtrRev_o = PRINT_ORIENT_R;
            }
            else if(m_JobVal == "Copy")
            {
                bPtr_o = COPY_ORIENT;
                bPtrRev_o = COPY_ORIENT_R;
            }
            else
            {
                DEBUGL8("CDocument::GetBlankPageData: Invalid jobtype\n");
            }


            switch(paperSize)
            {
                case ci::boxdocument::A3_R:
                    UpdateOrientation(bpData, bPtrRev_o, A3_O);
                    break;												
                case ci::boxdocument::A3:
                    UpdateOrientation(bpData, bPtr_o, A3_O);
                    break;
                case ci::boxdocument::B4_R:						
                    UpdateOrientation(bpData, bPtrRev_o, B4_O);
                    break;												
                case ci::boxdocument::B4:							
                    UpdateOrientation(bpData, bPtr_o, B4_O);
                    break;
                case ci::boxdocument::A4_R:
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtrRev_o, A4_O);
                        break;
                    }
                    else if(jobColorType == COPY_Rector_JOB ||
                            jobColorType == COPY_Copy_JPEG_JOB)
                    {
                        UpdateOrientation(bpData, bPtrRev_o, A4_O);
                        break;
                    }
                    UpdateOrientation(bpData, bPtrRev_o, A4_O);
                    break;												
                case ci::boxdocument::A4: 
                    UpdateOrientation(bpData, bPtr_o, A4_O);
                    break;
                case ci::boxdocument::B5_R: 
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtrRev_o, B5_O);
                        break;
                    }              							
                    else if(jobColorType == COPY_Rector_JOB ||
                            jobColorType == COPY_Copy_JPEG_JOB)
                    {
                        UpdateOrientation(bpData, bPtrRev_o, B5_O);
                        break;
                    }										
                    UpdateOrientation(bpData, bPtrRev_o, B5_O);
                    break;									
                case ci::boxdocument::B5: 							
                    UpdateOrientation(bpData, bPtr_o, B5_O);
                    break;
                case ci::boxdocument::A5_R:
                    UpdateOrientation(bpData, bPtrRev_o, A5_O);
                    break;									
                case ci::boxdocument::A5: 							
                    UpdateOrientation(bpData, bPtr_o, A5_O);
                    break;
                case ci::boxdocument::A6_R:
                    UpdateOrientation(bpData, bPtrRev_o, A6_O);
                    break;									
                case ci::boxdocument::A6: 							
                    UpdateOrientation(bpData, bPtr_o, A6_O);
                    break;
                case ci::boxdocument::POSTCARD_R: 
                    UpdateOrientation(bpData, bPtrRev_o, POSTCARD_O);
                    break;									
                case ci::boxdocument::POSTCARD: 
                    UpdateOrientation(bpData, bPtr_o, POSTCARD_O);
                    break;
                case ci::boxdocument::LEDGER_R:
                    UpdateOrientation(bpData, bPtrRev_o, LEDGER_O);
                    break;									
                case ci::boxdocument::LEDGER: 							
                    UpdateOrientation(bpData, bPtr_o, LEDGER_O);
                    break;
                case ci::boxdocument::LEGAL_R: 
                    UpdateOrientation(bpData, bPtrRev_o, LEGAL_O);
                    break;									
                case ci::boxdocument::LEGAL: 							
                    UpdateOrientation(bpData, bPtr_o, LEGAL_O);
                    break;
                case ci::boxdocument::LETTER_R:
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtrRev_o, LETTER_O);
                        break;
                    }
                    else if(jobColorType == COPY_Rector_JOB ||
                            jobColorType == COPY_Copy_JPEG_JOB)
                    {
                        UpdateOrientation(bpData, bPtrRev_o, LETTER_O);
                        break;
                    }										

                    UpdateOrientation(bpData, bPtrRev_o, LETTER_O);
                    break;									
                case ci::boxdocument::LETTER: 							
                    UpdateOrientation(bpData, bPtr_o, LETTER_O);
                    break;
                case ci::boxdocument::STATEMENT_R:
                    UpdateOrientation(bpData, bPtrRev_o, STATEMENT_O);
                    break;									
                case ci::boxdocument::STATEMENT: 							
                    UpdateOrientation(bpData, bPtr_o, STATEMENT_O);
                    break;												
                case ci::boxdocument::FOLIO_R: 
                    UpdateOrientation(bpData, bPtrRev_o, FOLIO_O);
                    break;									
                case ci::boxdocument::FOLIO: 							
                    UpdateOrientation(bpData, bPtr_o, FOLIO_O);
                    break;												
                case ci::boxdocument::COMPUTER_R:
                    UpdateOrientation(bpData, bPtrRev_o, COMPUTER_O);
                    break;
                case ci::boxdocument::COMPUTER: 							
                    UpdateOrientation(bpData, bPtr_o, COMPUTER_O);
                    break;												
                case ci::boxdocument::LEGAL13_R:
                    UpdateOrientation(bpData, bPtrRev_o, LEGAL13_O);
                    break;									
                case ci::boxdocument::LEGAL13: 							
                    UpdateOrientation(bpData, bPtr_o, LEGAL13_O);
                    break;												
                case ci::boxdocument::A3_WIDE_R:
                    UpdateOrientation(bpData, bPtrRev_o, A3_WIDE_O);
                    break;									
                case ci::boxdocument::SRA3_450_R:

                    UpdateOrientation(bpData, bPtrRev_o, SRA3_450_O);
                    break;									
                case ci::boxdocument::SRA3_460_R:

                    UpdateOrientation(bpData, bPtrRev_o, SRA3_460_O);
                    break;									
                case ci::boxdocument::A3_WIDE:
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtr_o, A3_WIDE_O);
                        break;
                    }
                    else
                    {
                        UpdateOrientation(bpData, bPtr_o, A3_WIDE_O);
                        break;
                    }     
                case ci::boxdocument::SRA3_450:
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB ||   jobColorType == PRINT_TTEC_JPEG_mono_JOB)
		    {
			//SRA3_450 is supported for Shasta/Shastina/Weiss2H
                        if((BOX_PRODUCT == "BP") || (BOX_PRODUCT == "ALABAMA") || ((BOX_PRODUCT == "WEISS")&&(SUBPRODUCT_MODEL == "H_MODEL")))
			{
                            UpdateOrientation(bpData, bPtr_o, SRA3_450_O);
                            break;
                        }
                        else if (BOX_PRODUCT == "MASH") {
                            UpdateOrientation(bpData, bPtr_o, SRA3_450_O);
                            break;
                        }												
                    }
                    else
                    {
                        UpdateOrientation(bpData, bPtr_o, SRA3_450_O);
                        break;
                    }
                case ci::boxdocument::SRA3_460: 
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
			//SRA3_460 is supported for Shasta/Shastina/Weiss2H
                        if((BOX_PRODUCT == "BP") || (BOX_PRODUCT == "ALABAMA") || ((BOX_PRODUCT == "WEISS")&&(SUBPRODUCT_MODEL == "H_MODEL")))
			{
                            UpdateOrientation(bpData, bPtr_o, SRA3_460_O);
                            break;
                        }
                        else if (BOX_PRODUCT == "MASH") {
                            UpdateOrientation(bpData, bPtr_o, SRA3_460_O);
                            break;
                        }												
                    }							
                    else {
                        UpdateOrientation(bpData, bPtr_o, SRA3_460_O);
                        break;
                    }
                case ci::boxdocument::LEDGER_WIDE_R: 	

                    UpdateOrientation(bpData, bPtrRev_o,LEDGER_WIDE_R_O);
                    break;									
                case ci::boxdocument::RECTANGLE13X19_R:
                    UpdateOrientation(bpData, bPtrRev_o,RECTANGLE13X19_O);
                    break;									
                case ci::boxdocument::LEDGER_WIDE:
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtrRev_o,LEDGER_WIDE_R_O);
                        break;
                    }
                    else {
                        UpdateOrientation(bpData, bPtrRev_o,LEDGER_WIDE_R_O);
                        break;
                    }
                case ci::boxdocument::RECTANGLE13X19:							
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || PRINT_TTEC_JPEG_mono_JOB) {
			//RECTANGLE13X19 is supported for Shasta/Shastina
                        if((BOX_PRODUCT == "BP") || (BOX_PRODUCT == "ALABAMA"))
			{
                            UpdateOrientation(bpData, bPtr_o,RECTANGLE13X19_O);
                            break;
                        }
                        else if (BOX_PRODUCT == "MASH") {
                            UpdateOrientation(bpData, bPtr_o,RECTANGLE13X19_O);
                            break;
                        }												
                    }							
                    else
                    {
                        UpdateOrientation(bpData, bPtr_o,RECTANGLE13X19_O);
                        break;												
                    }
                case ci::boxdocument::SQUARE8_5_R: 
                    UpdateOrientation(bpData, bPtrRev_o,SQUARE8_5_O);
                    break;									
                case ci::boxdocument::SQUARE8_5: 							
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtr_o,SQUARE8_5_O);
                        break;
                    }
                    UpdateOrientation(bpData, bPtr_o,SQUARE8_5_O);
                    break;												
                case ci::boxdocument::SIZE_8K_R:
                    UpdateOrientation(bpData, bPtrRev_o,SIZE_8K_O);
                    break;
                case ci::boxdocument::SIZE_8K: 
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtr_o,SIZE_8K_O);
                        break;
                    }        							
                    UpdateOrientation(bpData, bPtr_o,SIZE_8K_O);
                    break;											
                case ci::boxdocument::SIZE_16K_R: 
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtrRev_o,SIZE_16K_O);
                        break;
                    }
                    else if(jobColorType == COPY_Rector_JOB ||
                            jobColorType == COPY_Copy_JPEG_JOB)
                    {
                        UpdateOrientation(bpData, bPtrRev_o,SIZE_16K_O);
                        break;
                    }										

                    UpdateOrientation(bpData, bPtrRev_o,SIZE_16K_O);
                    break;									
                case ci::boxdocument::SIZE_16K: 
                    if(jobColorType == PRINT_TTEC_JPEG_color_JOB || 
                            jobColorType == PRINT_TTEC_JPEG_mono_JOB) {
                        UpdateOrientation(bpData, bPtr_o,SIZE_16K_O);
                        break;
                    }							
                    UpdateOrientation(bpData, bPtr_o,SIZE_16K_O);
                    break;		
                case ci::boxdocument::A1: //Do nothing
                case ci::boxdocument::A2: //Do nothing
                case ci::boxdocument::A7: //Do nothing
                case ci::boxdocument::B1: //Do nothing
                case ci::boxdocument::B2: //Do nothing
                case ci::boxdocument::B3: //Do nothing
                case ci::boxdocument::B6: //Do nothing
                case ci::boxdocument::B7: //Do nothing
                case ci::boxdocument::A1_R: //Do nothing
                case ci::boxdocument::A2_R: //Do nothing
                case ci::boxdocument::A7_R: //Do nothing
                case ci::boxdocument::B1_R: //Do nothing
                case ci::boxdocument::B2_R: //Do nothing
                case ci::boxdocument::B3_R: //Do nothing
                case ci::boxdocument::B6_R: //Do nothing
                case ci::boxdocument::B7_R: //Do nothing
                case ci::boxdocument::UNDEF_SIZE: //Do nothing		
                case ci::boxdocument::SPECIAL_SIZE: //Do nothing
                case ci::boxdocument::SPECIAL_LONG800: //Do nothing
                case ci::boxdocument::SPECIAL_LONG1200: //Do nothing
		    case ci::boxdocument::LEGAL135_R: //Do nothing
		    case ci::boxdocument::LEGAL135: //Do nothing
		    case ci::boxdocument::EXECTIVE_R: //Do nothing
		    case ci::boxdocument::EXECTIVE: //Do nothing
		    case ci::boxdocument::DOUBLEPOSTCARD: //Do nothing
		    case ci::boxdocument::DOUBLEPOSTCARD_R://Do nothing
                    break;
            }
            
            if(!bPtr)
            {
                DEBUGL8("CDocument::GetBlankPageData::bPtr pointing to NULL\n");
                return STATUS_FAILED;
            }

            if(m_JobVal == "Scan" || m_JobVal == "Fax")
            {
                for(int i = 0; i < SCAN_ARRAY_SIZE; i += COLUMN_SIZE)   
                {   
                    if(bPtr[i] == bpData.hSize) {
                        UpdateBlankPageData(bpData, bPtr, bThPtr, i+1);
                        break;
                    }
                    else if(bPtrRev[i] == bpData.hSize) {
                        UpdateBlankPageData(bpData, bPtrRev, bThPtrRev, i+1);
                        break;
                    }
                }           
            }

            else if(m_JobVal == "Print")
            {
                for(int i = 0; i < PRINT_ARRAY_SIZE; i += COLUMN_SIZE)
                {  
                    if(bPtr[i] == bpData.hSize)
                    {
                        if(bpData.hSize == COM_SRA3_450R || bpData.hSize == COM_SRA3_460R || bpData.hSize == COM_13X19R)
                        {
			    //SRA3_450, SRA3_460 is supported for Shasta/Shastina/Weiss2H and 13X19 is supported for Shasta and Shastina
                            if((BOX_PRODUCT == "BP") || (BOX_PRODUCT == "ALABAMA") || (BOX_PRODUCT == "WEISS"))
                                UpdateBlankPageData(bpData, bPtr, bThPtr, i+1);
                            else if(BOX_PRODUCT == "MASH")
                                UpdateBlankPageData(bpData, bPtr, bThPtr, i+11);

                            break;
                        }
                        UpdateBlankPageData(bpData, bPtr, bThPtr, i+1);
                        break;
                    }
                }
            }

            else if(m_JobVal == "Copy")
            {
                DEBUGL8("CDocument::GetBlankPageData: bpData.hSize = %d \n",bpData.hSize);
                for(int i = 0; i < COPY_ARRAY_SIZE; i += COLUMN_SIZE) 
                {
                    if(bPtr[i] == bpData.hSize)
                    {
                        DEBUGL8("CDocument::GetBlankPageData: bPtr[i] = %d \n",bPtr[i]);
                        DEBUGL8("CDocument::GetBlankPageData: index = %d \n",i);
                        UpdateBlankPageData(bpData, bPtr, bThPtr, i+1);
                        break;
                    }

                }
            }
            else 
                DEBUGL8("CDocument::GetBlankPageData: Invalid JobType\n");

            DEBUGL4("CDocument::GetBlankPageData: Exit\n");				
            return STATUS_OK;
        }

        Status CDocument::UpdateBlankPageData(blank_page_data &pData, int *arrayAddr, int *thumbnailArrayAddr, int index)
		  {
			  DEBUGL4("CDocument::UpdateBlankPageData: Enter\n");				
			  pData.mainScanPixel = *(arrayAddr+index+MAIN_SCAN_PIXEL);
			  pData.subScanPixel = *(arrayAddr+index+SUB_SCAN_PIXEL);
			  pData.mainScanTransferPixel = *(arrayAddr+index+MAIN_SCAN_TX_PIXEL);
			  pData.subScanTransferPixel = *(arrayAddr+index+SUB_SCAN_TX_PIXEL);									

			  //Fix for EBX_STFR_15356
			  char *fileSize = NULL;

			  fileSize = (char*)malloc(FILE_SIZE_MAX_LEN);
			  if(fileSize == NULL)
			  {
					DEBUGL1("CDocument::UpdateBlankPageData:malloc failed to allocate the memory\n");
					return STATUS_FAILED;
			  }
			  memset(fileSize,0,FILE_SIZE_MAX_LEN);
			  sprintf(fileSize, "%d", *(arrayAddr+index+FILE_SIZE));
			  pData.fileSize = *fileSize;
			  DEBUGL8("CDocument::UpdateBlankPageData: fileSize = %s\n",pData.fileSize.c_str());	
			  free(fileSize);
			  fileSize = NULL;
			  pData.mainThumbnailScanPixel = *(arrayAddr+index+MAIN_SCAN_PIXEL);
			  pData.mainThumbnailSubScanPixel = *(arrayAddr+index+SUB_SCAN_PIXEL);
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.mainScanPixel = %d \n", pData.mainScanPixel);
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.subScanPixel = %d \n", pData.subScanPixel);					
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.mainScanTransferPixel = %d \n", pData.mainScanTransferPixel);
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.subScanTransferPixel = %d \n", pData.subScanTransferPixel);
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.mainThumbnailScanPixel = %d \n", pData.mainThumbnailScanPixel);
			  DEBUGL8("CDocument::UpdateBlankPageData: pData.mainThumbnailSubScanPixel = %d \n", pData.mainThumbnailSubScanPixel);
			  return STATUS_OK;
		  }

        Status CDocument::UpdateOrientation(blank_page_data &pData, int *arrayAddr, int index)
        {
            DEBUGL4("CDocument::UpdateOrientation: Enter\n");		

            pData.hSize = *(arrayAddr+index+H_SIZE);
            pData.hImgCoordinate = *(arrayAddr+index+H_IMG_COORDINATE);
            pData.hAngle = *(arrayAddr+index+H_ANGLE);
            pData.hPaperSize = *(arrayAddr+index+H_PAPER_SIZE);
            pData.hOrientation = *(arrayAddr+index+H_ORIENTATION);

            DEBUGL8("CDocument::UpdateOrientation: pData.hSize = %d \n", pData.hSize);
            DEBUGL8("CDocument::UpdateOrientation: pData.hImgCoordinate = %d \n", pData.hImgCoordinate);
            DEBUGL8("CDocument::UpdateOrientation: pData.hAngle = %d \n", pData.hAngle);
            DEBUGL8("CDocument::UpdateOrientation: pData.hPaperSize = %d \n", pData.hPaperSize);
            DEBUGL8("CDocument::UpdateOrientation: pData.hOrientation = %d \n", pData.hOrientation);

            DEBUGL4("CDocument::UpdateOrientation: Exit\n");		
            return STATUS_OK;

        } 
        Status CDocument::GetPageList(PageList &list) {
            return GetPageList(list, 1, 65535);
        }

        Status CDocument::GetPageList(PageList &list, 
                unsigned int from, unsigned int size) {
            DocStatus st;
            DEBUGL4("CDocument::GetPageList:Enter\n");

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::GetPageList::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(st == DELETING) {
                DEBUGL1("CDocument::GetPageList::Document is DELETING\n");
                return STATUS_FAILED;
            }


            if(st == EDITING)
            {	
                //check if the session-id property set on the document is same as the current sessionID
                CString val;
                CString resourceKey=Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName)+"/";
                if(GetWebDAVProperty("sessionID", val)!= STATUS_OK)
                {
                    DEBUGL2("CDocument::GetPageList: GetProperty of sessionID failed\n");
                    val.clear();
                }
                DEBUGL8("CDocument::GetPageList::SessionID<%s>\n",val.c_str());
                if(val==m_sessionID)
                {	
                    //Initialize WorkSpace
                    WorkSpaceInit();
                }	
            }
            CString docpath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);
            list.clear();
            CString path = docpath + "/Image/" + CString(SYSTEMFILE);
            Status openStatus = STATUS_OK;
            if((openStatus = OpenSystemDataFile(m_SystemDataFile, path)) != STATUS_OK) {
                if( openStatus == STATUS_INVALID_URI)
                {
                    DEBUGL2("CDocument::GetPageList::returning STATUS_OK for Inavlid URI as Image system file does not exist\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
                    return STATUS_OK;
                }
                DEBUGL1("CDocument::GetPageList::OpenSystemDataFile Failed for Image\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                return STATUS_FAILED;
            }

            path =docpath+ "/Thumbnail/" + CString(SYSTEMFILE);						
            if((openStatus = OpenSystemDataFile(m_ThumbnailSystemDataFile, path)) != STATUS_OK) {
                if( openStatus == STATUS_INVALID_URI)
                {
                    DEBUGL2("CDocument::GetPageList::returning STATUS_OK for Inavlid URI as Thumbnail system file does not exist\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
                    return STATUS_OK;
                }
                DEBUGL1("CDocument::GetPageList::OpenSystemDataFile Failed for Thumbnail\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                return STATUS_FAILED;
            }

            path = docpath +"/Subsampling/" + CString(SYSTEMFILE);												
            if((openStatus = OpenSystemDataFile(m_SubsamplingSystemDataFile, path)) != STATUS_OK) {
                if( openStatus == STATUS_INVALID_URI)
                {
                    DEBUGL2("CDocument::GetPageList::returning STATUS_OK for Inavlid URI as Subsampling system file does not exist\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
                    return STATUS_OK;
                }
                DEBUGL1("CDocument::GetPageList::OpenSystemDataFile Failed for Subsampling\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                return STATUS_FAILED;
            }
			
            unsigned int total = m_SystemDataFile.sFileMan.hFlPageNum;;

            PageRef page;
            for(unsigned int pageno = from, cnt = 0; (cnt < size && pageno <= total); pageno++, cnt++) {
                if(GetPage(pageno, page) != STATUS_OK) {
                    DEBUGL1("CDocument::GetPageList::getting page %d is failed\n", pageno);
                    break;
                }
                list.push_back(page);
            }
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
            return STATUS_OK;
        }

        Status CDocument::SetWebDAVPropertyFromSystemFile(void* systemfile) {
            // get Page list
            if(m_PageList.empty()) {
                if(GetPageList(m_PageList) != STATUS_OK) {
                    return STATUS_FAILED;
                }
            }
            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == CREATING || st == EDITING)) {
                DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            iSSetsysfileInvoked = true;
            FL_FILE_MAN_FILE* fl_file_man_file = reinterpret_cast<FL_FILE_MAN_FILE*>(systemfile);
            m_SystemDataFile = static_cast<FL_FILE_MAN_FILE>(*fl_file_man_file);
            // document property
            m_TotalPage = m_SystemDataFile.sFileMan.hFlPageNum;
            SetWebDAVProperty("totalPages", m_TotalPage);

            //update total size.
            m_TotalSize = m_SystemDataFile.sFileMan.liFlSize;
            std::ostringstream st1;
            st1 << m_TotalSize;
            DEBUGL8("CDocument::SetWebDAVPropertyFromSystemFile: totalSize = (%s)\n", st1.str().c_str());
            Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st1.str());
            if(sd != STATUS_OK)
                DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile: Failed to set the totalSize for the document\n");


            PageList::iterator it = m_PageList.begin();
            try
            {
                for(int i = 0; it != m_PageList.end(); it++, i++) {
                    if(!(*it))
                    {
                        DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile: Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>((*it).operator->())->SetWebDAVPropertyFromSystemFile(&m_SystemDataFile.sPageManTbl[i]);
                }
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile::Exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }	
            //Now create a systemfile 
            Status ret=copySystemFile(m_SystemDataFile,"Image");
            if(ret != STATUS_OK)
            {
                DEBUGL1("CDocument::SetWebDAVPropertyFromSystemFile::copying SystemFile Failed\n");
                return ret;
            }
            return STATUS_OK;
        }

        Status CDocument::GetSystemFile(CString &path) {
            // TODO: copy to local folder

            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::GetSystemFile::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == USING || st == EDITING)) {
                DEBUGL1("CDocument::GetSystemFile::Document is NOT USING or EDITING\n");
                return STATUS_FAILED;
            }

            path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName);
            path += "/Image/" + CString(SYSTEMFILE);
            return STATUS_OK;
        }

        Status CDocument::GetSubsamplingSystemFile(CString &path) {
            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::GetSubsamplingSystemFile::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == USING || st == EDITING)) {
                DEBUGL1("CDocument::GetSubsamplingSystemFile::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName);
            path += "/Subsampling/" + CString(SYSTEMFILE);

            return STATUS_OK;
        }

        Status CDocument::GetThumbnailSystemFile(CString &path) {
            // TODO: copy to local folder
            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::GetThumbnailSystemFile::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(!(st == USING || st == EDITING)) {
                DEBUGL1("CDocument::GetThumbnailSystemFile::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName);
            path += "/Thumbnail/" + CString(SYSTEMFILE);

            return STATUS_OK;
        }

        Status CDocument::GetThumbnailImage(CString &path) {
            path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName);
            path += "/Thumbnail/001.png"; 
            return STATUS_OK;
        }


        Status CDocument::SetWEPDocument(dom::NodeRef node) {

            if(!node)
            {
                DEBUGL1("CDocument::SetWEPDocument::dom Node argument is invalid(NULL)\n");
                return STATUS_FAILED;
            }
            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::SetWEPDocument::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(st != CREATING) {
                DEBUGL1("CDocument::SetWEPDocument::Document is NOT CREATING\n");
                return STATUS_FAILED;
            }
            // WEP must be set using WebDAV for file permission
            // serialize hdb document in temporary folder
            CString weppath = Utility::GetHDBROOTPath();
            weppath += WEP_FILENAME;
            try {
                HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if(!hdb)
                {
                    DEBUGL1("CDocument::SetWEPDocument: Failed to acquire the hdb object\n");
                    return STATUS_FAILED;							
                }
                hdb->SerializeToFile(node, weppath);
            }
            catch(CException & except)
            {
                DEBUGL1("\nCDocument::SetWEPDocument: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCDocument::SetWEPDocument: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            // put WEP to document folder
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            path += WEP_FILENAME;
            DEBUGL8("CDocument::SetWEPDocument:: path = (%s)\n",path.c_str());
            Status ds = ci::operatingenvironment::File::CopyFile( weppath,path);
            if(ds!=STATUS_OK)
            {
                if(ds == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SetWEPDocument::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }
                else 
                {
                    DEBUGL1("CDocument::SetWEPDocument::put resource document %s is failed\n", path.c_str());
                    return STATUS_FAILED;
                }
            }

            struct stat weppath_buf;
            uint64 wepsize = 1;
            if(stat(weppath.c_str(), &weppath_buf) != 0)
            {
                DEBUGL2("CDocument::SetWEPDocument:: Cannot stat wep file, setting size as 0\n");
                wepsize = 0;
            }
            wepsize = wepsize? weppath_buf.st_size:0;
            SetAllSize();
            ostringstream docsize;	
            docsize << wepsize;
            path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            DEBUGL8("CDocument::SetWEPDocument::WEPSize Size: %s\n",docsize.str().c_str());
            SetWebDAVProperty("docWEPSize", docsize.str());

            File::DeleteFile(weppath);

            //Update ModifiedDate
            SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
            SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());

            return STATUS_OK;
        }

        Status CDocument::GetWEPDocument(dom::NodeRef &node, CString xpath) {

            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            path += WEP_FILENAME;

            // TODO :Confirm file exists or not
            // TODO: Need to copy to local?

            try {
                // Create / Open HDB Document
                dom::DocumentRef doc;
                HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if(!hdb)
                {
                    DEBUGL1("CDocument::GetWEPDocument: Failed to acquire the hdb object\n");
                    return STATUS_FAILED;							
                }

                std::ostringstream oss;
                Ref<CUUID> uuid = new CUUID();
                oss << "BoxDocumentWEP" << uuid->toString();
                m_WEPDocumentID = oss.str();
                CString folderpath = Utility::GetHDBROOTPath();
                Status st = hdb->CreateDocumentFromFile(folderpath, m_WEPDocumentID, doc, path);
                if(st != STATUS_OK) {
                    DEBUGL1("CDocument::GetWEPDocument::opening WEP is failed\n");
                    return STATUS_FAILED;
                }
                if(xpath != "") {
                    node = hdb->BindToElement(doc, xpath);
                } else {
                    node = doc->getDocumentElement();
                }
            }
            catch(CException & except)
            {
                DEBUGL1("\nCDocument::GetWEPDocument: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCDocument::GetWEPDocument: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CDocument::GetWEPDocument(CString& documentID) {
            DEBUGL4("CDocument::GetWEPDocument:: Enter\n");
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            path += WEP_FILENAME;

            DEBUGL8("CDocument::GetWEPDocument:: document ID = (%s)\n", documentID.c_str());
            // TODO :Confirm file exists or not
            try {	
                // Create HDB Document
                dom::DocumentRef doc;
                HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if(!hdb)
                {
                    DEBUGL1("CDocument::GetWEPDocument: Failed to acquire the hdb object\n");
                    return STATUS_FAILED;							
                }

                std::ostringstream oss;
                Ref<CUUID> uuid = new CUUID();
                oss << "WEP_" << uuid->toString();
                documentID = oss.str();
                CString folderpath = Utility::GetHDBROOTPath();
                DEBUGL8("CDocument::GetWEPDocument:: document ID = (%s)\n", documentID.c_str());
                Status st = hdb->CreateDocumentFromFile(folderpath, documentID, doc, path);
                if(st != STATUS_OK) {
                    DEBUGL1("CDocument::GetWEPDocument::opening WEP is failed\n");
                    return STATUS_FAILED;
                }
            }
            catch(CException & except)
            {
                DEBUGL1("\nCDocument::GetWEPDocument: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCDocument::GetWEPDocument: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument::GetWEPDocument:: Exit\n");
            return STATUS_OK;
        }

        Status CDocument::SetWebDAVProperty(CString key, int value) {
            std::ostringstream oss;
            oss << value;
            return SetWebDAVProperty(key, oss.str());
        }

        Status CDocument::GetWebDAVProperty(CString key, CString &value) {
            value = m_WebDAVProperties[key];
            return STATUS_OK;
        }

	Status CDocument::GetFaxPreviewProperty(bool &value)
	{
                DEBUGL4("CDocument::GetFaxPreviewProperty: Enter\n");
		CString docpath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName) ;
            	CString xmlfile = "documentproperties.xml";
            	CString domfile = "documentproperties_dom";
		CString nodeName = "faxPreview";
		CString fullpath = docpath + "/" + xmlfile;
		NodeRef rootNode = NULL;
                NodeRef child = NULL;
		NodeRef node = NULL;
	    	CString Value("");
		dom::DocumentRef domDocRef;
		Status st;
                ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;	
                pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if (!pHDB)
                {
                        DEBUGL1("CDocument::GetFaxPreviewProperty: Failed to Acquire HierarchicalDB\n");
                        return STATUS_FAILED;
                }	
		try
		{
			if(Utility::GetDomDocumentRef(pHDB, domDocRef, domfile, docpath, fullpath) != STATUS_OK)
			{
				DEBUGL1("CDocument::GetFaxPreviewProperty: Unable to GetDomDocumentRef from the [%s]\n",fullpath.c_str());
				return STATUS_FAILED;
			}
			rootNode = domDocRef->getDocumentElement();
			node = pHDB->BindToElement(rootNode,nodeName);
			if(!node)
			{
				DEBUGL1("CDocument::GetFaxPreviewProperty: Invalid node name : Node doesnt Exist ...\n");
				child = chelper::AppendElementNode(rootNode,"faxPreview");
				chelper::AppendTextNode(child,"false");
				if((st = pHDB->SerializeToFile(rootNode,fullpath)) != STATUS_OK)
				{
					if(st == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument::GetFaxPreviewProperty:Failed to serialize and returns STATUS_DISK_FULL\n");
						return STATUS_DISK_FULL;
					}
					else{
						DEBUGL1("CDocument::GetFaxPreviewProperty:Failed to serialize returns STATUS_FAILED\n");
						return STATUS_FAILED;
					}
				}
				else{
					value = false;
					DEBUGL1("CDocument::GetFaxPreviewProperty: SerializeToFile Success ...\n");
				    }
			}
			else{
				Value = node->getTextContent();
				if(Value.compare("true") == 0)
					value = true;
				else
					value = false;
			}
		}
		catch(DOMException except)
		{
			DEBUGL1("CDocument::GetFaxPreviewProperty: Failed due to DOM Exception\n");
			return STATUS_FAILED;
		}

                DEBUGL8("CDocument::GetFaxPreviewProperty: is [%d]\n",value);
                DEBUGL4("CDocument::GetFaxPreviewProperty: Exit\n");
		return STATUS_OK;
        }

	Status CDocument::SetFaxPreviewProperty(bool value)
	{
                DEBUGL4("CDocument::SetFaxPreviewProperty: Enter\n");
            	CString  xmlfile = "documentproperties.xml";
            	CString  domfile = "documentproperties_dom";
		CString  nodeName = "faxPreview";
		
		CString  docpath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName) ;
		CString fullpath = docpath + "/" + xmlfile;
		Status st;
		NodeRef rootNode = NULL;
                NodeRef child = NULL;
		NodeRef node = NULL;
		dom::DocumentRef domDocRef;
                ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;	
		CString Value = (value) ? "true" : "false";	
                pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if (!pHDB)
                {
                        DEBUGL1("CDocument::SetFaxPreviewProperty: Failed to Acquire HierarchicalDB\n");
                        return STATUS_FAILED;
                }	
		try
		{
			if(Utility::GetDomDocumentRef(pHDB, domDocRef, domfile, docpath, fullpath) != STATUS_OK)
			{
				DEBUGL1("CDocument::SetFaxPreviewProperty: Unable to GetDomDocumentRef from the [%s]\n",fullpath.c_str());
				return STATUS_FAILED;
			}
			rootNode = domDocRef->getDocumentElement();
			node = pHDB->BindToElement(rootNode,nodeName);
			if(!node)
			{
				DEBUGL1("CDocument::SetFaxPreviewProperty: Node [faxPreview] doesn't Exist : Creating new node...\n");
				child = chelper::AppendElementNode(rootNode,"faxPreview");
				chelper::AppendTextNode(child,Value);
				if((st = pHDB->SerializeToFile(rootNode,fullpath)) != STATUS_OK)
				{
					if(st == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument::SetFaxPreviewProperty:Failed to serialize and returns STATUS_DISK_FULL\n");
						return STATUS_DISK_FULL;
					}
					else{
						DEBUGL1("CDocument::SetFaxPreviewProperty:Failed to serialize returns STATUS_FAILED\n");
						return STATUS_FAILED;
					}
				}
				else
					DEBUGL1("CDocument::SetFaxPreviewProperty: SerializeToFile Success ...\n");
			}
			else
			{
				node->setTextContent(Value);
				if((st = pHDB->SerializeToFile(rootNode,fullpath)) != STATUS_OK)
				{
					if(st == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument::SetFaxPreviewProperty:Failed to serialize and returns STATUS_DISK_FULL\n");
						return STATUS_DISK_FULL;
					}
					else{
						DEBUGL1("CDocument::SetFaxPreviewProperty:Failed to serialize returns STATUS_FAILED\n");
						return STATUS_FAILED;
					}
				}
				        m_WebDAVProperties[nodeName] = Value;	
					DEBUGL1("CDocument::SetFaxPreviewProperty: Node [faxPreview] already Exist ... SerializeToFile Success ...\n");
			}
		}
		catch(DOMException except)
		{
			DEBUGL1("CDocument::SetFaxPreviewProperty: Failed due to DOM Exception\n");
			return STATUS_FAILED;
		}

                DEBUGL4("CDocument::SetFaxPreviewProperty: Exit\n");
		return STATUS_OK;
	}
        Status CDocument::SetName(CString name) 
        {
           if(Utility::ResourceExist( m_BoxBasePath, m_BoxNumber, m_FolderName, name)) {
              DEBUGL1("CDocument::SetName:: %s is already used\n", name.c_str());
              return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
           }
           DocStatus st;
           if(GetStatus(st) != STATUS_OK)
           {
              DEBUGL1("CDocument::SetName::GetStatus failed\n");
              return STATUS_FAILED;
           }
           if(st != READY)
           {
              DEBUGL1("CDocument::SetName::Renaming document is not possible coz the Document is not ready\n");
              return STATUS_USER_USING;
           }

           // change webDAV property
           if(SetWebDAVProperty("documentName", name) != STATUS_OK) {
              return STATUS_FAILED;
           }

           // rename the actual folder
           CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber, m_FolderName) + "/";
           CString from = path + m_DocumentName + "/";
           CString to = path + name + "/";
           Status ds = ci::operatingenvironment::Folder::MoveDir(from,	to);
           if(ds != STATUS_OK) {
              DEBUGL1("CDocument::SetName::renaming folder is failed\n");
              // TODO: Revert back webDAV property
              return ds;
           }
           m_DocumentName = name;
           //Update ModifiedDate
           SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());
           SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
           return STATUS_OK;
        }

        Status CDocument::GetName(CString &name) {
            name =  m_DocumentName;
            return STATUS_OK;
        }

        Status CDocument::GetPaperSizeSet(PaperSizeSet &paperset)
        {

            CString val;
            if(GetWebDAVProperty("paperSizeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetPaperSizeSet: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetPaperSizeSet:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            m_PaperSizeMap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                string first = minp.substr(0,nf);
                string second = minp.substr(nf+1);
                PaperSize eVal;							
                int abc = atoi(first.c_str());
                eVal = (PaperSize)abc;
                m_PaperSizeMap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }

            paperset.clear();
            std::map<PaperSize,int>::iterator mapIter;
            for(mapIter=m_PaperSizeMap.begin();mapIter!=m_PaperSizeMap.end();mapIter++)
            {
                DEBUGL8("CDocument::GetPaperSizeSet: PaperSize<%d> and PaperCount<%d>\n",mapIter->first,mapIter->second);
                paperset.insert(mapIter->first);
            }
            return STATUS_OK;
        }

        Status CDocument::GetJobTypeColorSet(JobTypeColorSet &jcset)
        {
            CString val;
            if(GetWebDAVProperty("jobTypeColorMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetJobTypeColorSet: GetProperty of JobTypeColorMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetJobTypeColorSet::Get VAL for jobTypeColorMap<%s>\n", val.c_str());					
            m_JobTypeColorMap.clear();						
            size_t found = val.find_first_of(";");
            while (found!=string::npos)
            {
                CString minp = val.substr(0,found);
                size_t nf = minp.find(",");
                string first = minp.substr(0,nf);
                string second = minp.substr(nf+1);
                JobTypeColor eVal;							
                int abc = atoi(first.c_str());
                eVal = (JobTypeColor)abc;
                m_JobTypeColorMap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found+1);
                found=val.find_first_of(";");
            }

            jcset.clear();
            std::map<JobTypeColor,int>::iterator mapIter;						
            for(mapIter=m_JobTypeColorMap.begin();mapIter!=m_JobTypeColorMap.end();mapIter++)
            {
                DEBUGL8("CDocument::GetJobTypeColorSet: JobTypeColor<%d> and JobTypeColorCount<%d> \n",mapIter->first,mapIter->second);
                jcset.insert(mapIter->first);
            }
            return STATUS_OK;	
        }


        Status CDocument::GetTotalPage(int &total) 
        {
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalPages", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetTotalPage: GetProperty of totalPages failed\n");
                return STATUS_FAILED;
            }
            std::istringstream iss(val);
            iss >> total;					
            m_TotalPage = total;
            return STATUS_OK;
        }

        Status CDocument::GetTotalSize(uint64 &total) 
        {
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetTotalSize: GetProperty of totalSize failed\n");
                return STATUS_FAILED;
            }
            std::istringstream iss(val);
            iss >> total;					
            m_TotalSize = total;
            return STATUS_OK;
        }

        Status CDocument::CutPage(int pageno)
        {
            vector<int> pages;
            pages.push_back(pageno);
            return(CutPage(pages));
        }

        Status CDocument::CutPage(std::vector<int> pages) 
        {
            DocStatus st;
            DEBUGL4("CDocument::CutPage: Enter\n");
            DEBUGL8("CDocument::CutPage: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Initialize WorkSpace
            WorkSpaceInit();

            if(this->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::CutPage: Getting document status is failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            //check the status of the document it should be Editing.
            if(!(st == EDITING)) 
            {
                DEBUGL1("CDocument::CutPage: Document status is not EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            // Validate the page number by reading total page count of the document
            int total;
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::CutPage::Getting total pages failed\n");
                return STATUS_FAILED;
            }


            std::vector<int>::iterator pIt;
            for(pIt=pages.begin();pIt !=pages.end();pIt++)
            {
                DEBUGL8("CDocument::CutPage: page number %d and total pages in the document are %d\n", (*pIt),total);
                if((*pIt)> total || (*pIt) < 0)
                {
                    DEBUGL1("CDocument::CutPage: Invalid page number %d and total pages in the document are %d\n", (*pIt),total);
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
            }

            //Delete Clipboard documents,if any
            std::vector<CString> clipBoardvec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(clipBoardvec, CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::CutPage: Getting collection list failed");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }

            for(unsigned int i = 0;i < clipBoardvec.size(); i++) 
            {
                int last = clipBoardvec[i].rfind("/");
                int pre = clipBoardvec[i].rfind("/", last - 1);
                CString fulldocumentname = clipBoardvec[i].substr(pre + 1, last - (pre + 1));
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                DEBUGL8("CDocument::CutPage: vector<%s>, fullDocName<%s> \n",clipBoardvec[i].c_str(),fulldocumentname.c_str());	  

                //Check if the clipborad document is of the same user
                CString sid;		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","sessionID", sid) != STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::CutPage: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());

                if(sid!=m_sessionID)
                    continue;

                Status ds = ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true);
                if(ds !=STATUS_OK) 
                {
                    DEBUGL1("CDocument::CutPage: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return ds;
                }

            }

            //Copy the document in Workspace to Clipboard
            Status ds;
            Status rst;
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";							
            CString clipbrdDocName = CLIPBOARD_PATH + m_DocumentName +"/";
            CString to = clipbrdDocName;
            ds = ci::operatingenvironment::Folder::CopyDir(from.c_str(),to.c_str());
            if(ds != STATUS_OK)
            {
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");

                if(ds == STATUS_DISK_FULL)   
                    DEBUGL1("CDocument::CutPage:CopyResource returned DISKFULL Error\n");

                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return ds;
            }

            std::vector < int > pagesToDelete;
            CString curBoxBasePath(m_BoxBasePath);
            CString curBoxNumber(m_BoxNumber);
            CString curFolderName(m_FolderName);
            CString curDocumentName(m_DocumentName);
            Status sdf;

            CString clipPath = CLIPBOARD_PATH;
            m_BoxBasePath=clipPath;
            m_BoxNumber="";
            m_FolderName="";
            CString tmpName = clipbrdDocName;
            size_t slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1);
            DEBUGL8("CDocument::CutPage: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());
            //Have only the pages that are to be cut and delete the other pages in the clipboard
                for(int pageno=1;pageno<=total;pageno++)
                {	
                    pIt = std::find(pages.begin(),pages.end(),pageno);
                    if(pIt==pages.end())
                    {
                        DEBUGL8("CDocument::CutPage: DeletingPage<%d> from ClipBoard Doc\n", pageno);
                        pagesToDelete.push_back(pageno);																
                    }	
                    else
                    {
                        DEBUGL8("CDocument::CutPage::Page<%d> restored\n",pageno);
                    }

            }
            DEBUGL4("CDocument::CutPage::PRF5\n");

            m_BoxBasePath=curBoxBasePath;
            m_BoxNumber=curBoxNumber;
            m_FolderName=curFolderName;
            m_DocumentName=curDocumentName;		

            // Get the page realted folders present in the Documents
            std::vector<CString> vec;
            vector<CString>::iterator theIterator;
            CString strpageno;
            std::ostringstream str;
            CString path("");

            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << 1;
            strpageno= str.str();

            if(Utility::GetCollectionList(vec, from)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::CutPage: Getting collection list failed");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");

                return STATUS_FAILED;
            }

            bool isThumbDataAvail = false;
            bool isSubsmplDataAvail = false;
            for(theIterator=vec.begin();theIterator !=vec.end();theIterator++)
            {
                int last = (*theIterator).rfind("/");
                int pre = (*theIterator).rfind("/", last - 1);
                CString fulldocumentname = (*theIterator).substr(pre + 1, last - (pre + 1));		
                DEBUGL8("CDocument::CutPage: Iterator String val<%s>,DocName<%s>\n",(*theIterator).c_str(),fulldocumentname.c_str());	 

                PageRef page;					
                if(this->GetPage(1, page) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::CutPage: Getting page 1 failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    rst = Utility::RemoveResource(clipbrdDocName);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");

                    return STATUS_FAILED;
                }

                if(fulldocumentname.compare("Image")==0)
                {
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);								
                    path=from+"Image/"+strpageno+ext;
                    if(Utility::ResourceExist(path)==false)
                        continue;
                    else
                    {
                        // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                        sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsImagedataPresent","true");
                        if(sdf != STATUS_OK) 
                        {
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                            rst = Utility::RemoveResource(clipbrdDocName);
                            if(rst != STATUS_OK)
                                DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CDocument::CutPage: Setting IsImagedataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());

                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CDocument::CutPage: Setting IsImagedataPresent property to %s is failed\n", clipbrdDocName.c_str());

                            return STATUS_FAILED;
                        }
                    }
                }
                else if(fulldocumentname.compare("Subsampling")==0)
                {
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);			
                    path=from+"Subsampling/"+strpageno+ext;
                    if(Utility::ResourceExist(path)==false)
                        continue;
                    else		
                    {
                        // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                        sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsSubsamplingdataPresent","true");
                        if(sdf != STATUS_OK) 
                        {
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                            rst = Utility::RemoveResource(clipbrdDocName);
                            if(rst != STATUS_OK)
                                DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CDocument::CutPage: Setting IsSubsamplingdataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());

                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CDocument::CutPage: Setting IsSubsamplingdataPresent property to %s is failed\n", clipbrdDocName.c_str());

                            return STATUS_FAILED;
                        }
                        isSubsmplDataAvail = true;

                    }
                }
                else if(fulldocumentname.compare("Thumbnail")==0)	
                {
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                    path=from+"Thumbnail/"+strpageno+ext;
                    if(Utility::ResourceExist(path)==false)
                        continue;
                    else		
                    {
                        // Update Image/thumbnail/subsampling folder presence as properties and return OK.
                        sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsThumbnaildataPresent","true");
                        if(sdf != STATUS_OK) 
                        {
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                            rst = Utility::RemoveResource(clipbrdDocName);
                            if(rst != STATUS_OK)
                                DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CDocument::CutPage: Setting IsThumbnaildataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());

                                return STATUS_DISK_FULL;      
                            }
                            DEBUGL1("CDocument::CutPage: Setting IsThumbnaildataPresent property to %s is failed\n", clipbrdDocName.c_str());

                            return STATUS_FAILED;
                        }
                        isThumbDataAvail = true;
                    }
                }
            }
            curBoxBasePath= (m_BoxBasePath);
            curBoxNumber= (m_BoxNumber);
            curFolderName= (m_FolderName);
            curDocumentName= (m_DocumentName);

            clipPath = CLIPBOARD_PATH;
            m_BoxBasePath=clipPath;
            m_BoxNumber="";
            m_FolderName="";
            tmpName = clipbrdDocName;
            slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1);
            DEBUGL8("CDocument::CutPage: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());

            if(DeletePages(pagesToDelete, isThumbDataAvail, isSubsmplDataAvail) != STATUS_OK) {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                DEBUGL1("CDocument::CutPage: ###########Deleting pages from ClipBoard failed\n");

                return STATUS_FAILED;
            }
            m_BoxBasePath=curBoxBasePath;
            m_BoxNumber=curBoxNumber;
            m_FolderName=curFolderName;
            m_DocumentName=curDocumentName;		
            if(DeletePages(pages, isThumbDataAvail, isSubsmplDataAvail) != STATUS_OK) {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                DEBUGL1("CDocument::CutPage: ###########Deleting pages from Workspace failed\n");

                return STATUS_FAILED;
            }

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
            PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
            PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
            PropertyMap.insert(pair::value_type("srcDocumentName",m_DocumentName));
            PropertyMap.insert(pair::value_type("sessionID",m_sessionID));						
            //CString cPath = CLIPBOARD_PATH + clipbrdDocName + "/";
            sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CutPage: Failed to remove half created folder\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::CutPage: SetProperties\n");

                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::CutPage: SetProperties\n");

                return STATUS_FAILED;
            }		

            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);						
            DEBUGL4("CDocument::CutPage: Exit\n");		

            return STATUS_OK;
        }

        Status CDocument::CopyPage(int pageno) 
        {
            vector<int> pages;
            pages.push_back(pageno);
            return(CopyPage(pages));
        }

        Status CDocument::CopyPage(std::vector<int> pages) 
        {

            DEBUGL4("CDocument::CopyPage: Enter\n");
            DEBUGL8("CDocument::CopyPage: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            // Now pre-requisites for Copying a page are validated.
            // Hence Create a clipboard from workspace and copy the page from the workspace to clipboard.
            CString from(""); 
            CString to;
            /*Read the UUID from documentproperties.xml*/
            CString WorkspaceDocName("");
            if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName, "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
            {
                DEBUGL1("CDocument::CopyPage: GetProperty of WorkspaceDocName failed\n");
                return STATUS_FAILED;
            }


            // check current status
            DocStatus st;
            CString newDocName;	 
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::CopyPage::GetStatus failed\n");						
                return STATUS_FAILED;
            }
            
            //Get sessionID
            CString sessID = "";
            if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName, "", "sessionID", sessID) != STATUS_OK)
            {
                DEBUGL1("CDocument::CopyPage: GetProperty of sessionID failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::CopyPage:sessID = %s m_sessionID = %s\n",sessID.c_str(),m_sessionID.c_str());

            if(st != EDITING) 
	    {
                newDocName = m_sessionID + "_" + WorkspaceDocName;
                from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            }
            else
            {
                if(st == EDITING && sessID != m_sessionID)
                {
                    DEBUGL2("CDocument::CopyPage:Document<%s> is being edited.!\n",docName_org.c_str());
                    return STATUS_USER_EDITING;
                }
                DEBUGL8("CDocument::CopyPage:Before Updation\nm_BoxBasePath<%s>\nm_BoxNumber<%s>\nm_FolderName<%s>\nm_DocumentName<%s>\n",m_BoxBasePath.c_str(),m_BoxNumber.c_str(),m_FolderName.c_str(),m_DocumentName.c_str());						
                newDocName = m_sessionID + "_" + WorkspaceDocName;
                CString path=WORKSPACE_PATH;
                m_BoxBasePath = path;
                m_BoxNumber="";
                m_FolderName	="";
                m_DocumentName = newDocName;
                DEBUGL8("CDocument::CopyPage:After Updation\nm_BoxBasePath<%s>\nm_BoxNumber<%s>\nm_FolderName<%s>\nnewDocName<%s>\n",m_BoxBasePath.c_str(),m_BoxNumber.c_str(),m_FolderName.c_str(),newDocName.c_str());
                //Point to the Workspace document if editing								
                from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";							
            }		

            // Validate the page number by reading total page count of the document
            int total;
            if(GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::CopyPage::Getting total pages failed\n");
                return STATUS_FAILED;
            }

            std::vector<int>::iterator pIt;
            for(pIt=pages.begin();pIt !=pages.end();pIt++)
            {
                DEBUGL8("CDocument::CopyPage: page number %d and total pages in the document are %d\n", (*pIt),total);
                if((*pIt)> total || (*pIt) < 0)
                {
                    DEBUGL1("CDocument::CopyPage: Invalid page number %d and total pages in the document are %d\n", (*pIt),total);
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
            }

            //Delete Clipboard documents,if any
            std::vector<CString> clipBoardvec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(clipBoardvec, CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::CopyPage: Getting collection list failed");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }

            for(unsigned int i = 0;i < clipBoardvec.size(); i++) 
            {
                int last = clipBoardvec[i].rfind("/");
                int pre = clipBoardvec[i].rfind("/", last - 1);
                CString fulldocumentname = clipBoardvec[i].substr(pre + 1, last - (pre + 1));
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","documentName", documentname) != STATUS_OK)
                {
                    DEBUGL1("CDocument::CopyPage:GetProperty Failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
                    return STATUS_FAILED;
                }

                DEBUGL8("CDocument::CopyPage: vector<%s>, fullDocName<%s> and docName<%s>\n",clipBoardvec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

                //Check if the clipborad document is of the same user
                CString sid;		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","sessionID", sid) != STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::CopyPage: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());

                if(sid!=m_sessionID)
                    continue;

                Status ds = ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true);
                if(ds != STATUS_OK) 
                {
                    DEBUGL1("CDocument::CopyPage: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return ds;
                }

            }

            //Copy the document in Workspace to Clipboard
            Status ds;
            Status rst;
            CString clipbrdDocName = CLIPBOARD_PATH + newDocName +"/";
            to = clipbrdDocName;
            ds = ci::operatingenvironment::Folder::CopyDir(from.c_str(),to.c_str());
            if(ds!=STATUS_OK)
            {
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");
                DEBUGL1("CDocument::CopyPage:CopyResource returned DISKFULL Error\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return ds;							
            }
            std::vector < int > pagesToDelete;
            //Have only the pages that are to be copied and delete the other pages in the Clipboard
            for(int pageno=1;pageno<=total;pageno++)
            {	
                pIt = std::find(pages.begin(),pages.end(),pageno);
                if(pIt==pages.end())
                {
                    DEBUGL8("CDocument::CopyPage::Page<%d> in Clipborad will be deleted\n",pageno);
                    pagesToDelete.push_back(pageno);							
                }	
                else
                {
                    DEBUGL8("CDocument::CopyPage::Page<%d> restored\n",pageno);
                }

            }

            CString curBoxBasePath(m_BoxBasePath);
            CString curBoxNumber(m_BoxNumber);
            CString curFolderName(m_FolderName);
            CString curDocumentName(m_DocumentName);
            Status sdf;

            CString clipPath = CLIPBOARD_PATH;
            clipPath = clipPath;
            m_BoxBasePath=clipPath;
            m_BoxNumber="";
            m_FolderName="";
            CString tmpName = clipbrdDocName;
            size_t slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1);
            DEBUGL8("CDocument::CopyPage: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());
            slPos = tmpName.rfind("/");
            m_DocumentName= tmpName.substr(slPos + 1);
            if(st != EDITING) 
            {			
                if(this->ReCreate()!=STATUS_OK)
                {
                    DEBUGL1("CDocument::CopyPage:ReCreate failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    rst = Utility::RemoveResource(clipbrdDocName);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                    return STATUS_FAILED;									
                }									
            }
            if (this->DeletePage(pagesToDelete)!=STATUS_OK)
            {
                DEBUGL1("CDocument::CopyPage:DeletePages failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                return STATUS_FAILED;									
            }
            if(st != EDITING) 
            {			
                if(this->EndCreating()!=STATUS_OK)
                {
                    DEBUGL1("CDocument::CopyPage:EndCreating failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    rst = Utility::RemoveResource(clipbrdDocName);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                    return STATUS_FAILED;									
                }								
            }	

            m_BoxBasePath=curBoxBasePath;
            m_BoxNumber=curBoxNumber;
            m_FolderName=curFolderName;
            m_DocumentName=curDocumentName;		

            // Get the page realted folders present in the Documents
            std::vector<CString> vec;
            vector<CString>::iterator theIterator;
            CString strpageno;
            std::ostringstream str;
            CString path("");

            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << 1;
            strpageno= str.str();

            if(Utility::GetCollectionList(vec, from)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::CopyPage: Getting collection list failed");
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                return STATUS_FAILED;
            }
            try
            {
                for(theIterator=vec.begin();theIterator !=vec.end();theIterator++)
                {
                    int last = (*theIterator).rfind("/");
                    int pre = (*theIterator).rfind("/", last - 1);
                    CString fulldocumentname = (*theIterator).substr(pre + 1, last - (pre + 1));		
                    DEBUGL8("CDocument::CopyPage: Iterator String val<%s>,DocName<%s>\n",(*theIterator).c_str(),fulldocumentname.c_str());	 

                    PageRef page;					
                    if(this->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::CopyPage: Getting page 1 failed\n");
                        rst = Utility::RemoveResource(clipbrdDocName);
                        if(rst != STATUS_OK)
                            DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }

                    if(fulldocumentname.compare("Image")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::CopyPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);								
                        path=from+"Image/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsImagedataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                rst = Utility::RemoveResource(clipbrdDocName);
                                if(rst != STATUS_OK)
                                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::CopyPage: Setting IsImagedataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());

                                    return STATUS_DISK_FULL;
                                }	
                                DEBUGL1("CDocument::CopyPage: Setting IsImagedataPresent property to %s is failed\n", clipbrdDocName.c_str());

                                return STATUS_FAILED;
                            }
                        }
                    }
                    else if(fulldocumentname.compare("Subsampling")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::CopyPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);								
                        path=from+"Subsampling/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsSubsamplingdataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                rst = Utility::RemoveResource(clipbrdDocName);
                                if(rst != STATUS_OK)
                                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");

                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::CopyPage: Setting IsSubsamplingdataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());
                                    return STATUS_DISK_FULL;				
                                }
                                DEBUGL1("CDocument::CopyPage: Setting IsSubsamplingdataPresent property to %s is failed\n", clipbrdDocName.c_str());

                                return STATUS_FAILED;
                            }

                        }
                    }
                    else if(fulldocumentname.compare("Thumbnail")==0)	
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::CopyPage:Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        path=from+"Thumbnail/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsThumbnaildataPresent","true");
                            if(sdf != STATUS_OK)
                            {
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                rst = Utility::RemoveResource(clipbrdDocName);
                                if(rst != STATUS_OK)
                                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::CopyPage: Setting IsThumbnaildataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());

                                    return STATUS_DISK_FULL;
                                }
                                DEBUGL1("CDocument::CopyPage: Setting IsThumbnaildataPresent property to %s is failed\n", clipbrdDocName.c_str());

                                return STATUS_FAILED;
                            }
                        }
                    }
                }
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::CopyPage::Exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
            PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
            PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
            PropertyMap.insert(pair::value_type("srcDocumentName",m_DocumentName));
            PropertyMap.insert(pair::value_type("sessionID",m_sessionID));						
            //CString cPath = CLIPBOARD_PATH + clipbrdDocName + "/";
            sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                rst = Utility::RemoveResource(clipbrdDocName);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CopyPage: Failed to remove half created folder\n");
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }
                return STATUS_FAILED;
            }		
            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	

            DEBUGL4("CDocument::CopyPage: Exit\n");		
            return STATUS_OK;
        }

        CString CDocument::GetNextPage(int pageno) {
            CString strpageno;
            std::ostringstream str;
            pageno = pageno+1;
            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << pageno;
            strpageno= str.str();
            return strpageno;
        }

        Status CDocument::PastePage(int pageno) 
        {
            DocStatus st;
            std::vector<CString> srcvec;
            vector<CString>::iterator it;
            vector<CString>::iterator iit;
            vector<CString>::iterator sit;
            vector<CString>::iterator tit;					
            CString clipbrdDocName("");
            bool IsImagedataPresent = false;
            bool IsSubsamplingdataPresent = false;
            bool IsThumbnaildataPresent = false;
            std::vector<CString> Imgvec;
            std::vector<CString> subsamvec;
            std::vector<CString> thumbnailvec;
            int total = 0;	

            DEBUGL4("CDocument::PastePage: Enter\n");	
            DEBUGL8("CDocument::PastePage: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            if(pageno < 0)
            {
                DEBUGL1("CDocument::PastePage:Invalid page number %d\n", pageno);
                return STATUS_FAILED;
            }

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Initialize WorkSpace
            WorkSpaceInit();

            /*Fix for STFR-7577*/
            /*Check the value of totalPages in documentproperties.xml for the document
             *that is there in /work/Workspace/ 
             *This will give the updated information in case deletepage operation has 
             *taken place.
             */
            if(iSSetsysfileInvoked)
            {
                if(GetPageList(m_PageList) != STATUS_OK)
                {
                    DEBUGL1("CDocument::PastePage::Getting PageList failed\n");
                    return STATUS_FAILED;
                }
            }
                if(this->GetTotalPage(total)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::PastePage::Getting total pages failed\n");
                    return STATUS_FAILED;
                }

                DEBUGL8("CDocument::PastePage::Total pages in the document are %d\n",total);
            int pos;
            CString boxbasepath_new("");
            pos = m_BoxBasePathOrg.rfind("/");
            boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
            DEBUGL8("CDocument::PastePage:: boxbasepath_new = (%s)\n", boxbasepath_new.c_str());

            if(boxbasepath_new == "PageLogBoxes")
            {
                if((static_cast<unsigned>(total) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
                {
                    DEBUGL1("CDocument::PastePage::Page Limit reached PAGELOGBOXES\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }
            }
            else if(static_cast<unsigned>(total) >= CBoxDocument::PAGE_LIMIT)
            {
                DEBUGL1("CDocument::PastePage::Page Limit reached\n");
                return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
            }



            //Get the status of the destination document, it should be Editing
            if(this->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::PastePage:Getting document status is failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            //check the status of the source document, it should be Editing
            if(!(st == EDITING)) 
            {
                DEBUGL1("CDocument::PastePage:Document status is not EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(srcvec, CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::PastePage: Getting collection list failed");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            //Iterate through the vector to read a document with current session-id				
            DEBUGL8("CDocument::PastePage:Current Session id <%s>\n",m_sessionID.c_str());	
            std::vector<CString> docNameVec;
            docNameVec.clear();
            for(it = srcvec.begin();it != srcvec.end(); it++) 
            {
                CString val;
                DEBUGL8("CDocument::PastePage: Contents of src vector <%s>\n",(*it).c_str());							
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",*it,"","sessionID", val)!=STATUS_OK)
                {
                    DEBUGL2("CDocument::PastePage: GetProperty of sessionID failed\n");
                    val.clear();
                }
                DEBUGL8("CDocument::PastePage::Document SessionID<%s>\n",val.c_str());
                if(val==m_sessionID)
                {
                    DEBUGL8("CDocument::PastePage::Document SessionID is equal to m_sessionID <%s> m_sessionID <%s>\n",val.c_str(),m_sessionID.c_str());							
                    docNameVec.push_back(*it);
                }
            }
            vector<CString>::iterator docNameVecIt;
            for(docNameVecIt = docNameVec.begin();docNameVecIt!=docNameVec.end();docNameVecIt++)
            {
                clipbrdDocName = *docNameVecIt;
                if(clipbrdDocName.empty())
                {
                    DEBUGL1("CDocument::PastePage: Clipboard does not have the required document --session ID might have expired");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }

                //Read the document in the Clipboard Path and other details set on the clipboard document.
                CString from =clipbrdDocName;
                CString val;
                CString resourceKey=from + "/";
                CString Path("");

                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsImagedataPresent", val) == STATUS_OK)
                {
                    if(val.compare("true")==0)
                    {	
                        IsImagedataPresent=true;
                        //Get the List of pages present in Clipboard/docname/Image folder if present.
                        Path=CLIPBOARD_PATH + resourceKey+"Image/";
                        DEBUGL8("CDocument::PastePage::<%s>\n",Path.c_str());
                        Imgvec.clear();
                        if(Utility::GetPageCollectionList(Imgvec, Path)!=STATUS_OK) 
                        {
                            DEBUGL1("CDocument::PastePage: Getting collection list failed");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                        DEBUGL8("CDocument::PastePage: Pages in Imagevec = (%d)\n",Imgvec.size());									
                    }
                }
                else
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		

                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsSubsamplingdataPresent", val) == STATUS_OK)
                {
                    if(val.compare("true")==0)
                    {	
                        IsSubsamplingdataPresent=true;
                        Path=CLIPBOARD_PATH + resourceKey+"Subsampling/";
                        subsamvec.clear();
                        if(Utility::GetPageCollectionList(subsamvec, Path)!=STATUS_OK) 
                        {
                            DEBUGL1("CDocument::PastePage: Getting collection list failed");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }	
                }
                else
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		

                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsThumbnaildataPresent", val)== STATUS_OK)
                {
                    if(val.compare("true")==0)
                    {
                        IsThumbnaildataPresent=true;
                        Path=CLIPBOARD_PATH + resourceKey+"Thumbnail/";
                        thumbnailvec.clear();
                        if(Utility::GetPageCollectionList(thumbnailvec,  Path)!=STATUS_OK) 
                        {
                            DEBUGL1("CDocument::PastePage: Getting collection list failed");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }	
                    }
                }
                else
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		

                //Get the destination folder details.
                CString to = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";

                // Get the page related folders present in the destination document 
                // check whether all the folders are in sync with src folders.
                //check if the contents in folder exist.
                std::vector<CString> tempvec;
                vector<CString>::iterator tempIt;
                if(Utility::GetCollectionList(tempvec,to+"Image/")!=STATUS_OK)
                {
                    DEBUGL1("CDocument::PastePage:Getting collection list for Image failed");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                if((tempvec.size() > 1)&&(IsImagedataPresent==false))
                {
                    DEBUGL2("CDocument::PastePage: Imagedatapresent <%d>\n",IsImagedataPresent);	 
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                tempvec.clear();
                if(Utility::GetCollectionList(tempvec, to+"Subsampling/")!=STATUS_OK)
                {
                    DEBUGL1("CDocument::PastePage:Getting collection list for Subsampling failed");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                if((tempvec.size()  > 1)&&(IsSubsamplingdataPresent==false))
                {
                    DEBUGL1("CDocument::PastePage: IsSubsamplingdataPresent <%d>\n",IsSubsamplingdataPresent);	 
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                tempvec.clear();						
                if(Utility::GetCollectionList(tempvec, to+"Thumbnail/")!=STATUS_OK)
                {
                    DEBUGL1("CDocument::PastePage:Getting collection list for Thumbnail failed");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                if((tempvec.size() > 1)&&(IsThumbnaildataPresent==false))
                {
                    DEBUGL1("CDocument::PastePage: IsThumbnaildataPresent <%d>\n",IsThumbnaildataPresent);	 
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }

                resourceKey = from;
                CString srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName;
                //Read the src box name,doc name etc and delete the pages at the src path and update the sdf.
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxBasePath", srcBoxBasePath) != STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxNumber", srcBoxNumber) != STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcFolderName", srcFolderName) != STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcDocumentName", srcDocumentName)!= STATUS_OK)
                {
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		

                CString curBoxBasePath(m_BoxBasePath);
                CString curBoxNumber(m_BoxNumber);
                CString curFolderName(m_FolderName);
                CString curDocumentName(m_DocumentName);
                CString fullname("");
                CString CutFlag("");						
                //The page number in the detination workspace
                int dstPageNum=pageno;
                Status ret;
                CString pagePath("");
                std::vector<CString> cjdFromVec;
                std::vector<CString> cjdToVec;
                for(iit=Imgvec.begin();iit!=Imgvec.end();iit++)
                {
                    DEBUGL8("CDocument::PastePage: page in Image Vec  is  %s\n",(*iit).c_str());	

                    size_t next = iit->rfind("/");
                    CString fullname = iit->substr(next + 1);
                    if(fullname.compare("00000")==0)
                    {
                        DEBUGL8("CDocument::PastePage: Skipping SDF<%s>\n",fullname.c_str());	
                        continue;
                    }
                    if((fullname.find(".xml") != std::string::npos) || (fullname.find("_dom") != std::string::npos) || (fullname.find(".uniqid_") != std::string::npos))
                    {
                        DEBUGL8("CDocument::PastePage: Skipping XML or DOM file<%s>\n",fullname.c_str());	
                        continue;
                    }

                    //Total number of pages
                    if(this->GetTotalPage(total)!=STATUS_OK)
                    {	
                        DEBUGL1("CDocument::PastePage::Getting total pages failed\n");
                        return STATUS_FAILED;
                    }
                    DEBUGL8("CDocument::PastePage::Total pages in the document from workspace = %d\n",total);


                    size_t last = fullname.find(".cjd");
                    if(last == CString::npos)
                    {	
                        DEBUGL8("CDocument::PastePage: Iterator String val<%s>,DocName<%s>\n",iit->c_str(),fullname.c_str());	 
                        //The page number in the source workspace
                        int srcPageNum;
                        PageRef pageRef;
                        CString hsToInt = "0x" + fullname;
                        bool isSamePos = false;
                        std::istringstream istr(hsToInt);				

                        // convert string page to int page
                        istr>>std::setbase(0)>>srcPageNum;	

                        if(srcPageNum == dstPageNum)
                            isSamePos = true;	

                        //GetPage from Source ClipBoard
                        DEBUGL8("CDocument::PastePage: GetPage called\n");	 
                        CString clipPath = CLIPBOARD_PATH;
                        m_BoxBasePath=clipPath;
                        m_BoxNumber="";
                        m_FolderName="";
                        DEBUGL8("CDocument::PastePage:ClipboardDocName<%s>\n",clipbrdDocName.c_str());
                        m_DocumentName= clipbrdDocName;

                        DEBUGL8("CDocument::PastePage: for GetPage--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str(), srcPageNum);
                        if(this->GetPage(srcPageNum,pageRef)!=STATUS_OK)
                        {
                            DEBUGL1("CDocument::PastePage:GetPage of %d failed\n",srcPageNum);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }	

                        //InsertPage at Destination Workspace
                        m_BoxBasePath=curBoxBasePath;
                        m_BoxNumber=curBoxNumber;
                        m_FolderName=curFolderName;
                        m_DocumentName=curDocumentName;																		
                        DEBUGL8("CDocument::PastePage: for Insert/Append/Replace Page--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str(), dstPageNum);
                        if(dstPageNum == total + 1)
                        {
                            if(IsImagedataPresent == false)
                                dynamic_cast<CPage*>(pageRef.operator->())->SetImage("", "");
                            if(IsThumbnaildataPresent == false)	
                                dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage("", "");
                            if(IsSubsamplingdataPresent == false)
                                dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage("", "");
                            DEBUGL8("CDocument::PastePage: AppendPage called\n");
                            ret = this->AppendPage(pageRef);
                            if(ret!=STATUS_OK)
                            {
                                DEBUGL1("CDocument::PastePage::AppendPage failed\n");											
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                return ret;				
                            }	
                        }
                        else 
                        {
                            DEBUGL8("CDocument::PastePage: InsertPage called\n");	 
                            ret = this->InsertPage(dstPageNum,pageRef);
                            if(ret!=STATUS_OK)
                            {
                                DEBUGL1("CDocument::PastePage::InsertPage failed\n");											
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                return ret;				
                            }

                        }	
                        dstPageNum++;
                    }
                    else 
                    {
                        CString cjdFrom = CLIPBOARD_PATH + resourceKey + "/Image/" + fullname;
                        DEBUGL8("CDocument::PastePage: cjdFrom = (%s)\n",cjdFrom.c_str());	 
                        cjdFromVec.push_back(cjdFrom);
                        std::ostringstream strm;
                        strm << std::hex << std::setfill('0') << std::setw(3) << dstPageNum;
                        CString dstCjdFile = strm.str() +".cjd";
                        CString cjdTo = curBoxBasePath + "/" + curDocumentName + "/Image/" + dstCjdFile;
                        DEBUGL8("CDocument::PastePage: cjdTo = (%s)\n",cjdTo.c_str());	 
                        cjdToVec.push_back(cjdTo);										

                    }
                }
                if(!cjdFromVec.empty())
                {
                    Status ds;
                    //Check if the resource already exists @ destination. if yes then move the cjd file by vector size and copy
                    iit = cjdToVec.begin();
                    if(Utility::ResourceExist(*(iit)))
                    {
                        int pValue = cjdToVec.size();
                        size_t next = iit->rfind("/");
                        CString pName("");
                        for(iit = cjdToVec.begin();iit!=cjdToVec.end();iit++)
                        {
                            pName = iit->substr(0,next + 1);
                            pName +=  pValue;
                            pName += ".cjd";
                            DEBUGL8("CDocument::PastePage: Moved cjd (%s) from cjdTo = (%s)\n",(*(iit)).c_str(), pName.c_str());										
                            ds = ci::operatingenvironment::File::MoveFile(*(iit),pName);
                            if(ds != STATUS_OK)
                            {
                                DEBUGL1("CDocument::PastePage::Copying cjd file failed\n");											
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                return ds;
                            }										
                        }
                    }
                    for(it = cjdFromVec.begin(), iit = cjdToVec.begin();it!=cjdFromVec.end();it++, iit++)
                    {
                        if(Utility::ResourceExist(*(it)))
                        {
                            DEBUGL8("CDocument::PastePage: cjdFrom = (%s)\n",(*(it)).c_str());	 
                            DEBUGL8("CDocument::PastePage: cjdTo = (%s)\n",(*(iit)).c_str());	 

                            ds = ci::operatingenvironment::File::CopyFile(*(it),*(iit));
                            if(ds != STATUS_OK)
                            {
                                DEBUGL1("CDocument::PastePage::Copying cjd file failed\n");											
                                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                return ds;
                            }

                        }
                    }
                }

                //Check for the CutDocument property and delete the original document
                CutFlag.clear();
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","cutDocument", CutFlag) != STATUS_OK)						{
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }		
                if(CutFlag=="true")
                {	
                    //Obtain the original document
                    DocumentRef orgDoc;
                    if(Utility::GetDocument(m_sessionID, orgDoc,srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::PastePage: Obtaining Originalgetd Document failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }

                    // Start to Delete
                    try
                    {
                        if(!orgDoc)
                        {
                            DEBUGL1("CDocument::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
                        {
                            DEBUGL1("CDocument::PastePage: Deleting document failed\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return STATUS_FAILED;
                        }
                    }
                    catch(exception& e)
                    {
                        DEBUGL1("CDocument::PastePage::Exception caught:(%s)\n",e.what());
                        return NULL;
                    }
                }	

            }
            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
            DEBUGL4("CDocument::PastePage:Exit\n");
            return STATUS_OK;
        }
        Status CDocument::FasterPastePage(int pageno)
		{
			DocStatus st;
			std::vector<CString> srcvec;
			vector<CString>::iterator it;
			vector<CString>::iterator iit;
			vector<CString>::iterator sit;
			vector<CString>::iterator tit;					
			CString clipbrdDocName("");
			bool IsImagedataPresent = false;
			bool IsSubsamplingdataPresent = false;
			bool IsThumbnaildataPresent = false;
			std::vector<CString> Imgvec;
			std::vector<CString> subsamvec;
			std::vector<CString> thumbnailvec;
			int total = 0;	

			DEBUGL4("CDocument::FasterPastePage: Enter\n");	
			DEBUGL8("CDocument::FasterPastePage: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

			if(pageno < 0)
			{
				DEBUGL1("CDocument::FasterPastePage:Invalid page number %d\n", pageno);
				return STATUS_FAILED;
			}

			//make a local copy of the member variables
			CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			boxbasepath_org = m_BoxBasePath;
			boxnumber_org = m_BoxNumber;
			folderName_org = m_FolderName;
			docName_org = m_DocumentName;

			//Initialize WorkSpace
			WorkSpaceInit();

			/*Fix for STFR-7577*/
			/*Check the value of totalPages in documentproperties.xml for the document
			 *that is there in /work/Workspace/ 
			 *This will give the updated information in case deletepage operation has 
			 *taken place.
			 */
			if(iSSetsysfileInvoked)
			{
				if(GetPageList(m_PageList) != STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage::Getting PageList failed\n");
					return STATUS_FAILED;
				}
			}
				if(this->GetTotalPage(total)!=STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage::Getting total pages failed\n");
					return STATUS_FAILED;
				}

				DEBUGL8("CDocument::FasterPastePage::Total pages in the document are %d\n",total);
			int pos;
			CString boxbasepath_new("");
			pos = m_BoxBasePathOrg.rfind("/");
			boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
			DEBUGL8("CDocument::FasterPastePage:: boxbasepath_new = (%s)\n", boxbasepath_new.c_str());

			if(boxbasepath_new == "PageLogBoxes")
			{
				if((static_cast<unsigned>(total) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
				{
					DEBUGL1("CDocument::FasterPastePage::Page Limit reached PAGELOGBOXES\n");
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}
			}
			else if(static_cast<unsigned>(total) >= CBoxDocument::PAGE_LIMIT)
			{
				DEBUGL1("CDocument::FasterPastePage::Page Limit reached\n");
				return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
			}



			//Get the status of the destination document, it should be Editing
			if(this->GetStatus(st) != STATUS_OK)
			{
				DEBUGL1("CDocument::FasterPastePage:Getting document status is failed\n");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				return STATUS_FAILED;
			}

			//check the status of the source document, it should be Editing
			if(!(st == EDITING)) 
			{
				DEBUGL1("CDocument::FasterPastePage:Document status is not EDITING\n");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				return STATUS_FAILED;
			}
			//Get the List of Documents in Clipboard
			if(Utility::GetCollectionList(srcvec, CLIPBOARD_PATH)!=STATUS_OK) 
			{
				DEBUGL1("CDocument::FasterPastePage: Getting collection list failed");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				return STATUS_FAILED;
			}

			//Iterate through the vector to read a document with current session-id				
			DEBUGL8("CDocument::FasterPastePage:Current Session id <%s>\n",m_sessionID.c_str());	
			std::vector<CString> docNameVec;
			docNameVec.clear();
			for(it = srcvec.begin();it != srcvec.end(); it++) 
			{
				CString val;
				DEBUGL8("CDocument::FasterPastePage: Contents of src vector <%s>\n",(*it).c_str());							
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",*it,"","sessionID", val)!=STATUS_OK)
				{
					DEBUGL2("CDocument::FasterPastePage: GetProperty of sessionID failed\n");
					val.clear();
				}
				DEBUGL8("CDocument::FasterPastePage::Document SessionID<%s>\n",val.c_str());
				if(val==m_sessionID)
				{
					DEBUGL8("CDocument::FasterPastePage::Document SessionID is equal to m_sessionID <%s> m_sessionID <%s>\n",val.c_str(),m_sessionID.c_str());							
					docNameVec.push_back(*it);
				}
			}
			vector<CString>::iterator docNameVecIt;
			for(docNameVecIt = docNameVec.begin();docNameVecIt!=docNameVec.end();docNameVecIt++)
			{
				clipbrdDocName = *docNameVecIt;
				if(clipbrdDocName.empty())
				{
					DEBUGL1("CDocument::FasterPastePage: Clipboard does not have the required document --session ID might have expired");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}

				//Read the document in the Clipboard Path and other details set on the clipboard document.
				CString from =clipbrdDocName;
				CString val;
				CString resourceKey=from + "/";
				CString Path("");

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsImagedataPresent", val) == STATUS_OK)
				{
					if(val.compare("true")==0)
					{	
						IsImagedataPresent=true;
						//Get the List of pages present in Clipboard/docname/Image folder if present.
						Path=CLIPBOARD_PATH + resourceKey+"Image/";
						DEBUGL8("CDocument::FasterPastePage::<%s>\n",Path.c_str());
						Imgvec.clear();
						if(Utility::GetPageCollectionList(Imgvec, Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::FasterPastePage: Getting collection list failed");
							RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							return STATUS_FAILED;
						}
						DEBUGL8("CDocument::FasterPastePage: Pages in Imagevec = (%d)\n",Imgvec.size());									
					}
				}
				else
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsSubsamplingdataPresent", val) == STATUS_OK)
				{
					if(val.compare("true")==0)
					{	
						IsSubsamplingdataPresent=true;
						Path=CLIPBOARD_PATH + resourceKey+"Subsampling/";
						subsamvec.clear();
						if(Utility::GetPageCollectionList(subsamvec, Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::FasterPastePage: Getting collection list failed");
							RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							return STATUS_FAILED;
						}
					}	
				}
				else
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsThumbnaildataPresent", val)== STATUS_OK)
				{
					if(val.compare("true")==0)
					{
						IsThumbnaildataPresent=true;
						Path=CLIPBOARD_PATH + resourceKey+"Thumbnail/";
						thumbnailvec.clear();
						if(Utility::GetPageCollectionList(thumbnailvec,  Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::FasterPastePage: Getting collection list failed");
							RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							return STATUS_FAILED;
						}	
					}
				}
				else
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		

				//Get the destination folder details.
				CString to = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";

				// Get the page related folders present in the destination document 
				// check whether all the folders are in sync with src folders.
				//check if the contents in folder exist.
				std::vector<CString> tempvec;
				vector<CString>::iterator tempIt;
				if(Utility::GetCollectionList(tempvec,to+"Image/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage:Getting collection list for Image failed");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
				if((tempvec.size() > 1)&&(IsImagedataPresent==false))
				{
					DEBUGL2("CDocument::FasterPastePage: Imagedatapresent <%d>\n",IsImagedataPresent);	 
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
				tempvec.clear();
				if(Utility::GetCollectionList(tempvec, to+"Subsampling/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage:Getting collection list for Subsampling failed");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
				if((tempvec.size()  > 1)&&(IsSubsamplingdataPresent==false))
				{
					DEBUGL1("CDocument::FasterPastePage: IsSubsamplingdataPresent <%d>\n",IsSubsamplingdataPresent);	 
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
				tempvec.clear();						
				if(Utility::GetCollectionList(tempvec, to+"Thumbnail/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage:Getting collection list for Thumbnail failed");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
				if((tempvec.size() > 1)&&(IsThumbnaildataPresent==false))
				{
					DEBUGL1("CDocument::FasterPastePage: IsThumbnaildataPresent <%d>\n",IsThumbnaildataPresent);	 
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}

				resourceKey = from;
				CString srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName;
				//Read the src box name,doc name etc and delete the pages at the src path and update the sdf.
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxBasePath", srcBoxBasePath) != STATUS_OK)
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxNumber", srcBoxNumber) != STATUS_OK)
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcFolderName", srcFolderName) != STATUS_OK)
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcDocumentName", srcDocumentName)!= STATUS_OK)
				{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		

				CString curBoxBasePath(m_BoxBasePath);
				CString curBoxNumber(m_BoxNumber);
				CString curFolderName(m_FolderName);
				CString curDocumentName(m_DocumentName);
				CString fullname("");
				CString CutFlag("");						
				//The page number in the detination workspace
				int dstPageNum=pageno;
				Status ret;
				CString pagePath("");
				std::vector<CString> cjdFromVec;
				std::vector<CString> cjdToVec;
				Status slideret;
				int vecsize = Imgvec.size(); 
				//algorithm to slide the pages. 
				//1. Calculate the total number of positions by which pages need to be shifted,
				// depending on the number of pages being inserted and number of pages already 
				// present in the document. 
				//2. Shift all the pages all together, depending on the number obtained for the
				//number of moves required by above step.
				//3. Insert the pages, present in the clipboard, to the document. 
				//
				//Eg. If there are 10 pages present in the document and we want to insert 
				//5 pages at the 5th position of the document, then we 10th page is moved to 
				//15th position, 9th to 14th position. and 5th page to 10th position. And 
				//insert 5 pages at the 5th position. By this pages are shifted only once.
				//
				//In a document, there is a system file and for every page, there is one property 
				//file. So we pass only the number of pages present in the vector. 
				//e.g. if there are 100 pages in a document then in image folder
				//number of files will be 201 (1(systemfile) + 100(property files) + 100 (images))
				if((slideret = this->SlidePages(dstPageNum,((vecsize-1)/3)))!=STATUS_OK)
				{
					DEBUGL1("CDocument::FasterPastePage: Slide Image failed\n");
					return slideret;
				}

				for(iit=Imgvec.begin();iit!=Imgvec.end();iit++)
				{
					DEBUGL8("CDocument::FasterPastePage: page in Image Vec  is  %s\n",(*iit).c_str());	

					size_t next = iit->rfind("/");
					CString fullname = iit->substr(next + 1);
					if(fullname.compare("00000")==0)
					{
						DEBUGL8("CDocument::FasterPastePage: Skipping SDF<%s>\n",fullname.c_str());	
						continue;
					}
					if((fullname.find(".xml") != std::string::npos) || (fullname.find("_dom") != std::string::npos) || (fullname.find(".uniqid_") != std::string::npos))
					{
						DEBUGL8("CDocument::FasterPastePage: Skipping XML file<%s>\n",fullname.c_str());	
						continue;
					}

					//Total number of pages
					if(this->GetTotalPage(total)!=STATUS_OK)
					{	
						DEBUGL1("CDocument::FasterPastePage::Getting total pages failed\n");
						return STATUS_FAILED;
					}
					DEBUGL8("CDocument::FasterPastePage::Total pages in the document from workspace = %d\n",total);


					size_t last = fullname.find(".cjd");
					if(last == CString::npos)
					{	
						DEBUGL8("CDocument::FasterPastePage: Iterator String val<%s>,DocName<%s>\n",iit->c_str(),fullname.c_str());	 
						//The page number in the source workspace
						int srcPageNum;
						PageRef pageRef;
						CString hsToInt = "0x" + fullname;
						bool isSamePos = false;
						std::istringstream istr(hsToInt);				

						// convert string page to int page
						istr>>std::setbase(0)>>srcPageNum;	

						if(srcPageNum == dstPageNum)
							isSamePos = true;	

						//GetPage from Source ClipBoard
						DEBUGL8("CDocument::FasterPastePage: GetPage called\n");	 
						CString clipPath = CLIPBOARD_PATH;
						m_BoxBasePath=clipPath;
						m_BoxNumber="";
						m_FolderName="";
						DEBUGL8("CDocument::FasterPastePage:ClipboardDocName<%s>\n",clipbrdDocName.c_str());
						m_DocumentName= clipbrdDocName;

						DEBUGL8("CDocument::FasterPastePage: for GetPage--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str(), srcPageNum);
						if(this->GetPage(srcPageNum,pageRef)!=STATUS_OK)
						{
							DEBUGL1("CDocument::FasterPastePage:GetPage of %d failed\n",srcPageNum);
							RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							return STATUS_FAILED;
						}	

						//InsertPage at Destination Workspace
						m_BoxBasePath=curBoxBasePath;
						m_BoxNumber=curBoxNumber;
						m_FolderName=curFolderName;
						m_DocumentName=curDocumentName;																		
						DEBUGL8("CDocument::FasterPastePage: for Insert/Append/Replace Page--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str(), dstPageNum);
						if(dstPageNum == total + 1)
						{
							if(IsImagedataPresent == false)
								dynamic_cast<CPage*>(pageRef.operator->())->SetImage("", "");
							if(IsThumbnaildataPresent == false)	
								dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage("", "");
							if(IsSubsamplingdataPresent == false)
								dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage("", "");
							DEBUGL8("CDocument::FasterPastePage: AppendPage called\n");
							ret = this->AppendPage(pageRef);
							if(ret!=STATUS_OK)
							{
								DEBUGL1("CDocument::FasterPastePage::AppendPage failed\n");											
								RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								return ret;				
							}	
						}
						else 
						{
							DEBUGL8("CDocument::FasterPastePage: InsertPage called\n");	 
							ret = this->FasterInsertPage(dstPageNum,pageRef);
							if(ret!=STATUS_OK)
							{
								DEBUGL1("CDocument::FasterPastePage::InsertPage failed\n");											
								RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								return ret;				
							}

						}	
						dstPageNum++;
					}
					else 
					{
						CString cjdFrom = CLIPBOARD_PATH + resourceKey + "/Image/" + fullname;
						DEBUGL8("CDocument::FasterPastePage: cjdFrom = (%s)\n",cjdFrom.c_str());	 
						cjdFromVec.push_back(cjdFrom);
						std::ostringstream strm;
						strm << std::hex << std::setfill('0') << std::setw(3) << dstPageNum;
						CString dstCjdFile = strm.str() +".cjd";
						CString cjdTo = curBoxBasePath + "/" + curDocumentName + "/Image/" + dstCjdFile;
						DEBUGL8("CDocument::FasterPastePage: cjdTo = (%s)\n",cjdTo.c_str());	 
						cjdToVec.push_back(cjdTo);										

					}
				}
				if(!cjdFromVec.empty())
				{
					Status ds;
					//Check if the resource already exists @ destination. if yes then move the cjd file by vector size and copy
					iit = cjdToVec.begin();
					if(Utility::ResourceExist(*(iit)))
					{
						int pValue = cjdToVec.size();
						size_t next = iit->rfind("/");
						CString pName("");
						for(iit = cjdToVec.begin();iit!=cjdToVec.end();iit++)
						{
							pName = iit->substr(0,next + 1);
							pName +=  pValue;
							pName += ".cjd";
							DEBUGL8("CDocument::FasterPastePage: Moved cjd (%s) from cjdTo = (%s)\n",(*(iit)).c_str(), pName.c_str());										
							ds = ci::operatingenvironment::File::MoveFile(*(iit),pName);
							if(ds != STATUS_OK)
							{
								DEBUGL1("CDocument::FasterPastePage::Copying cjd file failed\n");											
								RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								return ds;
							}										
						}
					}
					for(it = cjdFromVec.begin(), iit = cjdToVec.begin();it!=cjdFromVec.end();it++, iit++)
					{
						if(Utility::ResourceExist(*(it)))
						{
							DEBUGL8("CDocument::FasterPastePage: cjdFrom = (%s)\n",(*(it)).c_str());	 
							DEBUGL8("CDocument::FasterPastePage: cjdTo = (%s)\n",(*(iit)).c_str());	 

							ds = ci::operatingenvironment::File::CopyFile(*(it),*(iit));
							if(ds != STATUS_OK)
							{
								DEBUGL1("CDocument::FasterPastePage::Copying cjd file failed\n");											
								RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								return ds;
							}

						}
					}
				}

				//Check for the CutDocument property and delete the original document
				CutFlag.clear();
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","cutDocument", CutFlag) != STATUS_OK)						{
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}		
				if(CutFlag=="true")
				{	
					//Obtain the original document
					DocumentRef orgDoc;
					if(Utility::GetDocument(m_sessionID, orgDoc,srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName)!=STATUS_OK)
					{
						DEBUGL1("CDocument::FasterPastePage: Obtaining Originalgetd Document failed\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						return STATUS_FAILED;
					}

					// Start to Delete
					try
					{
						if(!orgDoc)
						{
							DEBUGL1("CDocument::FasterPastePage Page object is NULL\n");
							return STATUS_FAILED;
						}
						if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
						{
							DEBUGL1("CDocument::FasterPastePage: Deleting document failed\n");
							RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							return STATUS_FAILED;
						}
					}
					catch(exception& e)
					{
						DEBUGL1("CDocument::FasterPastePage::Exception caught:(%s)\n",e.what());
						return NULL;
					}
				}	

			}
			//revert back to original
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
			DEBUGL4("CDocument::FasterPastePage:Exit\n");
			return STATUS_OK;
		}



		Status CDocument::SlidePages(int dstpagenum, int Imgvecsize)
		{
			DEBUGL8("CDocument::SlidePages: Enter \n");

			//make a local copy of the member variable
			CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			boxbasepath_org = m_BoxBasePath;
			boxnumber_org = m_BoxNumber;
			folderName_org = m_FolderName;
			docName_org = m_DocumentName;
			DocStatus st;
			Status ds;
			if(this->GetStatus(st) != STATUS_OK)
			{
				DEBUGL1("CDocument::SlidePages::Getting document status is failed\n");
				return STATUS_FAILED;
			}
			if(!(st == CREATING || st == EDITING))
			{
				DEBUGL1("CDocument::SlidePages::Document is NOT CREATING or EDITING\n");
				return STATUS_FAILED;
			}
			if(st == EDITING)
			{
				//Initialize WorkSpace
				WorkSpaceInit();
			}
			int total;

			if(iSSetsysfileInvoked)
			{
				if(GetPageList(m_PageList) != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::Getting PageList failed\n");
					return STATUS_FAILED;
				}
			}

			Status ret;
			uint64 tempdocsize = m_TotalDocSize;
			// check total page size
			if(this->GetTotalPage(total)!=STATUS_OK)
			{
				DEBUGL1("CDocument::SlidePages::Getting total pages failed\n");
				return STATUS_FAILED;
			}

			DEBUGL8("CDocument::SlidePages::Total pages in the document are %d\n",total);

			if(dstpagenum > total){
				DEBUGL2("CDocument::SlidePages::Slide Pages is not needed..append case\n ");
				return STATUS_OK;
			}

			CString val;
			CString srcpath,dstpath, dstname;
			CString sExt("");
			PageRef pageRef=NULL;


			CString boxbasepath_new("");
			int pos = m_BoxBasePathOrg.rfind("/");
			boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);

			DEBUGL1("CDocument::SlidePages:: total plus Imgvecsize is (%d)\n", total + Imgvecsize);
			if(boxbasepath_new == "PageLogBoxes")
			{
				if((total + Imgvecsize) > CBoxDocument::PAGELOGBOX_PAGE_LIMIT)
				{
					DEBUGL1("CDocument::SlidePages::Page Limit reached for PAGELOGBOXES\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}
			}
			else if((total + Imgvecsize) > CBoxDocument::PAGE_LIMIT)
			{
				DEBUGL1("CDocument::SlidePages::Page Limit reached\n");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
				return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
			}

			if(Imgvecsize <= 0)
			{
				DEBUGL1("CDocument::SlidePages::Invalid number pages to be pasted %d\n", Imgvecsize);
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
				return STATUS_FAILED;
			}

			// open each SystemFiles
			CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
			FL_FILE_MAN_FILE systemfile;
			memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));
			CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
			if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK)
			{
				DEBUGL1("CDocument::SlidePages::OpenSystemDataFile Failed to open Image systemfile\n");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
				return STATUS_FAILED;
			}

			if(GetPage(1,pageRef) != STATUS_OK)
			{
				DEBUGL1("CDocument::SlidePages::getting page 1 details failed\n");
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
				return STATUS_FAILED;
			}

			bool subsampling_exists = false;
			FL_FILE_MAN_FILE subsampling;
			memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));			
			//check if subsampling Images exist then proceed.
			//use page number 1 to verify it as systemfile will be always present.
			if(!pageRef)
			{
				DEBUGL1("CDocument::SlidePages object is NULL\n");
				return STATUS_FAILED;
			}
			sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
			srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(1)+sExt;

			//control never enters in below if since subsampling files are not present
			if(Utility::ResourceExist(srcpath)==true)
			{
				DEBUGL8("CDocument::SlidePages::Subsampling File Exits\n");
				subsampling_exists=true;
			}
			if(subsampling_exists)
			{
				systemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
				if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::OpenSystemDataFile Failed to open subsampling systemfile\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return STATUS_FAILED;
				}
			}

			//use page number 1 to verify it as systemfile will be always present.
			bool thumbnail_exists = false;
			FL_FILE_MAN_FILE thumbnail;
			memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));			
			if(!pageRef)
			{
				DEBUGL1("CDocument::SlidePages page object is NULL\n");
				return STATUS_FAILED;
			}
			sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(THUMBNAILPAGETYPE);
			srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(1)+sExt;
			if(Utility::ResourceExist(srcpath)==true)
			{
				DEBUGL8("CDocument::SlidePages::Thumbnail File Exits\n");
				thumbnail_exists=true;
			}

			if(thumbnail_exists)
			{
				systemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
				if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::OpenSystemDataFile Failed to open thumbnail systemfile\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return STATUS_FAILED;
				}
			}

			DEBUGL8("CDocument::SlidePages::Slide Page information in SystemFiles\n");

			DEBUGL8("CDocument::SlidePages::total: %d, Imgvecsize:%d, dstpagenum %d\n",total,Imgvecsize,dstpagenum);
			FL_PAGE_MAN_TBL pageinfo; // Page Information in SystemFile
			CString imagename;

			// Slide Page information in SystemFiles
			for(int i = (total-dstpagenum); i >= 0 ; i--)
			{

				DEBUGL8("CDocument::SlidePages::In loop,total:%d, Imgvecsize:%d, dstpagenum %d\n",total,Imgvecsize,dstpagenum);
				int to = total + Imgvecsize;

				PageRef pageRef=NULL;
				if(GetPage((i+dstpagenum),pageRef, &systemfile, &thumbnail, &subsampling) != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::getting page %d is failed\n", dstpagenum);
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return STATUS_FAILED;
				}

				if(thumbnail_exists)
				{
					DEBUGL8("CDocument::SlidePages:: thumbnail systemdata file array updation: to (%d), total (%d)\n",to, total);
					thumbnail.sPageManTbl[to-1] = thumbnail.sPageManTbl[total-1];
					if(!pageRef)
					{
						DEBUGL1("CDocument::SlidePagesPage object is NULL\n");
						return STATUS_FAILED;
					}
					sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(THUMBNAILPAGETYPE);
					srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(i + dstpagenum)+sExt;
					dstname = Utility::GetHexadecimalPageNo(to);
					dstpath = path+"Thumbnail/"+ dstname+ sExt;
					// set the new thumbnail path & name of the page
					dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage(dstpath, dstname);
					// Update Thumbnail Image file name with the dstname set above in SetThumbnailImage
					dynamic_cast<CPage*>(pageRef.operator->())->UpdateThumbnailName(thumbnail.sPageManTbl[to-1]);

					DEBUGL8("CDocument::SlidePages::Moving Thumbnail Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
					ds = ci::operatingenvironment::File::CopyFile(srcpath.c_str(),dstpath.c_str());
					if(ds != STATUS_OK)
					{
						DEBUGL1("CDocument::SlidePages::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
						return ds;
					}

				}
				if(subsampling_exists)
				{
					DEBUGL8("CDocument::SlidePages:: subsampling systemdata file array updation: to (%d), total (%d)\n",to, total);
					subsampling.sPageManTbl[to-1] = subsampling.sPageManTbl[total-1];
					if(!pageRef)
					{
						DEBUGL1("CDocument::SlidePages Page object is NULL\n");
						return STATUS_FAILED;
					}
					sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
					srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(i+dstpagenum)+sExt;
					dstname = Utility::GetHexadecimalPageNo(to);
					dstpath = path+"Subsampling/"+ dstname +sExt;
					// set the new subsampling image path & name of the page
					dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage(dstpath, dstname);
					// Update subsampling Image file name with the dstname set above in SetSubsamplingImage
					dynamic_cast<CPage*>(pageRef.operator->())->UpdateSubsamplingName(subsampling.sPageManTbl[to-1]);

					DEBUGL8("CDocument::SlidePages::Moving Subsampling Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
					ds = ci::operatingenvironment::File::CopyFile(srcpath, dstpath);
					if(ds != STATUS_OK)
					{
						DEBUGL1("CDocument::SlidePages::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
						return ds;
					}
				}

				DEBUGL8("CDocument::SlidePages:: image systemdata file array updation: to (%d), total (%d)\n",to, total);
				systemfile.sPageManTbl[to-1] = systemfile.sPageManTbl[total-1];
				// Now move the existing Images before inserting the requested images.
				//convert the integer value to 3 digit string for page.
				srcpath = path+"Image/"+Utility::GetHexadecimalPageNo(i+dstpagenum);
				dstname = Utility::GetHexadecimalPageNo(to);
				dstpath = path+"Image/"+ dstname;
				if(!pageRef)
				{
					DEBUGL1("CDocument::SlidePages Page object is NULL\n");
					return STATUS_FAILED;
				}
				sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(IMAGEPAGETYPE);
				CString srcpathExt = srcpath + sExt;
				CString dstpathExt = dstpath + sExt;
				// set the new image path & name of the page
				if(!pageRef)
				{
					DEBUGL1("CDocument::SlidePages Page object is NULL\n");
					return STATUS_FAILED;
				}
				dynamic_cast<CPage*>(pageRef.operator->())->SetImage(dstpathExt,dstname);
				// Update Image file name with the dstname set above in SetImage
				if(!pageRef)
				{
					DEBUGL1("CDocument::SlidePages Page object is NULL\n");
					return STATUS_FAILED;
				}
				dynamic_cast<CPage*>(pageRef.operator->())->UpdateImageName(systemfile.sPageManTbl[to-1]);
				DEBUGL8("CDocument::SlidePages::Moving Image from srcpath-%s to dstpath -%s\n",srcpathExt.c_str(),dstpathExt.c_str());
				if(!m_bLink) {
					ds =  ci::operatingenvironment::File::CopyFile(srcpathExt, dstpathExt);
					if(ds != STATUS_OK)
					{
						DEBUGL1("CDocument::SlidePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
						return ds;
					}
				} else {
					Ref<ci::systeminformation::SystemInformation> spSysInfo =  ci::systeminformation::SystemInformation::Acquire();
					if(spSysInfo)
					{
						CString command = "mv " + srcpathExt + " " + dstpathExt;
						int ret;
						if(spSysInfo->RunCmd(command, ret) != STATUS_OK)
						{
							DEBUGL1("CDocument::SlidePages: Moving of image failed\n");
							return STATUS_FAILED;
						}
					}
				}

				//Move page property files
				CString srcPagePropertyFile  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i+dstpagenum) + ".xml";
				CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(to) + ".xml";

				//ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFile, dstPagePropertyFile);
				ds =  ci::operatingenvironment::File::CopyFile(srcPagePropertyFile, dstPagePropertyFile);
				if(ds != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return ds;
				}

				//Move page property files
				CString srcPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i+dstpagenum) + "_dom";
				CString dstPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(to) + "_dom";

				//ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFile, dstPagePropertyFile);
				ds =  ci::operatingenvironment::File::CopyFile(srcPagePropertyFiledom, dstPagePropertyFiledom);
				if(ds != STATUS_OK)
				{
					DEBUGL1("CDocument::SlidePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
					return ds;
				}
				srcpathExt = srcpath + ".cjd";
				dstpathExt = dstpath + ".cjd";
				//Copy Jpeg parameter file
				if(Utility::ResourceExist(srcpathExt))
				{
					ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
					if(ds != STATUS_OK)
					{
						DEBUGL1("CDocument::SlidePages::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
						return ds;
					}
				}

				DEBUGL8("CDocument::SlidePages::Moving Images successfull\n");

				total--;
			}
			// Save updated SystemFile
			//changed the $EB2/tmp path to "/work/CI/tmp/"
			CString tmppath = Utility::GetCITmpPath();
			tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
			ByteStreamRef bs = File::Open(tmppath, "w");
			bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
			bs->Close();
			// Upload
			CString uri = path + "Image/" + CString(SYSTEMFILE);
			ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
			if(ds!=STATUS_OK)
			{
				if(ds == STATUS_DISK_FULL)
				{
					DEBUGL1("CDocument::SlidePages::PutResource returned DISKFULL Error\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_DISK_FULL;
				}
				else
				{
					DEBUGL1("CDocument::SlidePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					return STATUS_FAILED;
				}
			}
			DEBUGL8("CDocument::SlidePages::Image systemfile Putting SuccessFull\n");
			File::DeleteFile(tmppath);
			m_SystemDataFile = systemfile;

			if(subsampling_exists) {
				//changed the $EB2/tmp path to "/work/CI/tmp/"
				tmppath = Utility::GetCITmpPath();
				tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
				bs = File::Open(tmppath, "w");
				bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
				bs->Close();
				// Upload
				uri = path + "Subsampling/" + CString(SYSTEMFILE);
				ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
				if(ds != STATUS_OK)
				{
					if(ds == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument::SlidePages::PutResource returned DISKFULL Error\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						return STATUS_DISK_FULL;
					}
					else
					{
						DEBUGL1("CDocument::SlidePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						return STATUS_FAILED;
					}
				}
				DEBUGL8("CDocument::SlidePages::Subsampling systemfile Putting SuccessFull\n");
				File::DeleteFile(tmppath);
				m_SubsamplingSystemDataFile = subsampling;
			}

			if(thumbnail_exists) 
			{
				//changed the $EB2/tmp path to "/work/CI/tmp/"
				tmppath = Utility::GetCITmpPath();
				tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
				bs = File::Open(tmppath, "w");
				bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
				bs->Close();
				// Upload
				uri = path + "Thumbnail/" + CString(SYSTEMFILE);
				ds = ci::operatingenvironment::File::CopyFile( tmppath,uri);
				if(ds != STATUS_OK)
				{
					if(ds == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument::SlidePages::PutResource returned DISKFULL Error\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						return STATUS_DISK_FULL;
					}
					else
					{
						DEBUGL1("CDocument::SlidePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						return STATUS_FAILED;
					}
				}
				DEBUGL8("CDocument::SlidePages::Thumbnail systemfile Putting SuccessFull\n");
				File::DeleteFile(tmppath);
				m_ThumbnailSystemDataFile = thumbnail;
			}


			//}
			RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
			return STATUS_OK;
			DEBUGL8("CDocument::SlidePages: Exit \n");
		}
	 
        Status CDocument::DeletePages(vector<int> pages, bool isThumbDataAvail, bool isSubsmplDataAvail) 
        {

            //DocStatus st;
            std::vector<int>::iterator pIt;
            DEBUGL4("CDocument::DeletePages: Enter for PageList\n");
            DEBUGL8("CDocument::DeletePages: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());

            Status ds;
            //Status rst;
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";							

            bool IsSubsamplingdataPresent = isSubsmplDataAvail;
            bool IsThumbnaildataPresent = isThumbDataAvail;
            uint64 tempdocsize = m_TotalDocSize;


            // Get the page realted folders present in the Documents
            std::vector<CString> vec;
            vector<CString>::iterator theIterator;
            CString strpageno;
            std::ostringstream str;
            CString path("");

            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << 1;
            strpageno= str.str();

            // check total page size
            int total;
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::DeletePages::Getting total pages failed\n");
                return STATUS_FAILED;
            }

            DEBUGL8("CDocument::DeletePages::Total pages in the document are %d\n",total);

            // open each of the SystemFiles
            DEBUGL8("CDocument::DeletePages: Opening each System file to update\n");					
            FL_FILE_MAN_FILE systemfile;
            memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));						
            CString systemfilepath = Utility::GetResourcePath(from+ "Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::DeletePages::OpenSystemDataFile failed");
                return STATUS_FAILED;
            }				

            FL_FILE_MAN_FILE subsampling;
				memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));						
            if(IsSubsamplingdataPresent)
            {	
                systemfilepath = Utility::GetResourcePath(from+ "Subsampling/" + SYSTEMFILE);
                if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::DeletePages:OpenSystemDataFile failed");
                    return STATUS_FAILED;
                }				
            }

            FL_FILE_MAN_FILE thumbnail;
				memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));						
            if(IsThumbnaildataPresent)
            {
                systemfilepath = Utility::GetResourcePath(from+ "Thumbnail/" + SYSTEMFILE);
                if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::OpenSystemDataFile Failed to open subsampling systemfile\n");
                    return STATUS_FAILED;
                }
            }
            int i = 0;
            vector<PageRef> pagesequence;
            vector<int> pagenosequence;

            for(int i = 1; i <= total; i++) {

                pIt = std::find(pages.begin(),pages.end(),i);
                if(pIt != pages.end()) { 
                    // Now Update the MixedInfoData 
                    DEBUGL8("CDocument::DeletePages: Updating MixedInformation\n");				
                    PageRef page = NULL;
                    if(GetPage(i,page)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages - GetPage of PageNum<%d> Failed\n",i);
                        return STATUS_FAILED;
                    }
                    if(UpdateMixedInfoData(page,false)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages - UpdateMixedInfoData of PageNum<%d> Failed\n",i);
                        return STATUS_FAILED;
                    }

                    //check which page related folders are present in the document (Thumbnail/Subsampling) and delete the page
                    DEBUGL8("CDocument::DeletePages: Deleting page<%d>\n",i);										
                    CString resourceKey;
                    if(IsThumbnaildataPresent == true)	
                    {
                        // convert int page no to str page no
                        CString strpageno = Utility::GetHexadecimalPageNo(i);
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        resourceKey = from + "Thumbnail/"+strpageno + ext;
                        ds= ci::operatingenvironment::File::DeleteFile(resourceKey.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", resourceKey.c_str());
                            return ds;
                        }
                    }

                    if(IsSubsamplingdataPresent == true)	
                    {
                        // convert int page no to str page no
                        CString strpageno = Utility::GetHexadecimalPageNo(i);
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
                        resourceKey = from + "Subsampling/"+strpageno+ext;
                        ds= ci::operatingenvironment::File::DeleteFile(resourceKey.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", resourceKey.c_str());
                            return ds;
                        }
                    }

                    // convert int page no to str page no
                    CString strpageno = Utility::GetHexadecimalPageNo(i);;
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);
                    resourceKey = from + "Image/"+strpageno+ext;
                    DEBUGL8("CDocument::DeletePages: delete image file (%s)\n", resourceKey.c_str());					
                    ds= ci::operatingenvironment::File::DeleteFile(resourceKey);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", resourceKey.c_str());
                        return ds;
                    }


                    //Delete Page properties
                    CString pagePropertyFile = from + "Image/" + "pageproperties_" + strpageno + ".xml";
                    DEBUGL8("CDocument::DeletePages: delete property file (%s)\n", pagePropertyFile.c_str());					
                    ds= ci::operatingenvironment::File::DeleteFile(pagePropertyFile);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", pagePropertyFile.c_str());
                        return ds;
                    }
                    //Delete Page properties dom
                    CString domPropertyFile = from + "Image/" + "pageproperties_" + strpageno + "_dom";
                    DEBUGL8("CDocument::DeletePages: delete dom property file (%s)\n", domPropertyFile.c_str());					
                    ds= ci::operatingenvironment::File::DeleteFile(domPropertyFile);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", domPropertyFile.c_str());
                        return ds;
                    }
                    //Delete *.cjd files if exists
                    CString CjdFiles = from + "Image/" + strpageno + ".cjd";
                    DEBUGL8("CDocument::DeletePages: delete property file (%s)\n", CjdFiles.c_str());					
                    if(Utility::ResourceExist(CjdFiles))
                    {
                        ds= ci::operatingenvironment::File::DeleteFile(CjdFiles);
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeletePages: DeleteResource %s is failed\n", pagePropertyFile.c_str());
                            return ds;
                        }
                    }
                    //Update Page number and size
                    FL_PAGE_MAN_TBL pageinfo;
                    if(IsSubsamplingdataPresent)
                    {	
                        //Update Page number
                        subsampling.sFileMan.hFlPageNum--;
                        subsampling.sFileMan.hFlPageNumE--;

                        // Update Page Size
                        dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pageinfo);			
                        subsampling.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;
                    }		

                    if(IsThumbnaildataPresent)
                    {	
                        //Update Page number
                        thumbnail.sFileMan.hFlPageNum--;
                        thumbnail.sFileMan.hFlPageNumE--;

                        // Update Page Size
                        dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pageinfo);			
                        thumbnail.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;
                    }

                    //Update Page number
                    systemfile.sFileMan.hFlPageNum--;
                    systemfile.sFileMan.hFlPageNumE--;

                    // Update Page Size
                    dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pageinfo);		
                    systemfile.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;

                    memset((FL_PAGE_MAN_TBL *)&(systemfile.sPageManTbl[i-1]),'\0',sizeof(FL_PAGE_MAN_TBL));
                    memset((FL_PAGE_MAN_TBL *)&(subsampling.sPageManTbl[i-1]),'\0',sizeof(FL_PAGE_MAN_TBL));			
                    memset((FL_PAGE_MAN_TBL *)&(thumbnail.sPageManTbl[i-1]),'\0',sizeof(FL_PAGE_MAN_TBL));

                }
                else {
                    PageRef pageRef=NULL;
                    if(GetPage(i,pageRef) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages::getting page %d is failed\n", i+1);
                        return STATUS_FAILED;
                    }
						  //commented to update the maps only once.
                    //if(UpdateMixedInfoData(pageRef,true)!=STATUS_OK)
                    //{
                      //  DEBUGL1("CDocument::DeletePages - UpdateMixedInfoData of PageNum<%d> Failed\n",i);
                      //  return STATUS_FAILED;
                    //}
                    pagesequence.push_back(pageRef);
                    pagenosequence.push_back(i);
                }
            }

            CString srcpath,dstpath, dstname;
            CString sExt("");
            // Slide Page information in SystemFiles
            DEBUGL8("CDocument::DeletePages::Sequencing the pages after deletion\n");						
            for(i = 0; i < pagesequence.size(); i ++) {

                CString srcPageNo = dynamic_cast<CPage*>(pagesequence.at(i).operator->())->GetPageNo();
                CString dstPageNo = Utility::GetHexadecimalPageNo(i+1);
                if(srcPageNo == dstPageNo) continue;
                if(IsThumbnaildataPresent) 
                {
                    thumbnail.sPageManTbl[i] = thumbnail.sPageManTbl[pagenosequence.at(i)-1];

                    sExt = dynamic_cast<CPage*>(pagesequence.at(i).operator->())->GetExtension(THUMBNAILPAGETYPE);
                    srcpath = from+"Thumbnail/"+srcPageNo+sExt;
                    dstname = dstPageNo; 
                    dstpath = from+"Thumbnail/"+ dstname+ sExt;
                    // set the new image path & name of the page
                    dynamic_cast<CPage*>(pagesequence.at(i).operator->())->SetThumbnailImage(dstpath, dstname);
                    // Update Image file name with the dstname set above in SetImage
                    dynamic_cast<CPage*>(pagesequence.at(i).operator->())->UpdateThumbnailName(thumbnail.sPageManTbl[i]);																				

                    DEBUGL8("CDocument::DeletePages::Moving Thumbnail Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                    ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                        return ds;
                    }

                }
                if(IsSubsamplingdataPresent) 
                {	
                    subsampling.sPageManTbl[i] = subsampling.sPageManTbl[pagenosequence.at(i)-1];

                    sExt = dynamic_cast<CPage*>(pagesequence.at(i).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                    srcpath = from+"Subsampling/"+srcPageNo+sExt;
                    dstname = dstPageNo;
                    dstpath = from+"Subsampling/"+ dstname+ sExt;
                    // set the new image path & name of the page
                    dynamic_cast<CPage*>(pagesequence.at(i).operator->())->SetSubsamplingImage(dstpath, dstname);
                    // Update Image file name with the dstname set above in SetImage
                    dynamic_cast<CPage*>(pagesequence.at(i).operator->())->UpdateSubsamplingName(subsampling.sPageManTbl[i]);																				

                    DEBUGL8("CDocument::DeletePages::Moving Subsampling Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                    ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                        return ds;
                    }
                }

                // Slide Page information in SystemFile
                systemfile.sPageManTbl[i] = systemfile.sPageManTbl[pagenosequence.at(i)-1];
                //convert the integer value to 3 digit string for page.
                srcpath = from+"Image/"+srcPageNo;
                dstname = dstPageNo;
                dstpath = from+"Image/"+ dstname;
                sExt = dynamic_cast<CPage*>(pagesequence.at(i).operator->())->GetExtension(IMAGEPAGETYPE);															
                CString srcpathExt = srcpath + sExt;
                CString dstpathExt = dstpath + sExt;												
                // set the new image path & name of the page
                dynamic_cast<CPage*>(pagesequence.at(i).operator->())->SetImage(dstpathExt, dstname);
                // Update Image file name with the dstname set above in SetImage
                dynamic_cast<CPage*>(pagesequence.at(i).operator->())->UpdateImageName(systemfile.sPageManTbl[i]);									
                DEBUGL8("CDocument::DeletePages::Moving Image from srcpath-%s to dstpath -%s\n",srcpathExt.c_str(),dstpathExt.c_str());
                ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                    return ds;
                }

                //Move pageproperty file
                CString prSrcpathExt = from+"Image/" + "pageproperties_" + srcPageNo + ".xml";
                CString prDstpathExt = from+"Image/" +  "pageproperties_" + dstPageNo + ".xml";						
                DEBUGL8("CDocument::DeletePages::Moving Image pageproperty file from srcpath-%s to dstpath -%s\n",prSrcpathExt.c_str(),prDstpathExt.c_str());						
                ds = ci::operatingenvironment::File::MoveFile(prSrcpathExt,prDstpathExt);
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                    return ds;
                }

                //Move pageproperty file
                CString prSrcpathExtdom = from+"Image/" + "pageproperties_" + srcPageNo + "_dom";
                CString prDstpathExtdom = from+"Image/" +  "pageproperties_" + dstPageNo + "_dom";						
                DEBUGL8("CDocument::DeletePages::Moving Image pageproperty file from srcpath-%s to dstpath -%s\n",prSrcpathExtdom.c_str(),prDstpathExtdom.c_str());						
                ds = ci::operatingenvironment::File::MoveFile(prSrcpathExtdom,prDstpathExtdom);
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                    return ds;
                }
                srcpathExt = srcpath+".cjd"; 
                dstpathExt = dstpath+".cjd"; 								
                //Copy Jpeg parameter file
                if(Utility::ResourceExist(srcpathExt))
                {
                    DEBUGL8("CDocument::DeletePages::Moving Image cjd file from srcpath-%s to dstpath -%s\n",srcpathExt.c_str(),dstpathExt.c_str());						
                    ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeletePages::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        return ds;
                    }
                }
                else
                    DEBUGL8("CDocument::DeletePages::No cjd file from srcpath-%s to dstpath -%s\n to move",srcpathExt.c_str(),dstpathExt.c_str());						
		       DEBUGL8("CDocument::DeletePages::Moving Images successfull\n");
            }
            if(IsSubsamplingdataPresent)
            {	
                //Update Page number
                std::ostringstream strm;
                strm << std::hex << std::setfill('0') << std::setw(3) << subsampling.sFileMan.hFlPageNum;
                strncpy(subsampling.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

            }		

            if(IsThumbnaildataPresent)
            {	
                std::ostringstream strm;
                strm << std::hex << std::setfill('0') << std::setw(3) << thumbnail.sFileMan.hFlPageNum;
                strncpy(thumbnail.sFileMan.aFlPageStrE, strm.str().c_str(), 5);
            }

            std::ostringstream strm;
            strm << std::hex << std::setfill('0') << std::setw(3) << systemfile.sFileMan.hFlPageNum;
            strncpy(systemfile.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

            for(i = pagenosequence.size(); i < total; i++) {
                memset((FL_PAGE_MAN_TBL *)&(systemfile.sPageManTbl[i]),'\0',sizeof(FL_PAGE_MAN_TBL));
                memset((FL_PAGE_MAN_TBL *)&(subsampling.sPageManTbl[i]),'\0',sizeof(FL_PAGE_MAN_TBL));			
                memset((FL_PAGE_MAN_TBL *)&(thumbnail.sPageManTbl[i]),'\0',sizeof(FL_PAGE_MAN_TBL));
            }

            m_TotalDocSize = systemfile.sFileMan.liFlSize;
            // Save updated SystemFile
            //changed the $EB2/tmp path to "/work/CI/tmp/"
            CString tmppath = Utility::GetCITmpPath();
            tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
            ByteStreamRef bs = File::Open(tmppath, "w");
            bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
            bs->Close();
            m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));
            // Upload
            CString uri = from + "Image/" + CString(SYSTEMFILE);
            ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
            if(ds==STATUS_DISK_FULL)
            {
                DEBUGL1("CDocument::DeletePages::PutResource returned DISKFULL Error\n");
                return STATUS_DISK_FULL;
            }
            else if (ds != STATUS_OK)
            {
                DEBUGL1("CDocument::DeletePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::DeletePages::Image systemfile Putting SuccessFull\n");
            File::DeleteFile(tmppath);
            m_SystemDataFile = systemfile;

            if(IsSubsamplingdataPresent) {
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
                bs = File::Open(tmppath, "w");
                bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                uri = from + "Subsampling/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::DeletePages::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }	
                else if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::DeletePages::Subsampling systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_SubsamplingSystemDataFile = subsampling;
            }
            if(IsThumbnaildataPresent) 
            {
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
                bs = File::Open(tmppath, "w");
                bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                uri = from + "Thumbnail/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::DeletePages::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }	
                else if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeletePages::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::DeletePages::Thumbnail systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_ThumbnailSystemDataFile = thumbnail;
            }
            //update the total page value and size value as webdav properties
            m_TotalPage = systemfile.sFileMan.hFlPageNum;
            SetWebDAVProperty("totalPages", m_TotalPage);

            m_TotalSize = systemfile.sFileMan.liFlSize;
            std::ostringstream st1;
            st1 << m_TotalSize;
            DEBUGL8("CDocument::DeletePages: totalSize = (%s)\n", st1.str().c_str());
            Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st1.str());
            if(sd != STATUS_OK)
                DEBUGL1("CDocument::DeletePages: Failed to set the totalSize for the document\n");
            //SetWebDAVProperty("totalSize", m_TotalSize);
            SetAllSize();
            //Update the page list
            m_PageList.clear();
            if(GetPageList(m_PageList) != STATUS_OK)
            {
                DEBUGL1("CDocument::DeletePages::GetPageList failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::DeletePages::PAGE LIST COUNT : %d\n, PAGES Deleted %d\n", m_TotalPage, pages.size());					

            //Update ModifiedDate
            SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
            SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());


            DEBUGL4("CDocument::DeletePages: Exit for PageList\n");

            DEBUGL4("CDocument::DeletePages: Exit\n");	
            return STATUS_OK;				
        }

        Status CDocument::DeletePage(int pageno, int delete_size) 
        {
            DEBUGL4("CDocument::DeletePage: PageNumbers to be deleted is from %d to %d\n",pageno,pageno+delete_size-1);

	    std::vector<int> pages;
	    if(delete_size <=0)
	    {
		    DEBUGL1("CDocument::DeletePage::No pages to be deleted as deletion size is zero; delete size=%d\n",delete_size);
		    return STATUS_OK;
	    }
	    for(int i=0;i<delete_size;i++)
            {
                pages.push_back(pageno+i);
            }
            return (DeletePage(pages));			
        }

        Status CDocument::DeletePage(std::vector<int> pages) 
        {
            DocStatus st;
	    int total;
            DEBUGL4("CDocument::DeletePage: Enter for PageList\n");
            DEBUGL8("CDocument::DeletePage: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_sessionID.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());
		
            if(pages.empty())
            {
                DEBUGL2("CDocument::DeletePage: vector is empty No pages to delete");
                return STATUS_OK;
            }

            if(this->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::DeletePage: Getting document status is failed\n");
                return STATUS_FAILED;
            }

            //check the status of the document
            if(!(st == CREATING || st == EDITING)) 
            {
                DEBUGL1("CDocument::DeletePage::Document is NOT CREATING or EDITING\n");
                return STATUS_FAILED;
            }
            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;
            if(st == EDITING)
            {
                //Initialize WorkSpace
                WorkSpaceInit();
            }

            if(this->GetTotalPage(total)!=STATUS_OK)
            {
                    DEBUGL1("CDocument::DeletePage::Getting total pages failed\n");
                    return STATUS_FAILED;
            }
            //Sort the vector
            std::sort(pages.begin(), pages.end());

            std::vector<int>::iterator pageno;
	    for(pageno=pages.end()-1;pageno>=pages.begin();pageno--)
	    {
		    if((*pageno <= 0)|| (*pageno > total ))
		    {
			    DEBUGL1("CDocument::DeletePage::Invalid pageno=%d\n",*pageno);
			    return STATUS_OUT_OF_RANGE;
		    }
		    if(DeleteSinglePage(*pageno)!=STATUS_OK)
		    {
			    DEBUGL1("CDocument::DeletePage: Failed to delete page<%d>",(*pageno));
			    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
			    return STATUS_FAILED;								
		    }
            }

            //revert back to original
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	

            DEBUGL4("CDocument::DeletePage: Exit for PageList\n");
            return STATUS_OK;
        }

        Status CDocument::DeleteSinglePage(int pageno) 
        {
            DEBUGL4("CDocument::DeleteSinglePage <%d>\n",pageno);

            if(iSSetsysfileInvoked)
            {						
                if(GetPageList(m_PageList) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::DeleteSinglePage::Getting PageList failed\n");
                    return STATUS_FAILED;
                }
            }

            Status ds;
            bool IsSubsamplingdataPresent = false;
            bool IsThumbnaildataPresent = false;
            uint64 tempdocsize = m_TotalDocSize;

            // check total page size
            int total;
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::DeleteSinglePage::Getting total pages failed\n");
                return STATUS_FAILED;
            }

	    DEBUGL8("CDocument::DeleteSinglePage::Total pages in the document are %d\n",total);

	    if(pageno <= 0|| pageno > total )
	    {
		    DEBUGL1("CDocument::DeleteSinglePage::Invalid pageno=%d\n",pageno);
		    return STATUS_OUT_OF_RANGE;
	    }
            // Now pre-requisites for Deleting a page are validated.
            CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";						
            CString tmpPath = from + "Subsampling/";
            //check if the contents in folder exist.
            std::vector<CString> tempvec;
            int tempcount = 0;
            vector<CString>::iterator tempIt;
            if(Utility::GetPageCollectionList(tempvec, tmpPath)!=STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage:Getting collection list for subsampling failed");
                return STATUS_FAILED;
            }
            for(tempIt=tempvec.begin();tempIt!=tempvec.end();tempIt++)
            {
                tempcount++;
            }
            if(tempcount > 1)
            {
                DEBUGL8("CDocument::DeleteSinglePage: subsampling_exists");
                IsSubsamplingdataPresent = true;
            }

            tmpPath = from + "Thumbnail/"; 
            tempcount = 0;
            tempvec.clear();
            if(Utility::GetPageCollectionList(tempvec, tmpPath)!=STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage::Getting collection list for thumbnail failed");
                return STATUS_FAILED;
            }
            for(tempIt=tempvec.begin();tempIt!=tempvec.end();tempIt++)
            {
                tempcount++;
            }
            if(tempcount > 1)
            {
                DEBUGL8("CDocument::DeleteSinglePage:: ThumbNail exists");
                IsThumbnaildataPresent = true;
            }


            // open each of the SystemFiles
            DEBUGL8("CDocument::DeleteSinglePage: Opening each System file to update\n");					
            FL_FILE_MAN_FILE systemfile;
            memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));									
            CString systemfilepath = Utility::GetResourcePath(from+ "Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::DeleteSinglePage::OpenSystemDataFile failed");
                return STATUS_FAILED;
            }				

            FL_FILE_MAN_FILE subsampling;
				memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));						
            if(IsSubsamplingdataPresent)
            {	
                systemfilepath = Utility::GetResourcePath(from+ "Subsampling/" + SYSTEMFILE);
                if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::DeleteSinglePage:OpenSystemDataFile failed");
                    return STATUS_FAILED;
                }				
            }

            FL_FILE_MAN_FILE thumbnail;
				memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));						
            if(IsThumbnaildataPresent)
            {
                systemfilepath = Utility::GetResourcePath(from+ "Thumbnail/" + SYSTEMFILE);
                if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::OpenSystemDataFile Failed to open subsampling systemfile\n");
                    return STATUS_FAILED;
                }
            }

            // Now Update the MixedInfoData 
            DEBUGL8("CDocument::DeleteSinglePage: Updating MixedInformation\n");				
            PageRef page;
            if(GetPage(pageno,page)!=STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage - GetPage of PageNum<%d> Failed\n",pageno);
                return STATUS_FAILED;
            }
            if(UpdateMixedInfoData(page,false)!=STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage - UpdateMixedInfoData of PageNum<%d> Failed\n",pageno);
                return STATUS_FAILED;
            }

            //check which page related folders are present in the document (Thumbnail/Subsampling) and delete the page
            DEBUGL8("CDocument::DeleteSinglePage: Deleting page<%d>\n",pageno);										
            CString resourceKey;
            if(IsThumbnaildataPresent == true)	
            {
                // convert int page no to str page no
                CString strpageno = Utility::GetHexadecimalPageNo(pageno);
                CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                resourceKey = from + "Thumbnail/"+strpageno + ext;
                ds= ci::operatingenvironment::File::DeleteFile(resourceKey.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", resourceKey.c_str());
                    return ds;
                }
            }

            if(IsSubsamplingdataPresent == true)	
            {
                // convert int page no to str page no
                CString strpageno = Utility::GetHexadecimalPageNo(pageno);
                CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
                resourceKey = from + "Subsampling/"+strpageno+ext;
                ds= ci::operatingenvironment::File::DeleteFile(resourceKey.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", resourceKey.c_str());
                    return ds;
                }
            }

            //Copy Jpeg parameter file
            resourceKey.clear();
            page->GetCopyJpegParameterFilePath(resourceKey);
            if(!resourceKey.empty())
            {
                ds= ci::operatingenvironment::File::DeleteFile(resourceKey.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", resourceKey.c_str());
                    return ds;
                }					
            }	
            else
            {
                DEBUGL8("CDocument::DeleteSinglePage: No CopyJpegParam file\n");					
            }
            // convert int page no to str page no
            CString strpageno = Utility::GetHexadecimalPageNo(pageno);;
            CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);
            resourceKey = from + "Image/"+strpageno+ext;
            DEBUGL8("CDocument::DeleteSinglePage: delete image file (%s)\n", resourceKey.c_str());					
            ds= ci::operatingenvironment::File::DeleteFile(resourceKey);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", resourceKey.c_str());
                return ds;
            }


            //Delete Page properties
            CString pagePropertyFile = from + "Image/" + "pageproperties_" + strpageno + ".xml";
            DEBUGL8("CDocument::DeleteSinglePage: delete property file (%s)\n", pagePropertyFile.c_str());					
            ds= ci::operatingenvironment::File::DeleteFile(pagePropertyFile);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", pagePropertyFile.c_str());
                return ds;
            }

            //Delete Page properties
            CString domPropertyFile = from + "Image/" + "pageproperties_" + strpageno + "_dom";
            DEBUGL8("CDocument::DeleteSinglePage: delete dom property file (%s)\n", domPropertyFile.c_str());					
            ds= ci::operatingenvironment::File::DeleteFile(domPropertyFile);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", pagePropertyFile.c_str());
                return ds;
            }
            //Delete *.cjd files if exists
            CString CjdFiles = from + "Image/" + strpageno + ".cjd";
            DEBUGL8("CDocument::DeleteSinglePage: delete property file (%s)\n", CjdFiles.c_str());					
            if(Utility::ResourceExist(CjdFiles))
            {
                ds= ci::operatingenvironment::File::DeleteFile(CjdFiles);
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage: DeleteResource %s is failed\n", pagePropertyFile.c_str());
                    return ds;
                }
            }

            //Update Page number and size
            FL_PAGE_MAN_TBL pageinfo;
            if(IsSubsamplingdataPresent)
            {	
                //Update Page number
                subsampling.sFileMan.hFlPageNum--;
                subsampling.sFileMan.hFlPageNumE--;
                std::ostringstream strm;
                strm << std::hex << std::setfill('0') << std::setw(3) << subsampling.sFileMan.hFlPageNum;
                strncpy(subsampling.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

                // Update Page Size
                dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pageinfo);			
                subsampling.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;
            }		

            if(IsThumbnaildataPresent)
            {	
                //Update Page number
                thumbnail.sFileMan.hFlPageNum--;
                thumbnail.sFileMan.hFlPageNumE--;
                std::ostringstream strm;
                strm << std::hex << std::setfill('0') << std::setw(3) << thumbnail.sFileMan.hFlPageNum;
                strncpy(thumbnail.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

                // Update Page Size
                dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pageinfo);			
                thumbnail.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;
            }

            //Update Page number
            systemfile.sFileMan.hFlPageNum--;
            systemfile.sFileMan.hFlPageNumE--;
            std::ostringstream strm;
            strm << std::hex << std::setfill('0') << std::setw(3) << systemfile.sFileMan.hFlPageNum;
            strncpy(systemfile.sFileMan.aFlPageStrE, strm.str().c_str(), 5);

            // Update Page Size
            dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pageinfo);		
            systemfile.sFileMan.liFlSize -= pageinfo.sPageMan.liPgDataSize;


            CString srcpath,dstpath, dstname;
            CString sExt("");
            // Slide Page information in SystemFiles
            DEBUGL8("CDocument::DeleteSinglePage::Sequencing the pages after deletion\n");						
            int i = 0;
            if(total != 1) 
            {
                for(i = pageno; i < total; i++) 
                {							
                    PageRef pageRef=NULL;
                    if(GetPage(i+1,pageRef) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeleteSinglePage::getting page %d is failed\n", i+1);
                        return STATUS_FAILED;
                    }

                    if(IsThumbnaildataPresent) 
                    {
                        thumbnail.sPageManTbl[i-1] = thumbnail.sPageManTbl[i];

                        sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        srcpath = from+"Thumbnail/"+Utility::GetHexadecimalPageNo(i+1)+sExt;
                        dstname = Utility::GetHexadecimalPageNo(i);
                        dstpath = from+"Thumbnail/"+ dstname+ sExt;
                        // set the new image path & name of the page
                        dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage(dstpath, dstname);
                        // Update Image file name with the dstname set above in SetImage
                        dynamic_cast<CPage*>(pageRef.operator->())->UpdateThumbnailName(thumbnail.sPageManTbl[i-1]);																				

                        DEBUGL8("CDocument::DeleteSinglePage::Moving Thumbnail Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                        ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeleteSinglePage::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                            return ds;
                        }

                    }
                    if(IsSubsamplingdataPresent) 
                    {	
                        subsampling.sPageManTbl[i-1] = subsampling.sPageManTbl[i];

                        sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                        srcpath = from+"Subsampling/"+Utility::GetHexadecimalPageNo(i+1)+sExt;
                        dstname = Utility::GetHexadecimalPageNo(i);
                        dstpath = from+"Subsampling/"+ dstname+ sExt;
                        // set the new image path & name of the page
                        dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage(dstpath, dstname);
                        // Update Image file name with the dstname set above in SetImage
                        dynamic_cast<CPage*>(pageRef.operator->())->UpdateSubsamplingName(subsampling.sPageManTbl[i-1]);																				

                        DEBUGL8("CDocument::DeleteSinglePage::Moving Subsampling Image from srcpath-%s to dstpath -%s\n",srcpath.c_str(),dstpath.c_str());
                        ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeleteSinglePage::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                            return ds;
                        }
                    }

                    // Slide Page information in SystemFile
                    systemfile.sPageManTbl[i-1] = systemfile.sPageManTbl[i];
                    //convert the integer value to 3 digit string for page.
                    srcpath = from+"Image/"+Utility::GetHexadecimalPageNo(i+1);
                    dstname = Utility::GetHexadecimalPageNo(i);
                    dstpath = from+"Image/"+ dstname;
                    sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(IMAGEPAGETYPE);															
                    CString srcpathExt = srcpath + sExt;
                    CString dstpathExt = dstpath + sExt;												
                    // set the new image path & name of the page
                    dynamic_cast<CPage*>(pageRef.operator->())->SetImage(dstpathExt, dstname);
                    // Update Image file name with the dstname set above in SetImage
                    dynamic_cast<CPage*>(pageRef.operator->())->UpdateImageName(systemfile.sPageManTbl[i-1]);									
                    DEBUGL8("CDocument::DeleteSinglePage::Moving Image from srcpath-%s to dstpath -%s\n",srcpathExt.c_str(),dstpathExt.c_str());
                    ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeleteSinglePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        return ds;
                    }

                    //Move pageproperty file
                    CString prSrcpathExt = from+"Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i+1) + ".xml";
                    CString prDstpathExt = from+"Image/" +  "pageproperties_" + dstname + ".xml";						
                    DEBUGL8("CDocument::DeleteSinglePage::Moving Image pageproperty file from srcpath-%s to dstpath -%s\n",prSrcpathExt.c_str(),prDstpathExt.c_str());						
                    ds = ci::operatingenvironment::File::MoveFile(prSrcpathExt,prDstpathExt);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeleteSinglePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        return ds;
                    }


                    //Move pageproperty dom file
                    CString prSrcpathExtdom = from+"Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(i+1) + "_dom";
                    CString prDstpathExtdom = from+"Image/" +  "pageproperties_" + dstname + "_dom";						
                    DEBUGL8("CDocument::DeleteSinglePage::Moving Image pageproperty dom file from srcpath-%s to dstpath -%s\n",prSrcpathExtdom.c_str(),prDstpathExtdom.c_str());						
                    ds = ci::operatingenvironment::File::MoveFile(prSrcpathExtdom,prDstpathExtdom);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::DeleteSinglePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                        return ds;
                    }
                    srcpathExt = srcpath+".cjd"; 
                    dstpathExt = dstpath+".cjd"; 								
                    //Copy Jpeg parameter file
                    if(Utility::ResourceExist(srcpathExt))
                    {
                        ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                        if(ds != STATUS_OK)
                        {
                            DEBUGL1("CDocument::DeleteSinglePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                            return ds;
                        }
                    }

                    DEBUGL8("CDocument::DeleteSinglePage::Moving Images successfull\n");
                }
            }
            else
            {
                DEBUGL8("CDocument::DeleteSinglePage:: No images to move. Total images before deletion %d\n", total);
            }

            memset((FL_PAGE_MAN_TBL *)&(systemfile.sPageManTbl[total-1]),'\0',sizeof(FL_PAGE_MAN_TBL));
            memset((FL_PAGE_MAN_TBL *)&(subsampling.sPageManTbl[total-1]),'\0',sizeof(FL_PAGE_MAN_TBL));			
            memset((FL_PAGE_MAN_TBL *)&(thumbnail.sPageManTbl[total-1]),'\0',sizeof(FL_PAGE_MAN_TBL));
            m_TotalDocSize = systemfile.sFileMan.liFlSize;
            // Save updated SystemFile
            //changed the $EB2/tmp path to "/work/CI/tmp/"
            CString tmppath = Utility::GetCITmpPath();
            tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
            ByteStreamRef bs = File::Open(tmppath, "w");
            bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
            bs->Close();
            m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));
            // Upload
            CString uri = from + "Image/" + CString(SYSTEMFILE);
            ds = ci::operatingenvironment::File::CopyFile(tmppath,uri);
            if(ds==STATUS_DISK_FULL)
            {
                DEBUGL1("CDocument::DeleteSinglePage::PutResource returned DISKFULL Error\n");
                return STATUS_DISK_FULL;
            }
            else if (ds != STATUS_OK)
            {
                DEBUGL1("CDocument::DeleteSinglePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::DeleteSinglePage::Image systemfile Putting SuccessFull\n");
            File::DeleteFile(tmppath);
            m_SystemDataFile = systemfile;

            if(IsSubsamplingdataPresent) {
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
                bs = File::Open(tmppath, "w");
                bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                uri = from + "Subsampling/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }	
                else if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::DeleteSinglePage::Subsampling systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_SubsamplingSystemDataFile = subsampling;
            }
            if(IsThumbnaildataPresent) 
            {
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
                bs = File::Open(tmppath, "w");
                bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                // Upload
                uri = from + "Thumbnail/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::PutResource returned DISKFULL Error\n");
                    return STATUS_DISK_FULL;
                }	
                else if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::DeleteSinglePage::Thumbnail systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_ThumbnailSystemDataFile = thumbnail;
            }
            //update the total page value and size value as webdav properties
            m_TotalPage = systemfile.sFileMan.hFlPageNum;
            SetWebDAVProperty("totalPages", m_TotalPage);

            m_TotalSize = systemfile.sFileMan.liFlSize;
            std::ostringstream st;
            st << m_TotalSize;
            DEBUGL8("CDocument::DeleteSinglePage: totalSize = (%s)\n", st.str().c_str());
            Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st.str());
            if(sd != STATUS_OK)
                DEBUGL1("CDocument::DeleteSinglePage: Failed to set the totalSize for the document\n");
            //SetWebDAVProperty("totalSize", m_TotalSize);
            SetAllSize();

            if(iSSetsysfileInvoked)
            {
                //Update the page list
                m_PageList.clear();
                if(GetPageList(m_PageList) != STATUS_OK)
                {
                    DEBUGL1("CDocument::DeleteSinglePage::GetPageList failed\n");
                    return STATUS_FAILED;
                }
                //m_PageList.remove(page);
            }
            DEBUGL8("CDocument::DeleteSinglePage::PAGE LIST COUNT : %d\n, PAGE NO %d\n", m_TotalPage, pageno);					

            //Update ModifiedDate
            SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
            SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());

            DEBUGL4("CDocument::DeleteSinglePage: Exit\n");	
            return STATUS_OK;				
        }

        Status CDocument::ReplacePage(int pageno, PageRef page)
        {
            PageList pages;
            pages.push_back(page);
            return ReplacePage(pageno, pages);

        }

        Status CDocument::ReplacePageByLink(int pageno, PageRef page)
        {
            DEBUGL4("CDocument::ReplacePageByLink:Enter\n");
            PageList pages;
            pages.push_back(page);
            m_bLink = true;
            Status st = ReplacePage(pageno, pages);
            m_bLink = false;
            DEBUGL4("CDocument::ReplacePageByLink:Exit\n");
            return st;
        }

        Status CDocument::ReplacePage(int pageno, PageList pages)
        {
            Status ds;
            DEBUGL4("CDocument::ReplacePage:Enter\n");

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            if(iSSetsysfileInvoked)
            {					
                if(GetPageList(m_PageList) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::ReplacePage::Getting PageList failed\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
            }
            DocStatus st;
            if(this->GetStatus(st) != STATUS_OK) 
            {
                DEBUGL1("CDocument::ReplacePage::Getting document status is failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            if(!(st == CREATING || st == EDITING)) 
            {
                DEBUGL1("CDocument::ReplacePage::Document is NOT CREATING or EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }
            Status ret;
            if(st == EDITING)
            {
                //Initialize WorkSpace
                WorkSpaceInit();
            }
            uint64 tempdocsize = m_TotalDocSize;
            // check total page size
            int total;
            if(this->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::ReplacePage::Getting total pages failed\n");
                return STATUS_FAILED;
            }

            DEBUGL8("CDocument::ReplacePage::Total pages in the document are %d\n",total);
            CString srcpath,dstpath, dstname;
            CString sExt("");
            PageRef pageRef;

            if((pageno > total) || (pageno <= 0)) 
            {
                DEBUGL1("CDocument::ReplacePage::Invalid insert point %d\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            // open each SystemFiles
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            FL_FILE_MAN_FILE systemfile;
            memset(&systemfile, '\0', sizeof(FL_FILE_MAN_FILE));									
            CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
            if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::ReplacePage::OpenSystemDataFile Failed to open Image systemfile\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            pageRef=NULL;
            if(GetPage(1,pageRef) != STATUS_OK)
            {
                DEBUGL1("CDocument::ReplacePage::getting page 1 details failed\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                return STATUS_FAILED;
            }

            bool subsampling_exists = false;
            FL_FILE_MAN_FILE subsampling;
				memset(&subsampling, '\0', sizeof(FL_FILE_MAN_FILE));						
            //check if subsampling Images exist then proceed.
            //use page number 1 to verify it as systemfile will be always present.
            try
            {
                if(!pageRef)
                {
                    DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
                srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(1)+sExt;
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::ReplacePage::Subsampling File Exits\n");
                    subsampling_exists=true;
                }

                if(subsampling_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
                    if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::ReplacePage::OpenSystemDataFile Failed to open subsampling systemfile\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                //check if subsampling Images exist then proceed.
                //use page number 1 to verify it as systemfile will be always present.
                bool thumbnail_exists = false;
                FL_FILE_MAN_FILE thumbnail;
					 memset(&thumbnail, '\0', sizeof(FL_FILE_MAN_FILE));						
                if(!pageRef)
                {
                    DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                sExt = dynamic_cast<CPage*>((pageRef).operator->())->GetExtension(THUMBNAILPAGETYPE);
                srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(1)+sExt;
                if(Utility::ResourceExist(srcpath)==true)
                {
                    DEBUGL8("CDocument::ReplacePage::Thumbnail File Exits\n");
                    thumbnail_exists=true;
                }

                if(thumbnail_exists)
                {
                    systemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
                    if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::ReplacePage::OpenSystemDataFile Failed to open thumbnail systemfile\n");		
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                }

                // Copy Image and Page Information
                PageRef page;
                FL_PAGE_MAN_TBL pageinfo; // Page Information in SystemFile
                CString imagename;
                CString source, target;
                PageList::iterator it = pages.begin();

                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    page = (*it);
                    imagename =Utility::GetHexadecimalPageNo(i);
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    page->GetImage(source);
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    dynamic_cast<CPage*>(page.operator->())->GetSystemFile(pageinfo);
                    sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);																		
                    dstname = imagename;
                    dstpath = path+"Image/"+ dstname+sExt; 
                    // set the Image file name & path for the page
                    // this may be redundant for setting dstpath, as user first calls PutImage which sets m_ImagePath
                    dynamic_cast<CPage*>(page.operator->())->SetImage(dstpath, dstname);

                    //Because OverwriteImage increments below members, but this is replace page
                    systemfile.sFileMan.hFlPageNum--;
                    systemfile.sFileMan.hFlPageNumE--;
                    ret=this->OverwriteImage(i, source, path + "Image/", imagename, sExt, pageinfo, systemfile);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage::Overwrite Image Failed for page %d\n",i);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    // Set the WebDAV properties of each new page.
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    } 
                    ret = dynamic_cast<CPage*>(page.operator->())->SetProperties(i, path);
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::ReplacePage:: SetProperties failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return ret;
                    }

                    //Set the following properties on Page
                    int value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgMLen;							
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageWidth",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage - SetWebDAVProperty of adjustedImageWidth Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hInPgSLen;
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("adjustedImageHeight",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage - SetWebDAVProperty of adjustedImageHeight Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hOrientation;								
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("orientation",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage - SetWebDAVProperty of orientation Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }
                    value = systemfile.sPageManTbl[pageno-1].sPageComAtr.hAngle;								
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CPage*>(page.operator->())->SetWebDAVProperty("angle",value);
                    if(ret != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage - SetWebDAVProperty of angle Failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);										
                        return ret;
                    }

                    //Copy Jpeg parameter file
                    if(!page)
                    {
                        DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                        return STATUS_FAILED;
                    }
                    if(dynamic_cast<CPage*>(page.operator->())->IsCopyJpegParameterSet()==STATUS_OK)
                    {	
                        if(!page)
                        {
                            DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        Status ret = dynamic_cast<CPage*>(page.operator->())->UploadCopyJpegParameter(imagename,path);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::ReplacePage - UploadCopyJpegParameter failed\n");
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                    if(subsampling_exists) 
                    {  
                        if(!page)
                        {
                            DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetSubsamplingImage(source);
                        dynamic_cast<CPage*>(page.operator->())->GetSubsamplingSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                        //Because OverwriteImage increments below members, but this is replace page
                        subsampling.sFileMan.hFlPageNum--;
                        subsampling.sFileMan.hFlPageNumE--;

                        ret = this->OverwriteImage(i, source, path + "Subsampling/", imagename, sExt, pageinfo, subsampling);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::ReplacePage::Overwrite Subsampling Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }        
                    }
                    if(thumbnail_exists) 
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::ReplacePage::Page object is NULL\n");
                            return STATUS_FAILED;
                        }
                        page->GetThumbnailImage(source);
                        dynamic_cast<CPage*>(page.operator->())->GetThumbnailSystemFile(pageinfo);
                        sExt = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        //Because OverwriteImage increments below members, but this is replace page
                        thumbnail.sFileMan.hFlPageNum--;
                        thumbnail.sFileMan.hFlPageNumE--;

                        ret=this->OverwriteImage(i, source, path + "Thumbnail/", imagename, sExt, pageinfo, thumbnail);
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CDocument::ReplacePage::Overwrite ThumbNail Image Failed for page %d\n",i);
                            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                            return ret;
                        }
                    }
                }

                // Save updated SystemFile
                //changed the $EB2/tmp path to "/work/CI/tmp/"
                CString tmppath = Utility::GetCITmpPath();
                tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
                ByteStreamRef bs = File::Open(tmppath, "w");
                bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
                bs->Close();
                m_TotalDocSize += (3 * sizeof(FL_FILE_MAN_FILE));
                // Upload
                CString uri = path + "Image/" + CString(SYSTEMFILE);
                ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::ReplacePage::PutResource returned DISKFULL Error\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_DISK_FULL;
                }
                else if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::ReplacePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    return STATUS_FAILED;
                }
                DEBUGL8("CDocument::ReplacePage::Image systemfile Putting SuccessFull\n");
                File::DeleteFile(tmppath);
                m_SystemDataFile = systemfile;

                if(subsampling_exists) {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Subsampling_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&subsampling, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Subsampling/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                    if(ds==STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::ReplacePage::PutResource returned DISKFULL Error\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_DISK_FULL;
                    }	
                    else if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                    DEBUGL8("CDocument::ReplacePage::Subsampling systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_SubsamplingSystemDataFile = subsampling;
                }
                if(thumbnail_exists) 
                {
                    //changed the $EB2/tmp path to "/work/CI/tmp/"
                    tmppath = Utility::GetCITmpPath();
                    tmppath += m_DocumentName + "_Thumbnail_" + CString(SYSTEMFILE);
                    bs = File::Open(tmppath, "w");
                    bs->WriteN(&thumbnail, 1, sizeof(FL_FILE_MAN_FILE));
                    bs->Close();
                    // Upload
                    uri = path + "Thumbnail/" + CString(SYSTEMFILE);
                    ds = ci::operatingenvironment::File::CopyFile( tmppath, uri);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage::PutResource returned DISKFULL Error\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_DISK_FULL;
                    }	
                    else if(ds != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage::PutResource %s to %s is failed\n",tmppath.c_str(), uri.c_str());
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                    DEBUGL8("CDocument::ReplacePage::Thumbnail systemfile Putting SuccessFull\n");
                    File::DeleteFile(tmppath);
                    m_ThumbnailSystemDataFile = thumbnail;
                }

                if(iSSetsysfileInvoked)
                {							
                    m_PageList.clear();
                    if(GetPageList(m_PageList) != STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage::Getting PageList failed\n");
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);				
                        return STATUS_FAILED;
                    }
                }	

                it = pages.begin();
                for(int i = pageno; it != pages.end(); i++, it++) 
                {
                    DEBUGL8("CDocument::ReplacePage::Updating Newly added Page number %d by GetPage call\n",i);
                    if(UpdateMixedInfoData((*it),true)!=STATUS_OK)
                    {
                        DEBUGL1("CDocument::ReplacePage - UpdateMixedInfoData of PageNum<%d> Failed\n",i);
                        RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        return STATUS_FAILED;
                    }
                    DEBUGL8("CDocument::ReplacePage::PAGE LIST COUNT : %d\n, PAGE NO %d\n", total, i);
                }

                //Update ModifiedDate
                SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
                SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());

                //After Inserting update total number of pages and size of the file.
                m_TotalPage = systemfile.sFileMan.hFlPageNum;
                SetWebDAVProperty("totalPages", m_TotalPage);

                m_TotalSize = systemfile.sFileMan.liFlSize;
                std::ostringstream st1;
                st1 << m_TotalSize;
                DEBUGL8("CDocument::ReplacePage: totalSize = (%s)\n", st1.str().c_str());
                Status sd = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", st1.str());
                if(sd != STATUS_OK)
                    DEBUGL1("CDocument::ReplacePage: Failed to set the totalSize for the document\n");

                //SetWebDAVProperty("totalSize", m_TotalSize);
                SetAllSize();

                //revert back to original
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::ReplacePage::exception caught:(%s)\n",e.what());
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument::ReplacePage:Enter\n");												
            return STATUS_OK;
        }


        Status CDocument::Initialize() {
            Status ds;
            //Status rst;
            // create Document folder
            CString docpath = m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName + "/" + m_DocumentName + "/";

            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> folder = NULL;
            ds = ci::operatingenvironment::Folder::CreateFolder(folder, docpath.c_str());
            if( ds != STATUS_OK) 
            {
                if(ds == STATUS_DISK_FULL)
                    DEBUGL1("CDocument::Initialize::DISKFULL Error\n");
                else
                    DEBUGL1("CDocument::Initialize::Error while creating a folder\n");

                return ds;
            }

            int r;
            CString spath = "'" + docpath + ".document'";
            CString createstatusfile = "touch " + spath;
            ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
            if(sysinfo->RunCmd(createstatusfile, r) != STATUS_OK)
            {
                DEBUGL1("CDocument::Initialize: Failed to run the command\n");
                return STATUS_FAILED;
            }

            spath = "'" + docpath + statusfilename::CREATING + "'";
            createstatusfile = "touch " + spath;
            if(sysinfo->RunCmd(createstatusfile, r) != STATUS_OK)
            {
                DEBUGL1("CDocument::Initialize: Failed to run the command\n");
                return STATUS_FAILED;
            }

            // create Image folders
            CString imagepath = docpath + "Image/";
            folder = NULL;
            ds = ci::operatingenvironment::Folder::CreateFolder(folder, imagepath.c_str());
            if(ds != STATUS_OK) 
            {
                DEBUGL1("CDocument::Initialize::CopyResource returned Error\n");
                Status rst = Utility::RemoveResource(docpath);
                if(rst != STATUS_OK)
                    DEBUGL2("CDocument::Initialize: Failed to remove half created document\n");

                return ds;
            }
            CString thumbnailpath = docpath + "Thumbnail/";
            folder = NULL;						
            ds = ci::operatingenvironment::Folder::CreateFolder(folder, thumbnailpath.c_str());
            if(ds!=STATUS_OK) 
            {
                DEBUGL1("CDocument::Initialize::CopyResource returned DISKFULL Error\n");
                Status rst = Utility::RemoveResource(docpath);
                if(rst != STATUS_OK)
                    DEBUGL2("CDocument::Initialize: Failed to remove half created document\n");
                return ds;
            }
            CString subsamplingpath = docpath + "Subsampling/";
            folder = NULL;						
            ds = ci::operatingenvironment::Folder::CreateFolder(folder, subsamplingpath.c_str());
            if(ds != STATUS_OK) 
            {
                DEBUGL1("CDocument::Initialize::CopyResource returned DISKFULL Error\n");
                Status rst = Utility::RemoveResource(docpath);
                if(rst != STATUS_OK)
                    DEBUGL2("CDocument::Initialize: Failed to remove half created document\n");
                return ds;
            } 
            return STATUS_OK;
        }

        Status CDocument::LoadProperties() {
            // get WebDAV properties.
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";

            // when Session::GetProperties() is called, 
            //  all map->second need to be empty string.
            std::map<CString, CString>::iterator it = m_WebDAVProperties.begin();
            for(;it != m_WebDAVProperties.end(); it++) {
                it->second = "";
            }

            if(Utility::GetAllProperties(path, "documentproperties.xml", m_WebDAVProperties)!= STATUS_OK) {
                DEBUGL1("CDocument::LoadProperties:getting properties is failed\n");
                return STATUS_FAILED;
            }

            std::istringstream totalpage(m_WebDAVProperties["totalPages"].c_str());
            totalpage >> m_TotalPage;
            std::istringstream totalsize(m_WebDAVProperties["totalSize"].c_str());
            totalsize >> m_TotalSize;
            for(it = m_WebDAVProperties.begin() ;it != m_WebDAVProperties.end(); it++) {
                DEBUGL8("CDocument::LoadProperties: Properties of document (%s) = (%s)\n", (it->first).c_str(), (it->second).c_str());
            }

            return STATUS_OK;
        }

        Status CDocument::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) 
        {
            m_WebDAVProperties = WebDAVpropertyMap;
            std::istringstream totalpage(WebDAVpropertyMap["totalPages"].c_str());
            totalpage >> m_TotalPage;
            std::istringstream totalsize(WebDAVpropertyMap["totalSize"].c_str());
            totalsize >> m_TotalSize;
            return STATUS_OK;	
        }

        Status CDocument::SaveProperties() {
            // get WebDAV properties.
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";

            Status sdf = Utility::SetProperties(path, "documentproperties.xml",m_WebDAVProperties);
            if(sdf != STATUS_OK) {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SaveProperties:setting properties is failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::SaveProperties:setting properties is failed\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }


        Status CDocument::GetProperties(std::map<CString, CString> &WebDAVProperties) 
        {

            // when Session::GetProperties() is called, 
            //  all map->second need to be empty string.
            std::map<CString, CString>::iterator it = m_WebDAVProperties.begin();
            for(;it != m_WebDAVProperties.end(); it++) 
                it->second = "";
            if(proputils::GetAllDocumentProperties(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName, m_WebDAVProperties)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetProperties:getting properties is failed\n");
                return STATUS_FAILED;
            }

            std::istringstream totalpage(m_WebDAVProperties["totalPages"].c_str());
            totalpage >> m_TotalPage;
            std::istringstream totalsize(m_WebDAVProperties["totalSize"].c_str());
            totalsize >> m_TotalSize;
            WebDAVProperties = m_WebDAVProperties;

            return STATUS_OK;
        }

        Status CDocument::SetProperties(std::map<CString, CString> WebDAVProperties) 
        {
            // get WebDAV properties.
            Status sdf = proputils::SetDocumentProperties(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName, WebDAVProperties);
            if(sdf != STATUS_OK) 
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::SetProperties:setting properties is failed because Disk is Full\n");
                    return STATUS_DISK_FULL; 
                }
                DEBUGL1("CDocument::SetProperties:setting properties is failed\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CDocument::Delete() {
            Status ds;
            DocStatus st;
            Status sdf;
            if(GetStatus(st)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get document status\n");
                return STATUS_FAILED;							
            }
            if(st!=DELETING)
            {	
                if(ChangeStatus(DELETING) != STATUS_OK) {
                    DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                    return STATUS_FAILED;
                }
            }	

            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            uint64 tempsize = 0;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalDocSize", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                return STATUS_FAILED;
            }
            tempsize = val.length()? atoi(val.c_str()): 0;
            // delete whole folder
            ds = ci::operatingenvironment::Folder::Remove(path.c_str(),true);
            if(ds != STATUS_OK) {
                DEBUGL1("CDocument::Delete : DeleteResource %s is failed\n", path.c_str());
                return ds;
            }
            uint64 size;
            if(m_FolderName.length()) {
                propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
                CString val;
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,"","","totalFolderSize", val) != STATUS_OK)
                {
                    DEBUGL1("CDocument::Delete : Failed to get the property\n");
                    return STATUS_FAILED;
                }
                uint64 size = val.length()? atoi(val.c_str()): 0;
                size -= tempsize;
                ostringstream foldsize;
                foldsize << size;
                sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,"","","totalFolderSize", foldsize.str());
                if(sdf != STATUS_OK)							
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::Delete : Failed to set the property because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CDocument::Delete : Failed to set the property\n");								
                    return STATUS_FAILED;
                }
            }
            propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", val) != STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get the property\n");
                return STATUS_FAILED;							
            }
            size = val.length()? atoi(val.c_str()): 0;
            size -= tempsize;
            ostringstream boxsize;
            boxsize << size;
            sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", boxsize.str());
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::Delete : Failed to set the property because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::Delete : Failed to set the property\n");								
                return STATUS_FAILED;							
            }
            return STATUS_OK;
        }

        //----
        // private functions of CDocument

        CString CDocument::GetStatusFileName(DocStatus st) {
            switch(st) {
                case CREATING : return  statusfilename::CREATING;
                case READY    : return  statusfilename::READY;
                case USING    : return  statusfilename::USING;
                case EDITING  : return  statusfilename::EDITING;
                case DELETING : return  statusfilename::DELETING;
                case WAITING : return  statusfilename::WAITING;
                case RESERVING : return  statusfilename::RESERVING;
            }
            return ""; 
        }

        Status CDocument::GetFullSize(uint64 &size)
        {
            CString val;
            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            GetWebDAVProperty("totalDocSize", val);
            size = val.length() ? atoi(val.c_str()) : 0;
            DEBUGL8("CDocument::GetFullSize - Full Size of Document <%llu>\n",size);		
            return STATUS_OK;
        }

        /**
         * save the delta document. 
         * change document status from EDITING to READY. if document status is 
         * NOT EDITING, it will fail.
         * when this method is called, unlock delta document. delta documents 
         * will be overwritten to original documents. after that all delta 
         * documents will be deleted. 
         * @param[out] progress - user can get operation progress from this.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::Save(ProgressRef &progress)
        {

            DEBUGL4(" CDocument::Save()-- Entered \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString saveProgShmName = "Save_" + CUUID().toString(); 
            m_SaveErrfile = CUUID().toString();

            //Create an instance of CProgress
            //Ref<CProgress> m_cprogress ;
            m_cprogress = new CProgress(saveProgShmName,m_SaveErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".saveDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1("CDocument::Save()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }

            this->m_SaveProgShmName = saveProgShmName;
            //Create shared memory to store progress of save operation
            m_prgShmid = SharedMemory::Create(m_SaveProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::Save: -- Failed to Create Shared Memory for Save Progress Name \n ");
                return STATUS_FAILED;
            }

            //Create an instance of the invoking Object
            //CDocument savedocObj = (CDocument)*this;			

            pRetValue = CreateSaveThread(this);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::Save()-- Creating Save thread Failed \n");
                return pRetValue;
            }
            progress = m_cprogress;
            return STATUS_OK;
        }
        /**
         * save the edited document with other name
         * change document status from EDITING to READY. if document status is 
         * NOT EDITING, it will fail.
         * when this method is called, unlock delta document. delta documents 
         * will be overwritten to original documents. after that all delta 
         * documents will be deleted. 
         * @param[out] progress - user can get operation progress from this.
         * @param[in] new_name - merged document save as the name
         * @param[in] resourcebasepath - save to the this folder, if it is set.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::SaveAs(ProgressRef &progress,CString new_name,CString resourcebasepath)
        {

            DEBUGL4(" CDocument::SaveAs()-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString saveAsProgShmName = "SaveAs_" + CUUID().toString(); 
            m_SaveAsErrfile = CUUID().toString(); 

            CString to = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,new_name) + "/";		
            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = m_BoxBasePath;
            boxnumber_org = m_BoxNumber;
            folderName_org = m_FolderName;
            docName_org = m_DocumentName;

            //Initialize WorkSpace
            WorkSpaceInit();

            // check current status
            DocStatus st;
            if(GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::SaveAs::GetStatus failed\n");						
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            if(st != EDITING) 
            {
                DEBUGL1("CDocument::SaveAs: Document is NOT EDITING\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }

            CString val;		
            Status st1 = proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","srcDocumentName",val );
            if(st1 != STATUS_OK)
            {
                DEBUGL1(" CDocument::SaveAs(): unablt to get the document name\n");
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }		

            DEBUGL8("CDocument::SaveAs: val (%s) new_name (%s) to (%s) \n", val.c_str(), new_name.c_str(), to.c_str());		
            if(Utility::ResourceExist(to))
            {
                if(new_name != val)
                {
                    DEBUGL1("CDocument::SaveAs: Resource with same name exist\n");
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
                }
            }
            RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

            //Create an instance of CProgress
            m_cprogress = new CProgress(saveAsProgShmName,m_SaveAsErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".saveAsDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::SaveAs()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }

				m_SaveAsProgShmName = saveAsProgShmName;

				m_prgShmid = SharedMemory::Create(m_SaveAsProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::SaveAs(): -- Failed to Create Shared Memory for SaveAs Progress Name \n ");
                return STATUS_FAILED;
            }

            //Create an instance of the invoking Object
            pRetValue = CreateSaveAsThread(this,new_name,resourcebasepath);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::SaveAs()-- Creating Save thread Failed \n");
                return pRetValue;
            }
            progress = m_cprogress;
            return STATUS_OK;

        }	



        /**
         * cut the page to clipboard
         * if document status is NOT EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pageno - source page number
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::CutPage(ProgressRef& progress, int pageno)
        {
            vector<int> pages;
            pages.push_back(pageno);
            return(CutPage(progress,pages));
        }	

        /**
         * cut the pages to clipboard
         * if document status is NOT EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pages - vector of source page numbers
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::CutPage(ProgressRef& progress, std::vector<int> pages)
        {
            DEBUGL4(" CDocument::CutPage()-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString cutProgShmName = "Cut_" + CUUID().toString(); 
            m_CutErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(cutProgShmName,m_CutErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".cutDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::CutPage()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_CutProgShmName = cutProgShmName;

            //Create shared memory to store the progress of cut operation
            m_prgShmid = SharedMemory::Create(m_CutProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1(" CDocument::CutPage() with progress: -- Failed to Create Shared Memory for Cut Progress\n ");
                return STATUS_FAILED;
            }


            //Create an instance of the invoking Object
            pRetValue = CreateCutThread(this,pages);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::CutPage()-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }	

        /**
         * copy the page to clipboard
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pageno - source page number
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::CopyPage(ProgressRef& progress, int pageno)
        {

            vector<int> pages;
            pages.push_back(pageno);
            return(CopyPage(progress,pages));

        }	
        /**
         * copy the pages to clipboard
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pages - vector of source page numbers
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::CopyPage(ProgressRef& progress, std::vector<int> pages)
        {

            DEBUGL4(" CDocument::CopyPage()-- Entered for Progress  \n ");
            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString copyProgShmName = "Copy_" + CUUID().toString(); 
            m_CopyErrfile = CUUID().toString(); 

            //Create an instance of CProgress	
            //Ref<CProgress> m_cprogress ;
            m_cprogress = new CProgress(copyProgShmName,m_CopyErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".copyDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::CopyPage()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }

            m_CopyProgShmName = copyProgShmName;

            //Create shared memory to store the progress of copy operation
            m_prgShmid = SharedMemory::Create(m_CopyProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::CopyPage() with progress: -- Failed to Create Shared Memory for Copy Progress\n ");
                return STATUS_FAILED;
            }

            //Create an instance of the invoking Object
            pRetValue = CreateCopyThread(this,pages);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::CopyPage()-- Creating Copy Thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }	

        /**
         * paste the page(s) from clipboard
         * if document status is NOT EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pageno - page number to insert
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CDocument::PastePage(ProgressRef& progress, int pageno)
        {

            DEBUGL4(" CDocument::PastePage()-- Entered for Progress\n");
            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString pasteProgShmName = "Paste_" + CUUID().toString(); 
            m_PasteErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(pasteProgShmName,m_PasteErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".pasteDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::PastePage()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }

            m_PasteProgShmName = pasteProgShmName;
            //Create shared memory to store the progress of paste operation
            m_prgShmid = SharedMemory::Create(m_PasteProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::PastePage() with progress: -- Failed to Create Shared Memory for Paste Progress\n ");
                return NULL;
            }

            //Create an instance of the invoking Object
            pRetValue = CreatePasteThread(this,pageno);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::PastePage()-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
		
            DEBUGL4(" CDocument::PastePage()-- Exit for Progress\n");
	
            return STATUS_OK;
        }	
        Status CDocument::FasterPastePage(ProgressRef& progress, int pageno)
		{

            DEBUGL4(" CDocument::FasterPastePage()-- Entered for Progress\n");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString pasteProgShmName = "Paste_" + CUUID().toString(); 
            m_PasteErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(pasteProgShmName,m_PasteErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".pasteDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::FasterPastePage()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }

            m_PasteProgShmName = pasteProgShmName;
            //Create shared memory to store the progress of paste operation
            m_prgShmid = SharedMemory::Create(m_PasteProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::FasterPastePage() with progress: -- Failed to Create Shared Memory for Paste Progress\n ");
                return NULL;
            }

            //Create an instance of the invoking Object
            pRetValue = CreateFasterPasteThread(this,pageno);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::FasterPastePage()-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }
        /**
         * delete page
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pageno - delete page number. after deletion, the pages that 
         *                     have greater page number are off to the front.
         * @param[in] size - delete page size (default = 1)
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::DeletePage(ProgressRef& progress, int pageno,int delete_size)
        {

            DEBUGL4("CDocument::DeletePage: PageNumbers to be deleted is from %d to %d\n",pageno,pageno+delete_size-1);
            std::vector<int> pages;
	    if(delete_size <=0)
            {
                    DEBUGL1("CDocument::DeletePage::No pages to be deleted delete_size=%d\n",delete_size);
                    return STATUS_OK;
            }
            for(int i=0;i<delete_size;i++)
            {
                pages.push_back(pageno+i);
            }
            return (DeletePage(progress,pages));

        }

        /**
         * delete page
         * @param[out] progress - user can get operation progress from this.
         * @param[in] pages - vector of delete page numbers. after deletion, 
         *                     the pages that have greater page numbers are off to
         *                     the front.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::DeletePage(ProgressRef& progress, std::vector<int> pages)
        {

            DEBUGL4(" CDocument::DeletePage()-- Entered for Progress \n ");
	    Status pRetValue = STATUS_OK;
	    //Generate a name for creating Shared memory
            CString deleteProgShmName = "Delete_" + CUUID().toString(); 
            m_DeleteErrfile = CUUID().toString();
            //Create an instance of CProgress
            m_cprogress = new CProgress(deleteProgShmName,m_DeleteErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".deleteDiskFullDoc_");
            if(!m_cprogress)
            {
                DEBUGL1(" CDocument::DeletePage()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_DeleteAsProgShmName = deleteProgShmName;
            //Create shared memory to store progress of delete operation
            m_prgShmid = SharedMemory::Create(m_DeleteAsProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("\n CDocument::DeletePage: -- Failed to Create Shared Memory for Delete Progress\n ");
               return NULL;
            }
            
            //Create an instance of the invoking Object
            pRetValue = CreateDeleteThread(this,pages);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CDocument::DeletePage()-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;



        }		


        Status CDocument::CreateCutThread(CDocument *cutdocumentObj, std::vector<int>pages)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingcutthread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateCutThread()-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }
            //Push the vector of pages into its respective static variable
            std::vector<int>::iterator it;
            for(it = pages.begin();it!=pages.end();it++)
                m_CutVecofPages.push_back(*it);

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_CutFlag = FLAG_SET;

            pRetVal = CreateThread(StartCutThread,reinterpret_cast<void*>(cutdocumentObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateCutThread::Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateCutThread:: Creation of thread Initiated\n");

           pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateCutThread()--Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;

            }
            DEBUGL4("CDocument::CreateCutThread: Exit\n");
            return pRetVal;

        }


        Status CDocument::CreateCopyThread(CDocument *copydocumentObj, std::vector<int>pages )
        {
            DEBUGL4("CDocument::CreateCopyThread: Enter \n");
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingcopythread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateCopyThread()-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;
            }

            //Push the vector of pages into its respective static variable
            std::vector<int>::iterator itr;
            for(itr=pages.begin();itr!=pages.end();itr++)
                m_CopyVecofPages.push_back(*itr);

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_CopyFlag = FLAG_SET;
            pRetVal = CreateThread(StartCopyThread,reinterpret_cast<void*>(copydocumentObj),m_ThreadID); 
            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateCopyThread::Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateCopyThread:: Creation of thread Initiated\n");

           //exit critical section
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateCopyThread()-- Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument::CreateCopyThread: Exit \n");
            return pRetVal;
        }


        Status CDocument::CreateSaveThread(CDocument *savedocObj)
        {

            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString slockpath="lockingSavethread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, slockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateSaveThread: -- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }

            pRetVal = CreateThread(StartSaveThread,reinterpret_cast<void*>(savedocObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateSaveThread: --Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateSaveThread: --Creation of thread Initiated\n");

            //exit critical section		
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateSaveThread: --Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }

            return pRetVal;

        }

        Status CDocument::CreateSaveAsThread(CDocument *saveasdocObj, CString newname, CString resourcebasepath)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString svlockpath="lockingSaveAsthread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex,svlockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateSaveAsThread: -- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }
            // Copy the inputs into the static variables
            //so that can be accessed in static thread
            saveasdocObj->m_SaveAsNewName = newname;
            saveasdocObj->m_SaveAsResourceBasePath = resourcebasepath;

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_SaveAsFlag = FLAG_SET;

            pRetVal = CreateThread(StartSaveAsThread,reinterpret_cast<void*>(saveasdocObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateSaveAsThread: --Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateSaveAsThread: --Creation of thread Initiated\n");

            //exit critical section	
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateSaveAsThread: --Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }

            return pRetVal;



        }

        Status CDocument::CreatePasteThread(CDocument *pastedocumentObj, int pageno)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString pstlockpath="lockingPastethread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, pstlockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreatePasteThread: -- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }

            // Copy the input into the static variable
            //so that it can be accessed in static thread
            pastedocumentObj->m_PastePageNo = pageno;

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_PasteFlag = FLAG_SET;

            pRetVal = CreateThread(StartPasteThread,reinterpret_cast<void*>(pastedocumentObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreatePasteThread: --Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreatePasteThread: --Creation of thread Initiated\n");

            //exit critical section	
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreatePasteThread: --Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument: CreatePasteThread: Exit\n");
            return pRetVal;


        }

        Status CDocument::CreateFasterPasteThread(CDocument *pastedocumentObj, int pageno)
		{
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString pstlockpath="lockingPastethread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, pstlockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateFasterPasteThread: -- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }

            // Copy the input into the static variable
            //so that it can be accessed in static thread
            pastedocumentObj->m_PastePageNo = pageno;

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_PasteFlag = FLAG_SET;

            pRetVal = CreateThread(StartFasterPasteThread,reinterpret_cast<void*>(pastedocumentObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateFasterPasteThread: --Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateFasterPasteThread: --Creation of thread Initiated\n");

            //exit critical section	
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateFasterPasteThread: --Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument: CreateFasterPasteThread: Exit\n");
            return pRetVal;


        }

        Status CDocument::CreateDeleteThread(CDocument *deletedocObj, vector< int> pages)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString dllockpath="lockingDeletethread";
            // enter critical section
            GlobalMutexRef threadMutex = NULL;

            pRetVal = Utility::EnterCriticalSection(threadMutex, dllockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateDeleteThread: -- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }
            //Push the vector of pages into its respective static variable
            std::vector<int>::iterator itr;
            for(itr=pages.begin();itr!=pages.end();itr++)
                m_DeleteVecofPages.push_back(*itr);

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_DeleteFlag = FLAG_SET;
            pRetVal = CreateThread(StartDeleteThread,reinterpret_cast<void*>(deletedocObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1("CDocument::CreateDeleteThread: --Could not Create a Thread\n");
            else
                DEBUGL8("CDocument::CreateDeleteThread: --Creation of thread Initiated\n");

				//exit critical section
				pRetVal = Utility::LeaveCriticalSection(threadMutex);
				if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("\n CDocument::CreateDeleteThread: --Releasing the Locked Resource Failed...\n ");
                return STATUS_FAILED;
            }

            return pRetVal;




        }


        Status CDocument::CreateThread(ThreadFun funcName,ThreadArg funcArgument,Ref<Thread> threadID)
        {
            DEBUGL4("CDocument::CreateThread: Enter \n");
			
            if(!(threadID = Thread::Create(funcName)))
            {
                DEBUGL1("CDocument::CreateThread: --Unable to create the thread\n");
                return STATUS_FAILED;
            }
            else
            {
                m_ThreadID = threadID;
                DEBUGL8("CDocument::CreateThread: -Thread created successfully\n");

                if(threadID->Start(funcArgument)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::CreateThread: -Unable to start the Thread!!!\n");
                    return STATUS_FAILED;
                }
                else
                    DEBUGL8("CDocument::CreateThread: -Thread started successfully\n");

		if(threadID->Detach()!=STATUS_OK)
		{
			DEBUGL1("CDocument::CreateThread: -Unable to detach the Thread!!!\n");
			return STATUS_FAILED;
		}
		else
			DEBUGL8("CDocument::CreateThread: -Thread detached successfully\n");
            }
				
            DEBUGL4("CDocument::CreateThread: Exit \n");			
            return STATUS_OK;

        }



        void* StartCutThread(void *arg)
        {	

            DEBUGL4("CDocument::StartCutThread()-- Started \n");
            //Status retStatus;
            Status sdf;
            //Copy the passed instance of the invoking object into a local variable 
            CDocument *documentobj = (CDocument *)arg;

				//Copy the pages from static variable to a local variable
				std::vector<int>::iterator itr;
				std::vector<int> pages;
            for(itr=documentobj->m_CutVecofPages.begin();itr!=documentobj->m_CutVecofPages.end();itr++)
                pages.push_back(*itr);	

            documentobj->m_CutVecofPages.clear();

				//Bind to Shared memory used for writing the updted progress in it
				void *pCutMapAddr;
				if(!documentobj->m_prgShmid)
				{
                DEBUGL1(" CDocument::StartCutThread: -- Shared memory ref is NULL\n ");
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }
            else
            {
                int iShmPidSize = documentobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                documentobj->m_prgShmid->Map(pCutMapAddr);
                if(pCutMapAddr!=NULL)
                {
                    memset(pCutMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1(" CDocument::StartCutThread: -- Mapping Failed for Cut Progress Name\n");
                    documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                    return NULL;
                }
            }
            
        
				*((int*)pCutMapAddr) = 1;
				DocStatus st;
				DEBUGL8("CDocument::StartCutThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", documentobj->m_sessionID.c_str(), documentobj->m_BoxNumber.c_str(), documentobj->m_FolderName.c_str(), documentobj->m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = documentobj->m_BoxBasePath;
            boxnumber_org = documentobj->m_BoxNumber;
            folderName_org = documentobj->m_FolderName;
            docName_org = documentobj->m_DocumentName;

            CString cutpath = Utility::GetResourcePath(documentobj->m_BoxBasePath,documentobj->m_BoxNumber,documentobj->m_FolderName) + "/";
            //Initialize WorkSpace
            documentobj->WorkSpaceInit();

            if(documentobj->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartCutThread: Getting document status is failed\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }

            //check the status of the document it should be Editing.
            if(!(st == EDITING)) 
            {
                DEBUGL1("CDocument::StartCutThread: Document status is not EDITING\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }
            // Validate the page number by reading total page count of the document
            int total;
            if(documentobj->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::StartCutThread::Getting total pages failed\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);			
                return NULL;
            }

            std::vector<int>::iterator pIt;
            for(pIt=pages.begin();pIt !=pages.end();pIt++)
            {
                DEBUGL8("CDocument::StartCutThread: page number %d and total pages in the document are %d\n", (*pIt),total);
                if((*pIt)> total || (*pIt) < 0)
                {
                    DEBUGL1("CDocument::StartCutThread: Invalid page number %d and total pages in the document are %d\n", (*pIt),total);
                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                    return NULL;
                }
            }

            //Delete Clipboard documents,if any
            std::vector<CString> clipBoardvec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(clipBoardvec, CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartCutThread: Getting collection list failed");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }

            for(unsigned int i = 0;i < clipBoardvec.size(); i++) 
            {
                int last = clipBoardvec[i].rfind("/");
                int pre = clipBoardvec[i].rfind("/", last - 1);
                CString fulldocumentname = clipBoardvec[i].substr(pre + 1, last - (pre + 1));
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","documentName", documentname) != STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCutThread:GetProperty Failed\n");
                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                    return NULL;
                }

                DEBUGL8("CDocument::StartCutThread: vector<%s>, fullDocName<%s> and docName<%s>\n",clipBoardvec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

                //Check if the clipborad document is of the same user
                CString sid;		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","sessionID", sid) != STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCutThread:GetProperty Failed\n");
                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                    return NULL;
                }
                DEBUGL8("CDocument::StartCutThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),documentobj->m_sessionID.c_str());

                if(sid!= documentobj->m_sessionID)
                    continue;

                Status ds = ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true);	
                if(ds !=STATUS_OK) 
                {
                    DEBUGL1("CDocument::StartCutThread: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                    return NULL;
                }

            }

            //Progress initialization
            int curProg =0;
            int count =0;
            uint totalCnt = pages.size()+1;

            //Copy the document in Workspace to Clipboard
            Status ds;
            CString from = Utility::GetResourcePath(documentobj->m_BoxBasePath,documentobj->m_BoxNumber,documentobj->m_FolderName,documentobj->m_DocumentName) + "/";			 

            //CString to = CBoxDocument::HOST;
            CString clipbrdDocName = CLIPBOARD_PATH + documentobj->m_DocumentName +"/";
            CString to = clipbrdDocName;
            ds = ci::operatingenvironment::Folder::CopyDir(from,to);
            if(ds == STATUS_DISK_FULL)
            {
                DEBUGL1("CDocument::StartCutThread:CopyResource returned DISKFULL Error\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                DEBUGL8("CDocument::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullDoc_" + documentobj->m_sessionID) != STATUS_OK)
                    DEBUGL2(" Cdocument::StartCutThread: Unable to create the file\n");
                documentobj->m_prgShmid = NULL;
                return NULL;
            } 
            else if( ds != STATUS_OK)
            {
                DEBUGL1("CDocument::StartCutThread: Copying document to ClipBoard failed\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }
            count = 1;				
            curProg = (int)((((float)count++)/((float)totalCnt))*100);
            if(curProg!=100)
            {
                *((int*)pCutMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCutThread::Current Progress<%d>\n",curProg);
            }	

            std::vector < int > pagesToDelete;
            CString curBoxBasePath(documentobj->m_BoxBasePath);
            CString curBoxNumber(documentobj->m_BoxNumber);
            CString curFolderName(documentobj->m_FolderName);
            CString curDocumentName(documentobj->m_DocumentName);

            CString clipPath = CLIPBOARD_PATH;
            //size_t pos = clipPath.length();
            clipPath = clipPath;//.substr(1,pos-2);
            documentobj->m_BoxBasePath=clipPath;
            documentobj->m_BoxNumber="";
            documentobj->m_FolderName="";
            CString tmpName = clipbrdDocName;
            size_t slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1);
            DEBUGL8("CDocument::StartCutThread: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());
            slPos = tmpName.rfind("/");
            documentobj->m_DocumentName= tmpName.substr(slPos + 1);
            //Have only the pages that are to be cut and delete the other pages in the clipboard
            for(int pageno=1;pageno<=total;pageno++)
            {	
                pIt = std::find(pages.begin(),pages.end(),pageno);
                if(pIt==pages.end())
                {   
                    DEBUGL8("CDocument::StartCutThread::Deleting page <%d> from ClipBoard Doc\n",pageno);
                    pagesToDelete.push_back(pageno);																
                }	
                else
                {
                    DEBUGL8("CDocument::StartCutThread::Page<%d> restored",pageno);
                }

            }

            documentobj->m_BoxBasePath=curBoxBasePath;
            documentobj->m_BoxNumber=curBoxNumber;
            documentobj->m_FolderName=curFolderName;
            documentobj->m_DocumentName=curDocumentName;		

            // Get the page realted folders present in the Documents
            std::vector<CString> vec;
            vector<CString>::iterator theIterator;
            CString strpageno;
            std::ostringstream str;
            CString path("");

            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << 1;
            strpageno= str.str();

            if(Utility::GetCollectionList(vec, from)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartCutThread: Getting collection list failed");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }

            bool IsThumbDataAvail = false;
            bool IsSubsmplDataAvail = false;

            try
            {
                for(theIterator=vec.begin();theIterator !=vec.end();theIterator++)
                {
                    int last = (*theIterator).rfind("/");
                    int pre = (*theIterator).rfind("/", last - 1);
                    CString fulldocumentname = (*theIterator).substr(pre + 1, last - (pre + 1));		
                    DEBUGL8("CDocument::StartCutThread: Iterator String val<%s>,DocName<%s>\n",(*theIterator).c_str(),fulldocumentname.c_str());	 
                    PageRef page;					
                    if(documentobj->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::StartCutThread: Getting page 1 failed\n");
                        documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                        return NULL;
                    }

                    if(fulldocumentname.compare("Image")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::Page object is NULL\n");
                            return NULL;
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);				
                        path=from+"Image/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsImagedataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCutThread: Setting IsImagedataPresent property to %s failed because Disk is Full\n", clipbrdDocName.c_str());
                                    DEBUGL8("CDocument::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                                    if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullDoc_" + documentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2(" Cdocument::StartCutThread: Unable to create the file\n");
                                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                    documentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCutThread: Setting IsImagedataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                                return NULL;
                            }
                        }
                    }
                    else if(fulldocumentname.compare("Subsampling")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::Page object is NULL\n");
                            return NULL;
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);				
                        path=from+"Subsampling/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsSubsamplingdataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCutThread: Setting IsSubsamplingdataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());
                                    DEBUGL8("CDocument::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                                    if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullDoc_" + documentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2("CDocument::StartCutThread: Unable to create the file\n");
                                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                                    documentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCutThread: Setting IsSubsamplingdataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                                return NULL;
                            }
                            IsSubsmplDataAvail = true;
                        }
                    }
                    else if(fulldocumentname.compare("Thumbnail")==0)	
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::Page object is NULL\n");
                            return NULL; 
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        path=from+"Thumbnail/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsThumbnaildataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCutThread: Setting IsThumbnaildataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());
                                    DEBUGL8("CDocument::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                                    if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullDoc_" + documentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2("CDocument::StartCutThread: Unable to create the file\n");
                                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                                    documentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCutThread: Setting IsThumbnaildataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                                return NULL;
                            }
                            IsThumbDataAvail = true;
                        }
                    }
                }
            }

            catch(exception& e)
            {
                DEBUGL1("CDocument::StartCutThread:Exception caught:(%s)\n",e.what());
                return NULL;
				}	

				curBoxBasePath = documentobj->m_BoxBasePath;
				curBoxNumber = documentobj->m_BoxNumber;
				curFolderName = documentobj->m_FolderName;
            curDocumentName = documentobj->m_DocumentName; 

            clipPath = CLIPBOARD_PATH;
            documentobj->m_BoxBasePath = clipPath;
            documentobj->m_BoxNumber = "";
            documentobj->m_FolderName = "";
            tmpName = clipbrdDocName;
            slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1); 
            DEBUGL8("CDocument::StartCutThread: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());
            slPos = tmpName.rfind("/");
            documentobj->m_DocumentName= tmpName.substr(slPos + 1);

            if(documentobj->DeletePages(pagesToDelete, IsThumbDataAvail, IsSubsmplDataAvail) != STATUS_OK)
            {
                DEBUGL8("CDocument::StartCutThread::Deleting pages from ClipBoard failed\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }

            documentobj->m_BoxBasePath=curBoxBasePath;
            documentobj->m_BoxNumber=curBoxNumber;
            documentobj->m_FolderName=curFolderName;
            documentobj->m_DocumentName=curDocumentName;     
            if(documentobj->DeletePages(pages, IsThumbDataAvail, IsSubsmplDataAvail) != STATUS_OK)
            {
                DEBUGL8("CDocument::StartCutThread::Deleting pages from Workspace failed\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);
                return NULL;
            }

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath",documentobj->m_BoxBasePath));
            PropertyMap.insert(pair::value_type("srcBoxNumber",documentobj->m_BoxNumber));
            PropertyMap.insert(pair::value_type("srcFolderName",documentobj->m_FolderName));
            PropertyMap.insert(pair::value_type("srcDocumentName",documentobj->m_DocumentName));
            PropertyMap.insert(pair::value_type("sessionID",documentobj->m_sessionID));						
            //CString cPath = CLIPBOARD_PATH + clipbrdDocName + "/";
            sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartCutThread: SetProperties failed because Disk is Full\n");
                    DEBUGL8("CDocument::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                    if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullDoc_" + documentobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartCutThread: Unable to create the file\n");
                    documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                    documentobj->m_prgShmid = NULL;
                    return NULL;
                }
                DEBUGL1("CDocument::StartCutThread: SetProperties\n");
                documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                documentobj->ErrorFileCreation(documentobj->m_CutErrfile,documentobj->m_prgShmid);				
                return NULL;
            }		

            //revert back to original
            documentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	

            *((int*)pCutMapAddr) = PROGRESS_COMPLETED;				
            documentobj->m_prgShmid = NULL;
            DEBUGL8("CDocument::StartCutThread::Current Progress<%d>\n",curProg);					
            DEBUGL4("CDocument::StartCutThread: Exit\n");			
            return NULL;	
        }


        void* StartCopyThread(void *arg)
        {
            DEBUGL4("CDocument::StartCopyThread()-- Started \n");
            //Status retStatus;
            Status sdf;
            //Copy the passed instance of the invoking object into a local variable 
            CDocument *cpydocumentobj = (CDocument *)arg;
            //Copy the pages from static variable to a local variable				
            std::vector<int>::iterator itr;
            std::vector<int> pages;
            for(itr=cpydocumentobj->m_CopyVecofPages.begin();itr!=cpydocumentobj->m_CopyVecofPages.end();itr++)
                pages.push_back(*itr);	

            cpydocumentobj->m_CopyVecofPages.clear();
            //Create Shared memory used for writing the updated progress in it
            void *pCopyMapAddr;
            if(!cpydocumentobj->m_prgShmid)
            {
                DEBUGL1("\n CDocument::StartCopyThread: -- Shared memory ref for copy is NULL\n ");
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }
            else
            {
                int iShmPidSize = cpydocumentobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                cpydocumentobj->m_prgShmid->Map(pCopyMapAddr);
                if(pCopyMapAddr!=NULL)
                {
                    memset(pCopyMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("\n CDocument::StartCopyThread: -- Mapping Failed for Cut Progress Name\n");
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    //m_CopyFlag = FLAG_RESET;
                    return NULL;
                }
            }

            //Set the Flage to 0 so the while() loop in the CreateCopyThread would end.
            //m_CopyFlag = FLAG_RESET;
            DEBUGL8("\nCDocument::StartCopyThread: m_CopyFlag reset\n ");
            //set the initial value of Copy Document progress as 1% . The Start Copy 
            //thread will update it as and when the operation progresses 
            *((int*)pCopyMapAddr) = 1;
            DEBUGL8("CDocument::StartCopyThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", cpydocumentobj->m_sessionID.c_str(), cpydocumentobj->m_BoxNumber.c_str(), cpydocumentobj->m_FolderName.c_str(), cpydocumentobj->m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = cpydocumentobj->m_BoxBasePath;
            boxnumber_org = cpydocumentobj->m_BoxNumber;
            folderName_org = cpydocumentobj->m_FolderName;
            docName_org = cpydocumentobj->m_DocumentName;
            CString copypath = Utility::GetResourcePath(cpydocumentobj->m_BoxBasePath,cpydocumentobj->m_BoxNumber,cpydocumentobj->m_FolderName);	
            //Progress initialization
            int curProg =0;
            int count =0;
            uint totalCnt = 5;


            // Now pre-requisites for Copying a page are validated.
            // Hence Create a clipboard from workspace and copy the page from the workspace to clipboard.
            CString from(""); 
            /*Read WorkspaceDocName from documentproperties.xml*/
            CString WorkspaceDocName("");
            if(proputils::GetProperty(cpydocumentobj->m_BoxBasePath, cpydocumentobj->m_BoxNumber, cpydocumentobj->m_FolderName, cpydocumentobj->m_DocumentName, "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartCopyThread: GetProperty of WorkspaceDocName failed\n");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }


            // check current status
            DocStatus st;
            CString newDocName;	 
            if(cpydocumentobj->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartCopyThread::GetStatus failed\n");						
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;;
            }
            
            //Get sessionID
            CString sessID = "";
            if(proputils::GetProperty(cpydocumentobj->m_BoxBasePath, cpydocumentobj->m_BoxNumber, cpydocumentobj->m_FolderName, cpydocumentobj->m_DocumentName, "", "sessionID", sessID) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartCopyThread: GetProperty of sessionID failed\n");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }
            
            DEBUGL8("CDocument::StartCopyThread:sessID = %s m_sessionID = %s\n",sessID.c_str(),cpydocumentobj->m_sessionID.c_str());             

            if(st != EDITING) 
	    {
                newDocName = cpydocumentobj->m_sessionID + "_" + WorkspaceDocName;
                from = Utility::GetResourcePath(cpydocumentobj->m_BoxBasePath,cpydocumentobj->m_BoxNumber,cpydocumentobj->m_FolderName,cpydocumentobj->m_DocumentName) + "/";
            }
            else
            {
                if(st == EDITING && sessID != cpydocumentobj->m_sessionID)
                {
                    DEBUGL1("CDocument::StartCopyThread:Document<%s> is being edited.!\n",docName_org.c_str());
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    if(Utility::CreateUniqueFile(copypath, ".copypage2ndsession_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" Cdocument::StartCopyThread: Unable to create the file\n");
                    cpydocumentobj->m_prgShmid = NULL;
                    return NULL;
                }
                DEBUGL8("CDocument::StartCopyThread:Before Updation\nm_BoxBasePath<%s>\nm_BoxNumber<%s>\nm_FolderName<%s>\nm_DocumentName<%s>\n",cpydocumentobj->m_BoxBasePath.c_str(),cpydocumentobj->m_BoxNumber.c_str(),cpydocumentobj->m_FolderName.c_str(),cpydocumentobj->m_DocumentName.c_str());						
                newDocName = cpydocumentobj->m_sessionID + "_" + WorkspaceDocName;
                CString path=WORKSPACE_PATH;
                cpydocumentobj->m_BoxBasePath = path;//.substr(1,path.length()-1);
                cpydocumentobj->m_BoxNumber="";
                cpydocumentobj->m_FolderName	="";
                cpydocumentobj->m_DocumentName = newDocName;
                DEBUGL8("CDocument::StartCopyThread:After Updation\nm_BoxBasePath<%s>\nm_BoxNumber<%s>\nm_FolderName<%s>\nnewDocName<%s>\n",cpydocumentobj->m_BoxBasePath.c_str(),cpydocumentobj->m_BoxNumber.c_str(),cpydocumentobj->m_FolderName.c_str(),newDocName.c_str());
                //Point to the Workspace document if editing								
                from = Utility::GetResourcePath(cpydocumentobj->m_BoxBasePath,cpydocumentobj->m_BoxNumber,cpydocumentobj->m_FolderName,cpydocumentobj->m_DocumentName) + "/";							
            }		

            // Validate the page number by reading total page count of the document
            int total;
            if(cpydocumentobj->GetTotalPage(total)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::StartCopyThread::Getting total pages failed\n");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }

            std::vector<int>::iterator pIt;
            for(pIt=pages.begin();pIt !=pages.end();pIt++)
            {
                DEBUGL8("CDocument::StartCopyThread: page number %d and total pages in the document are %d\n", (*pIt),total);
                if((*pIt)> total || (*pIt) < 0)
                {
                    DEBUGL1("CDocument::StartCopyThread: Invalid page number %d and total pages in the document are %d\n", (*pIt),total);
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }
            }

            //Delete Clipboard documents,if any
            std::vector<CString> clipBoardvec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(clipBoardvec, CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartCopyThread: Getting collection list failed");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }

            //Count 1
            count++;
            curProg = (int)((((float)count)/((float)totalCnt))*100);
            if(curProg!=100)
            {
                *((int*)pCopyMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCopyThread::Current Progress<%d>\n",curProg);
            }	

            for(unsigned int i = 0;i < clipBoardvec.size(); i++) 
            {
                int last = clipBoardvec[i].rfind("/");
                int pre = clipBoardvec[i].rfind("/", last - 1);
                CString fulldocumentname = clipBoardvec[i].substr(pre + 1, last - (pre + 1));
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","documentName", documentname) != STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCopyThread:GetProperty Failed\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }

                DEBUGL8("CDocument::StartCopyThread: vector<%s>, fullDocName<%s> and docName<%s>\n",clipBoardvec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

                //Check if the clipborad document is of the same user
                CString sid;		
                if(proputils::GetProperty(CLIPBOARD_PATH,"","",fulldocumentname,"","sessionID", sid) != STATUS_OK)
                {
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }
                DEBUGL8("CDocument::StartCopyThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(), cpydocumentobj->m_sessionID.c_str());

                if(sid!= cpydocumentobj->m_sessionID)
                    continue;

                if(ci::operatingenvironment::Folder::Remove(resourceKey,true)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCopyThread: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }

            }


            //Copy the document in Workspace to Clipboard
            Status ds;
            CString clipbrdDocName = CLIPBOARD_PATH + newDocName +"/";
            CString to = clipbrdDocName;
            ds = ci::operatingenvironment::Folder::CopyDir(from,to);
            if(ds!=STATUS_OK)
            {
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartCopyThread:CopyResource returned DISKFULL Error\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    if(Utility::CreateUniqueFile(copypath, ".copyDiskFullDoc_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" Cdocument::StartCopyThread: Unable to create the file\n");
                    cpydocumentobj->m_prgShmid = NULL;
                    return NULL;
                }
                else
                {
                    DEBUGL1("CDocument::StartCopyThread: Copying document to ClipBoard failed\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }
            }

            //Count 2
            count++;
            curProg = (int)((((float)count)/((float)totalCnt))*100);
            if(curProg!=100)
            {
                *((int*)pCopyMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCopyThread::Current Progress<%d>\n",curProg);
            }	


            std::vector < int > pagesToDelete;
            //Have only the pages that are to be copied and delete the other pages in the Clipboard
            for(int pageno=1;pageno<=total;pageno++)
            {	
                pIt = std::find(pages.begin(),pages.end(),pageno);
                if(pIt==pages.end())
                {
                    DEBUGL8("CDocument::StartCopyThread::Page<%d> in Clipborad will be deleted",pageno);
                    pagesToDelete.push_back(pageno);																
                }	
                else
                {
                    DEBUGL8("CDocument::StartCopyThread::Page<%d> restored",pageno);
                }			
            }

            CString curBoxBasePath(cpydocumentobj->m_BoxBasePath);
            CString curBoxNumber(cpydocumentobj->m_BoxNumber);
            CString curFolderName(cpydocumentobj->m_FolderName);
            CString curDocumentName(cpydocumentobj->m_DocumentName);

            CString clipPath = CLIPBOARD_PATH;
            //size_t pos = clipPath.length();
            clipPath = clipPath;//.substr(1,pos-2);
            cpydocumentobj->m_BoxBasePath=clipPath;
            cpydocumentobj->m_BoxNumber="";
            cpydocumentobj->m_FolderName="";
            CString tmpName = clipbrdDocName;
            size_t slPos = tmpName.length();
            tmpName = tmpName.substr(0,slPos-1);
            DEBUGL8("CDocument::StartCopyThread: tmpName<%s>,ClipboardDocName<%s>\n",tmpName.c_str(),clipbrdDocName.c_str());
            slPos = tmpName.rfind("/");
            cpydocumentobj->m_DocumentName= tmpName.substr(slPos + 1);
            if(st != EDITING) 
            {			
                if(cpydocumentobj->ReCreate()!=STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCopyThread:ReCreate failed\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }									
            }

            //Count 3
            count++;
            curProg = (int)((((float)count)/((float)totalCnt))*100);
            if(curProg!=100)
            {
                *((int*)pCopyMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCopyThread::Current Progress<%d>\n",curProg);
            }	

            if (cpydocumentobj->DeletePage(pagesToDelete)!=STATUS_OK)
            {
                DEBUGL1("CDocument::StartCopyThread:DeletePages failed\n");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }									
            if(st != EDITING) 
            {			
                if(cpydocumentobj->EndCreating()!=STATUS_OK)
                {
                    DEBUGL1("CDocument::StartCopyThread:EndCreating failed\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                    cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                    return NULL;
                }								
            }	

            cpydocumentobj->m_BoxBasePath=curBoxBasePath;
            cpydocumentobj->m_BoxNumber=curBoxNumber;
            cpydocumentobj->m_FolderName=curFolderName;
            cpydocumentobj->m_DocumentName=curDocumentName;		

            //Count 4
            count++;
            curProg = (int)((((float)count)/((float)totalCnt))*100);
            if(curProg!=100)
            {
                *((int*)pCopyMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCopyThread::Current Progress<%d>\n",curProg);
            }	


            // Get the page realted folders present in the Documents
            std::vector<CString> vec;
            vector<CString>::iterator theIterator;
            CString strpageno;
            std::ostringstream str;
            CString path("");

            // convert int page no to str page no
            str << std::setfill('0') << std::setw(3) << std::hex << 1;
            strpageno= str.str();

            if(Utility::GetCollectionList(vec, from)!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartCopyThread: Getting collection list failed");
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                return NULL;
            }

            try
            {
                for(theIterator=vec.begin();theIterator !=vec.end();theIterator++)
                {
                    int last = (*theIterator).rfind("/");
                    int pre = (*theIterator).rfind("/", last - 1);
                    CString fulldocumentname = (*theIterator).substr(pre + 1, last - (pre + 1));		
                    DEBUGL8("CDocument::StartCopyThread: Iterator String val<%s>,DocName<%s>\n",(*theIterator).c_str(),fulldocumentname.c_str());	 
                    PageRef page;					
                    if(cpydocumentobj->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CDocument::StartCopyThread: Getting page 1 failed\n");
                        cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                        cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                        return NULL;
                    }

                    if(fulldocumentname.compare("Image")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::StartCopyThread:Page object is NULL\n");
                            return NULL;         
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);				
                        path=from+"Image/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsImagedataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCopyThread: Setting IsImagedataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());
                                    DEBUGL8("Cdocument::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                                    if(Utility::CreateUniqueFile(copypath, ".copyDiskFullDoc_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2(" Cdocument::StartCopyThread: Unable to create the file\n");
                                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                    cpydocumentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCopyThread: Setting IsImagedataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                                return NULL;
                            }
                        }
                    }
                    else if(fulldocumentname.compare("Subsampling")==0)
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::StartCopyThread:Page object is NULL\n");
                            return NULL;          
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);				
                        path=from+"Subsampling/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.		
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsSubsamplingdataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCopyThread: Setting IsSubsamplingdataPresent property to %s is failed because Disk is Full\n", clipbrdDocName.c_str());
                                    DEBUGL8("Cdocument::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                                    if(Utility::CreateUniqueFile(copypath, ".copyDiskFullDoc_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2(" CDocument::StartCopyThread: Unable to create the file\n");
                                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                    cpydocumentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCopyThread: Setting IsSubsamplingdataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                                return NULL;
                            }

                        }
                    }
                    else if(fulldocumentname.compare("Thumbnail")==0)	
                    {
                        if(!page)
                        {
                            DEBUGL1("CDocument::StartCopyThread:Page object is NULL\n");
                            return NULL;         
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);
                        path=from+"Thumbnail/"+strpageno+ext;
                        if(Utility::ResourceExist(path)==false)
                            continue;
                        else		
                        {
                            // Update Image/thumbnail/subsampling folder presence as properties and return OK.
                            sdf = proputils::SetProperty("","","",clipbrdDocName,"","IsThumbnaildataPresent","true");
                            if(sdf != STATUS_OK) 
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CDocument::StartCopyThread: Setting IsThumbnaildataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                    DEBUGL8("Cdocument::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                                    if(Utility::CreateUniqueFile(copypath, ".copyDiskFullDoc_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                                        DEBUGL2(" CDocument::StartCopyThread: Unable to create the file\n");
                                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                                    cpydocumentobj->m_prgShmid = NULL;
                                    return NULL;
                                }
                                DEBUGL1("CDocument::StartCopyThread: Setting IsThumbnaildataPresent property to %s is failed\n", clipbrdDocName.c_str());
                                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);
                                return NULL;
                            }
                        }
                    }
                }
            }
            catch(exception& e)
            {
                DEBUGL1("CDocument::StartCopyThread::Exception caught:(%s)\n",e.what());
                return NULL;
            }
            //Count 5
            count++;
            curProg = (int)((((float)count)/((float)totalCnt))*100);
            if(curProg != 100)
            {
                *((int*)pCopyMapAddr) = curProg;				
                DEBUGL8("CDocument::StartCopyThread::Current Progress<%d>\n",curProg);
            }	

            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath",cpydocumentobj->m_BoxBasePath));
            PropertyMap.insert(pair::value_type("srcBoxNumber",cpydocumentobj->m_BoxNumber));
            PropertyMap.insert(pair::value_type("srcFolderName",cpydocumentobj->m_FolderName));
            PropertyMap.insert(pair::value_type("srcDocumentName",cpydocumentobj->m_DocumentName));
            PropertyMap.insert(pair::value_type("sessionID",cpydocumentobj->m_sessionID));						
            //CString cPath = CLIPBOARD_PATH + clipbrdDocName + "/";
            sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf != STATUS_DISK_FULL)
                {
                    DEBUGL8("Cdocument::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                    if(Utility::CreateUniqueFile(copypath, ".copyDiskFullDoc_" + cpydocumentobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" CDocument::StartCopyThread: Unable to create the file\n");
                    cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    cpydocumentobj->m_prgShmid = NULL;
                    return NULL;
                }
                cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                cpydocumentobj->ErrorFileCreation(cpydocumentobj->m_CopyErrfile,cpydocumentobj->m_prgShmid);				
                return NULL;
            }		

            //revert back to original
            cpydocumentobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	

            *((int*)pCopyMapAddr) = PROGRESS_COMPLETED;				
            cpydocumentobj->m_prgShmid = NULL;
            DEBUGL4("CDocument::StartCopyThread: Exit\n");	
            return NULL;			
        }


        void* StartSaveThread(void * arg)
        {
            DEBUGL4("CDocument::StartSaveThread: Started\n");

            Status sdf;
            //Status retStatus;
            //Copy the passed instance of the invoking object into a local variable 
            CDocument *savedocobj = (CDocument*)arg;
            //Create Shared memory used for writing the updated progress in it
            void *pSaveMapAddr;
            if(!savedocobj->m_prgShmid)
            {
                DEBUGL1("\n CDocument::StartSaveThread: -- Failed to Create Shared Memory for Save Progress Name \n ");
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);
                return NULL;
            }
            else
            {
                int iShmPidSize = savedocobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                savedocobj->m_prgShmid->Map(pSaveMapAddr);
                if(pSaveMapAddr!=NULL)
                {
                    memset(pSaveMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("\n CDocument::StartSaveThread: -- Mapping Failed for Save Progress Name\n");
                    savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);
                    return NULL;
                }
            }

            //Create a temporary save opertion in respective box/folder. This indicates that the save is in progress.
            CString savepath;
            if(savedocobj->m_FolderName.empty())
                savepath = Utility::GetResourcePath(savedocobj->m_BoxBasePath, savedocobj->m_BoxNumber);
            else
                savepath = Utility::GetResourcePath(savedocobj->m_BoxBasePath, savedocobj->m_BoxNumber, savedocobj->m_FolderName);

            DEBUGL8(" CDocument::StartSaveThread::savepath = (%s)\n", savepath.c_str());

            if(Utility::CreateUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                DEBUGL2(" CDocument::StartSaveThread: Unable to create the file\n");


            //set the initial value of Save Document progress as 1% . The Start Save 
            //thread will update it as and when the operation progresses 

            *((int*)pSaveMapAddr) = 1;

            DEBUGL8("CDocument::StartSaveThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", savedocobj->m_sessionID.c_str(), savedocobj->m_BoxNumber.c_str(), savedocobj->m_FolderName.c_str(), savedocobj->m_DocumentName.c_str());
 
            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = savedocobj->m_BoxBasePath;
            boxnumber_org = savedocobj->m_BoxNumber;
            folderName_org = savedocobj->m_FolderName;
            docName_org = savedocobj->m_DocumentName;
            CString savpath = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName);

            //Initialize WorkSpace
            savedocobj->WorkSpaceInit();

            // check current status
            DocStatus st;
            if(savedocobj->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartSaveThread::GetStatus failed\n");						
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            if(st != EDITING) 
            {
                DEBUGL1("CDocument::StartSaveThread: Document is NOT EDITING\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            //Workspace Doc path
            CString from = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName) + "/";
            CString curBoxBasePath(savedocobj->m_BoxBasePath);
            CString curBoxNumber(savedocobj->m_BoxNumber);
            CString curFolderName(savedocobj->m_FolderName);
            CString curDocumentName(savedocobj->m_DocumentName);

            //Original Document Path
            CString resourceKey = from;
            CString val;
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxBasePath", val) != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            savedocobj->m_BoxBasePath = val;
            val.clear();
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcBoxNumber", val) != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            savedocobj->m_BoxNumber = val;
            val.clear();	
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcFolderName",val ) != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            savedocobj->m_FolderName = val;
            val.clear();		
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcDocumentName",val ) != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            savedocobj->m_DocumentName = val;
            val.clear();	

            CString to = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName) + "/";
            int count=1;
            int numRes = 1;
            //BoxDocument copies workspace Document (WD) to the Box/Folder of original Document (OD). Add suffix to the folder name of WD. 
            //The status of WD should be creating.
            //OD : folder name=original status=editing
            //WD : folder name=original_suffix status=creating					
            CString wtoos = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName) + "_original_suffix/" ;
            Status status=ci::operatingenvironment::Folder::CopyDir(resourceKey,wtoos);						
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartSaveThread: Moving document from Workspace failed\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            status = ci::operatingenvironment::File::MoveFile(wtoos + "/editing.sts", wtoos + "/creating.sts");
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::StartSaveThread: Failed to move to deleting\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            //BoxDocument changes the folder name of OD.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original_suffix status=creating
            CString origDoc = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName) + "/";
            CString otoos =  Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName) + "_original_suffix_2";
            status=ci::operatingenvironment::Folder::MoveDir(origDoc, otoos);	
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartSaveThread: Moving document from Workspace failed\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            //BoxDocument changes the folder name of WD to original folder name.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original status=creating
            CString originalDoc = Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName);
            status=ci::operatingenvironment::Folder::MoveDir(wtoos,originalDoc);	
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartSaveThread: Moving document from Workspace failed\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            //BoxDocument changes the status of WD to ready.
            //OD : folder name=original_suffix_2 status=editing
            //WD : folder name=original status=ready
            status = ci::operatingenvironment::File::MoveFile(originalDoc + "/creating.sts", originalDoc + "/ready.sts");
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::StartSaveThread: Failed to move to deleting\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            int curProg = (int)((((float)count++)/((float)numRes))*100);
            if(curProg!=100)
            {
                *((int*)pSaveMapAddr) = curProg;				
                DEBUGL8("CDocument::StartSaveThread::Current Progress<%d>\n",curProg);
            }

            //BoxDocument deletes OD.
            //OD : folder name=original_suffix_2 status=deleting. Instead of moving it, deleting the folder.
            //WD : folder name=original status=ready
            status = ci::operatingenvironment::Folder::Remove(otoos, true);
            if(status != STATUS_OK)
            { 
                DEBUGL1("CDocument::StartSaveThread: Failed to move to deleting\n");
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                savedocobj->ErrorFileCreation(savedocobj->m_SaveAsErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            // Dont delete clipboard documents after Save Change - done for Fixing FR-545	
            //Remove the properties
            resourceKey= Utility::GetResourcePath(savedocobj->m_BoxBasePath,savedocobj->m_BoxNumber,savedocobj->m_FolderName,savedocobj->m_DocumentName)+"/";

            savedocobj->SetWebDAVProperty("srcBoxBasePath","");
            savedocobj->SetWebDAVProperty("srcBoxNumber","");
            savedocobj->SetWebDAVProperty("srcFolderName","");	
            savedocobj->SetWebDAVProperty("srcDocumentName","");		
            savedocobj->SetWebDAVProperty("IsImagedataPresent","");		
            savedocobj->SetWebDAVProperty("IsSubsamplingdataPresent","");		
            savedocobj->SetWebDAVProperty("IsThumbnaildataPresent","");		

            if(savedocobj->SetWebDAVProperty("sessionID", "") != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }
            if(savedocobj->SetWebDAVProperty("cutDocument", "") != STATUS_OK)
            {
                savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok
                savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                return NULL;
            }

            //Update ModifiedDate
            savedocobj->SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());
            savedocobj->SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());

            //To Fix FR_5121. Change the clipboard document properties srcBoxBasePath to /storage/box/EFiling
            //and set srcDocument name to orginal document name.
            std::map<CString, CString> PropertyMap;
            typedef  std::map<CString, CString> pair;		
            PropertyMap.clear();						
            CString clipbrdDocName = CLIPBOARD_PATH + curDocumentName +"/";
            if(Utility::ResourceExist(clipbrdDocName))
            {		
                DEBUGL8("CDocument::StartSaveThread: clipbrdDocName (%s) m_BoxBasePath (%s) m_DocumentName(%s)\n", 
                        clipbrdDocName.c_str(), savedocobj->m_BoxBasePath.c_str(), savedocobj->m_DocumentName.c_str());
                PropertyMap.insert(pair::value_type("srcBoxBasePath",savedocobj->m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",savedocobj->m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",savedocobj->m_FolderName));
                PropertyMap.insert(pair::value_type("srcDocumentName",savedocobj->m_DocumentName));

                sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::StartSaveThread: SetProperties failed because Disk is Full\n");
                        DEBUGL8("CDocument::StartSaveThread::savepath = (%s)\n", savpath.c_str());
                        //revert back to original
                        savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                        if(Utility::CreateUniqueFile(savpath, ".saveDiskFullDoc_" + savedocobj->m_sessionID) != STATUS_OK)
                            DEBUGL2("CDocument::StartdSaveThread: Unable to create the file\n");
                        if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                            DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");
                        savedocobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CDocument::StartSaveThread: SetProperties failed\n");
                    //revert back to original
                    savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);			
                    //Create a file indicating the Status to be not Status Ok
                    //savedocobj->ErrorFileCreation(savedocobj->m_SaveErrfile,savedocobj->m_prgShmid);

                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

                    return NULL;
                }		
            }
            //revert back to original
            savedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

            if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + savedocobj->m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::StartSaveThread: Unable to create the file\n");

            *((int*)pSaveMapAddr) = PROGRESS_COMPLETED;				
            savedocobj->m_prgShmid = NULL;
            DEBUGL8("CDocument::StartSaveThread::Current Progress<%d>\n",curProg);
            DEBUGL4("CDocument::StartSaveThread: Exit\n");		
            return NULL;		
        }


        void* StartSaveAsThread(void * arg)
        {
            DEBUGL4("CDocument::StartSaveAsThread:-- Started\n");
            //Status retStatus;
            Status sdf;
            //Copy the passed instance of the invoking object into a local variable 
            CDocument *saveAsdocobj = (CDocument*)arg;
            //Copy the inputs from static variable into a local varibale 
            CString newname = saveAsdocobj->m_SaveAsNewName;
            saveAsdocobj->m_SaveAsNewName ="";
            CString resourcebasepath = saveAsdocobj->m_SaveAsResourceBasePath;
            saveAsdocobj->m_SaveAsResourceBasePath="";

            //Create Shared memory used for writing the updated progress in it
            void *pSaveAsMapAddr;
            if(!saveAsdocobj->m_prgShmid)
            {
                DEBUGL1("\n CDocument::StartSaveAsThread: -- Failed to Create Shared Memory for SaveAs Progress Name \n ");
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);
                return NULL;
            }
            else
            {
                int iShmPidSize = saveAsdocobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                saveAsdocobj->m_prgShmid->Map(pSaveAsMapAddr);
                if(pSaveAsMapAddr!=NULL)
                {
                    memset(pSaveAsMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("\n CDocument::StartSaveAsThread: -- Mapping Failed for SaveAs Progress Name\n");
                    saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);		
                    return NULL;
                }
            }	

            //Create a temporary save opertion in respective box/folder. This indicates that the save is in progress.
            CString savepath;
            if(saveAsdocobj->m_FolderName.empty())
                savepath = Utility::GetResourcePath(saveAsdocobj->m_BoxBasePath, saveAsdocobj->m_BoxNumber);
            else
                savepath = Utility::GetResourcePath(saveAsdocobj->m_BoxBasePath, saveAsdocobj->m_BoxNumber, saveAsdocobj->m_FolderName);

            DEBUGL8(" CDocument::StartSaveAsThread::savepath = (%s)\n", savepath.c_str());

            if(Utility::CreateUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

            //set the initial value of SaveAs Document progress as 1% . The Start SaveAs 
            //thread will update it as and when the operation progresses 
            *((int*)pSaveAsMapAddr) = 1;	

            DEBUGL8("CDocument::StartSaveAsThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", saveAsdocobj->m_sessionID.c_str(), saveAsdocobj->m_BoxNumber.c_str(), saveAsdocobj->m_FolderName.c_str(), saveAsdocobj->m_DocumentName.c_str());

            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = saveAsdocobj->m_BoxBasePath;
            boxnumber_org = saveAsdocobj->m_BoxNumber;
            folderName_org = saveAsdocobj->m_FolderName;
            docName_org = saveAsdocobj->m_DocumentName;
            CString saveaspath = Utility::GetResourcePath( saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName);

            //Initialize WorkSpace
            saveAsdocobj->WorkSpaceInit();

            // check current status
            DocStatus st;
            if(saveAsdocobj->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartSaveAsThread::GetStatus failed\n");						
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok		
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);		

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }
            if(st != EDITING) 
            {
                DEBUGL1("CDocument::StartSaveAsThread: Document is NOT EDITING\n");
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok		
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }

            //Workspace Doc path
            CString resourceKey = Utility::GetResourcePath( saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName) + "/";
            CString curBoxBasePath( saveAsdocobj->m_BoxBasePath);
            CString curBoxNumber(saveAsdocobj->m_BoxNumber);
            CString curFolderName(saveAsdocobj->m_FolderName);
            CString curDocumentName(saveAsdocobj->m_DocumentName);

            //Properties set on Workspace Doc
            CString val("");
            if(proputils::GetProperty(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName,"","srcBoxBasePath", val) != STATUS_OK)
            {
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok						
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            saveAsdocobj->m_BoxBasePath = val;
            val.clear();
            if(proputils::GetProperty(curBoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName,"","srcBoxNumber", val) != STATUS_OK)
            {
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok					
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            saveAsdocobj->m_BoxNumber = val;
            val.clear();	
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName,"","srcFolderName",val ) != STATUS_OK)
            {
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok					
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            saveAsdocobj->m_FolderName = val;
            val.clear();		
            if(proputils::GetProperty(curBoxBasePath,curBoxNumber,curFolderName,saveAsdocobj->m_DocumentName,"","srcDocumentName",val ) != STATUS_OK)
            {
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok				
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            saveAsdocobj->m_DocumentName = val;
            val.clear();	

            //Change the original document state to READY
            if(saveAsdocobj->ChangeStatus(READY) != STATUS_OK) 
            {
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                //Create a file indicating the Status to be not Status Ok		
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            //Remove the properties
            std::map<CString, CString> PropertyMap;		
            typedef  std::map<CString, CString> pair;
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath", ""));						
            PropertyMap.insert(pair::value_type("srcBoxNumber", ""));						
            PropertyMap.insert(pair::value_type("srcFolderName", ""));						
            PropertyMap.insert(pair::value_type("srcDocumentName", ""));						
            PropertyMap.insert(pair::value_type("IsImagedataPresent", ""));						
            PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent", ""));
            PropertyMap.insert(pair::value_type("IsThumbnaildataPresent", ""));
            PropertyMap.insert(pair::value_type("sessionID", ""));
            PropertyMap.insert(pair::value_type("cutDocument", ""));
            PropertyMap.insert(pair::value_type("lastAccessDate", Utility::GetUnixTime()));	
            PropertyMap.insert(pair::value_type("lastModifiedDate", Utility::GetUnixTime()));						
            CString oPath = Utility::GetResourcePath(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName)+"/";

            sdf = Utility::SetProperties(oPath,"documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartSaveAsThread:SetProperty failed because Disk is Full\n");
                    DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                    if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    return NULL;
                }
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);
                return NULL;
            }		

            //Set New Document name on the WorkSpace Doc
            sdf = proputils::SetProperty(curBoxBasePath,curBoxNumber,curFolderName,curDocumentName,"","srcDocumentName", newname);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartSaveAsThread:SetProperty failed because Disk is Full\n");
                    DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                    if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->m_prgShmid = NULL;
                    return NULL;
                }
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		

            //New document 
            saveAsdocobj->m_DocumentName = newname;
            CString to = Utility::GetResourcePath(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName) + "/";

            int count=1;
            int numRes = 1;
            //Folder::MoveDir will not work on interdevice (i.e /work to /storage). 
            //So remove original document then move the workspace document to storage
            Status status;
            Status rst;
            if(Utility::ResourceExist(to))
            {
                status=ci::operatingenvironment::Folder::Remove(to,true);	
                if((status!=STATUS_OK)) 
                {
                    DEBUGL1("CDocument::StartSaveThread: Deleting document from Workspace failed\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                    return NULL;
                }
            }

            status = ci::operatingenvironment::Folder::MoveDir(resourceKey,to);	
            if(status!=STATUS_OK) 
            {
                DEBUGL1("CDocument::StartSaveAsThread: Moving document from Workspace failed\n");
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");				
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }

            //Change the state to READY
            if(saveAsdocobj->ChangeStatus(READY) != STATUS_OK) 
            {
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");

                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            //Set the new name
            sdf = proputils::SetProperty(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName,"","documentName",newname);
            if(sdf != STATUS_OK)
            {	
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartSaveAsThread: Setting the new name on document failed because Disk is Full\n");
                    DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");
                    if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->m_prgShmid = NULL;
                    return NULL;
                }
                DEBUGL1("CDocument::StartSaveAsThread: Setting the new name on document failed\n");
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");																				

                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }
            //Set new WorkspaceDocName
            CString WorkspaceDocName = CUUID().toString();
            sdf = proputils::SetProperty(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName,"","WorkspaceDocName",WorkspaceDocName);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::StartSaveAsThread: Setting the WorkspaceDocName on document failed because Disk is Full\n");
                    DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");
                    if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    return NULL;
                }
                DEBUGL1("CDocument::StartSaveAsThread: Setting the WorkspaceDocName on document failed\n");
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");

                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);
                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                return NULL;
            }


            //Remove the properties
            PropertyMap.clear();
            //update the other properties 
            PropertyMap.insert(pair::value_type("srcBoxBasePath", ""));						
            PropertyMap.insert(pair::value_type("srcBoxNumber", ""));						
            PropertyMap.insert(pair::value_type("srcFolderName", ""));						
            PropertyMap.insert(pair::value_type("srcDocumentName", ""));						
            PropertyMap.insert(pair::value_type("IsImagedataPresent", ""));						
            PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent", ""));
            PropertyMap.insert(pair::value_type("IsThumbnaildataPresent", ""));
            PropertyMap.insert(pair::value_type("sessionID", ""));
            PropertyMap.insert(pair::value_type("cutDocument", ""));
            PropertyMap.insert(pair::value_type("lastAccessDate", Utility::GetUnixTime()));			
            PropertyMap.insert(pair::value_type("lastModifiedDate", Utility::GetUnixTime()));						
            resourceKey= Utility::GetResourcePath(saveAsdocobj->m_BoxBasePath,saveAsdocobj->m_BoxNumber,saveAsdocobj->m_FolderName,saveAsdocobj->m_DocumentName)+"/";

            sdf = Utility::SetProperties(resourceKey,"documentproperties.xml",PropertyMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");
                    if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                    saveAsdocobj->m_prgShmid = NULL;
                    return NULL;
                }
                rst = Utility::RemoveResource(to);
                if(rst != STATUS_OK)
                    DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");
                saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);				

                if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

                return NULL;
            }		
            //To Fix FR_5121. Change the clipboard document properties srcBoxBasePath to /storage/box/EFiling
            //and set srcDocument name to orginal document name.
            typedef  std::map<CString, CString> pair;		
            PropertyMap.clear();						
            CString clipbrdDocName = CLIPBOARD_PATH + curDocumentName +"/";
            if(Utility::ResourceExist(clipbrdDocName))
            {		
                DEBUGL8("CDocument::StartSaveAsThread: clipbrdDocName (%s) m_BoxBasePath (%s) m_DocumentName(%s)\n", 
                        clipbrdDocName.c_str(), saveAsdocobj->m_BoxBasePath.c_str(), saveAsdocobj->m_DocumentName.c_str());
                PropertyMap.insert(pair::value_type("srcBoxBasePath",saveAsdocobj->m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",saveAsdocobj->m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",saveAsdocobj->m_FolderName));
                PropertyMap.insert(pair::value_type("srcDocumentName",saveAsdocobj->m_DocumentName));

                sdf = Utility::SetProperties(clipbrdDocName, "documentproperties.xml",PropertyMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CDocument::StartSaveAsThread: SetProperties failed because Disk is Full\n");
                        DEBUGL8("CDocument::StartSaveAsThread::savepath = (%s)\n", saveaspath.c_str());
                        rst = Utility::RemoveResource(to);
                        if(rst != STATUS_OK)
                            DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");
                        if(Utility::CreateUniqueFile(saveaspath, ".saveAsDiskFullDoc_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                            DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");
                        //revert back to original
                        saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                        if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                            DEBUGL2("CDocument::StartSaveAsThread: Unable to delete the file\n");
                        saveAsdocobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CDocument::StartSaveAsThread: SetProperties failed\n");
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CDocument::StartSaveAsThread: Failed to remove half created folder\n");

                    //revert back to original
                    saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);			

                    if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CDocument::StartSaveAsThread: Unable to delete the file\n");

                    saveAsdocobj->ErrorFileCreation(saveAsdocobj->m_SaveAsErrfile,saveAsdocobj->m_prgShmid);
                    return NULL;
                }		
            }		
            //revert back to original
            saveAsdocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);						
            int curProg = (int)((((float)count++)/((float)numRes))*100);
            if(curProg!=100)
            {
                *((int*)pSaveAsMapAddr) = curProg;				
                DEBUGL8("CDocument::StartSaveAsThread::Current Progress<%d>\n",curProg);
            }

            if(Utility::DeleteUniqueFile(savepath, ".saveisinprogress_" + saveAsdocobj->m_sessionID) != STATUS_OK)
                DEBUGL2("CDocument::StartSaveAsThread: Unable to create the file\n");

            *((int*)pSaveAsMapAddr) = PROGRESS_COMPLETED;				
            saveAsdocobj->m_prgShmid = NULL;
            DEBUGL8("CDocument::StartSaveAsThread::Current Progress<%d>\n",curProg);

            DEBUGL4("CDocument::StartSaveAsThread: Exit\n");	
            return NULL;

        }

        void* StartPasteThread(void *arg)
		  {
			  DEBUGL4("CDocument::StartPasteThread()-- Started \n");

			  //Status retStatus;
			  //Copy the passed instance of the invoking object into a local variable 
			  CDocument *pastedocobj = (CDocument *)arg;
			  //Copy the inputs from static variable into a local variable 
			  int pageno = pastedocobj->m_PastePageNo;

			  //Create Shared memory used for writing the updated progress in it
			  void *pPasteMapAddr;
			  if(!pastedocobj->m_prgShmid)
			  {
				  DEBUGL1("\n CDocument::StartPasteThread: -- Shared memory ref for paste is null\n ");
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }
			  else
			  {
				  int iShmPidSize = pastedocobj->m_prgShmid->getSize();
				  //Map the Created Segment to another address
				  pastedocobj->m_prgShmid->Map(pPasteMapAddr);
				  if(pPasteMapAddr!=NULL)
				  {
					  memset(pPasteMapAddr,0,iShmPidSize);
				  }
				  else
				  {
					  DEBUGL1("\n CDocument::StartPasteThread: -- Mapping Failed for Paste Progress Name\n");
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  //m_PasteFlag = FLAG_RESET;
					  return NULL;
				  }
			  }

			  //set the initial value of Paste Document progress as 1% . The Start Paste 
			  //thread will update it as and when the operation progresses
			  *((int*)pPasteMapAddr) = 1;

			  DocStatus st;
			  std::vector<CString> srcvec;
			  vector<CString>::iterator it;
			  vector<CString>::iterator iit;
			  vector<CString>::iterator sit;
			  vector<CString>::iterator tit;	
			  CString clipbrdDocName("");
			  CString clipbrdDocName1("");
			  bool IsImagedataPresent = false;
			  bool IsSubsamplingdataPresent = false;
			  bool IsThumbnaildataPresent = false;
			  std::vector<CString> Imgvec;

			  std::vector<CString> subsamvec;
			  std::vector<CString> thumbnailvec;
			  int total;	

			  DEBUGL8("CDocument::StartPasteThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", pastedocobj->m_sessionID.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str());

			  //make a local copy of the member variables
			  CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			  boxbasepath_org = pastedocobj->m_BoxBasePath;
			  boxnumber_org = pastedocobj->m_BoxNumber;
			  folderName_org = pastedocobj->m_FolderName;
			  docName_org = pastedocobj->m_DocumentName;

			  if(pageno < 0)
			  {
				  DEBUGL1("CDocument::StartPasteThread:Invalid page number %d and total pages in the document are %d\n", pageno,total);
				  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);					
				  //Create a file indicating the Status to be not Status Ok	
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }
			  CString pastepath = Utility::GetResourcePath(pastedocobj->m_BoxBasePath,pastedocobj->m_BoxNumber,pastedocobj->m_FolderName);

			  //Initialize WorkSpace
			  pastedocobj->WorkSpaceInit();


			  /*Fix for STFR-7577
				*Check the value of totalPages in documentproperties.xml for the document
				*that is there in /work/Workspace/ and not in /storage/box/EfilingBoxes/
				*This will give the updated information in case deletepage operation has
				*taken place.
				*/
			  if(pastedocobj->iSSetsysfileInvoked)
			  {
				  if(pastedocobj->GetPageList(pastedocobj->m_PageList) != STATUS_OK)
				  {
					  DEBUGL1("CDocument::StartPasteThread::Getting PageList failed\n");
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
			  }
			  else
			  {
				  if(pastedocobj->GetTotalPage(total)!=STATUS_OK)
				  {
					  DEBUGL1("CDocument::StartPasteThread::Getting total pages failed\n");
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  DEBUGL8("CDocument::StartPasteThread::Total pages in the document are %d\n",total);
			  }

			  int pos;
			  CString boxbasepath_new("");
			  pos =pastedocobj->m_BoxBasePathOrg.rfind("/");
			  boxbasepath_new =  pastedocobj->m_BoxBasePathOrg.substr(pos+1);
			  if(boxbasepath_new == "PageLogBoxes")
			  {
				  if((static_cast<unsigned>(total) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
				  {
					  DEBUGL1("CDocument::StartPasteThread::Page Limit reached for PAGELOGBOXES\n");
					  return NULL;
				  }
			  }
			  else if(static_cast<unsigned>(total) >= CBoxDocument::PAGE_LIMIT)
			  {
				  DEBUGL1("CDocument::StartPasteThread::Page Limit reached\n");
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }

			  //Get the status of the destination document, it should be Editing
			  if(pastedocobj->GetStatus(st) != STATUS_OK)
			  {
				  DEBUGL1("CDocument::StartPasteThread:Getting document status is failed\n");
				  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }

			  //check the status of the source document, it should be Editing
			  if(!(st == EDITING)) 
			  {
				  DEBUGL1("CDocument::StartPasteThread:Document status is not EDITING\n");
				  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }

			  //Get the List of Documents in Clipboard
			  if(Utility::GetCollectionList(srcvec, CLIPBOARD_PATH)!=STATUS_OK) 
			  {
				  DEBUGL1("CDocument::StartPasteThread: Getting collection list failed");
				  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				  return NULL;
			  }


			  //Iterate through the vector to read a document with current session-id				
			  DEBUGL8("CDocument::StartPasteThread:Current Session id <%s>\n",pastedocobj->m_sessionID.c_str());	
			  std::vector<CString> docNameVec;
			  docNameVec.clear();
			  for(it = srcvec.begin();it != srcvec.end(); it++) 
			  {
				  CString val;
				  DEBUGL8("CDocument::StartPasteThread: Contents of src vector <%s>\n",(*it).c_str());							
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",*it,"","sessionID", val)!=STATUS_OK)
				  {
					  DEBUGL2("CDocument::StartPasteThread: GetProperty of sessionID failed\n");
					  val.clear();
				  }
				  DEBUGL8("CDocument::StartPasteThread::Document SessionID<%s>\n",val.c_str());
				  if(val==pastedocobj->m_sessionID)
				  {
					  DEBUGL8("CDocument::StartPasteThread::Document SessionID is equal to m_sessionID <%s> m_sessionID <%s>\n",val.c_str(),pastedocobj->m_sessionID.c_str());				
					  docNameVec.push_back(*it);						
				  }
			  }

			  vector<CString>::iterator docNameVecIt;
			  //Calculation of progress


			  uint numRes = 0;
			  for(docNameVecIt = docNameVec.begin();docNameVecIt!=docNameVec.end();docNameVecIt++)
			  {

				  std::vector<CString> Imgvec1;
				  clipbrdDocName1 = *docNameVecIt;
				  if(clipbrdDocName1.empty())
				  {
					  DEBUGL1("CDocument::StartPasteThread: Clipboard does not have the required document --session ID might have expired");
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }

				  //Read the document in the Clipboard Path and other details set on the clipboard document.
				  CString from =clipbrdDocName1;
				  CString val;
				  CString resourceKey=from + "/";
				  CString Path("");

				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName1,"","IsImagedataPresent", val) == STATUS_OK)
				  {
					  if(val.compare("true")==0)
					  {	
						  IsImagedataPresent=true;
						  //Get the List of pages present in Clipboard/docname/Image folder if present.
						  Path=CLIPBOARD_PATH + resourceKey+"Image/";
						  if(Utility::GetPageCollectionList(Imgvec1, Path)!=STATUS_OK) 
						  {
							  DEBUGL1("CDocument::StartPasteThread: Getting collection list failed");
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }
					  }
				  }
				  else
				  {
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }


				  int Imgveccount = Imgvec1.size();
				  Imgveccount = ((Imgveccount-1)/3);
				  numRes = numRes + Imgveccount;
			  }

			  int curProg =0;
			  int count=0;
			  for(docNameVecIt = docNameVec.begin();docNameVecIt!=docNameVec.end();docNameVecIt++)
			  {
				  clipbrdDocName = *docNameVecIt;
				  if(clipbrdDocName.empty())
				  {
					  DEBUGL1("CDocument::StartPasteThread: Clipboard does not have the required document --session ID might have expired");
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }

				  //Read the document in the Clipboard Path and other details set on the clipboard document.
				  CString from =clipbrdDocName;
				  CString val;
				  CString resourceKey=from + "/";
				  CString Path("");
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsImagedataPresent", val) == STATUS_OK)
				  {
					  if(val.compare("true")==0)
					  {	
						  IsImagedataPresent=true;
						  //Get the List of pages present in Clipboard/docname/Image folder if present.
						  Path=CLIPBOARD_PATH + resourceKey+"Image/";
						  Imgvec.clear();
						  if(Utility::GetPageCollectionList(Imgvec, Path)!=STATUS_OK) 
						  {
							  DEBUGL1("CDocument::StartPasteThread: Getting collection list failed");
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }
					  }
				  }
				  else
				  {
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		

				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsSubsamplingdataPresent", val) == STATUS_OK)
				  {


					  if(val.compare("true")==0)
					  {	
						  IsSubsamplingdataPresent=true;
						  Path=CLIPBOARD_PATH + resourceKey+"Subsampling/";
						  if(Utility::GetPageCollectionList(subsamvec, Path)!=STATUS_OK) 
						  {
							  DEBUGL1("CDocument::StartPasteThread: Getting collection list failed");
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }
					  }	
				  }
				  else
				  {
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		

				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsThumbnaildataPresent", val)== STATUS_OK)
				  {

					  if(val.compare("true")==0)
					  {
						  IsThumbnaildataPresent=true;
						  Path=CLIPBOARD_PATH + resourceKey+"Thumbnail/";
						  if(Utility::GetPageCollectionList(thumbnailvec, Path)!=STATUS_OK) 
						  {
							  DEBUGL1("CDocument::StartPasteThread: Getting collection list failed");
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }	
					  }
				  }
				  else
				  {
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		

				  //Get the destination folder details.
				  CString to = Utility::GetResourcePath(pastedocobj->m_BoxBasePath,pastedocobj->m_BoxNumber,pastedocobj->m_FolderName,pastedocobj->m_DocumentName) + "/";

				  // Get the page related folders present in the destination document 
				  // check whether all the folders are in sync with src folders.
				  //check if the contents in folder exist.
				  std::vector<CString> tempvec;
				  vector<CString>::iterator tempIt;
				  if(Utility::GetCollectionList(tempvec,to+"Image/")!=STATUS_OK)
				  {
					  DEBUGL1("CDocument::StartPasteThread:Getting collection list for Image failed");
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  if((tempvec.size() > 1)&&(IsImagedataPresent==false))
				  {
					  DEBUGL2("CDocument::StartPasteThread: Imagedatapresent <%d>\n",IsImagedataPresent);	 
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  tempvec.clear();
				  if(Utility::GetCollectionList(tempvec,to+"Subsampling/")!=STATUS_OK)
				  {
					  DEBUGL1("CDocument::StartPasteThread:Getting collection list for Subsampling failed");
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  if((tempvec.size()  > 1)&&(IsSubsamplingdataPresent==false))
				  {
					  DEBUGL2("CDocument::StartPasteThread: IsSubsamplingdataPresent <%d>\n",IsSubsamplingdataPresent);	 
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  tempvec.clear();						
				  if(Utility::GetCollectionList(tempvec,to+"Thumbnail/")!=STATUS_OK)
				  {
					  DEBUGL1("CDocument::StartPasteThread:Getting collection list for Thumbnail failed");
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }
				  if((tempvec.size() > 1)&&(IsThumbnaildataPresent==false))
				  {
					  DEBUGL2("CDocument::StartPasteThread: IsThumbnaildataPresent <%d>\n",IsThumbnaildataPresent);	 
					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }

				  resourceKey = from;
				  CString srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName;
				  //Read the src box name,doc name etc and delete the pages at the src path and update the sdf.
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxBasePath", srcBoxBasePath) != STATUS_OK)
				  {


					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxNumber", srcBoxNumber) != STATUS_OK)
				  {


					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcFolderName", srcFolderName) != STATUS_OK)
				  {


					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcDocumentName", srcDocumentName) != STATUS_OK)
				  {


					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		

				  CString curBoxBasePath(pastedocobj->m_BoxBasePath);
				  CString curBoxNumber(pastedocobj->m_BoxNumber);
				  CString curFolderName(pastedocobj->m_FolderName);
				  CString curDocumentName(pastedocobj->m_DocumentName);
				  CString fullname("");
				  CString CutFlag("");						
				  Status ret;
				  CString pagePath("");		
				  //The page number in the detination workspace
				  int dstPageNum=pageno;
				  std::vector<CString> cjdFromVec;
				  std::vector<CString> cjdToVec;

				  for(iit=Imgvec.begin();iit!=Imgvec.end();iit++)
				  {
					  DEBUGL8("CDocument::StartPasteThread: page in Image Vec  is  %s\n",(*iit).c_str());	

					  size_t next = iit->rfind("/");
					  CString fullname = iit->substr(next + 1);
					  if(fullname.compare("00000")==0)
					  {
						  DEBUGL8("CDocument::StartPasteThread: Skipping SDF<%s>\n",fullname.c_str());	
						  continue;
					  }
					  if((fullname.find(".xml") != std::string::npos) || (fullname.find("_dom") != std::string::npos)|| (fullname.find(".uniqid_") != std::string::npos))
					  {
						  DEBUGL8("CDocument::StartPasteThread: Skipping xml or dom <%s>\n",fullname.c_str());	
						  continue;
					  }

					  //Total number of pages
					  if(pastedocobj->GetTotalPage(total)!=STATUS_OK)
					  {	
						  DEBUGL1("CDocument::StartPasteThread::Getting total pages failed\n");
						  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
						  return NULL;
					  }

					  size_t last = fullname.rfind(".cjd");
					  if(last == CString::npos)
					  {	
						  DEBUGL8("CDocument::StartPasteThread: Iterator String val<%s>,DocName<%s>\n",iit->c_str(),fullname.c_str());	 
						  //The page number in the source workspace
						  int srcPageNum;
						  PageRef pageRef;
						  bool isSamePos = false;
						  CString hsToInt = "0x" + fullname;
						  std::istringstream istr(hsToInt);				

						  // convert string page to int page
						  istr>>std::setbase(0)>>srcPageNum;	

						  if(srcPageNum == dstPageNum)
							  isSamePos = true;	

						  //GetPage from Source ClipBoard
						  DEBUGL8("CDocument::StartPasteThread: GetPage called\n");	 
						  CString clipPath = CLIPBOARD_PATH;
						  pastedocobj->m_BoxBasePath=clipPath;
						  pastedocobj->m_BoxNumber="";
						  pastedocobj->m_FolderName="";

						  DEBUGL8("CDocument::StartPasteThread: ClipboardDocName<%s>\n", clipbrdDocName.c_str());
						  pastedocobj->m_DocumentName = clipbrdDocName;

						  DEBUGL8("CDocument::StartPasteThread: for GetPage--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", pastedocobj->m_BoxBasePath.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str(), srcPageNum);
						  if(pastedocobj->GetPage(srcPageNum,pageRef)!=STATUS_OK)
						  {
							  DEBUGL1("CDocument::StartPasteThread:GetPage of %d failed\n",srcPageNum);
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }	

						  //InsertPage at Destination Workspace
						  pastedocobj->m_BoxBasePath=curBoxBasePath;
						  pastedocobj->m_BoxNumber=curBoxNumber;
						  pastedocobj->m_FolderName=curFolderName;
						  pastedocobj->m_DocumentName=curDocumentName;																		
						  DEBUGL8("CDocument::StartPasteThread: for Insert/Append/Replace Page--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", pastedocobj->m_BoxBasePath.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str(), dstPageNum);
						  if(dstPageNum == total + 1)
						  {
							  if(IsImagedataPresent == false)
							  {
								  if(!pageRef)
								  {
									  DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									  return NULL;
								  }
								  dynamic_cast<CPage*>(pageRef.operator->())->SetImage("", "");
							  }
							  if(IsThumbnaildataPresent == false)	
							  {
								  if(!pageRef)
								  {
									  DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									  return NULL;
								  }
								  dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage("", "");
							  }
							  if(IsSubsamplingdataPresent == false)
							  {  
								  if(!pageRef)
								  {
									  DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									  return NULL;         
								  }
								  dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage("", "");
							  }
							  DEBUGL8("CDocument::StartPasteThread: AppendPage called\n");
							  ret = pastedocobj->AppendPage(pageRef);
							  if(ret!=STATUS_OK)
							  {
								  if(ret == ::STATUS_DISK_FULL)
								  {
									  DEBUGL1("CDocument::StartPasteThread::AppendPage returned DISKFULL Error\n");
									  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									  if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullDoc_" + pastedocobj->m_sessionID) != STATUS_OK)
										  DEBUGL2("CDocument::StartPasteThread: Unable to create the file\n");

									  pastedocobj->m_prgShmid = NULL;
									  return NULL;
								  }
								  else
								  {	
									  DEBUGL1("CDocument::StartPasteThread::AppendPage failed\n");											
									  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
									  return NULL;
								  }
							  }
							  count++;
							  curProg = (int)(((count*100)/numRes));
							  if(curProg!=100)
							  {
								  if(curProg == 0)
								  { curProg = 1;

									  *((int*)pPasteMapAddr) = curProg;				
								  }
								  else
								  {
									  *((int*)pPasteMapAddr) = curProg;				
									  DEBUGL8("CDocument::StartPasteThread::Current Progress<%d>\n",curProg);						
								  }
							  }

						  }
						  else 
						  {
							  DEBUGL8("CDocument::StartPasteThread: InsertPage called\n");	 
							  ret = pastedocobj->InsertPage(dstPageNum,pageRef);
							  if(ret!=STATUS_OK)
							  {
								  if(ret == STATUS_DISK_FULL)
								  {
									  DEBUGL1("CDocument::StartPasteThread::InsertPage returned DISKFULL Error\n");
									  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									  if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullDoc_" + pastedocobj->m_sessionID) != STATUS_OK)
										  DEBUGL2("CDocument::StartPasteThread: Unable to create the file\n");
									  pastedocobj->m_prgShmid = NULL;
									  return NULL;

								  }
								  else
								  {	
									  DEBUGL1("CDocument::StartPasteThread::InsertPage failed\n");											
									  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
									  return NULL;
								  }
							  }
							  count++;
							  curProg = (int)(((count*100)/numRes));
							  if(curProg!=100)
							  {
								  if(curProg == 0)
								  {			  curProg = 1;

									  *((int*)pPasteMapAddr) = curProg;			
								  }
								  else
								  {
									  *((int*)pPasteMapAddr) = curProg;				
									  DEBUGL8("CDocument::StartPasteThread::Current Progress<%d>\n",curProg);						
								  }
							  }

						  }
                        dstPageNum++;
					  }
					  else
					  {
						  DEBUGL8("CDocument::StartPasteThread: Skipping cjd docName<%s>\n",fullname.c_str());	 										
						  CString cjdFrom = CLIPBOARD_PATH + resourceKey + "/Image/" + fullname;
						  DEBUGL8("CDocument::StartPasteThread: cjdFrom = (%s)\n",cjdFrom.c_str());	 
						  cjdFromVec.push_back(cjdFrom);
						  CString cjdTo = curBoxBasePath + "/" + curDocumentName + "/Image/" + fullname;
						  DEBUGL8("CDocument::StartPasteThread: cjdTo = (%s)\n",cjdTo.c_str());	 
						  cjdToVec.push_back(cjdTo);										

					  }
				  }

				  if(!cjdFromVec.empty())
				  {
					  for(it = cjdFromVec.begin(), iit = cjdToVec.begin();it!=cjdFromVec.end();it++, iit++)
					  {
						  if(Utility::ResourceExist(*(it)))
						  {
							  DEBUGL8("CDocument::StartPasteThread: cjdFrom = (%s)\n",(*(it)).c_str());	 
							  DEBUGL8("CDocument::StartPasteThread: cjdTo = (%s)\n",(*(iit)).c_str());	 

							  if(ci::operatingenvironment::File::CopyFile(*(it),*(iit)) != STATUS_OK)
							  {
								  DEBUGL1("CDocument::StartPasteThread::Copying cjd file failed\n");											
								  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
								  return NULL;
							  }

						  }
					  }
				  }

				  //Check for the CutDocument property and delete the original document
				  CutFlag.clear();
				  if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","cutDocument", CutFlag) != STATUS_OK)
				  {

					  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					  return NULL;
				  }		
				  if(CutFlag=="true")
				  {	
					  //Obtain the original document
					  DocumentRef orgDoc;
					  if(Utility::GetDocument(pastedocobj->m_sessionID, orgDoc,srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName)!=STATUS_OK)
					  {
						  DEBUGL1("CDocument::StartPasteThread: Obtaining Original Document failed\n");
						  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
						  return NULL;
					  }

					  // Start to Delete
					  try
					  {
						  if(!orgDoc)
						  {
							  DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
							  return NULL;         
						  }
						  if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
						  {
							  DEBUGL1("CDocument::StartPasteThread: Deleting document failed\n");
							  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							  pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							  return NULL;
						  }
					  }
					  catch(exception& e)
					  {
						  DEBUGL1("CDocument::StartPasteThread::Exception caught:(%s)\n",e.what());
						  return NULL;
					  }
				  }	

				  DEBUGL8("CDocument::StartPasteThread::Current Progress<%d>\n",curProg);	
			  }
			  curProg = 100;
			  //revert back to original
			  pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);			

			  if(pastedocobj->m_prgShmid) { 


				  *((int*)pPasteMapAddr) = PROGRESS_COMPLETED;					

				  pastedocobj->m_prgShmid = NULL;
			  }

			  DEBUGL4("CDocument::StartPasteThread: Exit\n");	
			  return NULL;
		  }


		void* StartFasterPasteThread(void *arg)
		{
			DEBUGL4("CDocument::StartFasterPasteThread()-- Started \n");

			//Status retStatus;
			//Copy the passed instance of the invoking object into a local variable 
			CDocument *pastedocobj = (CDocument *)arg;
			//Copy the inputs from static variable into a local variable 
			int pageno = pastedocobj->m_PastePageNo;

			//Create Shared memory used for writing the updated progress in it
			void *pPasteMapAddr;
			if(!pastedocobj->m_prgShmid)
			{
				DEBUGL1("\n CDocument::StartFasterPasteThread: -- Shared memory ref for paste is null\n ");
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}
			else
			{
				int iShmPidSize = pastedocobj->m_prgShmid->getSize();
				//Map the Created Segment to another address
				pastedocobj->m_prgShmid->Map(pPasteMapAddr);
				if(pPasteMapAddr!=NULL)
				{
					memset(pPasteMapAddr,0,iShmPidSize);
				}
				else
				{
					DEBUGL1("\n CDocument::StartFasterPasteThread: -- Mapping Failed for Paste Progress Name\n");
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
			}

			//set the initial value of Paste Document progress as 1% . The Start Paste 
			//thread will update it as and when the operation progresses
			*((int*)pPasteMapAddr) = 1;

			DocStatus st;
			std::vector<CString> srcvec;
			vector<CString>::iterator it;
			vector<CString>::iterator iit;
			vector<CString>::iterator sit;
			vector<CString>::iterator tit;	
			CString clipbrdDocName("");
			bool IsImagedataPresent = false;
			bool IsSubsamplingdataPresent = false;
			bool IsThumbnaildataPresent = false;
			std::vector<CString> Imgvec;
			std::vector<CString> subsamvec;
			std::vector<CString> thumbnailvec;
			int total;	

			DEBUGL8("CDocument::StartFasterPasteThread: m_sessionID %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", pastedocobj->m_sessionID.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str());

			//make a local copy of the member variables
			CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			boxbasepath_org = pastedocobj->m_BoxBasePath;
			boxnumber_org = pastedocobj->m_BoxNumber;
			folderName_org = pastedocobj->m_FolderName;
			docName_org = pastedocobj->m_DocumentName;

			if(pageno < 0)
			{
				DEBUGL1("CDocument::StartFasterPasteThread:Invalid page number %d and total pages in the document are %d\n", pageno,total);
				pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);					
				//Create a file indicating the Status to be not Status Ok	
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}
			CString pastepath = Utility::GetResourcePath(pastedocobj->m_BoxBasePath,pastedocobj->m_BoxNumber,pastedocobj->m_FolderName);

			//Initialize WorkSpace
			pastedocobj->WorkSpaceInit();


			/*Fix for STFR-7577
			 *Check the value of totalPages in documentproperties.xml for the document
			 *that is there in /work/Workspace/ and not in /storage/box/EfilingBoxes/
			 *This will give the updated information in case deletepage operation has
			 *taken place.
			 */
			if(pastedocobj->iSSetsysfileInvoked)
			{
				if(pastedocobj->GetPageList(pastedocobj->m_PageList) != STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread::Getting PageList failed\n");
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
			}
			else
			{
				if(pastedocobj->GetTotalPage(total)!=STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread::Getting total pages failed\n");
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				DEBUGL8("CDocument::StartFasterPasteThread::Total pages in the document are %d\n",total);
			}

			int pos;
			CString boxbasepath_new("");
			pos =pastedocobj->m_BoxBasePathOrg.rfind("/");
			boxbasepath_new =  pastedocobj->m_BoxBasePathOrg.substr(pos+1);
			if(boxbasepath_new == "PageLogBoxes")
			{
				if((static_cast<unsigned>(total) >= CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
				{
					DEBUGL1("CDocument::StartFasterPasteThread::Page Limit reached for PAGELOGBOXES\n");
					return NULL;
				}
			}
			else if(static_cast<unsigned>(total) >= CBoxDocument::PAGE_LIMIT)
			{
				DEBUGL1("CDocument::StartFasterPasteThread::Page Limit reached\n");
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}

			//Get the status of the destination document, it should be Editing
			if(pastedocobj->GetStatus(st) != STATUS_OK)
			{
				DEBUGL1("CDocument::StartFasterPasteThread:Getting document status is failed\n");
				pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}

			//check the status of the source document, it should be Editing
			if(!(st == EDITING)) 
			{
				DEBUGL1("CDocument::StartFasterPasteThread:Document status is not EDITING\n");
				pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}

			//Get the List of Documents in Clipboard
			if(Utility::GetCollectionList(srcvec, CLIPBOARD_PATH)!=STATUS_OK) 
			{
				DEBUGL1("CDocument::StartFasterPasteThread: Getting collection list failed");
				pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
				pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
				return NULL;
			}

			//Iterate through the vector to read a document with current session-id				
			DEBUGL8("CDocument::StartFasterPasteThread:Current Session id <%s>\n",pastedocobj->m_sessionID.c_str());	
			std::vector<CString> docNameVec;
			docNameVec.clear();
			for(it = srcvec.begin();it != srcvec.end(); it++) 
			{
				CString val;
				DEBUGL8("CDocument::StartFasterPasteThread: Contents of src vector <%s>\n",(*it).c_str());							
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",*it,"","sessionID", val)!=STATUS_OK)
				{
					DEBUGL2("CDocument::StartFasterPasteThread: GetProperty of sessionID failed\n");
					val.clear();
				}
				DEBUGL8("CDocument::StartFasterPasteThread::Document SessionID<%s>\n",val.c_str());
				if(val==pastedocobj->m_sessionID)
				{
					DEBUGL8("CDocument::StartFasterPasteThread::Document SessionID is equal to m_sessionID <%s> m_sessionID <%s>\n",val.c_str(),pastedocobj->m_sessionID.c_str());				
					docNameVec.push_back(*it);						
				}
			}
			vector<CString>::iterator docNameVecIt;
			for(docNameVecIt = docNameVec.begin();docNameVecIt!=docNameVec.end();docNameVecIt++)
			{
				clipbrdDocName = *docNameVecIt;
				if(clipbrdDocName.empty())
				{
					DEBUGL1("CDocument::StartFasterPasteThread: Clipboard does not have the required document --session ID might have expired");
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}

				//Read the document in the Clipboard Path and other details set on the clipboard document.
				CString from =clipbrdDocName;
				CString val;
				CString resourceKey=from + "/";
				CString Path("");

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsImagedataPresent", val) == STATUS_OK)
				{
					if(val.compare("true")==0)
					{	
						IsImagedataPresent=true;
						//Get the List of pages present in Clipboard/docname/Image folder if present.
						Path=CLIPBOARD_PATH + resourceKey+"Image/";
						if(Utility::GetPageCollectionList(Imgvec, Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::StartFasterPasteThread: Getting collection list failed");
							pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							return NULL;
						}
					}
				}
				else
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsSubsamplingdataPresent", val) == STATUS_OK)
				{
					if(val.compare("true")==0)
					{	
						IsSubsamplingdataPresent=true;
						Path=CLIPBOARD_PATH + resourceKey+"Subsampling/";
						if(Utility::GetPageCollectionList(subsamvec, Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::StartFasterPasteThread: Getting collection list failed");
							pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							return NULL;
						}
					}	
				}
				else
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		

				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","IsThumbnaildataPresent", val)== STATUS_OK)
				{
					if(val.compare("true")==0)
					{
						IsThumbnaildataPresent=true;
						Path=CLIPBOARD_PATH + resourceKey+"Thumbnail/";
						if(Utility::GetPageCollectionList(thumbnailvec, Path)!=STATUS_OK) 
						{
							DEBUGL1("CDocument::StartFasterPasteThread: Getting collection list failed");
							pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							return NULL;
						}	
					}
				}
				else
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		

				//Get the destination folder details.
				CString to = Utility::GetResourcePath(pastedocobj->m_BoxBasePath,pastedocobj->m_BoxNumber,pastedocobj->m_FolderName,pastedocobj->m_DocumentName) + "/";

				// Get the page related folders present in the destination document 
				// check whether all the folders are in sync with src folders.
				//check if the contents in folder exist.
				std::vector<CString> tempvec;
				vector<CString>::iterator tempIt;
				if(Utility::GetCollectionList(tempvec,to+"Image/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread:Getting collection list for Image failed");
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				if((tempvec.size() > 1)&&(IsImagedataPresent==false))
				{
					DEBUGL2("CDocument::StartFasterPasteThread: Imagedatapresent <%d>\n",IsImagedataPresent);	 
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				tempvec.clear();
				if(Utility::GetCollectionList(tempvec,to+"Subsampling/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread:Getting collection list for Subsampling failed");
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				if((tempvec.size()  > 1)&&(IsSubsamplingdataPresent==false))
				{
					DEBUGL2("CDocument::StartFasterPasteThread: IsSubsamplingdataPresent <%d>\n",IsSubsamplingdataPresent);	 
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				tempvec.clear();						
				if(Utility::GetCollectionList(tempvec,to+"Thumbnail/")!=STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread:Getting collection list for Thumbnail failed");
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}
				if((tempvec.size() > 1)&&(IsThumbnaildataPresent==false))
				{
					DEBUGL2("CDocument::StartFasterPasteThread: IsThumbnaildataPresent <%d>\n",IsThumbnaildataPresent);	 
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}

				resourceKey = from;
				CString srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName;
				//Read the src box name,doc name etc and delete the pages at the src path and update the sdf.
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxBasePath", srcBoxBasePath) != STATUS_OK)
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcBoxNumber", srcBoxNumber) != STATUS_OK)
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcFolderName", srcFolderName) != STATUS_OK)
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","srcDocumentName", srcDocumentName) != STATUS_OK)
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		

				CString curBoxBasePath(pastedocobj->m_BoxBasePath);
				CString curBoxNumber(pastedocobj->m_BoxNumber);
				CString curFolderName(pastedocobj->m_FolderName);
				CString curDocumentName(pastedocobj->m_DocumentName);
				CString fullname("");
				CString CutFlag("");						
				Status ret;

				//Calculate progress
				uint numRes = 0;
				for(iit=Imgvec.begin();iit!=Imgvec.end();iit++)
				{
					DEBUGL8("CDocument::StartFasterPasteThread: page in Image Vec  is  %s\n",(*iit).c_str());	
					size_t next = iit->rfind("/");
					CString fullname = iit->substr(next + 1);
					if(fullname.compare("00000")==0)
					{
						DEBUGL8("CDocument::StartFasterPasteThread: Skipping SDF<%s>\n",fullname.c_str());	
						continue;
					}
					else
						numRes++;
				}				
				DEBUGL8("CDocument::StartFasterPasteThread::Total number of resources to be copied <%d>\n",numRes);
				int curProg =0;
				int count =1;		
				CString pagePath("");		
				//The page number in the detination workspace
				int dstPageNum=pageno;
				std::vector<CString> cjdFromVec;
				std::vector<CString> cjdToVec;
				//Status slideret;
				int vecsize = Imgvec.size();
				//algorithm to slide the pages. 
				//1. Calculate the total number of positions by which pages need to be shifted,
				// depending on the number of pages being inserted and number of pages already 
				// present in the document. 
				//2. Shift all the pages all together, depending on the number obtained for the
				//number of moves required by above step.
				//3. Insert the pages, present in the clipboard, to the document. 
				//
				//Eg. If there are 10 pages present in the document and we want to insert 
				//5 pages at the 5th position of the document, then we 10th page is moved to 
				//15th position, 9th to 14th position. and 5th page to 10th position. And 
				//insert 5 pages at the 5th position. By this pages are shifted only once.
				//
				//In a document, there is a system file and for every page, there is an image 
				//file. So we pass only the nmber of pages present in the vector.
				if(pastedocobj->SlidePages(dstPageNum,((vecsize-1)/3))!=STATUS_OK)
				{
					DEBUGL1("CDocument::StartFasterPasteThread: Slide Image failed\n");
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}


				for(iit=Imgvec.begin();iit!=Imgvec.end();iit++)
				{
					DEBUGL8("CDocument::StartPasteThread: page in Image Vec  is  %s\n",(*iit).c_str());	

					size_t next = iit->rfind("/");
					CString fullname = iit->substr(next + 1);
					if(fullname.compare("00000")==0)
					{
						DEBUGL8("CDocument::StartFasterPasteThread: Skipping SDF<%s>\n",fullname.c_str());	
						continue;
					}
					if((fullname.find(".xml") != std::string::npos) || (fullname.find("_dom") != std::string::npos) || (fullname.find(".uniqid_") != std::string::npos))
					{
						DEBUGL8("CDocument::StartFasterPasteThread: Skipping xml or dom<%s>\n",fullname.c_str());	
						continue;
					}

					//Total number of pages
					if(pastedocobj->GetTotalPage(total)!=STATUS_OK)
					{	
						DEBUGL1("CDocument::StartFasterPasteThread::Getting total pages failed\n");
						pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
						return NULL;
					}

					size_t last = fullname.rfind(".cjd");
					if(last == CString::npos)
					{	
						DEBUGL8("CDocument::StartFasterPasteThread: Iterator String val<%s>,DocName<%s>\n",iit->c_str(),fullname.c_str());	 
						//The page number in the source workspace
						int srcPageNum;
						PageRef pageRef;
						bool isSamePos = false;
						CString hsToInt = "0x" + fullname;
						std::istringstream istr(hsToInt);				

						// convert string page to int page
						istr>>std::setbase(0)>>srcPageNum;	

						if(srcPageNum == dstPageNum)
							isSamePos = true;	

						//GetPage from Source ClipBoard
						DEBUGL8("CDocument::StartFasterPasteThread: GetPage called\n");	 
						CString clipPath = CLIPBOARD_PATH;
						pastedocobj->m_BoxBasePath=clipPath;
						pastedocobj->m_BoxNumber="";
						pastedocobj->m_FolderName="";

						DEBUGL8("CDocument::StartFasterPasteThread: ClipboardDocName<%s>\n", clipbrdDocName.c_str());
						pastedocobj->m_DocumentName = clipbrdDocName;

						DEBUGL8("CDocument::StartFasterPasteThread: for GetPage--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", pastedocobj->m_BoxBasePath.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str(), srcPageNum);
						if(pastedocobj->GetPage(srcPageNum,pageRef)!=STATUS_OK)
						{
							DEBUGL1("CDocument::StartFasterPasteThread:GetPage of %d failed\n",srcPageNum);
							pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							return NULL;
						}	

						//InsertPage at Destination Workspace
						pastedocobj->m_BoxBasePath=curBoxBasePath;
						pastedocobj->m_BoxNumber=curBoxNumber;
						pastedocobj->m_FolderName=curFolderName;
						pastedocobj->m_DocumentName=curDocumentName;																		
						DEBUGL8("CDocument::StartFasterPasteThread: for Insert/Append/Replace Page--> m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s, page no %d\n", pastedocobj->m_BoxBasePath.c_str(), pastedocobj->m_BoxNumber.c_str(), pastedocobj->m_FolderName.c_str(), pastedocobj->m_DocumentName.c_str(), dstPageNum);
						if(dstPageNum == total + 1)
						{
							if(IsImagedataPresent == false)
							{
								if(!pageRef)
								{
									DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									return NULL;
								}
								dynamic_cast<CPage*>(pageRef.operator->())->SetImage("", "");
							}
							if(IsThumbnaildataPresent == false)	
							{
								if(!pageRef)
								{
									DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									return NULL;
								}
								dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage("", "");
							}
							if(IsSubsamplingdataPresent == false)
							{  
								if(!pageRef)
								{
									DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
									return NULL;         
								}
								dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage("", "");
							}
							DEBUGL8("CDocument::StartFasterPasteThread: AppendPage called\n");
							ret = pastedocobj->AppendPage(pageRef);
							if(ret!=STATUS_OK)
							{
								if(ret == ::STATUS_DISK_FULL)
								{
									DEBUGL1("CDocument::StartFasterPasteThread::AppendPage returned DISKFULL Error\n");
									pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullDoc_" + pastedocobj->m_sessionID) != STATUS_OK)
										DEBUGL2("CDocument::StartPasteThread: Unable to create the file\n");

									pastedocobj->m_prgShmid = NULL;
									return NULL;
								}
								else
								{	
									DEBUGL1("CDocument::StartFasterPasteThread::AppendPage failed\n");											
									pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
									return NULL;
								}
							}
							if(numRes != 0)	
								curProg = (int)((((float)count++)/((float)numRes))*100);
							if(curProg!=100)
							{
								*((int*)pPasteMapAddr) = curProg;				
								DEBUGL8("CDocument::StartFasterPasteThread::Current Progress<%d>\n",curProg);						
							}						
						}
						else 
						{
							DEBUGL8("CDocument::StartFasterPasteThread: FasterInsertPage called\n");	 
							ret = pastedocobj->FasterInsertPage(dstPageNum,pageRef);
							if(ret!=STATUS_OK)
							{
								if(ret == STATUS_DISK_FULL)
								{
									DEBUGL1("CDocument::StartFasterPasteThread::InsertPage returned DISKFULL Error\n");
									pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullDoc_" + pastedocobj->m_sessionID) != STATUS_OK)
										DEBUGL2("CDocument::StartPasteThread: Unable to create the file\n");
									pastedocobj->m_prgShmid = NULL;
									return NULL;

								}
								else
								{	
									DEBUGL1("CDocument::StartFasterPasteThread::InsertPage failed\n");											
									pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
									pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
									return NULL;
								}
							}
							if(numRes != 0)	
								curProg = (int)((((float)count++)/((float)numRes))*100);
							if(curProg!=100)
							{
								*((int*)pPasteMapAddr) = curProg;				
								DEBUGL8("CDocument::StartFasterPasteThread::Current Progress<%d>\n",curProg);						
							}						
						}		
						dstPageNum++;
					}
					else
					{
						DEBUGL8("CDocument::StartFasterPasteThread: Skipping cjd docName<%s>\n",fullname.c_str());	 										
						CString cjdFrom = CLIPBOARD_PATH + resourceKey + "/Image/" + fullname;
						DEBUGL8("CDocument::StartFasterPasteThread: cjdFrom = (%s)\n",cjdFrom.c_str());	 
						cjdFromVec.push_back(cjdFrom);
						CString cjdTo = curBoxBasePath + "/" + curDocumentName + "/Image/" + fullname;
						DEBUGL8("CDocument::StartFasterPasteThread: cjdTo = (%s)\n",cjdTo.c_str());	 
						cjdToVec.push_back(cjdTo);										

					}
				}

				if(!cjdFromVec.empty())
				{
					for(it = cjdFromVec.begin(), iit = cjdToVec.begin();it!=cjdFromVec.end();it++, iit++)
					{
						if(Utility::ResourceExist(*(it)))
						{
							DEBUGL8("CDocument::StartFasterPasteThread: cjdFrom = (%s)\n",(*(it)).c_str());	 
							DEBUGL8("CDocument::StartFasterPasteThread: cjdTo = (%s)\n",(*(iit)).c_str());	 

							if(ci::operatingenvironment::File::CopyFile(*(it),*(iit)) != STATUS_OK)
							{
								DEBUGL1("CDocument::StartFasterPasteThread::Copying cjd file failed\n");											
								pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
								pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
								return NULL;
							}

						}
					}
				}

				//Check for the CutDocument property and delete the original document
				CutFlag.clear();
				if(proputils::GetProperty(CLIPBOARD_PATH,"","",clipbrdDocName,"","cutDocument", CutFlag) != STATUS_OK)
				{
					pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
					pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
					return NULL;
				}		
				if(CutFlag=="true")
				{	
					//Obtain the original document
					DocumentRef orgDoc;
					if(Utility::GetDocument(pastedocobj->m_sessionID, orgDoc,srcBoxBasePath,srcBoxNumber,srcFolderName,srcDocumentName)!=STATUS_OK)
					{
						DEBUGL1("CDocument::StartFasterPasteThread: Obtaining Original Document failed\n");
						pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
						pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
						return NULL;
					}

					// Start to Delete
					try
					{
						if(!orgDoc)
						{
							DEBUGL1("CDocument::StartPasteThread:Page object is NULL\n");
							return NULL;         
						}
						if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
						{
							DEBUGL1("CDocument::StartFasterPasteThread: Deleting document failed\n");
							pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
							pastedocobj->ErrorFileCreation(pastedocobj->m_PasteErrfile,pastedocobj->m_prgShmid);
							return NULL;
						}
					}
					catch(exception& e)
					{
						DEBUGL1("CDocument::StartFasterPasteThread::Exception caught:(%s)\n",e.what());
						return NULL;
					}
				}	

				*((int*)pPasteMapAddr) = PROGRESS_COMPLETED;					
				pastedocobj->m_prgShmid = NULL;
				DEBUGL8("CDocument::StartFasterPasteThread::Current Progress<%d>\n",curProg);	
			}
			if(pastedocobj->m_prgShmid) { 
				*((int*)pPasteMapAddr) = PROGRESS_COMPLETED;					
				pastedocobj->m_prgShmid = NULL;
			}
			//revert back to original
			pastedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);			
			DEBUGL4("CDocument::StartFasterPasteThread: Exit\n");	
			return NULL;
		}

        void* StartDeleteThread(void * arg)
        {
            DEBUGL4("CDocument::StartDeleteThread()-- Started \n");

            DocStatus st;
            //Status retStatus;
            //Copy the passed instance of the invoking object into a local variable 
            CDocument *deletedocobj = (CDocument *)arg;
            //Copy the inputs from static variable into a local variable 
            std::vector<int>::iterator itr;
            std::vector<int> pages;
            for(itr=deletedocobj->m_DeleteVecofPages.begin();itr!=deletedocobj->m_DeleteVecofPages.end();itr++)
                pages.push_back(*itr);	

            deletedocobj->m_DeleteVecofPages.clear();

            //Create Shared memory used for writing the updated progress in it
            void *pDeleteMapAddr;
            if(!deletedocobj->m_prgShmid)
            {
                DEBUGL1("\n CDocument::StartDeleteThread: -- Failed to Create Shared Memory for Delete Progress Name \n ");
                deletedocobj->ErrorFileCreation(deletedocobj->m_DeleteErrfile,deletedocobj->m_prgShmid);
                return NULL;
            }
            else
            {
                int iShmPidSize = deletedocobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                deletedocobj->m_prgShmid->Map(pDeleteMapAddr);
                if(pDeleteMapAddr!=NULL)
                {
                    memset(pDeleteMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("\n CDocument::StartDeleteThread: -- Mapping Failed for Delete Progress Name\n");
                    deletedocobj->ErrorFileCreation(deletedocobj->m_DeleteErrfile,deletedocobj->m_prgShmid);
                    return NULL;
                }
            }
            CString deletepath = Utility::GetResourcePath(deletedocobj->m_BoxBasePath,deletedocobj->m_BoxNumber,deletedocobj->m_FolderName);

            //set the initial value of Delete Document progress as 1% . The Start Delete 
            //thread will update it as and when the operation progresses
            *((int*)pDeleteMapAddr) = 1;

            if(deletedocobj->GetStatus(st) != STATUS_OK)
            {
                DEBUGL1("CDocument::StartDeleteThread: Getting document status is failed\n");
                //Create a file indicating the Status to be not Status Ok	
                deletedocobj->ErrorFileCreation(deletedocobj->m_DeleteErrfile,deletedocobj->m_prgShmid);
                return NULL;
            }

            //check the status of the document
            if(!(st == CREATING || st == EDITING)) 
            {
                DEBUGL1("CDocument::StartDeleteThread::Document is NOT CREATING or EDITING\n");
                //Create a file indicating the Status to be not Status Ok	
                deletedocobj->ErrorFileCreation(deletedocobj->m_DeleteErrfile,deletedocobj->m_prgShmid);
                return NULL;
            }
            //make a local copy of the member variables
            CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
            boxbasepath_org = deletedocobj->m_BoxBasePath;
            boxnumber_org = deletedocobj->m_BoxNumber;
            folderName_org = deletedocobj->m_FolderName;
            docName_org = deletedocobj->m_DocumentName;

            if(st == EDITING)
            {
                //Initialize WorkSpace
                deletedocobj->WorkSpaceInit();
            }		

	    int total;
	    if(deletedocobj->GetTotalPage(total)!=STATUS_OK)
	    {
		    DEBUGL1("CDocument::StartDeleteThread::Getting total pages failed\n");
		    return NULL;
	    }

	    std::vector<int>::iterator it;
	    for(it=pages.begin(); it!=pages.end(); it++)
	    {
		    if(*it <= 0|| *it > total )
		    {
			    DEBUGL1("CDocument::StartDeleteThread::Invalid pageno=%d\n",*it);
			    return NULL;
		    }
	    }

            //Sort the vector
            std::sort(pages.begin(), pages.end());	

            int curProg =0;
            int count =1;
            int numResTmp = pages.size();
            *((int*)pDeleteMapAddr)=1;
            std::vector<int>::iterator pageno;
            for(pageno=pages.end()-1;pageno>=pages.begin();pageno--)
            {
               Status drst = deletedocobj->DeleteSinglePage(*pageno);
               DEBUGL4("CDocument::StartDeleteThread <%d>\n",*pageno);
               if(drst != STATUS_OK)
               {
                  if(drst == STATUS_DISK_FULL)
                  {
                     DEBUGL1("CDocument::StartDeleteThread: Failed to delete page due to disk full <%d>",(*pageno));
                     if(Utility::CreateUniqueFile(deletepath, ".deleteDiskFullDoc_" + deletedocobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" Cdocument::StartDeleteThread: Unable to create the file\n");
                     deletedocobj->m_prgShmid = NULL;
                     return NULL;

                  }
                  DEBUGL1("CDocument::StartDeleteThread: Failed to delete page<%d>",(*pageno));
                  deletedocobj->RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);	
                  deletedocobj->ErrorFileCreation(deletedocobj->m_DeleteErrfile,deletedocobj->m_prgShmid);
                  return NULL;								
               }
               curProg = (int)(((float)count/(float)numResTmp)*100);
               if(curProg != 100)
	       {
		       *((int*)pDeleteMapAddr)= curProg;
		       DEBUGL1("CDocument::StartDeleteThread: Current Progress is<%d> count = <%d>, numResTmp = <%d> curProg = <%d> \n",*((int*)pDeleteMapAddr),count,numResTmp,curProg);
	       }
               count++;
           }
            *((int*)pDeleteMapAddr) = PROGRESS_COMPLETED;			
            deletedocobj->m_prgShmid = NULL;
            DEBUGL8("CDocument::StartDeleteThread::Current Progress<%d>\n",curProg);

            DEBUGL4("CDocument::StartDeleteThread: Exit\n");	
            return NULL;
        }

        // constructor
        CDocumentProperties::CDocumentProperties(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) :
            m_BoxBasePath(boxbasepath), 
            m_BoxNumber(boxnumber), 
            m_FolderName(foldername),
            m_DocumentName(documentname)
        {
            //Set Last access date as webdav property							
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            CString local = Utility::GetUnixTime();		

            std::map<CString, CString> PropertyMap;
            CString xmlfile("documentproperties.xml");
            PropertyMap["lastModifiedDate"] =  local;
            PropertyMap["lastAccessDate"] =  local;
            Status st = Utility::SetProperties(propertypath,xmlfile,PropertyMap);	
            if(st != STATUS_OK)
            {
                DEBUGL1("\n CDocumentProperties::CDocumentProperties: Failed to set the property \n");	
            }
        }

        // destructor
        CDocumentProperties::~CDocumentProperties()
        {
        }

        /**
         * get a name of the document
         * @param[out] name - a name of the container
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetName(CString &name)
        {
            name=m_DocumentName;
            return STATUS_OK;    
        }

        /**
         * get total page of the document
         * @param[out] total - total page of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetTotalPage(int &total)
        {
            CString val="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"", "totalPages", val)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetTotalPage::failed to get the property\n");
                return STATUS_FAILED;
            }											

            std::istringstream iss(val);
            iss >> total;							
            return STATUS_OK;
        }

        /**
         * get "from" property of the document
         * @param[out] from - "from" property of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetFromProperty(CString &from)
        {
            from="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"", "from", from)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetFromProperty::failed to get the property\n");
                return STATUS_FAILED;
            }								
            return STATUS_OK;
        }

        /**
         * get reception time of the document
         * @param[out] receptiontime - reception time of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetReceptionTime(CString &receptiontime)
        {
            receptiontime="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","receptionTime", receptiontime)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetReceptionTime::failed to get the property\n");
                return STATUS_FAILED;
            }					
            return STATUS_OK;
        }

        /**
         * get reception number of the document
         * @param[out] receptionnum - reception number of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetReceptionNumber(CString &receptionnum)
        {
            receptionnum="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","receptionNumber", receptionnum)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetReceptionNumber::failed to get the property\n");
                return STATUS_FAILED;
            }			
            return STATUS_OK;
        }
        Status CDocumentProperties::GetStatus(DocStatus &st) 
        {
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            if(Utility::ResourceExist( path + statusfilename::CREATING)) 
            {
                st = CREATING;
            } 
            else if(Utility::ResourceExist( path + statusfilename::READY)) 
            {
                st = READY;
            }
            else if(Utility::ResourceExist( path + statusfilename::USING)) 
            {
                st = USING;
            }
            else if(Utility::ResourceExist( path + statusfilename::EDITING)) 
            {
                st = EDITING;
            }
            else if(Utility::ResourceExist( path + statusfilename::DELETING)) 
            {
                st = DELETING;
            } 
            else if(Utility::ResourceExist( path + statusfilename::WAITING)) 
            {
                st = WAITING;		
            }
			else if(Utility::ResourceExist( path + statusfilename::RESERVING)) 
            {
                st = RESERVING;		
            }

            else 
            {
                // if file is not found, document status is considered as CREATING.
                st = CREATING;
                if(Utility::CreateFile(path, statusfilename::CREATING) != STATUS_OK) 
                {
                    DEBUGL1("CDocumentProperties::GetStatus::creating status file is failed\n");
                    return STATUS_FAILED;
                }
            }
            return STATUS_OK;
        }

        /**
         * get fromString of the document
         * @param[out] fromString - fromString of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetFromString(CString &fromString)
        {
            fromString="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","fromString", fromString)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetFromString::failed to get the property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;

        }
        /**
         * get fromStringFirstName of the document
         * @param[out] firstName - firstName of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetFromStringFirstName(CString &firstName)
        {
            firstName ="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","fromStringFirstName", firstName)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetFromStringFirstName::failed to get the firstName property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * get fromStringLastName of the document
         * @param[out] lastName - lastName of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetFromStringLastName(CString &lastName)
        {
            lastName ="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","fromStringLastName", lastName)!= STATUS_OK)
            {
                DEBUGL1("CDocument::GetFromStringLastName::failed to get the lastName property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * get the status for FAX received data.
         * @param[out] receivedData - the status for FAX received data. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */	   
        Status CDocumentProperties::GetStatusOfReceivedData(CString &receivedData)		
        {
            receivedData=""; 
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","StatusOfReceivedData",receivedData)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::GetStatusOfReceivedData::failed to get the statusOfReceivedData property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * get the status for hard copy.
         * @param[out] hardCopy - the status for hard copy. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */
        Status CDocumentProperties::GetStatusOfHardCopy(CString &hardCopy) 
        {
            hardCopy="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","StatusOfHardCopy",hardCopy)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::GetStatusOfHardCopy::failed to get the statusOfHardCopy property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        } 

        /**
         * get the status for relay report.
         * @param[out] relayReport - the status for relay report. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */	   
        Status CDocumentProperties::GetStatusOfRelayReport(CString &relayReport)
        {
            relayReport="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","StatusOfRelayReport",relayReport)!=STATUS_OK)
            {	
                DEBUGL1("CDocument::GetStatusOfRelayReport::failed to get the statusOfRelayReport property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * get the status of polling transmission
         * @param[out] pollingTransmission - the status for polling transmission.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocumentProperties::GetStatusOfPollingTransmission(CString &pollingTransmission)
        {
            pollingTransmission = "";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","statusOfPollingTransmission",pollingTransmission) != STATUS_OK)
            {
                DEBUGL1("CDocument::GetStatusOfPollingTransmission::failed to get the statusOfPollingTransmission property\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * set the status for FAX received data.
         * @param[in] recievedData - the status for FAX received data. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */	   
        Status CDocumentProperties::SetStatusOfReceivedData(CString receivedData)
        {
            DEBUGL4("CDocumentProperties::SetStatusOfReceivedData:Enter\n");
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("documentproperties.xml");
            PropertyMap.insert(property_pair::value_type("StatusOfReceivedData",receivedData.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            DEBUGL4("CDocumentProperties::SetStatusOfReceivedData:Exit\n");
            return st;
        } 

        /**
         * set the status for hard copy.
         * @param[in] hardCopy - the status for hard copy. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */	   
        Status CDocumentProperties::SetStatusOfHardCopy(CString hardCopy)
        {
            DEBUGL4("CDocumentProperties::SetStatusOfHardCopy:Enter\n");
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("documentproperties.xml");
            PropertyMap.insert(property_pair::value_type("StatusOfHardCopy",hardCopy.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            DEBUGL4("CDocumentProperties::SetStatusOfHardCopy:Exit\n");
            return st;
        } 

        /**
         * set the status for relay report.
         * @param[in] relayReport - the status for relay report. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetDocumentList       
         */
        Status CDocumentProperties::SetStatusOfRelayReport(CString relayReport)
        {
            DEBUGL4("CDocumentProperties::SetStatusOfRelayReport:Enter\n");
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("documentproperties.xml");
            PropertyMap.insert(property_pair::value_type("StatusOfRelayReport",relayReport.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            DEBUGL4("CDocumentProperties::SetStatusOfRelayReport:Exit\n");
            return st;
        } 

        /**
         * set the status for polling transmission
         * @paramin] pollingTransmission - the status for polling transmission
         * return STATUS_OK on success,
         *        STATUS_FAILED on failure.
         */
        Status CDocumentProperties::SetStatusOfPollingTransmission(CString pollingTransmission)
        {
            DEBUGL4("CDocumentProperties::SetStatusOfPollingTransmission:Enter\n");
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("documentproperties.xml");
            PropertyMap.insert(property_pair::value_type("statusOfPollingTransmission",pollingTransmission.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            DEBUGL4("CDocumentProperties::SetStatusOfPollingTransmission:Exit\n");
            return st;
        }

        Status CDocument::SetWebDAVProperty(CString key, CString value) 
        {
            typedef std::map<CString, CString> pair;
            std::map<CString, CString> PropertyMap;
            CString xmlfile("documentproperties.xml");
            CString modifiedtime = Utility::GetUnixTime();
            m_WebDAVProperties[key] = value;
            PropertyMap.insert(pair::value_type(key.c_str(), value.c_str()));
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            return st;
        }
	Status CDocument::SetWebDAVProperties(std::map<CString, CString> WebDAVPropertyMap)
	{
		std::map<CString,CString>::iterator pIt;
		typedef std::map<CString, CString> pair;
		std::map<CString, CString> PropertyMap;
		CString xmlfile("documentproperties.xml");
		CString modifiedtime = Utility::GetUnixTime();
		for(pIt = WebDAVPropertyMap.begin();pIt != WebDAVPropertyMap.end();pIt++)
		{
			m_WebDAVProperties[pIt->first] = m_WebDAVProperties[pIt->second];
			PropertyMap.insert(pair::value_type(pIt->first, pIt->second));
			DEBUGL8("CDocument::SetWebDAVProperties Key is (%s)  value (%s) \n",pIt->first, pIt->second);
		}
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            return st;
	}
        /**
         * get a map of paper size in Document 
         * @param[out] papermap - a map of paper size in Document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetPaperSizeMap(PaperSizeMap &papermap)
        {
            DEBUGL4("CDocument::GetPaperSizeMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","paperSizeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetPaperSizeMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetPaperSizeMap:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            papermap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                PaperSize eVal;							
                int abc = atoi(first.c_str());
                eVal = (PaperSize)abc;
                papermap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CDocument::GetPaperSizeMap Exit\n");		
            return STATUS_OK;
        }

        /**
         * get a map of color mode in Document 
         * @param[out] colormap - a map of color mode in Document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetColorModeMap(ColorModeMap &colormap)
        {
            DEBUGL4("CDocument::GetColorModeMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","colorModeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetColorModeMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetColorModeMap:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            colormap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                ColorMode eVal;							
                if(first == "Color")
                    eVal = COLOR;
                else if (first == "Gray")
                    eVal = GRAY;
                else if (first == "Mono")
                    eVal = MONO;

                colormap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CDocument::GetColorModeMap Exit\n");		
            return STATUS_OK;

        }

        /**
         * get a map of job type in Document 
         * @param[out] jobmap - a map of job type in Document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetJobTypeMap(JobTypeMap &jobmap)
        {
            DEBUGL4("CDocument::GetJobTypeMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","jobTypeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetJobTypeMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetJobTypeMap:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            jobmap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                jobmap.insert(make_pair(first,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CDocument::GetJobTypeMap Exit\n");		
            return STATUS_OK;

        }

        /**
         * get a map of horizontal resolution in Document 
         * @param[out] hrmap - a map of horizontal resolution in Document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetHorizontalResolutionMap(ResolutionMap &hrmap)
        {
            DEBUGL4("CDocument::GetHorizontalResolutionMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","horizontalResolutionMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetHorizontalResolutionMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetHorizontalResolutionMap:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            hrmap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                int iVal = atoi(first.c_str());
                hrmap.insert(make_pair(iVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CDocument::GetHorizontalResolutionMap Exit\n");		
            return STATUS_OK;
        }


        /**
         * get a map of vertical resolution in Document 
         * @param[out] vrmap - a map of vertical resolution in Document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetVerticalResolutionMap(ResolutionMap &vrmap)
        {
            DEBUGL4("CDocument::GetVerticalResolutionMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","verticalResolutionMap", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetVerticalResolutionMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CDocument::GetVerticalResolutionMap:Get VAL for paperSizeMap <%s>\n", val.c_str());					

            vrmap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                int iVal = atoi(first.c_str());
                vrmap.insert(make_pair(iVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CDocument::GetVerticalResolutionMap Exit\n");		
            return STATUS_OK;

        }

        /**
         * set input page count of the document
         * @param[in] count - input page count of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::SetInputPageCount(int count)
        {
            DEBUGL4("CDocument::SetInputPageCount Enter\n");		
            if(SetWebDAVProperty("InputPageCount", count) != STATUS_OK) 
            {
                DEBUGL1("CDocument::SetInputPageCount failed\n");		
                return STATUS_FAILED;
            }
            DEBUGL4("CDocument::SetInputPageCount Exit\n");		
            return STATUS_OK;
        }

        /**
         * get input page count of the document
         * @param[out] count - input page count of the document
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CDocument::GetInputPageCount(int &count)
        {
            DEBUGL4("CDocument::GetInputPageCount Enter\n");		
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","InputPageCount", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetInputPageCount: failed\n");
                return STATUS_FAILED;
            }
            if(val == "")
                val = "0";
            std::istringstream iss(val);
            iss >> count;
            DEBUGL4("CDocument::GetInputPageCount Exit\n");		
            return STATUS_OK;
			}
			Status CDocument::GetViewPageList(PageList &list) {
				return GetViewPageList(list, 1, 65535);
			}	

			Status CDocument::GetViewPageList(PageList &list, unsigned int from, unsigned int size) {
				DocStatus st;
				DEBUGL4("CDocument::GetViewPageList:Enter\n");

				FL_FILE_MAN_FILE *systemDataFile = new FL_FILE_MAN_FILE;
				FL_FILE_MAN_FILE *subsamplingSystemDataFile = new FL_FILE_MAN_FILE;
				FL_FILE_MAN_FILE *thumbnailSystemDataFile = new FL_FILE_MAN_FILE;
				memset(systemDataFile,'\0',sizeof(FL_FILE_MAN_FILE));
				memset(subsamplingSystemDataFile,'\0',sizeof(FL_FILE_MAN_FILE));			
				memset(thumbnailSystemDataFile,'\0',sizeof(FL_FILE_MAN_FILE));
				//make a local copy of the member variables
				CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
				boxbasepath_org = m_BoxBasePath;
				boxnumber_org = m_BoxNumber;
				folderName_org = m_FolderName;
				docName_org = m_DocumentName;

				if(this->GetStatus(st) != STATUS_OK) {
					DEBUGL1("CDocument::GetViewPageList::Getting document status is failed\n");
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
						return STATUS_FAILED;
				}
				if(st == DELETING) {
					DEBUGL1("CDocument::GetViewPageList::Document is DELETING\n");
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
					return STATUS_FAILED;
				}


				if(st == EDITING)
				{	
					//check if the session-id property set on the document is same as the current sessionID
					CString val;
					CString resourceKey=Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName)+"/";
					if(GetWebDAVProperty("sessionID", val)!= STATUS_OK)
					{
							DEBUGL2("CDocument::GetViewPageList: GetProperty of sessionID failed\n");
							val.clear();
						}
						DEBUGL8("CDocument::GetViewPageList::SessionID<%s>\n",val.c_str());
						if(val==m_sessionID)
						{	
								//Initialize WorkSpace
								WorkSpaceInit();
						}	
				}
				CString docpath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);
				list.clear();
				CString path = docpath + "/Image/" + CString(SYSTEMFILE);
				Status openStatus = STATUS_OK;
				if((openStatus = OpenSystemDataFile(systemDataFile, path)) != STATUS_OK) {
					if( openStatus == STATUS_INVALID_URI)
					{
						DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Image system file does not exist\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
						delete systemDataFile;
						delete thumbnailSystemDataFile;
						delete subsamplingSystemDataFile;
						return STATUS_OK;
					}
					DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Image\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
					return STATUS_FAILED;
				}

				path =docpath+ "/Thumbnail/" + CString(SYSTEMFILE);						
				if((openStatus = OpenSystemDataFile(thumbnailSystemDataFile, path)) != STATUS_OK) {
					if( openStatus == STATUS_INVALID_URI)
					{
						DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Thumbnail system file does not exist\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
						delete systemDataFile;
						delete thumbnailSystemDataFile;
						delete subsamplingSystemDataFile;
						return STATUS_OK;
					}
					DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Thumbnail\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
					return STATUS_FAILED;
				}
				path = docpath +"/Subsampling/" + CString(SYSTEMFILE);												
				if((openStatus = OpenSystemDataFile(subsamplingSystemDataFile, path)) != STATUS_OK) {
					if( openStatus == STATUS_INVALID_URI)
					{
						DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Subsampling system file does not exist\n");
						RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
						delete systemDataFile;
						delete thumbnailSystemDataFile;
						delete subsamplingSystemDataFile;
						return STATUS_OK;
					}
					DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Subsampling\n");
					RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
					return STATUS_FAILED;
				}

				int total = 0;// = m_SystemDataFile.sFileMan.hFlPageNum;;
				Status stat = GetTotalPage(total);//m_SystemDataFile.sFileMan.hFlPageNum;
				if(stat != STATUS_OK) {
					delete systemDataFile;
					delete thumbnailSystemDataFile;
					delete subsamplingSystemDataFile;
					DEBUGL1("CDocument::GetViewPageList::Error while getting the pagelist\n");
					return stat;
				}

				PageRef page;
				for(unsigned int pageno = from, cnt = 0; (cnt < size && pageno <= total); pageno++, cnt++) {
					if(GetPage(pageno, page, systemDataFile, thumbnailSystemDataFile, subsamplingSystemDataFile) != STATUS_OK) {
						DEBUGL1("CDocument::GetViewPageList::getting page %d is failed\n", pageno);
						break;
					}
					list.push_back(page);
				}
				RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
				delete systemDataFile;
				delete thumbnailSystemDataFile;
				delete subsamplingSystemDataFile;
				return STATUS_OK;
			}
        Status CDocument::GetPage(int pageno, PageRef &page,
							 FL_FILE_MAN_FILE *systemDataFile, FL_FILE_MAN_FILE *thumbnailSystemDataFile, 
							 FL_FILE_MAN_FILE *subsamplingSystemDataFile) {

		//For PageLogBox PAGE_LIMIT
		CString boxbasepath_new("");
		int pos;
		pos =  m_BoxBasePathOrg.rfind("/");
		boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
			std::ostringstream oss;
			oss << pageno;

			//make a local copy of the member variables
			CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			boxbasepath_org = m_BoxBasePath;
			boxnumber_org = m_BoxNumber;
			folderName_org = m_FolderName;
			docName_org = m_DocumentName;

			DocStatus st;
		if(!m_insertblankpage)	    
		{
			DEBUGL1("CDocument::GetPage:: pageno = (%d) (%s)\n", pageno, boxbasepath_new.c_str());
			if(boxbasepath_new == "PageLogBoxes")
			{
				DEBUGL8("Entered in the check\n");
				if((static_cast<unsigned>(pageno) > CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
				{
					DEBUGL1("CDocument::GetPage::Page Limit reached for PAGELOGBOXES\n");
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}
				else
					DEBUGL8("Entered in the check1\n");

			}
			else if((pageno <= 0) || (static_cast<unsigned>(pageno) > CBoxDocument::PAGE_LIMIT)) {
				DEBUGL1("CDocument::GetPage::Invalid page number %d\n", pageno);
				return STATUS_FAILED;
			}
			if(this->GetStatus(st) != STATUS_OK) {
				DEBUGL1("CDocument::GetPage::Getting document status is failed\n");
				return STATUS_FAILED;
			}
			if(st == DELETING) {
				DEBUGL1("CDocument::GetPage::Document is deleting\n");
				return STATUS_FAILED;
			}

			if(st == EDITING)
			{	
				//check if the session-id property set on the document is same as the current sessionID
				CString val;
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", val)!=STATUS_OK)
				{
					DEBUGL2("CDocument::GetPage: GetProperty of sessionID failed\n");
					val.clear();
				}	
				DEBUGL8("CDocument::GetPage: val = (%s),  m_sessionID = (%s)\n",val.c_str(),(m_sessionID).c_str());
				if(val==m_sessionID)
				{	
					//Initialize WorkSpace
					DEBUGL8("CDocument::GetPage: sessionIDs are same.. call WorkSpaceInit\n");
					WorkSpaceInit();
				}	
			}
		}
		else 
			WorkSpaceInit();
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);

            FL_PAGE_MAN_TBL systemfile;
            FL_PAGE_MAN_TBL thumbnail;
            FL_PAGE_MAN_TBL subsampling;
            memset((FL_PAGE_MAN_TBL *)&(systemfile),'\0',sizeof(FL_PAGE_MAN_TBL));
            memset((FL_PAGE_MAN_TBL *)&(subsampling),'\0',sizeof(FL_PAGE_MAN_TBL));			
            memset((FL_PAGE_MAN_TBL *)&(thumbnail),'\0',sizeof(FL_PAGE_MAN_TBL));

            DEBUGL8("CDocument::GetPage: m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());						

            // check SystemFile
            CString systemfilepath = Utility::GetResourcePath(path + "/Image/" + SYSTEMFILE);

            DEBUGL8("CDocument::GetPage:systemDataFile.sFileMan.hFlPageNum<%d>,pageno<%d>",systemDataFile->sFileMan.hFlPageNum,pageno);						
            if(systemDataFile->sFileMan.hFlPageNum < pageno) {
                DEBUGL1("CDocument::GetPage::Page %d doesn't exist\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            systemfile = systemDataFile->sPageManTbl[pageno - 1];
            systemfilepath = Utility::GetResourcePath(path + "/Thumbnail/" + SYSTEMFILE);

            if(thumbnailSystemDataFile->sFileMan.hFlPageNum >= pageno) {
                thumbnail = thumbnailSystemDataFile->sPageManTbl[pageno - 1];
            }

            systemfilepath = Utility::GetResourcePath(path + "/Subsampling/" + SYSTEMFILE);

            if(subsamplingSystemDataFile->sFileMan.hFlPageNum >= pageno) {
                subsampling = subsamplingSystemDataFile->sPageManTbl[pageno - 1];
            }

            Status ret;
            try
            {
                page = new CPage(pageno, path, m_BoxBasePath);

                if(!page)
                {
                    DEBUGL1("CDocument::GetPage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CPage*>(page.operator->())->LoadProperties(systemfile,subsampling,thumbnail);
                if(ret != STATUS_OK) {
                    DEBUGL1("CDocument::GetPage::Loading Page is failed\n");
                    page = NULL; // release
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return ret;
                }	
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
            }
            catch(exception& e)
            {
                DEBUGL8("CDocument::GetPage::Loadin Page failed because an exception  was caught:(%s)\n",e.what());
                page = NULL;
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

	Status CDocument::OpenSystemDataFile(FL_FILE_MAN_FILE *system, CString path) {
		DEBUGL4("CDocument::OpenSystemDataFile: Enter\n");
		int len = path.rfind("/");
		CString systemFileName = path.substr(len+1,path.length());
		int len1 = path.rfind("/", len - 1);
		CString pagetype = path.substr(len1 + 1, (len - (len1 + 1))); 
		CString docpath = path.substr(0,len1+1);
		DEBUGL8("CDocument::OpenSystemDataFile: critical section for %s:%s\n", pagetype.c_str(), systemFileName.c_str());
		CString pLockpath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/"+pagetype+"/";
		DEBUGL8("CDocument::OpenSystemDataFile: pLockpath is  [%s]\n", pLockpath.c_str());
		int fdescLockfile;
		CString locktypefile = pagetype + "_systemfilelock";
		CString uriPathToLock = docpath + "." + locktypefile;
		//Skip critical section if the /work/ci/insertblankpageflag exists
		bool flockType = true;
		if(!m_insertblankpage)
		{
			if(Utility::AcquireLockforSystemfile(uriPathToLock, fdescLockfile, flockType) != STATUS_OK)
			{
				DEBUGL1("CDocument::OpenSystemDataFile::AcquireLockforSystemfile failed\n");
				return STATUS_FAILED;
			}
		}
		DEBUGL8("CDocument::OpenSystemDataFile: Enter -- Opening %s systemfile\n",path.c_str());
		int FD;
		int errnum = 0;
		FD = open(path.c_str(),O_RDONLY);
		errnum=errno;

		if(FD==-1)
		{
			DEBUGL1("CDocument::OpenSystemDataFile:file open error\n");
			if(!m_insertblankpage)
		    		if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK)
					DEBUGL1("CDocument::OpenSystemDataFile::ReleaseLockforSystemfile failed\n");
			if( errnum == ENOENT) {
				DEBUGL1("CDocument::OpenSystemDataFile:: File doesn't exist\n");
				return STATUS_INVALID_URI;
			}							
			return STATUS_FAILED;
		}

		if(read(FD,system, sizeof(FL_FILE_MAN_FILE) ) == -1) {
			DEBUGL1("CDocument::OpenSystemDataFile::Reading system data file is failed\n");
			close(FD);
			if(!m_insertblankpage)
		    		if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK)
		    			DEBUGL1("CDocument::OpenSystemDataFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
			return STATUS_FAILED;
		}
		close(FD);
		if(!m_insertblankpage)
		{
			if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK){
				DEBUGL1("CDocument::OpenSystemDataFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
				return STATUS_FAILED;
			}
		}
		DEBUGL4("CDocument::OpenSystemDataFile: Exit\n");
		return STATUS_OK;
	}
    
 	Status  CDocument::SlidePagesForMove(int srcpageNo, int dstpageNo, FL_FILE_MAN_FILE &systemfile, bool subsampling_exists, FL_FILE_MAN_FILE &subsampling, bool thumbnail_exists, FL_FILE_MAN_FILE &thumbnail)
    {
        Status ds;
        int to = srcpageNo;
        int dir;
        if(srcpageNo < dstpageNo) {
            dir = 1;
        } else {
            dir = -1;
        }
        Ref<Page> pageRef;
        CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
        CString srcpath, dstpath, sExt, fromstr, tostr;
        while (to != dstpageNo) {
            int from = to + dir;
            DEBUGL8("CDocument::SlidePagesForMove: from=%d to=%d\n", from, to);
            // slide files
            if(GetPage(from, pageRef) != STATUS_OK)
            {
                DEBUGL1("CDocument::SlidePagesForMove::getting page %d is failed\n", from);
                return STATUS_FAILED;
            }
            fromstr = Utility::GetHexadecimalPageNo(from);
            tostr = Utility::GetHexadecimalPageNo(to);
            if(thumbnail_exists)
            {
                thumbnail.sPageManTbl[to-1] = thumbnail.sPageManTbl[from-1];
                sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(THUMBNAILPAGETYPE);
                srcpath = path+"Thumbnail/"+ fromstr +sExt;
                dstpath = path+"Thumbnail/"+ tostr + sExt;
                dynamic_cast<CPage*>(pageRef.operator->())->SetThumbnailImage(dstpath, tostr);
                dynamic_cast<CPage*>(pageRef.operator->())->UpdateThumbnailName(thumbnail.sPageManTbl[to-1]);
                ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),dstpath.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::SlidePagesForMove::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                    return ds;
                }
            }
            if(subsampling_exists) 
            {
                subsampling.sPageManTbl[to-1] = subsampling.sPageManTbl[from-1];
                sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);								
                srcpath = path+"Subsampling/"+ fromstr +sExt;
                dstpath = path+"Subsampling/"+ tostr +sExt;
                dynamic_cast<CPage*>(pageRef.operator->())->SetSubsamplingImage(dstpath, tostr); 
                dynamic_cast<CPage*>(pageRef.operator->())->UpdateSubsamplingName(subsampling.sPageManTbl[to-1]);
                ds = ci::operatingenvironment::File::MoveFile(srcpath, dstpath);
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::SlidePagesForMove::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),dstpath.c_str());
                    return ds;
                }
            }
            systemfile.sPageManTbl[to-1] = systemfile.sPageManTbl[from-1];
            srcpath = path+"Image/"+fromstr;
            dstpath = path+"Image/"+ tostr;
            sExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(IMAGEPAGETYPE);															
            CString srcpathExt = srcpath + sExt;
            CString dstpathExt = dstpath + sExt;							
            dynamic_cast<CPage*>(pageRef.operator->())->SetImage(dstpathExt,tostr);
            dynamic_cast<CPage*>(pageRef.operator->())->UpdateImageName(systemfile.sPageManTbl[to-1]);
            ds =  ci::operatingenvironment::File::MoveFile(srcpathExt, dstpathExt);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::SlidePagesForMove::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                return ds;
            }
            CString srcPagePropertyFile  = path + "Image/" + "pageproperties_" + fromstr + ".xml";
            CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + tostr + ".xml";
            ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFile, dstPagePropertyFile);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::SlidePageForMove::Moving property file from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFile.c_str(),dstPagePropertyFile.c_str());
                return ds;
            }
            CString srcPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(from) + "_dom";
            CString dstPagePropertyFiledom  = path + "Image/" + "pageproperties_" + Utility::GetHexadecimalPageNo(to) + "_dom";
            ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFiledom, dstPagePropertyFiledom);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::SlidePageForMove::Moving property dom file from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFiledom.c_str(),dstPagePropertyFiledom.c_str());
                return ds;
            }
            srcpathExt = srcpath + ".cjd"; 
            dstpathExt = dstpath + ".cjd";
            if(Utility::ResourceExist(srcpathExt))
            {
                ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),dstpathExt.c_str());
                if(ds != STATUS_OK)
                {
                    DEBUGL1("CDocument::SlidePageForMove::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),dstpathExt.c_str());
                    return ds;
                }
            }
            to = from;
        }
        return STATUS_OK;
    }

    Status CDocument::UpdateSystemFile(FL_FILE_MAN_FILE &systemfile, CString path) {
        CString tmppath = Utility::GetCITmpPath();
        tmppath += m_DocumentName + "_Image_" + CString(SYSTEMFILE);
        ByteStreamRef bs = File::Open(tmppath, "w");
        bs->WriteN(&systemfile, 1, sizeof(FL_FILE_MAN_FILE));
        bs->Close();
        Status ds = ci::operatingenvironment::File::CopyFile(tmppath,path);
        if(ds!=STATUS_OK)
        {
            if(ds == STATUS_DISK_FULL)
            {
                DEBUGL1("CDocument::UpdateSystemFile::PutResource returned DISKFULL Error\n");
                return STATUS_DISK_FULL;
            }
            else
            {
                DEBUGL1("CDocument::UpdateSystemFile::PutResource %s to %s is failed\n",tmppath.c_str(), path.c_str());
                return STATUS_FAILED;
            }
        }
        DEBUGL8("CDocument::UpdateSystemFile::Systemfile %s Putting SuccessFull\n", path.c_str());
        File::DeleteFile(tmppath);
        return STATUS_OK;
    }

    bool CDocument::hasSubsampling(PageRef page) {
        CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";		
        CString sExt = dynamic_cast<CPage*>((page).operator->())->GetExtension(SUBSAMPLINGPAGETYPE);						
        CString srcpath = path+"Subsampling/"+Utility::GetHexadecimalPageNo(1)+sExt;
        if(Utility::ResourceExist(srcpath)==true)
        {
            return true;
        }
        return false;
    }

    bool CDocument::hasThumbnail(PageRef page) {
        CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
        CString sExt = dynamic_cast<CPage*>((page).operator->())->GetExtension(THUMBNAILPAGETYPE);
        CString srcpath = path+"Thumbnail/"+Utility::GetHexadecimalPageNo(1)+sExt;
        if(Utility::ResourceExist(srcpath)==true)
        {
            return true;
        }
        return false;
    }

    Status  CDocument::MovePage(int srcpageNo, int dstpageNo )
    {
        DEBUGL4("CDocument::MovePage:Enter\n");
        int total;
        DocStatus st;
        if(srcpageNo == dstpageNo)
        {
            DEBUGL1("CDocument::MovePage::source & destination page numbers are same srcpageNo=%d or dstpageNo=%d\n",srcpageNo,dstpageNo);
            return STATUS_OK;
        }
        if(this->GetStatus(st) != STATUS_OK) 
        {
            DEBUGL1("CDocument::MovePage::Getting document status is failed\n");
            return STATUS_FAILED;
        }
        if(!(st == CREATING)) 
        {
            DEBUGL1("CDocument::MovePage::Document is NOT CREATING\n");
            return STATUS_FAILED;
        }
        if(this->GetTotalPage(total)!=STATUS_OK)
        {	
            DEBUGL1("CDocument::MovePage::Getting total pages failed\n");
            return STATUS_FAILED;
        }
        if((srcpageNo <= 0) || (srcpageNo > total) || (dstpageNo<=0) || (dstpageNo > total))
        {
            DEBUGL1("CDocument::MovePage::Invalid srcpageNo=%d or dstpageNo=%d\n",srcpageNo,dstpageNo);
            return STATUS_OUT_OF_RANGE;
        }

        Status ds;
        CString srcpath, dstpath, sExt;
        PageRef pageRef=NULL;

        // open each SystemFiles
        CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName) + "/";
        FL_FILE_MAN_FILE systemfile;
        CString systemfilepath = Utility::GetResourcePath(path + "Image/" + SYSTEMFILE);
        if(OpenSystemDataFile(systemfile, systemfilepath) != STATUS_OK) 
        {
            DEBUGL1("CDocument::MovePage::OpenSystemDataFile Failed to open Image systemfile\n");
            return STATUS_FAILED;
        }

        if(GetPage(1,pageRef) != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::getting page 1 details failed\n");
            return STATUS_FAILED;
        }
        FL_FILE_MAN_FILE subsampling;
        bool subsampling_exists = this->hasSubsampling(pageRef);
        if(subsampling_exists) {
            systemfilepath = Utility::GetResourcePath(path + "Subsampling/" + SYSTEMFILE);
            if(OpenSystemDataFile(subsampling, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::MovePage::OpenSystemDataFile Failed to open subsampling systemfile\n");
                return STATUS_FAILED;
            }
        }
        FL_FILE_MAN_FILE thumbnail;
        bool thumbnail_exists = this->hasThumbnail(pageRef);
        if(thumbnail_exists) {
            systemfilepath = Utility::GetResourcePath(path + "Thumbnail/" + SYSTEMFILE);
            if(OpenSystemDataFile(thumbnail, systemfilepath) != STATUS_OK) 
            {
                DEBUGL1("CDocument::MovePage::OpenSystemDataFile Failed to open thumbnail systemfile\n");			
                return STATUS_FAILED;
            }
        }

        // Backup source page
        if(GetPage(srcpageNo, pageRef) != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::getting page %d is failed\n", srcpageNo);
            return STATUS_FAILED;
        }
        FL_PAGE_MAN_TBL pageinfo, subsamplinginfo, thumbnailinfo; // Page Information in SystemFile
        CString imagetmp, subsamplingtmp, thumbnailtmp, cjdtmp, imageExt, subsamplingExt, thumbnailExt;
        CString pagestr;
        CString tmppath = Utility::GetCITmpPath();

        memcpy(&pageinfo, &systemfile.sPageManTbl[srcpageNo-1], sizeof(FL_PAGE_MAN_TBL));
        imageExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(IMAGEPAGETYPE);															
        pagestr = Utility::GetHexadecimalPageNo(srcpageNo);
        srcpath = path+"Image/"+ pagestr;
        dstpath = tmppath + m_DocumentName + "_Image_" + pagestr;
        CString srcpathExt = srcpath + imageExt;
        imagetmp = dstpath + imageExt;
        ds =  ci::operatingenvironment::File::MoveFile(srcpathExt, imagetmp);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),imagetmp.c_str());
            return ds;
        }
        CString srcPagePropertyFile  = path + "Image/" + "pageproperties_" + pagestr + ".xml";
        CString tmpPagePropertyFile  = tmppath + m_DocumentName + "_Image_" + "pageproperties_" + pagestr + ".xml";
        ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFile, tmpPagePropertyFile);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFile.c_str(),tmpPagePropertyFile.c_str());
            return ds;
        }
        CString srcPagePropertyFiledom  = path + "Image/" + "pageproperties_" + pagestr + "_dom";
        CString tmpPagePropertyFiledom  = tmppath + m_DocumentName + "_Image_" + "pageproperties_" + pagestr + "_dom";
        ds =  ci::operatingenvironment::File::MoveFile(srcPagePropertyFiledom, tmpPagePropertyFiledom);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",srcPagePropertyFiledom.c_str(),tmpPagePropertyFiledom.c_str());
            return ds;
        }
        srcpathExt = srcpath + ".cjd"; 
        cjdtmp = dstpath + ".cjd";
        if(Utility::ResourceExist(srcpathExt))
        {
            ds = ci::operatingenvironment::File::MoveFile(srcpathExt.c_str(),cjdtmp.c_str());
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",srcpathExt.c_str(),cjdtmp.c_str());
                return ds;
            }
        }
        if(thumbnail_exists) 
        {
            memcpy(&thumbnailinfo, &thumbnail.sPageManTbl[srcpageNo-1], sizeof(FL_PAGE_MAN_TBL));
            thumbnailExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(THUMBNAILPAGETYPE);
            srcpath = path+"Thumbnail/"+pagestr+thumbnailExt;
            thumbnailtmp = tmppath + m_DocumentName + "_Thumbnail_" + pagestr + thumbnailExt;
            ds = ci::operatingenvironment::File::MoveFile(srcpath.c_str(),thumbnailtmp.c_str());
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),thumbnailtmp.c_str());
                return ds;
            }
        }
        if(subsampling_exists) 
        {
            memcpy(&subsamplinginfo, &subsampling.sPageManTbl[srcpageNo-1], sizeof(FL_PAGE_MAN_TBL));
            subsamplingExt = dynamic_cast<CPage*>(pageRef.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);	
            srcpath = path+"Subsampling/"+pagestr+subsamplingExt;
            subsamplingtmp = tmppath + m_DocumentName + "_Subsampling_" + pagestr + subsamplingExt;
            ds = ci::operatingenvironment::File::MoveFile(srcpath, subsamplingtmp);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",srcpath.c_str(),subsamplingtmp.c_str());
                return ds;
            }
        }
        // Slide pages from src+-1 to dst
        this->SlidePagesForMove(srcpageNo, dstpageNo, systemfile, subsampling_exists, subsampling, thumbnail_exists, thumbnail);
        
        // Overwrite from backup source to dst
        memcpy(&systemfile.sPageManTbl[dstpageNo-1], &pageinfo, sizeof(FL_PAGE_MAN_TBL));
        pagestr = Utility::GetHexadecimalPageNo(dstpageNo);
        strncpy(systemfile.sPageManTbl[dstpageNo-1].sPageMan.aPgStr, pagestr.c_str(), 5);
        dstpath = path+"Image/"+ pagestr;
        CString dstpathExt = dstpath + imageExt;
        ds =  ci::operatingenvironment::File::MoveFile(imagetmp, dstpathExt);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",imagetmp.c_str(),dstpathExt.c_str());
            return ds;
        }
        CString dstPagePropertyFile  = path + "Image/" + "pageproperties_" + pagestr + ".xml";
        ds =  ci::operatingenvironment::File::MoveFile(tmpPagePropertyFile, dstPagePropertyFile);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",tmpPagePropertyFile.c_str(), dstPagePropertyFile.c_str());
            return ds;
        }
        CString dstPagePropertyFiledom  = path + "Image/" + "pageproperties_" + pagestr + "_dom";
        ds =  ci::operatingenvironment::File::MoveFile(tmpPagePropertyFiledom, dstPagePropertyFiledom);
        if(ds != STATUS_OK)
        {
            DEBUGL1("CDocument::MovePage::Moving Image from srcpath-%s to dstpath -%s Failed\n",tmpPagePropertyFiledom.c_str(),dstPagePropertyFiledom.c_str());
            return ds;
        }
        dstpathExt = dstpath + ".cjd"; 
        if(Utility::ResourceExist(cjdtmp))
        {
            ds = ci::operatingenvironment::File::MoveFile(cjdtmp, dstpathExt);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Image property file from srcpath-%s to dstpath -%s Failed\n",cjdtmp.c_str(),dstpathExt.c_str());
                return ds;
            }
        }
        if(thumbnail_exists) 
        {
            memcpy(&thumbnail.sPageManTbl[dstpageNo-1], &thumbnailinfo, sizeof(FL_PAGE_MAN_TBL));
            strncpy(thumbnail.sPageManTbl[dstpageNo-1].sPageMan.aPgStr, pagestr.c_str(), 5);
            dstpath = path+"Thumbnail/"+pagestr+thumbnailExt;
            ds = ci::operatingenvironment::File::MoveFile(thumbnailtmp.c_str(),dstpath.c_str());
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Thumbnail Image from srcpath-%s to dstpath -%s Failed\n",thumbnailtmp.c_str(),dstpath.c_str());
                return ds;
            }
        }
        if(subsampling_exists) 
        {
            memcpy(&subsampling.sPageManTbl[dstpageNo-1], &subsamplinginfo, sizeof(FL_PAGE_MAN_TBL));
            strncpy(subsampling.sPageManTbl[dstpageNo-1].sPageMan.aPgStr, pagestr.c_str(), 5);
            dstpath = path+"Subsampling/"+pagestr+subsamplingExt;
            ds = ci::operatingenvironment::File::MoveFile(subsamplingtmp,dstpath);
            if(ds != STATUS_OK)
            {
                DEBUGL1("CDocument::MovePage::Moving Subsampling Image from srcpath-%s to dstpath -%s Failed\n",subsamplingtmp.c_str(),dstpath.c_str());
                return ds;
            }
        }
        // Save updated SystemFile
        CString uri = path + "Image/" + CString(SYSTEMFILE);
        ds = this->UpdateSystemFile(systemfile, uri);
        if (ds != STATUS_OK) {
            return ds;
        }
        m_SystemDataFile = systemfile;
        if(subsampling_exists) {
            uri = path + "Subsampling/" + CString(SYSTEMFILE);
            ds = this->UpdateSystemFile(subsampling, uri);
            if (ds != STATUS_OK) {
                return ds;
            }
            m_SubsamplingSystemDataFile = subsampling;
        }
        if(thumbnail_exists) 
        {
            uri = path + "Thumbnail/" + CString(SYSTEMFILE);
            ds = this->UpdateSystemFile(thumbnail, uri);
            if (ds != STATUS_OK) {
                return ds;
            }
            m_ThumbnailSystemDataFile = thumbnail;
        }
        //Update ModifiedDate
        SetWebDAVProperty("lastModifiedDate",Utility::GetUnixTime());
        SetWebDAVProperty("lastAccessDate",Utility::GetUnixTime());
        DEBUGL4("CDocument::MovePage:Exit\n");
        return STATUS_OK;
    }

	Status CDocument::GetRotation(int pageNo,RotateAngle &rangle)
	{
		DEBUGL4("CDocument::GetRotation Enter\n");
		int total;
		CString angleVal("");
		Status st;
		if(this->GetTotalPage(total)!=STATUS_OK)
		{
			DEBUGL1("CDocument::GetRotation:Failed to get total pages in a document\n");
			return STATUS_FAILED;
		}
		if(pageNo<=0 || pageNo > total)
		{
			DEBUGL1("CDocument::GetRotation:User specified page doesn't exist\n");
			return STATUS_OUT_OF_RANGE;
		}
		dom::DocumentRef domDocRef;
		ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
		pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
		if (!pHDB)
		{
			DEBUGL1("CDocument::GetRotation: Failed to Acquire HierarchicalDB\n");
			return STATUS_FAILED;
		}
		NodeRef rootNode = NULL;	
		NodeRef child = NULL;
		CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(pageNo) + ".xml";
		CString domfile = "pageproperties_" + Utility::GetHexadecimalPageNo(pageNo) + "_dom";
		DocStatus sts;
		if(this->GetStatus(sts) != STATUS_OK) 
		{
			DEBUGL1("CDocument::GetRotation:Getting document status is failed\n");
			return STATUS_FAILED;
		}
		if(sts == EDITING)
		{	
			//Initialize WorkSpace
			WorkSpaceInit();
		}
		CString docPath, pagePath, fullpath;
		docPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName);
		pagePath = docPath + "/" + "Image";
		fullpath = pagePath + "/" + xmlfile;
		try{
			if(Utility::GetDomDocumentRef(pHDB, domDocRef, domfile, pagePath, fullpath) != STATUS_OK)
			{
				DEBUGL1("CDocument::GetRotation: Unable to GetDomDocumentRef from the [%s]\n",fullpath.c_str());
				return STATUS_FAILED;
			}

			rootNode = domDocRef->getDocumentElement();
			NodeRef node = pHDB->BindToElement(rootNode,"rotationAngle");
			if(!node)
			{
				DEBUGL2("CDocument:GetRotation:Seems the rotation angle property doesn't exists/BindToElement return STATUS_FAILED.\n");
				child = chelper::AppendElementNode(rootNode,"rotationAngle");
				chelper::AppendTextNode(child,"0");
				angleVal = "0";
				if((st = pHDB->SerializeToFile(rootNode,fullpath)) != STATUS_OK)
				{
					if(st == STATUS_DISK_FULL)
					{
						DEBUGL1("CDocument:GetRotation:Failed to serialize and returns STATUS_DISK_FULL\n");
						return STATUS_DISK_FULL;
					}
					else{
						DEBUGL1("CDocument:GetRotation:Failed to serialize returns STATUS_FAILED\n");
						return STATUS_FAILED;	
					}
				}
				else
					DEBUGL8("CDocument:GetRotation: SerializeToFile is OK\n");
			}
			else
			{
				angleVal = node->getTextContent();
				DEBUGL6("CDocument:GetRotation: rotationAngle node already exist...Getting the node value success\n");
			}
		}
		catch(DOMException except)
		{
			DEBUGL1("CDocument:GetRotation: Failed due to DOM Exception\n");
			return STATUS_FAILED;
		}
		DEBUGL8("CDocument:GetRotation: rotationAngle is [%s]\n",angleVal.c_str());
			
		if((angleVal == "0") || (angleVal == ""))
			rangle = ROTATEBY0;
		else if(angleVal == "90")
			rangle = ROTATEBY90;
		else if(angleVal == "180")
			rangle = ROTATEBY180;
		else if(angleVal == "270")
			rangle = ROTATEBY270;
		else
		{
			DEBUGL1("CDocument:GetRotation:Invalid Angle [%s]\n",angleVal.c_str());
			return STATUS_FAILED;
		}
		DEBUGL4("CDocument::GetRotation Exit\n");
		return STATUS_OK;

	}
	Status  CDocument::Rotate(int pageNo)
	{
		DEBUGL4("CDocument::Rotate Enter\n");

		int total;
		Status st;
		dom::DocumentRef domDocRef;
		ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
		pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
		if (!pHDB)
		{
			DEBUGL1("CDocument::Rotate: Failed to Acquire HierarchicalDB\n");
			return STATUS_FAILED;
		}
		NodeRef rootNode = NULL;	
		NodeRef child = NULL;
		DocStatus sts;
		if(this->GetStatus(sts) != STATUS_OK) 
		{
			DEBUGL1("CDocument::Rotate:Getting document status is failed\n");
			return STATUS_FAILED;
		}
		if(!(sts == CREATING || sts == EDITING)) 
		{
			DEBUGL1("CDocument::Rotate:Document is NOT CREATING or EDITING\n");
			return STATUS_FAILED;
		}
		if(sts == EDITING)
		{	
			//Initialize WorkSpace
			WorkSpaceInit();
		}
		if(this->GetTotalPage(total)!=STATUS_OK)
		{
			DEBUGL1("CDocument::Rotate:Failed to get total pages in a document\n");
			return STATUS_FAILED;
		}
		if(pageNo<=0 || pageNo > total)
		{
			DEBUGL1("CDocument::Rotate:User specified page doesn't exist\n");
			return STATUS_OUT_OF_RANGE;
		}
		CString angleVal("");
		CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(pageNo) + ".xml";
		CString domfile = "pageproperties_" + Utility::GetHexadecimalPageNo(pageNo) + "_dom";
		CString docPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName);
		CString pagePath = docPath + "/" + "Image";
		CString path = pagePath + "/";
		CString fullpath = pagePath + "/" + xmlfile;
		try{
				if(Utility::GetDomDocumentRef(pHDB, domDocRef, domfile, pagePath, fullpath) != STATUS_OK)
				{
					DEBUGL1("CDocument::Rotate: Unable to GetDomDocumentRef from the [%s]\n",fullpath.c_str());
					return STATUS_FAILED;
				}
				rootNode = domDocRef->getDocumentElement();
				NodeRef node = pHDB->BindToElement(rootNode,"rotationAngle");
				if(!node)
				{
					DEBUGL2("CDocument:Rotate:Seems the rotation angle property doesn't exists/BindToElement return STATUS_FAILED.\n");
					child = chelper::AppendElementNode(rootNode,"rotationAngle");
					chelper::AppendTextNode(child,"0");
					node = pHDB->BindToElement(rootNode,"rotationAngle");
					angleVal = "0";
				}
				else
				{
					angleVal = node->getTextContent();
					DEBUGL6("CDocument:Rotate: rotationAngle node already exist...Getting the node value success\n");
				}

			if((angleVal == "0") || angleVal == ""){
				//rangle = ROTATEBY0;
				angleVal = "90";
			}
			else if(angleVal == "90")
			{
				//rangle = ROTATEBY90;
				angleVal = "180";

			}
			else if(angleVal == "180")
			{
				//rangle = ROTATEBY180;
				angleVal = "270";

			}
			else if(angleVal == "270")
			{
				//rangle = ROTATEBY270;
				angleVal = "0";

			}
			else
			{
				DEBUGL1("CDocument:Rotate:Invalid angleVal [%s]\n", angleVal.c_str());
				return STATUS_FAILED;
			}
			node->setTextContent(angleVal);
			if((st = pHDB->SerializeToFile(rootNode,fullpath)) != STATUS_OK)
			{
				DEBUGL1("CDocument::Rotate:Failed to serialize ...\n");
				if(st == STATUS_DISK_FULL)
				{
					DEBUGL1("CDocument::Rotate:Failed to serialize and returns STATUS_DISK_FULL\n");
					return STATUS_DISK_FULL;
				}
				else
				{
					DEBUGL1("CDocument::Rotate:Failed to serialize returns STATUS_FAILED\n");
					return STATUS_FAILED;	
				}
			}
			else
				DEBUGL8("CDocument::Rotate: SerializeToFile success\n");
		}
		catch(DOMException except)
		{
			DEBUGL1("CDocument::Rotate: Failed due to DOM Exception\n");
			return STATUS_FAILED;
		}
		DEBUGL8("CDocument:Rotate: Page is rotated by angleVal = [%s]\n", angleVal.c_str());
		DEBUGL4("CDocument::Rotate Exit\n");
		return STATUS_OK;
	}

	CViewDocument::CViewDocument(CString sessionID, CString boxbasepath, CString boxnumber, CString foldername, CString documentname) :
		m_sessionID(sessionID),
		m_BoxBasePath(boxbasepath),
		m_BoxBasePathOrg(boxbasepath),
		m_BoxNumber(boxnumber), 
           m_FolderName(foldername),
           m_DocumentName(documentname)

       {
          if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
             DEBUGL2("\nCDocument::CViewDocument: Failed to increment the count\n ");

          typedef std::map<CString, CString> property_pair;
          m_WebDAVProperties.insert(property_pair::value_type("documentName", documentname));
          m_WebDAVProperties.insert(property_pair::value_type("jobType", ""));
          m_WebDAVProperties.insert(property_pair::value_type("totalSize", "0"));
          m_WebDAVProperties.insert(property_pair::value_type("totalPages", "0"));

          CString local = Utility::GetUnixTime();

          m_WebDAVProperties.insert(property_pair::value_type("creationDate", local));
          m_WebDAVProperties.insert(property_pair::value_type("lastModifiedDate", local));			
          m_WebDAVProperties.insert(property_pair::value_type("cutDocument",""));	
       }

        Status CViewDocument::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) 
        {
           m_WebDAVProperties = WebDAVpropertyMap;
           return STATUS_OK;	
        }
        Status CViewDocument::GetName(CString &name)
        {
           name=m_DocumentName;
           return STATUS_OK;    
        }		
        Status CViewDocument::GetViewPageList(PageList &list) {
            return GetViewPageList(list, 1, 65535);
        }

		  Status CViewDocument::GetViewPageList(PageList &list, unsigned int from, unsigned int size) {
			  DocStatus st;
			  DEBUGL4("CDocument::GetViewPageList:Enter\n");

			  FL_FILE_MAN_FILE *systemDataFile = new FL_FILE_MAN_FILE;
			  FL_FILE_MAN_FILE *subsamplingSystemDataFile = new FL_FILE_MAN_FILE;
			  FL_FILE_MAN_FILE *thumbnailSystemDataFile = new FL_FILE_MAN_FILE;
			  memset((FL_FILE_MAN_FILE *)(systemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));
			  memset((FL_FILE_MAN_FILE *)(subsamplingSystemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));			
			  memset((FL_FILE_MAN_FILE *)(thumbnailSystemDataFile),'\0',sizeof(FL_FILE_MAN_FILE));
			  //make a local copy of the member variables
			  CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
			  boxbasepath_org = m_BoxBasePath;
			  boxnumber_org = m_BoxNumber;
			  folderName_org = m_FolderName;
			  docName_org = m_DocumentName;

			  if(this->GetStatus(st) != STATUS_OK) {
				  DEBUGL1("CDocument::GetViewPageList::Getting document status is failed\n");
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return STATUS_FAILED;
			  }
			  if(st == DELETING) {
				  DEBUGL1("CDocument::GetViewPageList::Document is DELETING\n");
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return STATUS_FAILED;
			  }


			  if(st == EDITING)
			  {	
				  //check if the session-id property set on the document is same as the current sessionID
				  CString val;
				  CString resourceKey=Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName)+"/";
				  if(GetWebDAVProperty("sessionID", val)!= STATUS_OK)
				  {
					  DEBUGL2("CDocument::GetViewPageList: GetProperty of sessionID failed\n");
					  val.clear();
				  }
				  DEBUGL8("CDocument::GetViewPageList::SessionID<%s>\n",val.c_str());
				  if(val==m_sessionID)
				  {	
					  //Initialize WorkSpace
					  WorkSpaceInit();
				  }	
			  }
			  CString docpath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);
			  list.clear();
			  CString path = docpath + "/Image/" + CString(SYSTEMFILE);
			  Status openStatus = STATUS_OK;
			  if((openStatus = OpenSystemDataFile(systemDataFile, path)) != STATUS_OK) {
				  if( openStatus == STATUS_INVALID_URI)
				  {
					  DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Image system file does not exist\n");
					  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
					  delete systemDataFile;
					  delete subsamplingSystemDataFile;
					  delete thumbnailSystemDataFile;
					  return STATUS_OK;
				  }
				  DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Image\n");
				  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return STATUS_FAILED;
			  }

			  path =docpath+ "/Thumbnail/" + CString(SYSTEMFILE);						
			  if((openStatus = OpenSystemDataFile(thumbnailSystemDataFile, path)) != STATUS_OK) {
				  if( openStatus == STATUS_INVALID_URI)
				  {
					  DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Thumbnail system file does not exist\n");
					  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
					  delete systemDataFile;
					  delete subsamplingSystemDataFile;
					  delete thumbnailSystemDataFile;
					  return STATUS_OK;
				  }
				  DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Thumbnail\n");
				  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return STATUS_FAILED;
			  }

			  path = docpath +"/Subsampling/" + CString(SYSTEMFILE);												
			  if((openStatus = OpenSystemDataFile(subsamplingSystemDataFile, path)) != STATUS_OK) {
				  if( openStatus == STATUS_INVALID_URI)
				  {
					  DEBUGL2("CDocument::GetViewPageList::returning STATUS_OK for Inavlid URI as Subsampling system file does not exist\n");
					  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);											
					  delete systemDataFile;
					  delete subsamplingSystemDataFile;
					  delete thumbnailSystemDataFile;
					  return STATUS_OK;
				  }
				  DEBUGL1("CDocument::GetViewPageList::OpenSystemDataFile Failed for Subsampling\n");
				  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);									
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return STATUS_FAILED;
			  }

			  int total = 0;// = m_SystemDataFile.sFileMan.hFlPageNum;;
			  Status stat = GetTotalPage(total);//m_SystemDataFile.sFileMan.hFlPageNum;
			  if(stat != STATUS_OK) {
				  delete systemDataFile;
				  delete subsamplingSystemDataFile;
				  delete thumbnailSystemDataFile;
				  return stat;
			  }

			  PageRef page;
			  for(unsigned int pageno = from, cnt = 0; (cnt < size && pageno <= total); pageno++, cnt++) {
				  if(GetPage(pageno, page, systemDataFile, thumbnailSystemDataFile, subsamplingSystemDataFile) != STATUS_OK) {
					  DEBUGL1("CDocument::GetViewPageList::getting page %d is failed\n", pageno);
					  break;
				  }
				  list.push_back(page);
			  }
			  RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);							
			  delete systemDataFile;
			  delete subsamplingSystemDataFile;
			  delete thumbnailSystemDataFile;
			  return STATUS_OK;
		  }
        Status CViewDocument::GetPage(int pageno, PageRef &page,
							 FL_FILE_MAN_FILE *systemDataFile, FL_FILE_MAN_FILE *thumbnailSystemDataFile, 
							 FL_FILE_MAN_FILE *subsamplingSystemDataFile) {

            //For PageLogBox PAGE_LIMIT
            CString boxbasepath_new("");
            int pos;
            pos =  m_BoxBasePathOrg.rfind("/");
            boxbasepath_new =  m_BoxBasePathOrg.substr(pos+1);
            DEBUGL1("CDocument::GetPage:: pageno = (%d) (%s)\n", pageno, boxbasepath_new.c_str());
            if(boxbasepath_new == "PageLogBoxes")
            {
                DEBUGL8("Entered in the check\n");
                if((static_cast<unsigned>(pageno) > CBoxDocument::PAGELOGBOX_PAGE_LIMIT))
                {
                    DEBUGL1("CDocument::GetPage::Page Limit reached for PAGELOGBOXES\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }
                else
                    DEBUGL8("CDocument::GetPage::Entered in the check1\n");

            }
            else if((pageno <= 0) || (static_cast<unsigned>(pageno) > CBoxDocument::PAGE_LIMIT)) {
                DEBUGL1("CDocument::GetPage::Invalid page number %d\n", pageno);
                return STATUS_FAILED;
            }
		std::ostringstream oss;
		oss << pageno;

		//make a local copy of the member variables
		CString boxnumber_org, boxbasepath_org, folderName_org, docName_org;
		boxbasepath_org = m_BoxBasePath;
		boxnumber_org = m_BoxNumber;
		folderName_org = m_FolderName;
		docName_org = m_DocumentName;

		DocStatus st;

            if(this->GetStatus(st) != STATUS_OK) {
                DEBUGL1("CDocument::GetPage::Getting document status is failed\n");
                return STATUS_FAILED;
            }
            if(st == DELETING) {
                DEBUGL1("CDocument::GetPage::Document is deleting\n");
                return STATUS_FAILED;
            }

            //CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);
            if(st == EDITING)
            {	
                //check if the session-id property set on the document is same as the current sessionID
                CString val;
                //CString resourceKey=path+"/";
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","sessionID", val)!=STATUS_OK)
                {
                    DEBUGL2("CDocument::GetPage: GetProperty of sessionID failed\n");
                    val.clear();
                }	
                DEBUGL8("CDocument::GetPage: val = (%s),  m_sessionID = (%s)\n",val.c_str(),(m_sessionID).c_str());
                if(val==m_sessionID)
                {	
                    //Initialize WorkSpace
                    DEBUGL8("CDocument::GetPage: sessionIDs are same.. call WorkSpaceInit\n");
                    WorkSpaceInit();
                }	
            }
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName,m_DocumentName);

            FL_PAGE_MAN_TBL systemfile;
            FL_PAGE_MAN_TBL thumbnail;
            FL_PAGE_MAN_TBL subsampling;
            memset((FL_PAGE_MAN_TBL *)&(systemfile),'\0',sizeof(FL_PAGE_MAN_TBL));
            memset((FL_PAGE_MAN_TBL *)&(subsampling),'\0',sizeof(FL_PAGE_MAN_TBL));			
            memset((FL_PAGE_MAN_TBL *)&(thumbnail),'\0',sizeof(FL_PAGE_MAN_TBL));

            DEBUGL8("CDocument::GetPage: m_BoxBasePath %s, m_BoxNumber %s, m_FolderName %s, m_DocumentName %s\n", m_BoxBasePath.c_str(), m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());						

            // check SystemFile
            CString systemfilepath = Utility::GetResourcePath(path + "/Image/" + SYSTEMFILE);

            DEBUGL8("CDocument::GetPage:systemDataFile.sFileMan.hFlPageNum<%d>,pageno<%d>",systemDataFile->sFileMan.hFlPageNum,pageno);						
            if(systemDataFile->sFileMan.hFlPageNum < pageno) {
                DEBUGL1("CDocument::GetPage::Page %d doesn't exist\n", pageno);
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            systemfile = systemDataFile->sPageManTbl[pageno - 1];
            systemfilepath = Utility::GetResourcePath(path + "/Thumbnail/" + SYSTEMFILE);

            if(thumbnailSystemDataFile->sFileMan.hFlPageNum >= pageno) {
                thumbnail = thumbnailSystemDataFile->sPageManTbl[pageno - 1];
            }

            systemfilepath = Utility::GetResourcePath(path + "/Subsampling/" + SYSTEMFILE);

            if(subsamplingSystemDataFile->sFileMan.hFlPageNum >= pageno) {
                subsampling = subsamplingSystemDataFile->sPageManTbl[pageno - 1];
            }

            Status ret;
            try
            {
                page = new CPage(pageno, path, m_BoxBasePath);

                if(!page)
                {
                    DEBUGL1("CDocument::GetPage::Page object is NULL\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CPage*>(page.operator->())->LoadProperties(systemfile,subsampling,thumbnail);
                if(ret != STATUS_OK) {
                    DEBUGL1("CDocument::GetPage::Loading Page is failed\n");
                    page = NULL; // release
                    RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                    return ret;
                }	
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
            }
            catch(exception& e)
            {
                DEBUGL8("CDocument::GetPage::Loadin Page failed because an exception  was caught:(%s)\n",e.what());
                page = NULL;
                RevertPaths(boxbasepath_org,boxnumber_org,folderName_org,docName_org);
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }
        void CViewDocument::WorkSpaceInit()
        {
            CString wrkpath=WORKSPACE_PATH;
            wrkpath = wrkpath;

            CString clippath=CLIPBOARD_PATH;
            clippath = clippath;

            DEBUGL8("CDocument::WorkSpaceInit::m_BoxBasePath<%s>,wrkpath<%s>,clipPath<%s>\n",m_BoxBasePath.c_str(),wrkpath.c_str(),clippath.c_str());
            size_t w=m_BoxBasePath.find(wrkpath);
            size_t c=m_BoxBasePath.find(clippath);
            /*Read UUID from documentproperties.xml*/
            CString WorkspaceDocName("");
            if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, m_DocumentName, "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
            {
                DEBUGL1("CDocument::WorkSpaceInit: GetProperty of WorkspaceDocName failed\n");
            }

            if((w==CString::npos)&&(c==CString::npos))
            {
                //Workspace doc path
                CString newDocName;
                newDocName = m_sessionID + "_" + WorkspaceDocName;
                //Update the document path to the Workspace. So that any further operations happen on 
                //the delta document
                m_BoxBasePath = wrkpath;
                m_BoxNumber = "";
                m_FolderName = "";
                m_DocumentName = newDocName;						
                DEBUGL8("CDocument::WorkSpaceInit::m_BoxBasePath<%s>,m_BoxNumber<%s>,m_FolderName<%s>,m_DocumentName<%s>\n",m_BoxBasePath.c_str(),m_BoxNumber.c_str(),m_FolderName.c_str(),m_DocumentName.c_str());						
            }
        }
	Status CViewDocument::OpenSystemDataFile(FL_FILE_MAN_FILE *system, CString path) {
		DEBUGL4("CViewDocument::OpenSystemDataFile: Enter\n");
		int len = path.rfind("/");
		CString systemFileName = path.substr(len+1,path.length());
		int len1 = path.rfind("/", len - 1);
		CString pagetype = path.substr(len1 + 1, (len - (len1 + 1))); 
		CString docpath = path.substr(0,len1+1);
		DEBUGL8("CViewDocument::OpenSYstemDataFile: critical section for %s:%s\n", pagetype.c_str(), systemFileName.c_str());

		CString pLockpath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName)+"/"+pagetype+"/";
		DEBUGL8("CViewDocument::OpenSYstemDataFile: pLockpath is  [%s]\n", pLockpath.c_str());
		int fdescLockfile;
		CString locktypefile = pagetype + "_systemfilelock";
		CString uriPathToLock = docpath + "." + locktypefile;
		bool flockType = true;
		//Skip critical section if the /work/ci/insertblankpageflag exists
		if(Utility::AcquireLockforSystemfile(uriPathToLock, fdescLockfile, flockType) != STATUS_OK)
		{
			DEBUGL1("CViewDocument::OpenSystemDataFile::AcquireLockforSystemfile failed\n");
			return STATUS_FAILED;
		}

		int FD;
		int errnum = 0;
		FD = open(path.c_str(),O_RDONLY);
		errnum=errno;

		if(FD==-1)
		{
			DEBUGL1("CViewDocument::OpenSystemDataFile open error\n");
		    	if(Utility::ReleaseLockforSystemfile(FD) != STATUS_OK)
		    		DEBUGL1("CViewDocument::OpenSystemDataFile: ReleaseLockforSystemfile returned STATUS_FAILED\n");
			if( errnum == ENOENT) {
				DEBUGL1("CViewDocument::OpenSystemDataFile::File doesn't exist\n");
				return STATUS_INVALID_URI;
			}							
			return STATUS_FAILED;
		}

		DEBUGL8("CViewDocument::OpenSystemDataFile: Enter -- Opening %s systemfile\n",path.c_str());
		if(read(FD,system, sizeof(FL_FILE_MAN_FILE) ) == -1) {
			DEBUGL1("CViewDocument::OpenSystemDataFile::Reading system data file is failed\n");
			close(FD);
		    	if(Utility::ReleaseLockforSystemfile(FD) != STATUS_OK)
		    		DEBUGL1("CViewDocument::OpenSystemDataFile:: ReleaseLockforSystemfile returned STATUS_FAILED\n");
			return STATUS_FAILED;
		}
		close(FD);
		if(Utility::ReleaseLockforSystemfile(fdescLockfile) != STATUS_OK){
			DEBUGL1("CViewDocument::OpenSystemDataFile::ReleaseLockforSystemfile returned STATUS_FAILED\n");
			return STATUS_FAILED;
		}
		DEBUGL4("CViewDocument::OpenSystemDataFile: Exit\n");
		return STATUS_OK;
	}

        void CViewDocument::RevertPaths(CString basepath,CString boxNumber,CString folderName,CString docName)
        {
            DEBUGL8(" CDocument::RevertPaths:: basepath (%s) boxnumber (%s) foldername(%s) docname (%s)\n",
                    basepath.c_str(),boxNumber.c_str(), folderName.c_str(), docName.c_str());
            CString wrkpath=WORKSPACE_PATH;
            DEBUGL8(" CDocument::RevertPaths:: m_basepath (%s) m_boxnumber (%s) m_foldername(%s) m_docname (%s)\n",
                    m_BoxBasePath.c_str(),m_BoxNumber.c_str(), m_FolderName.c_str(), m_DocumentName.c_str());					
            if(m_BoxBasePath == wrkpath)
            {
                m_BoxBasePath = basepath;
                m_BoxNumber = boxNumber;
                m_FolderName = folderName;
                m_DocumentName = docName;						
                DEBUGL8("CDocument::RevertPaths: Paths reverted to original\n");						
            }
        }



        Status CViewDocument::GetWebDAVProperty(CString key, CString &value) {
            value = m_WebDAVProperties[key];
            return STATUS_OK;
        }

        Status CViewDocument::GetStatus(DocStatus &st) {
            CString path = Utility::GetResourcePath(m_BoxBasePath,
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName) + "/";
            DEBUGL8("CViewDocument::GetStatus path = (%s)\n",path.c_str());
            if(Utility::ResourceExist(path + statusfilename::CREATING)) {
                st = CREATING;
            } else if(Utility::ResourceExist(path + statusfilename::READY)) {
                st = READY;
            } else if(Utility::ResourceExist(path + statusfilename::USING)) {
                st = USING;
            } else if(Utility::ResourceExist(path + statusfilename::EDITING)) {
                st = EDITING;
            } else if(Utility::ResourceExist(path + statusfilename::DELETING)) {
                st = DELETING;
            } else if(Utility::ResourceExist(path + statusfilename::WAITING)) {
                st = WAITING;
            } else if(Utility::ResourceExist(path + statusfilename::RESERVING)) {
                st = RESERVING;
            } else {
                // if file is not found, document status is considered as CREATING.
                st = CREATING;

                if(Utility::CreateFile(path, statusfilename::CREATING) != STATUS_OK) {
                    DEBUGL1("CViewDocument::GetStatus::creating status file is failed\n");
                    return STATUS_FAILED;
                }
            }
            return STATUS_OK;
        }
        
        Status CViewDocument::GetPaperSizeSet(PaperSizeSet &paperset)
        {

            CString val;
            if(GetWebDAVProperty("paperSizeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CViewDocument::GetPaperSizeSet: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CViewDocument::GetPaperSizeSet:Get VAL for paperSizeMap <%s>\n", val.c_str());

            m_PaperSizeMap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                string first = minp.substr(0,nf);
                string second = minp.substr(nf+1);
                PaperSize eVal;
                int abc = atoi(first.c_str());
                eVal = (PaperSize)abc;
                m_PaperSizeMap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }

            paperset.clear();
            std::map<PaperSize,int>::iterator mapIter;
            for(mapIter=m_PaperSizeMap.begin();mapIter!=m_PaperSizeMap.end();mapIter++)
            {
                DEBUGL8("CViewDocument::GetPaperSizeSet: PaperSize<%d> and PaperCount<%d>\n",mapIter->first,mapIter->second);
                paperset.insert(mapIter->first);
            }
            return STATUS_OK;
        }

        Status CViewDocument::GetJobTypeColorSet(JobTypeColorSet &jcset)
        {
            CString val;
            if(GetWebDAVProperty("jobTypeColorMap", val)!=STATUS_OK)
            {
                DEBUGL1("CViewDocument::GetJobTypeColorSet: GetProperty of JobTypeColorMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CViewDocument::GetJobTypeColorSet::Get VAL for jobTypeColorMap<%s>\n", val.c_str());
            m_JobTypeColorMap.clear();
            size_t found = val.find_first_of(";");
            while (found!=string::npos)
            {
                CString minp = val.substr(0,found);
                size_t nf = minp.find(",");
                string first = minp.substr(0,nf);
                string second = minp.substr(nf+1);
                JobTypeColor eVal;
                int abc = atoi(first.c_str());
                eVal = (JobTypeColor)abc;
                m_JobTypeColorMap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found+1);
                found=val.find_first_of(";");
            }

            jcset.clear();
            std::map<JobTypeColor,int>::iterator mapIter;
            for(mapIter=m_JobTypeColorMap.begin();mapIter!=m_JobTypeColorMap.end();mapIter++)
            {
                DEBUGL8("CViewDocument::GetJobTypeColorSet: JobTypeColor<%d> and JobTypeColorCount<%d> \n",mapIter->first,mapIter->second);
                jcset.insert(mapIter->first);
            }
            return STATUS_OK;
        }
        Status CViewDocument::GetPaperSizeMap(PaperSizeMap &papermap)
        {
            DEBUGL4("CViewDocument::GetPaperSizeMap Enter\n");
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","paperSizeMap", val)!=STATUS_OK)
            {
                DEBUGL1("CViewDocument::GetPaperSizeMap: GetProperty of paperSizeMap failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CViewDocument::GetPaperSizeMap:Get VAL for paperSizeMap <%s>\n", val.c_str());

            papermap.clear();
            size_t found1 = val.find_first_of(";");
            while (found1!=string::npos)
            {
                CString minp = val.substr(0,found1);
                size_t nf = minp.find(",");
                CString first = minp.substr(0,nf);
                CString second = minp.substr(nf+1);
                PaperSize eVal;
                int abc = atoi(first.c_str());
                eVal = (PaperSize)abc;
                papermap.insert(make_pair(eVal,atoi(second.c_str())));
                val = val.substr(found1+1);
                found1=val.find_first_of(";");
            }
            DEBUGL4("CViewDocument::GetPaperSizeMap Exit\n");
            return STATUS_OK;
        }

        Status CViewDocument::GetThumbnailImage(CString &path) {
            path = Utility::GetResourcePath(m_BoxBasePath,
                    m_BoxNumber,
                    m_FolderName,
                    m_DocumentName);
            path += "/Thumbnail/001.png";
            return STATUS_OK;
        }

        Status CViewDocument::GetTotalPage(int &total) 
        {
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalPages", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetTotalPage: GetProperty of totalPages failed\n");
                return STATUS_FAILED;
            }
            std::istringstream iss(val);
            iss >> total;					
            return STATUS_OK;
        }


       CViewDocument::~CViewDocument()
        {				
           if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
              DEBUGL2("\nCViewDocument::CDocument: Failed to increment the count\n ");

        }		
        Status CViewDocument::GetTotalSize(uint64 &total) 
        {
            CString val("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,m_DocumentName,"","totalSize", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::GetTotalSize: GetProperty of totalSize failed\n");
                return STATUS_FAILED;
            }
            std::istringstream iss(val);
            iss >> total;					
            m_TotalSize = total;
            return STATUS_OK;
        }
    }; // end of namespace boxdocument
}; // end of namespace ci
