/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cpage.h
Revision: com_t#6
File Spec: EBX:MA6039.A-DEV_SRC;com_t#6
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:50:54

Outline : 

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
  1:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
  	Creation Date: 13-JAN-2009 19:36:02
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
  
  2:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
  	Creation Date: 13-JAN-2009 18:00:09
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
  
  3:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
  	Creation Date: 13-JAN-2009 15:14:46
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
  
  ------------------------------------------------------------------------------
History:
 * Revision com_t#6 (APPROVED)
 *   Created:  09-JAN-2009 21:50:54      CHANDRAMOHAN.PUJARI
 *     Added fucntions for image extension support
 *   Updated:  09-JAN-2009 21:50:54      CHANDRAMOHAN.PUJARI
 *     Added fucntions for image extension support
 *   Updated:  09-JAN-2009 21:50:54      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#6 created from revision com_t#5 with status
 *     $TO_BE_DEFINED
 *   Updated:  09-JAN-2009 21:50:54      CHANDRAMOHAN.PUJARI
 *     Added fucntions for image extension support
 * 
 * Revision com_t#5 (UNIT TESTED)
 *   Created:  23-DEC-2008 22:00:25      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:00:25      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#5 created from revision com_t#4 with status
 *     $TO_BE_DEFINED
 *   Updated:  23-DEC-2008 22:00:25      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:00:25      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 * 
 * Revision com_t#4 (APPROVED)
 *   Updated:  19-DEC-2008 21:41:49      CHANDRAMOHAN.PUJARI
 *     support for copyjpeg parameter
 *   Created:  19-DEC-2008 21:41:44      CHANDRAMOHAN.PUJARI
 *     support for copyjpeg parameter
 *   Updated:  19-DEC-2008 21:41:44      CHANDRAMOHAN.PUJARI
 *     support for copyjpeg parameter
 *   Updated:  19-DEC-2008 21:41:41      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#4 created from revision com_t#3 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#3 (APPROVED)
 *   Created:  08-DEC-2008 21:04:07      CHANDRAMOHAN.PUJARI
 *     Added Code for ColorMode Information
 *   Updated:  08-DEC-2008 21:04:07      CHANDRAMOHAN.PUJARI
 *     Added Code for ColorMode Information
 *   Updated:  08-DEC-2008 21:04:07      CHANDRAMOHAN.PUJARI
 *     Added Code for ColorMode Information
 *   Updated:  08-DEC-2008 21:04:07      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#3 created from revision com_t#2 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#2 (APPROVED)
 *   Created:  17-NOV-2008 22:02:03      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s of Page Class
 *   Updated:  17-NOV-2008 22:02:03      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s of Page Class
 *   Updated:  17-NOV-2008 22:02:03      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#2 created from revision com_t#1 with status
 *     $TO_BE_DEFINED
 *   Updated:  17-NOV-2008 22:02:03      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s of Page Class
 * 
 * Revision com_t#1 (APPROVED)
 *   Updated:  03-NOV-2008 19:07:45      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 *   Created:  03-NOV-2008 19:07:44      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 *   Updated:  03-NOV-2008 19:07:44      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#1 created from revision com_m#1.2 with
 *     status $TO_BE_DEFINED
 *   Updated:  03-NOV-2008 19:07:44      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 * 
 * Revision com_m#1.2 (APPROVED)
 *   Updated:  01-SEP-2008 17:15:59      13848
 *     Updated attribute(s)
 *   Created:  01-SEP-2008 17:14:34      13848
 *     Update for Ph3.5 1st build
 *   Updated:  01-SEP-2008 17:13:14      13848
 *     Item revision com_m#1.2 created from revision com_m#1.1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.1 (UNIT TESTED)
 *   Updated:  01-SEP-2008 16:51:17      13848
 *     Updated attribute(s)
 *   Created:  25-AUG-2008 20:11:41      13848
 *     BoxDocument 2nd release
 *   Updated:  25-AUG-2008 20:08:18      13848
 *     Item revision com_m#1.1 created from revision com_m#1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1 (UNDER WORK)
 *   Created:  19-AUG-2008 14:34:41      13848
 *     Initial revision
========================== End of Source Header =============================*/

#ifndef __CI_CPAGE_H__
#define __CI_CPAGE_H__
#include <map>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
//#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/page.h>
#include "systemdatafile.h"
#define IMAGEPAGETYPE 1
#define SUBSAMPLINGPAGETYPE 2
#define THUMBNAILPAGETYPE 3

namespace ci {
	namespace boxdocument {

		using namespace operatingenvironment;

		/**
		 * Page class provides facilities of page operation.
		 */
		class CPage : public Page
		{
			private:
				//Ref<DocumentStore::Session> m_Session;
				int m_PageNo;
				CString m_DocumentURI;
				std::map<CString, CString> m_WebDAVProperties;

				static std::map<CString,PaperSize> m_PaperSizeEnumStringMap;
				static std::map<int,CString> m_ExtensionTypes;
				FL_PAGE_MAN_TBL m_PageInformation;
				FL_PAGE_MAN_TBL m_SubsamplingPageInformation;
				FL_PAGE_MAN_TBL m_ThumbnailPageInformation;

				CString m_ImageName;
				CString m_SubsamplingName;
				CString m_ThumbnailName;

				/// these image paths are changed when the page is appended to Document
				CString m_ImagePath;       
				CString m_SubsamplingPath; 
				CString m_ThumbnailPath;   

				/// properties from system file 
				int m_HorizontalResolution; 
				int m_VerticalResolution;   
				int m_ImageWidth;
				int m_ImageHeight;
				CString m_PaperSize;
				uint64 m_FileSize;
				CString m_ColorMode;
			   char* m_ParamFile;    
				PaperSize m_PaperSizeEnum;
				CString m_BlankPropertyFilePath;					
				uint32 m_ParamFileSize;
				CString m_BoxBasePath;
				// Convert m_PageNo to 5-digit string
				CString Get5DigitPageNo();

				// Set property from system file
				Status SetResolution(int mainResolution, int subResolution);
				Status SetImageSize(int w,int h);
				Status SetColorMode(int colormode,int databit) ;
				Status GetFileFormat(FileFormat &format,int ctype,int yccform,int colormode,int databit);
				

			public:
				// constructor
				CPage(int pageno = 0, 
					CString documenturi = "",
					CString boxbasepath = "/storage/box/EFilingBoxes");

				// destructor 
				~CPage();

				/**
				 * set the paper size
				 * @param[in] size - file size
				 * @return STATUS_OK on success.
				 */
				Status SetFileSize(unsigned int size);
				/**
				 * set the paper size
				 * @param[in] size - paper size
				 * @return STATUS_OK on success.
				 */
				Status SetPaperSize(int size);

				/**
				 * set the subsampling image & path (for internal use)
				 * image path may not exist
				 * @param[in] path - image file path to be set (including image name & ext)
				 * @param[in] name - image file name to be set
				 * @return STATUS_OK on success.
				 */
				Status SetSubsamplingImage(CString path, CString name);

				/**
				 * set the thumbnail image & path (for internal use)
				 * image path may not exist
				 * @param[in] path - image file path to be set (including image name & ext)
				 * @param[in] name - image file name to be set
				 * @return STATUS_OK on success.
				 */
				Status SetThumbnailImage(CString path, CString name);

				/**
				 * set the image & path (for internal use)
				 * image path may not exist
				 * @param[in] path - image file path to be set (including image name & ext)
				 * @param[in] name - image file name to be set
				 * @return STATUS_OK on success.
				 */
				Status SetImage(CString path, CString name);

				/**
				 * set the WebDAV properties of the page (for internal use)
				 * @param[in] session - document store session id
				 * @param[in] pageno - page no of this page
				 * @param[in] documenturi - uri of the document containing this page
				 * @return STATUS_OK on success
				 *			  STATUS_FAILED on failure
				 */
				Status SetProperties(/*Ref<DocumentStore::Session> session, */int pageno, CString documenturi);

				/**
				 * put an image to the page
				 * actual image is NOT copied to under the document folder if this function
				 * has NO owner document.
				 * @param[in] path - the image file path to be put
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status PutImage(CString path);

				/**
				 * get an image path to the page
				 * @param[out] path - local path of the image.
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetImage(CString &path);

				/**
				 * put a subsampling image to the page
				 * actual image is NOT copied to under the document folder if this function
				 * has NO owner document.
				 * @param[in] path - the subsampling image file path to be put
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status PutSubsamplingImage(CString path);

				/**
				 * get a subsampling image path to the page
				 * @param[out] path - local path of the image.
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetSubsamplingImage(CString &path);

				/**
				 * put a thumbnail image to the page
				 * actual image is NOT copied to under the document folder if this function
				 * has NO owner document.
				 * @param[in] path - the subsampling image file path to be put
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status PutThumbnailImage(CString path);

				/**
				 * get a thumbnail image path to the page
				 * @param[out] path - local path of the image.
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetThumbnailImage(CString &path);

				/**
				 * set the page property
				 * @param[in] key - the property name to be set
				 * @param[in] value - the property value to be set
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status SetWebDAVProperty(CString key, CString value);

				/**
				 * set document property
				 * @param[in] key - the property name to be set
				 * @param[in] value - the property value to be set
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status SetWebDAVProperty(CString key, int value);

				/**
				 * get the page property
				 * @param[in] key - the property name to be set
				 * @param[out] value - the property value
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetWebDAVProperty(CString key, CString &value);

				//-------------------- System File Properties --------------------

				/**
				 * set system file properties
				 *  the properties are reflected to Document on addition
				 * @param[in] systemfile - a pointer to System File
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status SetSystemFile(void* systemfile);

				/**
				 * set subsampling system file properties
				 *  the properties are reflected to Document on addition
				 * @param[in] systemfile - a pointer to System File
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */

				Status SetSubSamplingSystemFile(void* systemfile);

				/**
				 * set thumbnail system file properties
				 *  the properties are reflected to Document on addition
				 * @param[in] systemfile - a pointer to System File
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */

				Status SetThumbnailSystemFile(void* systemfile);


				/**
				 * get resolution of the image
				 * @param[out] horizontal - horizontal resolution of the page
				 * @param[out] vertical - vertical resolution of the page
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetResolution(int &horizontal, int &vertical);

				/**
				 * get size of the image
				 * @param[out] width - width (pixels) of the page
				 * @param[out] height - height (pixels) of the page
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetImageSize(int &width, int &height);

			    /**
			     * get adjusted size (internal data size) of the image
			     * @param[out] width - width (pixels) of the page
			     * @param[out] height - height (pixels) of the page
			     * @return STATUS_OK on success,
			     *         STATUS_FAILED on failure.
			     */
			    Status GetAdjustedImageSize(int &width, int &height);

				/**
				 * get size of the paper
				 * @param[out] size - the string of paper size
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetPaperSize(CString &size);

			    /**
			     * get size of the paper
			     * @param[out] size - the constant of paper size
			     * @return STATUS_OK on success,
			     *         STATUS_FAILED on failure.
			     */
			    Status GetPaperSize(PaperSize &size);

				/**
				 * get file size of the page
				 * @param[out] size - size of the page
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetFileSize(uint64 &size);
				//-------------------- end of System File Properties --------------------

				// CPage methods
				/**
				 * Add the page to document
				 */
				Status AddToDocument(int pageno, CString documenturi, bool link);

				/**
				 * set properties from system file on memory
				 * some document properties are set as WebDAV properties. Also, some page 
				 * properties are set if the main image is copied to the document folder.
				 * @param[in] systemfile - a pointer to System File
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status SetWebDAVPropertyFromSystemFile(void* systemfile);

				/**
				 * load properties from WebDAV
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status LoadProperties(FL_PAGE_MAN_TBL &systemfile, 
						FL_PAGE_MAN_TBL &subsamplingsystemfile,
						FL_PAGE_MAN_TBL &thumbnailsystemfile);

				/**
				 * get system file for page
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetSystemFile(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * set system file for subsampling image
				 */
				Status SetSubsamplingSystemFile(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * get system file for subsampling
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetSubsamplingSystemFile(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * set system file for thumbnail image
				 */
				Status SetThumbnailSystemFile(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * get system file for thumbnail
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetThumbnailSystemFile(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * Update file name in SystemFile (sPageMan.aPgStr) to internal name
				 * @param[in/out] systemfile - target SystemFile
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status UpdateImageName(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * Update subsampling name in SystemFile (sPageMan.aPgStr) to internal name
				 * @param[in/out] systemfile - target SystemFile
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status UpdateSubsamplingName(FL_PAGE_MAN_TBL &systemfile);

				/**
				 * Update thumbnail name in SystemFile (sPageMan.aPgStr) to internal name
				 * @param[in/out] systemfile - target SystemFile
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status UpdateThumbnailName(FL_PAGE_MAN_TBL &systemfile);
				//-------------------- Copy--JPEG API's ----------------------

				/**
				 * set Copy-JPEG parameter
				 * this parameter is also stored as file when the page is associated with 
				 * Document.
				 * @param[in] param - Copy-JPEG parameter to be stored.
				 * @param[in] size - Size of the Copy-JPEG parameter to be stored. default size is 66
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status SetCopyJpegParameter(void *param, uint32 size=66);

				/**
				 * get file path of Copy-JPEG parameter
				 * @param[out] path - file path of Copy-JPEG parameter. if fails, empty 
				 *                     string "" will return.
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure. e.g. file not found.
				 */
				Status GetCopyJpegParameterFilePath(CString &path);

			    /**
			     * get format of image file
			     * @param[out] format - format of image file.
			     * @return STATUS_OK on success,
			     *         STATUS_FAILED on failure.
			     */
			    Status GetFileFormat(FileFormat &format);
			    
			    /**
			     * get format of subsampling image file
			     * @param[out] format - format of image file.
			     * @return STATUS_OK on success,
			     *         STATUS_FAILED on failure.
			     */
			    Status GetSubsamplingFileFormat(FileFormat &format);
			    
			    /**
			     * get format of thumbnail file
			     * @param[out] format - format of image file.
			     * @return STATUS_OK on success,
			     *         STATUS_FAILED on failure.
			     */
			    Status GetThumbnailFileFormat(FileFormat &format);
			    
			    /**
			     * get orientation of image file
			     * @param[out] orientation - PORTRAIT / LANDSCAPE
			     * @return STATUS_OK on success
			     *         STATUS_FAILED on failure.
			     */
			    Status GetOrientation(Orientation &orientation);
			    
			    /**
			     * get angle of image file
			     * @param[out] angle - NOROTATE / ROTATE90 / ROTATE180 / ROTATE270
			     * @return STATUS_OK on success
			     *         STATUS_FAILED on failure.
			     */
			    Status GetAngle(Angle &angle);
			    
			    /**
			     * get color mode of image file
			     * @param[out] color - COLOR / GRAY / MONO
			     * @return STATUS_OK on success
			     *         STATUS_FAILED on failure.
			     */
			    Status GetColorMode(ColorMode &color);
				 
				/**
				 * UploadCopyJpegParameter puts the cjd file to the server along with main image.
				 * @param[in] session - Webdav session object 
				 * @param[in] imageName - Name of the image whose corresponding CJD file needs to be uploaded
				 * @param[in] docUri - Path where CJD file needs to be uploaded
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure. e.g. file not found.
				 *         STATUS_DISKFULL on disk full 
				 */
				Status UploadCopyJpegParameter(/*Ref<ci::DocumentStore::Session> session,*/CString imageName,CString docUri);

				/**
				 * informs the user if Copy-JPEG parameter is set previously
				 * @param
				 * @return STATUS_OK if Copy-JPEG parameter is set
				 *         STATUS_FAILED if Copy-JPEG parameter is not set.
				 */
				Status IsCopyJpegParameterSet();
				
				/**
				* Get the extension type for the image
				* @param[in] pageType -
				*		1 - Normal Image
				*		2 - SubSampling Image
				*		3 - Thumbnail Image	
				* @return - The extension type
				*/
				CString GetExtension(int pageType);

				/**
				 * Get the Page number for given page ref
				 * @return - The Page Number
				 */
				CString GetPageNo();
				CString GetPropertyFile();
				CString GetBlankPropertyFile();
				Status SetBlankPropertyFile(int pageno,CString path="");
				

		}; // CPage class

	}; // end of namespace boxdocument
}; // end of namespace ci

#endif // __CI_CPAGE_H__

