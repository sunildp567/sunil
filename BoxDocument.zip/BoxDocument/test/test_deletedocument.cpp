// test case of delete document

#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>

using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

// AL side
bool test_deletedocument_AL() {
    // AL knowledge
    CString BoxBasePath = "DocumentStore/EFilingBoxes";
    CString BoxNumber = "00000";
    CString FolderName = "";
    CString DocumentName = "00000";
    
    // 1: get an instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(!boxdoc) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // 1.1: Delete Document
    if(boxdoc->DeleteDocument(BoxBasePath, BoxNumber, FolderName, DocumentName) != STATUS_OK) {
        DEBUGL1("BoxDocument::DeleteDocument() is failed\n");
        return false;
    }
    
    return true;
}

bool test_deletedocument() {
    return test_deletedocument_AL();
}


