/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cboxdocument.h
Revision: com_t#4
File Spec: EBX:MA6033.A-DEV_SRC;com_t#4
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:31:19

Outline : 

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
1:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
Creation Date: 13-JAN-2009 19:36:02
Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA

2:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
Creation Date: 13-JAN-2009 18:00:09
Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA

3:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
Creation Date: 13-JAN-2009 15:14:46
Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA

------------------------------------------------------------------------------
History:
Revision com_t#4 (APPROVED)
Created:  09-JAN-2009 21:31:19      CHANDRAMOHAN.PUJARI
Added overloaded function for delete Document with progress Ref
Updated:  09-JAN-2009 21:31:19      CHANDRAMOHAN.PUJARI
Added overloaded function for delete Document with progress Ref
Updated:  09-JAN-2009 21:31:19      CHANDRAMOHAN.PUJARI
Item revision com_t#4 created from revision com_t#3 with status
$TO_BE_DEFINED
Updated:  09-JAN-2009 21:31:19      CHANDRAMOHAN.PUJARI
Added overloaded function for delete Document with progress Ref

Revision com_t#3 (APPROVED)
Created:  19-DEC-2008 22:15:59      CHANDRAMOHAN.PUJARI
code indentation done
Updated:  19-DEC-2008 22:15:59      CHANDRAMOHAN.PUJARI
Item revision com_t#3 created from revision com_t#2 with status
$TO_BE_DEFINED
Updated:  19-DEC-2008 22:15:59      CHANDRAMOHAN.PUJARI
code indentation done
Updated:  19-DEC-2008 22:15:59      CHANDRAMOHAN.PUJARI
code indentation done

Revision com_t#2 (APPROVED)
Created:  08-DEC-2008 20:27:12      CHANDRAMOHAN.PUJARI
Added New API Acquire with sessionID parameter and updated the
comments
Updated:  08-DEC-2008 20:27:12      CHANDRAMOHAN.PUJARI
Added New API Acquire with sessionID parameter and updated the
comments
Updated:  08-DEC-2008 20:27:12      CHANDRAMOHAN.PUJARI
Item revision com_t#2 created from revision com_t#1 with status
$TO_BE_DEFINED
Updated:  08-DEC-2008 20:27:12      CHANDRAMOHAN.PUJARI
Added New API Acquire with sessionID parameter and updated the
comments

Revision com_t#1 (APPROVED)
Updated:  03-NOV-2008 19:18:02      CHANDRAMOHAN.PUJARI
Item revision com_t#1 created from revision com_m#1.2 with
status $TO_BE_DEFINED
Created:  03-NOV-2008 19:18:02      CHANDRAMOHAN.PUJARI
Added m_sessionID for clipboard functionalities such as copy,cut
and paste
Updated:  03-NOV-2008 19:18:02      CHANDRAMOHAN.PUJARI
Added m_sessionID for clipboard functionalities such as copy,cut
and paste
Updated:  03-NOV-2008 19:18:02      CHANDRAMOHAN.PUJARI
Added m_sessionID for clipboard functionalities such as copy,cut
and paste

Revision com_m#1.2 (APPROVED)
		Updated:  01-SEP-2008 17:15:57      13848
Updated attribute(s)
		Created:  01-SEP-2008 17:14:33      13848
		Update for Ph3.5 1st build
		Updated:  01-SEP-2008 17:13:13      13848
		Item revision com_m#1.2 created from revision com_m#1.1 with
		status $TO_BE_DEFINED

Revision com_m#1.1 (UNIT TESTED)
		Updated:  01-SEP-2008 16:51:16      13848
Updated attribute(s)
		Created:  25-AUG-2008 20:11:37      13848
		BoxDocument 2nd release
		Updated:  25-AUG-2008 20:07:19      13848
		Item revision com_m#1.1 created from revision com_m#1 with
		status $TO_BE_DEFINED

Revision com_m#1 (UNDER WORK)
		Created:  19-AUG-2008 14:33:36      13848
		Initial revision
		========================== End of Source Header =============================*/

#ifndef __CI_CBOXDOCUMENT_H__
#define __CI_CBOXDOCUMENT_H__

#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/OperatingEnvironment/thread.h>
#include "cprogress.h"
#include <CI/BoxDocument/progress.h>
#include "CI/OperatingEnvironment/sharedmemory.h"
#include "CI/OperatingEnvironment/file.h"
#include "CI/OperatingEnvironment/folder.h"

namespace ci{
		namespace boxdocument {

						#define TEMPORARY_EXTRACT_DOC_LIST "/storage/box/EFilingBoxes/.extractedfiles"

						using namespace operatingenvironment;
						typedef void *ThreadArg;
						typedef void *ThreadRtn;
						typedef ThreadRtn (*ThreadFun)(ThreadArg);
						#define FLAG_RESET false
						#define FLAG_SET true
						#define UUID_CONTENT_LENGTH 100
						#define AUTH_STATE 				"authState"
						#define AUTH_FAILURE_COUNT 	"authFailureCount"
						#define AUTH_FAILURE_COUNT_SSDK	"authFailureCount_SSDK"					
						#define AUTH_TIMER 				"authTimer"
						#define USER_THREADLOCKPATH "lockingstartupdationofusercount"
						
						/**
						 * CBoxDocument class provides to actual facility of BOX
						 */
						class CBoxDocument : public BoxDocument
						{
								private:
										/// determine which BoxDocument locking the document
										CUUIDRef m_uuid;
										Ref<Thread> m_ThreadID;
										static CString m_boxbasepath;
										static CString m_boxnumber;
										static CString m_foldername;
										static CString m_documentname;
										static int m_DelDocFlag;
					
										
										CString m_DelDocProgShmName;
										CString m_DeleteDocErrfile;
										
										/**
										* Create a new Thread object with specified functionName and launch it with 
										* specified functionArgument
										*/
										Status CreateThread(ThreadFun functionName,ThreadArg functionArgument,Ref<Thread> threadID);
										/**
										* Launch or Start a new thread for Delete Document operation 
										*/
										static void* StartDeleteDocumentThread(void* arg);
										/**
										* 
										* On occurence of an error, this function 
										* is called and a file is created by a given filename
										*/
										void ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid);
										
										/**
									     * get password protected Box instance
									     * @param[out] box - instance of Box class 
									     * @param[in] boxbasepath - box type e.g. "eFilingboxes"
									     * @param[in] boxnumber - string of 1-20 digits box number
									     * @param[in] boxpassword - box password
									     * @return STATUS_OK on success,
									     *         STATUS_FAILED on failure,
									     *         STATUS_AUTHENTICATIONFAILS on authentication fails,
									     *         STAUTS_BOXISLOCKED on box is locked.
									     *         STATUS_RESOURCENOTFOUND if the box is not found
									     */										
										Status GetPasswordProtectedBox(BoxRef &box, CString boxbasepath, 
													CString boxnumber,CString boxpassword);
										
										Status DeleteBox(BoxRef box,CString boxbasepath, CString boxnumber);
										
										Status SetProperty(CString boxpath, CString PropName,uint32 PropVal);
										Status SetProperty(CString boxpath, CString PropName,CString PropVal);
										
										Status GetProperty(CString boxpath, CString PropName,uint32& PropVal);
										Status GetProperty(CString boxpath, CString PropName,CString& PropVal);

										Status Initialize(CString boxbasepath);
										Status RemoveStatusFile(CString boxbasepath);
										Status ClearClipboardWorkspace();
										Status CreateSharedMem(CString boxbasepath);
										/**
										* get password protected Box instance
										* @param[out] box - instance of Box class 
										* @param[in] boxbasepath - box type e.g. "eFilingboxes"
										* @param[in] boxnumber - string of 1-20 digits box number
										* @param[in] boxpassword - box password
										* @return STATUS_OK on success,
										*         STATUS_FAILED on failure,
										*         STATUS_AUTHENTICATIONFAILS on authentication fails,
										*         STATUS_RESOURCENOTFOUND if the box is not found
										*/																				
										Status GetPasswordProtectedMailBox(BoxRef &box, CString boxbasepath, CString boxnumber,CString boxpassword, bool enableAdminPass);
										
										
								public:
										//Holds the Session ID
										CString m_sessionID;
										static const uint EFILING_BOX_LIMIT = 201;
										static const uint ITUT_BOX_LIMIT = 300;									
										static const uint FOLDER_LIMIT = 100;
										static const uint DOC_LIMIT = 400;
										static const uint PAGE_LIMIT = 1000;
										static const uint PAGELOGBOX_PAGE_LIMIT = 1000;
										static const uint PAGELOGBOX_DOC_LIMIT = 1000;
										static const uint FAXRXPREVIEWBOX_DOC_LIMIT = 1000;
										static Status incrementUserCount(CString boxbasepath);
										static Status decrementUserCount(CString boxbasepath);
										/** constructor */
										CBoxDocument(CString sessionID);

										/** Virtual destructor */
										virtual ~CBoxDocument();

										/**
										 * Returns a reference to a BoxDocument
										 * @return reference to BoxDocument interface  
										 */
										static BoxDocumentRef Acquire();

										/**
										 * Returns a reference to a BoxDocument
										 * Updates the session ID if present else creates a new sessionID and returns it to the user. 
										 * @return reference to BoxDocument interface  
										 */
										static BoxDocumentRef Acquire(CString &sessionId);
										/**
									     * create new box
									     * @param[out] box - instance of Box class
									     * @param[in] boxbasepath - box type e.g. "eFilingboxes"
									     * @param[in] boxnumber - string of 1-20 digits box number
									     * @param[in] boxpassword - the password of box. if empty, the box is 
									     *                          NOT protected.
									     * @return STATUS_OK on success,
									     *         STATUS_FAILED on failure,
									     *         STATUS_DISK_FULL if there is not enough space on the disk.
									     *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the resource limit is reached    
									     *         STATUS_RESOURCE_WITH_SAME_NAME_EXISTS If the resource already exits
									     */
									    Status CreateBox(BoxRef &box, 
									                             CString boxbasepath, 
									                             CString boxnumber,
									                             CString boxpassword="");

									    /**
									     * get protected Box instance by path
									     * @param[out] box - instance of Box class 
									     * @param[in] boxbasepath - box type e.g. "eFilingboxes"
									     * @param[in] boxnumber - string of 1-20 digits box number
									     * @param[in] boxpassword - box password
									     * @return STATUS_OK on success,
									     *         STATUS_FAILED on failure,
									     *         STATUS_AUTHENTICATIONFAILS on authentication fails,
									     *         STAUTS_BOXISLOCKED on box is locked.
									     *         STATUS_RESOURCENOTFOUND if the box is not found
									     */
									    Status GetBox(BoxRef &box, 
									                          CString boxbasepath, 
									                          CString boxnumber,
									                          CString boxpassword="");

										/**
										 * get a list of box
										 * @param[out] list - list of boxes. This list have snapshot of each box
										 *                     instances. the snapshot is independent from original
										 *                     boxes. it means you can read properties only through
										 *                     the snapshot. if you call other methods to the 
										 *                     snapshot, it will fail.
										 * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */
										Status GetBoxList(BoxList &list, CString boxbasepath);
										/**
										 * get a list of box
										 * @param[out] list - list of boxes. This list have snapshot of each box
										 *                     instances. the snapshot is independent from original
										 *                     boxes. it means you can read properties only through
										 *                     the snapshot. if you call other methods to the 
										 *                     snapshot, it will fail.
										 * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										 * @param[in] from - return list from this value.
										 * @param[in] size - list size, if "from" + "size" is bigger than the 
										 *                    number of all boxes, return list size will be smaller
										 *                    than "size".
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */
										Status GetBoxList(BoxList &list, CString boxbasepath, 
														unsigned int from, unsigned int size);

										/**
										 * delete the box
										 * if documents in the box is using, it will fail(some documents are 
										 *  deleted).
										 * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										 * @param[in] boxnumber - string of 1-20 digits box number
									      * @param[in] boxpassword - box password										 
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */
										Status DeleteBox(CString boxbasepath, CString boxnumber,CString boxpassword="");
										
									    /**
									     * get protected MailBox instance by path
									     * @param[out] box - instance of Box class 
									     * @param[in] boxbasepath - box type e.g. "eFilingboxes"
									     * @param[in] boxnumber - string of 1-20 digits box number
									     * @param[in] context - access context enum    
									     * @param[in] boxpassword - box password
									     * @return STATUS_OK on success,
									     *         STATUS_FAILED on failure,
									     *         STATUS_AUTHENTICATIONFAILS on authentication fails,
									     *         STATUS_BOXISLOCKED on box is locked.
									     *		  STATUS_RESOURCENOTFOUND	if Box is not found     
									     *		  STATUS_NOT_ALLOWED if any invalid box operation is performed
									     */
										Status GetMailBox(BoxRef &box, CString boxbasepath, CString boxnumber,
														AccessContext context,CString boxpassword = "",CString phoneno = "" , bool enableAdminPass = true);

										/**
										 * delete the mail box
										 * if documents in the box is using, it will fail(some documents are 
										 *  deleted).
										 * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										 * @param[in] boxnumber - string of 1-20 digits box number
									      * @param[in] context - access context enum    
									      * @param[in] boxpassword - box password										 
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */
										Status DeleteMailBox(CString boxbasepath, CString boxnumber,AccessContext context,CString boxpassword="");
										 
										/**
										 * delete document
										 * document status will be changed to DELETING. after that, document will
										 * be deleted. 
										 * if document status is NOT READY or EDITING, it will fail.
										 * @param[out] progress - user can get operation progress from this.
										 * @param[in] boxbasepath - box type e.g. "eFilingboxes"
										 * @param[in] boxnumber - string of 1-20 digits box number
										 * @param[in] foldername - folder name.
										 * @param[in] documentname - serial number from "00000".
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */
										Status DeleteDocument(ProgressRef& progress,
																CString boxbasepath, 
																CString boxnumber,
																CString foldername,
																CString documentname);

										/**
										 * Initialize all Documents.
										 * If Document status is CREATING or DELETING, it is changed to WAITING.
										 * WAITING Document is deleted when Cleanup() is called. If Document status
										 * is EDITING or USING, it is changed to READY. Also the method clean up 
										 * box clipboard.
										 * Till finishing initialization, BoxDocument::GetStatus returns 
										 * INITIALIZING. And BoxDocument returns STATUS_FAILED_INITIALIZATION 
										 * on the other methods. 
										 * @return STATUS_OK on success.
										 *         STATUS_FAILED_INITIALIZATION on INITIALIZING.
										 */
										Status Initialize();
										
										/**
										 * Cleanup all WAITING Documents.
										 * The method search each box and delete WAITING Document.
										 * @return STATUS_OK on success.
										 *         STATUS_FAILED_INITIALIZATION when uninitialized
										 */
										Status Cleanup(CString boxbasepath);
										/**
										 * Cleanup all WAITING Documents.
										 * The method search each box and delete WAITING Document.
										 * @return STATUS_OK on success.
										 *         STATUS_FAILED_INITIALIZATION when uninitialized
										 */
										Status Cleanup();
										
										/**
										 * return the status of BoxDocument
										 * @return READY - BoxDocument is available.
										 *         INITIALIZING - BoxDocument is initializing, not available.
										 *         UNINITIALIZED - BoxDocument is uninitialized, not available.
										 */
										BoxDocStatus GetStatus(CString boxbasepath);

									    /**
									     * confirm Box exists or not
									     * @param[in] boxbasepath - box type e.g. "eFilingboxes"
									     * @param[in] boxnumber - string of 1-20 digits box number
									     * @return true if box exists
									     *         false if box doesn't exist.
									     */
									    bool BoxExist(CString boxbasepath, CString boxnumber);										

										/**
										* Delete all folders/documents and delete all boxes except public box
										* @param[in] boxbasepath - box type e.g. "eFilingboxes"
										* @return STATUS_OK on success,
										*         STATUS_AUTHENTICATIONFAILS on Authentication failure.
										*         STATUS_NOTREADY if Box is not READY
										*         STATUS_FAILED on failure
										*/
										Status DeleteAll(CString boxbasepath);

										/**
										* Deletes all Box/folders/documents by changing the status of the document to DELETING
										* @param[in] boxbasepath - box type e.g. "eFilingboxes"
										* @return STATUS_OK on success,
										*         STATUS_FAILED on failure
										*/
										Status StartDeletion(CString boxbasepath);

										/**
										* Verifies if the status of documents is WAITING/DELETING/READY. If one of the document 
										* status is not WAITING/DELETING/READY then it return STATUS_NOTREADY error.
										* @param[in] boxbasepath - box type e.g. "eFilingboxes"
										* @param[in] passwd - Admin password
										* @return STATUS_OK on success,
										*         STATUS_NOTREADY if Box is not READY
										*         STATUS_FAILED on failure
										*/
										Status CheckStatus(CString boxbasepath);

										/**
										* deletes all documents which are copied to clipboard during clipboard operations.
										* This API only deletes document in clipboard related to a particular session. 
										* @return STATUS_OK on success,
										*         STATUS_FAILED on failure
										*/
										Status ClearClipBoard();

										/**
										* This method search for each box present in the EFilingBoxes and unlock the box if it is locked. 
										* @return STATUS_OK
										*		STATUS_FAILED
										*/
										Status UnlockAllBoxes();

										/**
										* Delete all folders/documents and delete all boxes
										* @param[in] boxbasepath - box type e.g. "eFilingboxes"
										* @param[in] publicbox - create public box
										* @return STATUS_OK on success. 
										*         STATUS_FAILED on Failure	
										*/
										Status DeleteAll(CString boxbasepath, bool publicbox);
										
										/**
										 * confirm the BoxBasePath is used.
										 * @param[in] boxbasepath - box type e.g. "EFilingboxes"
										 * @return true if the boxbasepath is used.
										 *         false if the boxbasepath is NOT used.
										 */
										bool isUsed(CString boxbasepath = "EFilingBoxes");	
										/*
										 * get a list of box
										 * @param[out] list - list of boxes. This list have snapshot of each box
										 *                     instances. the snapshot is independent from original
										 *                     boxes. it means you can read properties only through
										 *                     the snapshot. if you call other methods to the 
										 *                     snapshot, it will fail.
										 * @param[out] totalBoxes - Total number of boxes 										 
										 * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										 * @return STATUS_OK on success,
										 *         STATUS_FAILED on failure.
										 */

										Status GetBoxList(BoxList &list, int &totalBoxes, CString boxbasepath);
										
                              
										/*
										* get a list of mailbox
										* @param[out] list - list of mailboxes. This list have snapshot of each mailbox
										*                     instances. the snapshot is independent from original
										*                     mailboxes. it means you can read properties only through
										*                     the snapshot. if you call other methods to the 
										*                     snapshot, it will fail.
										* @param[out] totalBoxes - Total number of mailboxes 										 
										* @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
										* @return STATUS_OK on success,
										*         STATUS_FAILED on failure.
										*/
										Status GetMailBoxList(BoxList &list, int &totalBoxes, CString boxbasepath);


								};// class CBoxDocument
				}; // end of namespace boxdocument
		}; // end of namespace ci

#endif // __CI_CBOXDOCUMENT_H__
