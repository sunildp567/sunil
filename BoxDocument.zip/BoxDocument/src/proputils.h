/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
Filename: webdavwrapper.h
Revision: com#3.0
File Spec: EBX:A10955.A-DEV_SRC;com#3.0
Originator: 07475
Last Changed: 27-MAY-2009 13:22:52

Outline : 

============================== Source Header End=================================*/

#ifndef __CI_PROPUTILS_H__
#define __CI_PROPUTILS_H__

#include <vector>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/globalmutex.h>
#include <CI/BoxDocument/document.h>
#include "cboxdocument.h"
#include "cextract.h"

namespace ci {
namespace boxdocument {

using namespace operatingenvironment;

const CString BOXPATH = "/storage/box";
#define STORAGE_PART_NAME "STORAGE"
#define STORAGE_NEAR_FULL_CHECK_SIZE (1024*200)
/**
 * propretriever has helper functions to read and update the properties related to boxdocument
 */
 
class proputils
{
public:
	/**
	* Retrieve all the properties for the given box.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[out] PropertyMap - Map containing all properties related to given box.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetAllBoxProperties(CString boxbasepath, 
										CString boxnumber,
										std::map<CString, CString> &PropertyMap);
	/**
	* Retrieve all the properties for the given Folder.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[out] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetAllFolderProperties(CString boxbasepath,
								CString boxnumber,
								CString foldername,
								std::map<CString, CString> &PropertyMap);
	
	
	/**
	* Retrieve all the properties for the given document.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[out] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetAllDocumentProperties(CString boxbasepath,
									CString boxnumber,
									CString foldername,
									CString documentname,
									std::map<CString, CString> &PropertyMap);

	/**
	* Retrieve all the properties for the given Page.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[in] PageNumber - serial number from "000".	
	* @param[out] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetAllPageProperties(CString boxbasepath,
									CString boxnumber,
									CString foldername,
									CString documentname,
									CString PageNum,
									std::map<CString, CString> &PropertyMap);
	
	static Status GetProperties(CString boxbasepath,
							CString boxnumber,
							CString folder,
							CString documentpath,
							CString pagepath,
							std::map<CString, CString> &PropertyMap);
	/**
	* Retrieve the string value of the requested properties for the given resource type
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[in] PageNumber - serial number from "000".	
	* @param[in] NodeName - Name of the node whose value needs to be retieved.
	* @param[out] Value - string Value of the requested property 
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetProperty(CString boxbasepath,
							CString boxnumber,
							CString folder,
							CString documentpath,
							CString pagepath,
							CString NodeName,
							CString &Value);
	
	static Status GetPageProperty(CString path,
							CString xmlfile,
							CString NodeName,
							CString &propertyvalue)	;

	/**
	* Set the list of properties for the given box.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status SetBoxProperties(CString boxbasepath,
							CString boxnumber,
							std::map<CString, CString> PropertyMap);
	/**
	* Set the list properties for the given Folder.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[in] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status SetFolderProperties(CString boxbasepath,
								CString boxnumber,
								CString foldername,
								std::map<CString, CString> PropertyMap);
	
	
	/**
	* Set the list properties for the given document.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[in] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status SetDocumentProperties(CString boxbasepath,
									CString boxnumber,
									CString foldername,
									CString documentname,
									std::map<CString, CString> PropertyMap);

	/**
	* Set the list properties for the given Page.
	* @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @param[in] PageNumber - serial number from "000".	
	* @param[in] PropertyMap - vector containing all properties related to given box  
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status SetPageProperties(CString boxbasepath,
								CString boxnumber,
								CString foldername,
								CString documentname,
								CString PageNum,
								std::map<CString, CString> PropertyMap);

	static Status SetProperty(CString boxbasepath,
							CString boxnumber,
							CString folder,
							CString documentpath,
							CString pagepath,
							CString NodeName,
							CString Value);
	

	
	
};

class Utility 
{
public:

	/**
	* get document instance
	* @param[out] doc - instance of Document class 
	* @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetDocument(CString sessionID, DocumentRef& doc,CString boxbasepath,CString boxnumber,CString foldername,CString documentname);

	/**
	* Read the number of folders present inside the given box.
	*/
	static Status GetFolderCount(CString boxbasepath,CString boxNumber,unsigned int &count);
	
	/**
	* Read the number of documents present inside the given box.
	*/
	static Status GetDocumentCount(CString boxbasepath,CString boxNumber,CString folderpath,unsigned int &count, bool underbox=false);

	
	/**
	* Get local time
	*/
	static CString GetLocalTime();

	/**
	* get unix time
	*/
	static CString GetUnixTime();

	/**
	* convert to zero-filling, 5-digit string
	*/
	static CString Get5DigitPageNo(int pageno);

	/**
	* extract folder path from file name
	*/
	static CString GetFolderPath(CString filename);

	/**
	* get temporary folder path
	*/
	static CString GetTmpPath();

	/**
	* get temporary folder path meant for CI i,,e "/Work/CI/tmp"
	*/
	static CString GetCITmpPath();

	/**
	* get HDB Root path
	*/
	static CString GetHDBROOTPath();

	/**
	* get EB2 Root path
	*/
	static CString GetEB2ROOTPath();
	/**
	* convert to zero-filling, 3-digit string
	* @return 3 digit hexadecimal Page number
	**/
	static CString GetHexadecimalPageNo(int pageno);

	/*
	* Calculate the size of the Resouce
	*/
	static Status ResourceSize(CString sessionID, CString boxbasepath, CString boxnumber, CString foldername,CString documentname, CString filename,uint64 &ressize);
	/*
	 * Parse the nodes below the root node and return the nodenames and corresponding values 
	 */
	static Status GetAllProperties(CString path,CString xmlfile, std::map<CString, CString> &PropertyMap);
	static Status GetPropertyMaps(CString path, CString xmlfile, std::map<CString, CString> &PropertyMap, 
															CString *stringArray, int stringArraySize, bool flag = true); 

	/**
	* check resource (Box/Folder/Document/File)  exist on WebDAV server
	* @param[in] session - WebDAV session 
	* @param[in] path - resource path from WebDAV path.
	                  e.g. "/DocumentStore/-"
	* @return true if resource exists,
	*         false if not exist.
	*/
	static bool ResourceExist(CString path);

	/**
	* check resource (Box/Folder/Document) exist on WebDAV server
	* @param[in] session - WebDAV session 
	* @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @return true if resource exists,
	*         false if not exist.
	*/
	static bool ResourceExist(CString boxbasepath,CString boxnumber,CString foldername = "",CString documentname = "");

	/**
	* get resource (Box/Folder/Document) path on WebDAV server
	* @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
	* @param[in] boxnumber - string of 1-20 digits box number
	* @param[in] foldername - folder name.
	* @param[in] documentname - serial number from "00000".
	* @return resource path from WebDAV path.
	*          e.g. "/DocumentStore/-"
	*/
	static CString GetResourcePath(CString boxbasepath,CString boxnumber = "",CString foldername = "",CString documentname = "");

	/**
	* get collection list on WebDAV server
	*  list is sorted by collection name.
	* @param[out] vec - collection name list
	* @param[in]  path - resource path.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	static Status GetCollectionList(std::vector<CString> &vec,CString path);

	static Status GetDocumentList(std::vector<CString> &vec,CString path);	

	static Status GetPageCollectionList(std::vector<CString> &vec,CString path); 	

	static Status SetProperties(CString path,CString xmlfile, std::map<CString, CString> PropertyMap);

	static Status Getxmlfile(CString boxbasepath,CString boxnumber,CString folder,CString documentpath,
					CString pagepath,std::vector<CString> &values);

	/**
	 * enter critical section
	 *  arguments are used to distinguish which critical section is used.
	 * @param[in] path - to distinguish which critical section will be used.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	static Status EnterCriticalSection(GlobalMutexRef &m_mutex, CString path);

	/**
	 * leave critical section
	 *  arguments are used to distinguish which critical section was used.
	 * @param[in] path - to distinguish which critical section will be used.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
 	 * Note that The User must pass mutex object that was created while acquing the or entereing critical section
 	 * Else this API will return Failure. Also the API cannot be use to leave a semaphore without acquiring, 
 	 * hence it can be used only in single process context.(This can be treated as a limitation).
	 */
	 
	static Status LeaveCriticalSection(GlobalMutexRef &m_mutex);
	
	static Status GetProperty(CString path,CString xmlfile, CString NodeName, CString &value);
	static Status CreateFile(CString path,  CString filename);
	static Status InitSts(CString path);
	static Status RemoveResource(CString path);
	/*
	 *  CreateUniqueFile
	 * @param[in] path - where the unique file has to be created.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 "	As Name/path for the critical section was going beyond 255 bytes when multi byte characters are used, 
	 *   Implementation was modified to use a unique ID for each box/document/folder/page/. 
	*/
	static Status CreateUniqueFile(CString path, CString uniqid = ".uniqid_");
	/*
	 *  CreateUniqueFile
	 * @param[in] path - where the unique file has to be created.
	 * @param[in/out] uniqid - on input, it is ".delete_" name expected by users.
	 * 					On output it is appended with suffix.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 "	As Name/path for the critical section was going beyond 255 bytes when multi byte characters are used, 
	 *   Implementation was modified to use a unique ID for each box/document/folder/page/. 
	*/
	static Status CreateUniqueFile(CString path, CString *uniqid);  //added as a fix to DTFR_17238
	/*
	 *  GetUniqueFile
	 * @param[in] path - where the unique file has to be created.
	 * @param[in] uniqFileName - Name of the unique file thats obtatined/created
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 "	As Name/path for the critical section was going beyond 255 bytes when multi byte characters are used, 
	 *   Implementation was modified to use a unique ID for each box/document/folder/page/. 
	 *   The UID will be created if it does not exist. Else same UID will be used as path for Critical section for locking
	*/
	
	static Status GetUniqueFile(CString path, CString &uniqFileName, CString uniqid = ".uniqid_", bool getuniqfile = true);	
	
	/*
	 *  Delete unique file
	 * @param[in] path - where the unique file has to be created.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	*/
	static Status DeleteUniqueFile(CString path, CString uniqid = ".uniqid_");
	
	/*
	* Get status of a document
	*/	
	static Status GetStatus(CString boxpath, CString boxnum, CString foldername, CString docName, DocStatus &eDocStatus);		
	
	/*
	*change status of a document
	*/	
	static Status ChangeStatus(CString boxpath, CString boxnum, CString foldername, CString docName, DocStatus eDocStatus);		

	/*
	* Get the sub product
	*/	
	static CString GetSubProduct();

	/*
	 *Get the EQUIPMENT BRAND from the setenv file 	
        */		
	static CString GetEquipmentBrand();	

	/**
	 * Limits the document name to 64 characters
	 * if document with the same document name is already present, truncates the 
	 * document name to 60 characters and appends it with "-001" which is increamented 
	 * if the document name with "-001" post-fix is also present
	 *@param[in/out] documentname - document name which has to be limited to 64 characters
			[in/out] newpath - location of the document
			[in] path - /storage/box/EFliingBoxes/
	 *@return STATUS_OK on success
			  STATUS_FAILED on failure
	 */
	static Status LimitTo64Characters(CString &documentname,CString &newpath,CString path);

	/**
	 * Truncates the documentname
	 * @param[in] indocname - input document name 
	 *		[in/out] outdocname - truncated document name
	 *		[in] trunc - Length of the document name
	 *@return STATUS_OK on success
	 *        STATUS_FAILED on failure
	 */
	static Status TruncateDocumentName(const char *indocname,CString &outdocname,int trunc);

	static Status CompareProductType(CString srcProduct, CString dstProduct, bool &);
	/**
	 * To acquire lock on lockfiles created for systemDataFile operations
	 * @param[in] path - document path 
	 *	      [in/out] fileDescriptor - fd of the file to lock system data
	 *	      [in] openSystemFile - boolean value to identify shared or exclusive lock
	 *@return STATUS_OK on success
	 *        STATUS_FAILED on failure
	 */
        static Status AcquireLockforSystemfile(CString path, int &fileDescriptor, bool openSystemFile);
	/**
	 * To release lock on lockfiles created for systemDataFile operations
	 * @param[in] 
	 *	      [in/out] fileDescriptor - fd of the file to lock system data
	 *@return STATUS_OK on success
	 *        STATUS_FAILED on failure
	 */
        static Status ReleaseLockforSystemfile(int &fileDescriptor);
	/**
	 * To get valid docRef for further dom operations.
	 * @param[in] path - document path 
	 *	      [in/out] HierarchicalDBRef - pHDB 
	 *	      [in/out] dom::DocumentRef - doc
	 *	      [in] domfilename - CString type with value documentproperties_dom/pageproperties_*_dom
	 *	      [in] pLockpath   - CString type with value holding document folder path or page image folder path
	 *	      [in] fullpath    - CString type with value holding fullpath for documentproperties_dom/pageproperties_*_dom
	 *@return STATUS_OK on success
	 *        STATUS_FAILED on failure
	 */        
	static Status GetDomDocumentRef(hierarchicaldb::HierarchicalDBRef &hdb, dom::DocumentRef &doc, CString domfilename, CString pLockpath, CString fullpath);
	/**
	 * To get available size of /storage partition for CreateDocument operations.
	 * @param[in/out] bHasAvailableSize - boolean type to check if /storage has 200MB of space available.
	 * @return STATUS_OK, if  GetAvailableSize() is success, else
	 *         STATUS_FAILED,
	 */        
 	static Status IsStorageFull(bool &bHasAvailableSize);
};
/**
 * predicate object for confirm the folder is Folder
 */
class IsFolder 
{
public:
    IsFolder();
    bool operator()(CString path) const;
}; // class IsFolder

/**
 *  predicate object for confirm the folder is Document
 */
class IsDocument 
{
public:
    IsDocument();
    bool operator()(CString path) const;
}; // class IsDocument

/**
 * CtiticalSection class using GlobalMutex
 */
class CriticalSection 
{
private:
	CString key;
	GlobalMutexRef m_mutex;	
public:
    CriticalSection(CString path);
    ~CriticalSection();
}; // class CriticalSection
DECL_OBJ_REF(CriticalSection);
}
}
#endif
	
