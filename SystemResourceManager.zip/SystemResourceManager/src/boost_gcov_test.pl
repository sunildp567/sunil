#!/usr/bin/perl


use Getopt::Std;
use Cwd;

sub print_usage
{
    print STDOUT "Usage: boostUnitTestScript.pl [-q][-h]  \n";
    print STDOUT "       -q is quiet mode, output redirected to unit_test.log  \n";
    print STDOUT "       -h displays this help message  \n";
}

sub run_boost_test_program
{
   sleep 2;
   if (-x $PROGRAM)
   {
	   print STDOUT "\n*******************Executing the program  $PROGRAM**************************\n";
	   print STDOUT	   "($ENV{'EB2'}/build/debug/bin/$PROGRAM) >cisrm_unit_test.log 2>&1";	
	   system "($ENV{'EB2'}/build/debug/bin/$PROGRAM) >cisrm_unit_test.log 2>&1";	
	   sleep 30;
       
       print STDOUT "\n***********************************************************\n";
       print STDOUT "** Boost unit testing for $test_location\n";
       print STDOUT "** Output written to $PROGRAM.out\n";
       print STDOUT "***********************************************************\n\n";
   } else {
       die "$PROGRAM not found\n";
   }
}

# only source files with the gcno can be tested for coverage
sub list_gcno
{
    my @TMP_SOURCES = <*.gcno>;
    if ( @TMP_SOURCES == 0 ){
       print STDOUT "There are no .gcno files in this directory\n";
       print STDOUT "please export BOOST_UNIT_TEST=enabled and rebuild\n";
       exit;
    }
    # now remove the boost test program related source files
    foreach (@TMP_SOURCES) {
       if((! /^boost/) and (!/unit_test/)){
          s/\.gcno/.cpp/;
          @SOURCES = (@SOURCES, $_);
       }
    }
}
sub cleanup
{
    system "rm -f *.gcov *.gcda ";
}

sub run_gcov
{
    system "gcov $_[0] >/dev/null 2>&1";
}

 



sub cleanup_gcov
{
    system "rm -f *.gcov";
}

sub report_header
{
   print STDOUT "Filename            Executed    Total    %\n";
}


sub report_gcov
{
   my $filename = $_[0];
   open(INFILE, "<$filename.gcov") or return print STDOUT "could not open $filename.gcov\n";
   my $local_lines=0;
   my $local_not_executed=0;
   my $local_executed=0;
   my $local_non_executable=0;
   while(<INFILE>){
      if (/^[ 	][ 	]*-:/){
          $local_non_executable++;
      }
      if (/^[ 	][ 	]*[0-9][0-9]*:/){
          $local_executed++;
          $local_lines++;
      }
      if (/^[ 	][ 	]*#####:/){
          $local_not_executed++;
          $local_lines++;
      }
   }
   my $percentage = $local_executed*100/$local_lines;
   $global_lines += $local_lines;
   $global_not_executed += $local_not_executed;
   $global_executed += $local_executed;
   $global_non_executable += $local_non_executable;
   printf STDOUT "%-20s %5d     %5d     %.2f\n",$filename,  $local_executed, $local_lines, $percentage;
   close(INFILE);
}

sub get_pwd
{

   my $location = cwd;
   #SYSROM_SRC/dev/CI/Codecs/UnitTest
   #if ($location =~ /UnitTest$/){
   #    $location =~ s/^.*SYSROM_SRC\/dev\///;
   #    $location =~ s/\/UnitTest//;
   #    $location =~ s/\//::/g;
   #    $test_location = $location;
   #} else {
   #    print "$location is not a valid UnitTest directory\n";
   #    exit;
   #}
}

sub do_redirects
{
     open (SAVOUT, ">&STDOUT") or die "could not dup STDOUT: $!";
     open (STDOUT, ">unit_test.log") or die "could not open log file: $!";
     select STDOUT; $| = 1;
     open (STDERR, ">&STDOUT") or die "could not dup STDOUT : $!";
     select STDERR; $| = 1;
}

# main program starts here
getopts('qh');
if ($opt_h == 1)
{
   print_usage;
   exit;
}
$MODE = $opt_q;
$PROGRAM = cisrmtestsuit;
$APPLICATION = cisystemresourcemanager;

$global_lines=0;
$global_not_executed=0;
$global_executed=0;
$global_non_executable=0;

# first run the boost program
get_pwd;
if ($MODE == 1){
    do_redirects;
}
cleanup;

run_boost_test_program;
list_gcno;
report_header;
foreach (@SOURCES) {
   cleanup_gcov;
   run_gcov $_;
   report_gcov $_;
}
$percentage = $global_executed*100/$global_lines;
printf STDOUT "\n%-27s   %5d		%5d		%.2f\n",$PROGRAM, $global_executed, $global_lines, $percentage;
if ($MODE == 1){
    printf SAVOUT "%-20s %5d     %5d     %.2f",$test_location, $global_executed, $global_lines, $percentage;
}
