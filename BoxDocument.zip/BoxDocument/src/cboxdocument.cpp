//*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cboxdocument.cpp
 Revision: com_t#4
 File Spec: EBX:MA6032.A-DEV_SRC;com_t#4
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:30:22

 Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#4 (APPROVED)
     Created:  09-JAN-2009 21:30:22      CHANDRAMOHAN.PUJARI
       Added overloaded function for delete Document with progress Ref
     Updated:  09-JAN-2009 21:30:22      CHANDRAMOHAN.PUJARI
       Added overloaded function for delete Document with progress Ref
     Updated:  09-JAN-2009 21:30:22      CHANDRAMOHAN.PUJARI
       Item revision com_t#4 created from revision com_t#3 with status
       $TO_BE_DEFINED
     Updated:  09-JAN-2009 21:30:22      CHANDRAMOHAN.PUJARI
       Added overloaded function for delete Document with progress Ref
   
   Revision com_t#3 (APPROVED)
     Updated:  19-DEC-2008 21:30:57      CHANDRAMOHAN.PUJARI
       updated session id return value
     Created:  19-DEC-2008 21:30:56      CHANDRAMOHAN.PUJARI
       updated session id return value
     Updated:  19-DEC-2008 21:30:56      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
     Updated:  19-DEC-2008 21:30:56      CHANDRAMOHAN.PUJARI
       updated session id return value
   
   Revision com_t#2 (APPROVED)
     Updated:  08-DEC-2008 20:33:10      CHANDRAMOHAN.PUJARI
       Added Code for Acquire with sessionID
       parameter,ScanPreview,Error Codes,LastAccessdate and modified
       date and updated the comments
     Updated:  08-DEC-2008 20:33:08      CHANDRAMOHAN.PUJARI
       Added Code for Acquire with sessionID
       parameter,ScanPreview,Error Codes,LastAccessdate and modified
       date and updated the comments
     Updated:  08-DEC-2008 20:33:08      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
     Created:  08-DEC-2008 20:33:07      CHANDRAMOHAN.PUJARI
       Added Code for Acquire with sessionID
       parameter,ScanPreview,Error Codes,LastAccessdate and modified
       date and updated the comments
   
   Revision com_t#1 (APPROVED)
     Created:  03-NOV-2008 19:20:49      CHANDRAMOHAN.PUJARI
       Added m_sessionid parameter and code for clipboard
       functionalities such as copy,cut and paste
     Updated:  03-NOV-2008 19:20:49      CHANDRAMOHAN.PUJARI
       Added m_sessionid parameter and code for clipboard
       functionalities such as copy,cut and paste
     Updated:  03-NOV-2008 19:20:49      CHANDRAMOHAN.PUJARI
       Added m_sessionid parameter and code for clipboard
       functionalities such as copy,cut and paste
     Updated:  03-NOV-2008 19:20:49      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:57      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:33      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:13      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:16      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:36      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:07:09      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:33:26      13848
       Initial revision
========================== End of Source Header =============================*/
#include <iomanip>
#include <sstream>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/OperatingEnvironment/bytestream.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include "CI/HierarchicalDB/DOM/node.h"
#include "CI/Codecs/passwordidentifier.h"
#include "cboxdocument.h"
#include "cdocument.h"
#include "cbox.h"
#include "cviewbox.h"
#include "proputils.h"
#include <CI/SI/ssdksecuritymanagerinterface.h>
#include <CI/SI/ssdkusertokeninterface.h>
#include <CI/SI/ssdkconfiginterface.h>
#include <CI/SI/ssdkrbacmgmtinterface.h>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


#define EFILING_BOXBASEPATH		"/storage/box/EFilingBoxes"
#define TEMP_BOXBASEPATH			"/storage/box/TempBoxes"
#define OVERLAY_BOXBASEPATH 	"/storage/box/OverlayBoxes"
#define POLLING_BOXBASEPATH 		"/storage/box/PollingBoxes"
#define PAGELOG_BOXBASEPATH 	"/storage/box/PageLogBoxes"
#define ITUT_BOXBASEPATH 			"/storage/box/ITUTBoxes"
#define FAXRXPREVIEW_BOXBASEPATH 			"/storage/box/FaxRxPreviewBoxes"

namespace ci {
    namespace boxdocument {

        typedef struct BoxCount {
            int efilingCount;
            int tempCount;
            int overlayCount;
            int pollingCount;
            int pagelogCount;
            int itutCount;
            int faxrxCount;
        } BoxCount;

#define USERCOUNT_MEMORY "BoxUserCountSharedMemory"//use shared memory to maintain a count of users of BoxDocument instead of xml

        using namespace std;
        using namespace ci::softwarediagnostics;
        using namespace dom;
        using namespace ssdk;
        using namespace ci::codecs;

        typedef std::map<CString, CString> property_pair;

        namespace boxdocstatusfilename
        {
            static const CString INITIALIZING = "initializing.sts";
            static const CString INITIALIZED = "initialized.sts";
            static const CString DELETINGALL = "deleting.sts";		
        };


        // BoxDocument interface
        BoxDocumentRef BoxDocument::Acquire() 
        {
            CString sessionId ="";
            return CBoxDocument::Acquire(sessionId);
        }

        //BoxDocument Interface
        BoxDocumentRef BoxDocument::Acquire(CString &sessionId) 
        {
            return CBoxDocument::Acquire(sessionId);
        }



        // destructor
        CBoxDocument::~CBoxDocument() 
        {
            // release Session
        }

        /**
         * Returns a reference to a BoxDocument
         * Updates the session ID if present else creates a new sessionID and returns it to the user. 
         * @return reference to BoxDocument interface  
         */
        BoxDocumentRef CBoxDocument::Acquire(CString &sessionId)
        {
            //setting Session-ID 
            if(sessionId.empty())
            {
                CUUIDRef uid = new CUUID();	  
                sessionId= uid->toString();
            }		
            BoxDocumentRef Boxdocref = new CBoxDocument(sessionId);
            return Boxdocref;
        }

        // CBoxDocument interface
        // public functions
        // constructor
        CBoxDocument::CBoxDocument(CString sessionID):m_sessionID(sessionID) 
        {
            m_sessionID = sessionID;
            DEBUGL8("CBoxDocument::Acquire - m_SessionID is %s\n",m_sessionID.c_str());
        }

        /**
         * create new box
         * @param[out] box - instance of Box class
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[in] boxpassword - the password of box. if empty, the box is 
         *                          NOT protected.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the resource limit is reached    
         *         STATUS_RESOURCE_WITH_SAME_NAME_EXISTS if the resource already exists 
         */
        Status CBoxDocument::CreateBox(BoxRef &box,CString boxbasepath, CString boxnumber,CString boxpassword)
        {
            DEBUGL4("CBoxDocument::CreateBox::Enter\n");


            // Validate the input parameters & confirm boxnumber is NOT empty
            if((boxnumber.empty()) ||(boxbasepath.empty())) 
            {
                DEBUGL1("CBoxDocument::CreateBox::one of the Input Parameters (boxnumber - <%s> or boxbasepath-<%s>) are Invalid \n",boxnumber.c_str(),boxbasepath.c_str());
                return STATUS_FAILED;
            }

            if(boxbasepath.find("/storage") == std::string::npos)
                boxbasepath = BOXPATH + "/" + boxbasepath;


            //confirm boxbasepath folder already exists
            CString path = boxbasepath + "/";
            if(!ci::operatingenvironment::Folder::Exists(path)) 
            {
                DEBUGL1("CBoxDocument::CreateBox::boxbasepath %s is not found\n", boxbasepath.c_str());
                return STATUS_FAILED;
            }

            //Check if Box is previously initialized or not.
            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::CreateBox: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;	
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::CreateBox: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;		
            }
	    //Check has been added to skip GetCollectionList() in case of TempBoxes creation
	    if((boxbasepath==EFILING_BOXBASEPATH) || (boxbasepath==ITUT_BOXBASEPATH))
	    {
		    //Check if the box doesnot exceed the Box Limit
		    std::vector<CString> vec;
		    path = Utility::GetResourcePath(boxbasepath) + "/";
		    //Now get the list of files present under the boxbasepath.
		    if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
		    {
			    DEBUGL1("CBoxDocument::GetBoxList::Getting collection list is failed");
			    return STATUS_FAILED;
		    }
		    if(((boxbasepath==EFILING_BOXBASEPATH)&&(vec.size()>=EFILING_BOX_LIMIT))
				    ||((boxbasepath==ITUT_BOXBASEPATH)&&(vec.size()>=ITUT_BOX_LIMIT)))
		    {
			    DEBUGL1("CBoxDocument::CreateBox::Box Limit reached\n");
			    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;			
		    }
	    }
            // confirm boxnumber folder donesn't exist
            if(ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath, boxnumber,"","")))
            {
                DEBUGL1("CBoxDocument::CreateBox::boxnumber %s already exists\n", boxnumber.c_str());
                return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
            }
	    Status ret;
	    bool bHasAvailableSize = false;
	    ret = Utility::IsStorageFull(bHasAvailableSize);
	    if(ret != STATUS_OK)
	    {
		    DEBUGL1("CBox::CreateBox:: IsStorageFull() API failed for /storage \n");
		    return STATUS_FAILED;
	    }
	    else
	    {
		    if(!bHasAvailableSize)
		    {
			    DEBUGL1("CBox::CreateBox:: /storage is near full return STATUS_DISK_FULL\n");
			    return STATUS_DISK_FULL;
		    }
	    }
	    ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> BoxpathPtr = NULL;
	    path = path + boxnumber + "/";

		    //Now create the Box in the given path
		    Status ds = ci::operatingenvironment::Folder::CreateFolder(BoxpathPtr,path.c_str());	
		    if(ds != STATUS_OK)
		    {
			    DEBUGL1("CBoxDocument::CreateBox::Creation of %s Failed\n", path.c_str());
			    Status rst = Utility::RemoveResource(path);
			    if(rst != STATUS_OK)
			    {
				    DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created folder\n");
				    return rst;
			    }					
			    return ds;	
		    }
		    else if(!BoxpathPtr)
		    {
			    DEBUGL1("CBoxDocument::CreateBox::<%s> Folder Creation Failed\n",path.c_str());
			    return STATUS_FAILED;
		    }
		    //Copy boxproperties.xml file to box path	
		    CString origPropertyPath = Utility::GetEB2ROOTPath() + "/bin/boxproperties.xml"; 
		    DEBUGL8("CBoxDocument::CreateBox: origPropertyPath = (%s)\n",origPropertyPath.c_str());
		    DEBUGL8("CBoxDocument::CreateBox: toath = (%s)\n",path.c_str());
		    dom::DocumentRef domDocRef;
		    ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
		    pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
		    if (!pHDB)
		    {
			    DEBUGL1("CBoxDocument::CreateBox: Failed to Acquire HierarchicalDB\n");
			    return STATUS_FAILED;
		    }

		    ds = pHDB->CreateDocumentFromFile(path, "boxproperties_dom", domDocRef, origPropertyPath);
		    if(ds != STATUS_OK)
		    {
			    DEBUGL1("CBoxDocument::CreateBox::Creation of %s Failed\n", path.c_str());
			    Status rst = Utility::RemoveResource(path);
			    if(rst != STATUS_OK)
			    {
				    DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created box\n");
				    return rst;
			    }
			    return ds;	
		    }
	    // get box instance
            try
            {
                box = new CBox(m_sessionID, boxbasepath, boxnumber);
                if(!box)
                {
                    DEBUGL1("CBoxDocument::CreateBox: box object is null\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CBox*>(box.operator->())->SaveProperties();
                if(ret != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::CreateBox::SaveProperties failed\n");
                    box = NULL; // release
                    Status rst = Utility::RemoveResource(path);
                    if(rst != STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created box\n");
                        return rst;
                    }		
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("CBoxDocument::CreateBox: Caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }

            //Set the password and other authentication related properties
            if(!boxpassword.empty())
            {	
			std::map<CString, CString> PropertyMap;
			typedef  std::map<CString, CString> pair;
			CString xmlfile("boxproperties.xml");
			DEBUGL8("CBoxDocument::CreateBox::Setting Authentication related properties\n");	
			PropertyMap.insert(pair::value_type("password", (const CString) boxpassword));
			PropertyMap.insert(pair::value_type("isPasswordProtected", "true"));
			PropertyMap.insert(pair::value_type("authState","IDLE"));
			PropertyMap.insert(pair::value_type("authTimer","0"));
			PropertyMap.insert(pair::value_type("authFailureCount","0"));
			if(Utility::SetProperties(path, xmlfile, PropertyMap) != STATUS_OK)
			{
				DEBUGL1("CBoxDocument::CreateBox::Setting property to %s is failed\n", path.c_str());
				Status rst = Utility::RemoveResource(path);
				if(rst != STATUS_OK)
				{
					DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created box\n");
					return rst;
				}			
				return STATUS_FAILED;
			}
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::CreateBox::Loading Box is failed\n");
                        box = NULL;
                        return ret;
                    }
            }
            DEBUGL4("CBoxDocument::CreateBox::Exit\n");		
            return STATUS_OK;
        }

        /**
         * get protected Box instance by path
         * @param[out] box - instance of Box class 
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[in] boxpassword - box password
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_AUTHENTICATIONFAILS on authentication fails,
         *         STAUTS_BOXISLOCKED on box is locked.
         *         STATUS_RESOURCENOTFOUND if the box is not found
         */
        Status CBoxDocument::GetBox(BoxRef &box, CString boxbasepath, CString boxnumber,CString boxpassword)
        {
            DEBUGL4("CBoxDocument::GetBox::Enter\n");		
            box = NULL;
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;	
            else
                DEBUGL8("CBoxDocument::GetBox: storage is appened to path\n");


            if(boxnumber.empty() || boxbasepath.empty())
            {
                DEBUGL1("CBoxDocument::GetBox::one of the Input Parameters (boxnumber - <%s> or boxbasepath-<%s>) are Invalid \n",boxnumber.c_str(),boxbasepath.c_str());
                return STATUS_FAILED;
            }

            if(boxbasepath==ITUT_BOXBASEPATH || boxbasepath==POLLING_BOXBASEPATH)
            {
                DEBUGL1("CBoxDocument::GetBox::Box is ITUTBox/PollingBox\n");
                return STATUS_FAILED;		
            }
            // confirm boxnumber folder donesn't exist
            if(!(ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath, boxnumber,"",""))))
            {
                DEBUGL1("CBoxDocument::GetBox::Box is not found %s\n",boxbasepath.c_str());
                return STATUS_RESOURCENOTFOUND;
            }

            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::GetBox: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::GetBox::BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }

            Status ret;
            //Get the password property set on the Box
            CString isPwdProtected;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","","isPasswordProtected",isPwdProtected)!= STATUS_OK)	
            {
                DEBUGL1("CBoxDocument::GetBox:GetProperty of isPasswordProtected Failed\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CBoxDocument::GetBox::isPasswordProtected Box = (%s)\n",isPwdProtected.c_str());	
            //For unprotected box
            if(isPwdProtected=="false")
            {
                DEBUGL8("CBoxDocument::GetBox::Unprotected Box\n");	
                box = new CBox(m_sessionID, boxbasepath, boxnumber);
                try
                {
                    if(!box)
                    {
                        DEBUGL1("CBoxDocument::GetBox: box object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetBox::Loading Box is failed\n");
                        box = NULL;
                        return ret;
                    }
                    DEBUGL4("CBoxDocument::GetBox::Exit\n");
                }
                catch(exception &e)
                {
                    DEBUGL1("CBoxDocument::GetBox: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
                return STATUS_OK;
            }
            //protected box
            else
            {
                DEBUGL8("CBoxDocument::GetBox::Protected Box\n");	
                ret = GetPasswordProtectedBox(box,boxbasepath, boxnumber,boxpassword);
                if(ret!=STATUS_OK)
                {	
                    DEBUGL1("CBoxDocument::GetBox::GetPasswordProtectedBox failed\n");
                    return ret;
                }
            }

            DEBUGL4("CBoxDocument::GetBox::Exit\n");		
            return STATUS_OK;
        }

        Status CBoxDocument::GetPasswordProtectedBox(BoxRef &box, CString boxbasepath, CString boxnumber,CString boxpassword)
        {
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Enter\n");	

            std::map<CString, CString> PropMap;
            Status sdf;
            //Get the password property set on the Box
            CString boxPath = Utility::GetResourcePath(boxbasepath, boxnumber)+"/";
            CString password;	
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","","password", password) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                return STATUS_FAILED;
            }

            //Get PasswordPolicy setting from ssdk
            uint maxFailureCount;
            uint64 maxTimerVal;

            ssdk::SSDKStatus statusCode;
            //Creating an instance of usertoken which will be used to authorize the operation
            Ref<SSDKSecurityManagerInterface> ssdkSecurityManagerInterface =ssdk::GetSecurityManager();
            if(!ssdkSecurityManagerInterface)
            {
                DEBUGL1("CBoxDocument::CGetPasswordProtectedBox: ssdkSecurityManagerInterface object is null\n");
                return STATUS_FAILED;
            }
            Ref<SSDKUserTokenInterface> userInterface = dynamic_cast<SSDKUserTokenInterface*> (ssdkSecurityManagerInterface->GetInterface(SSDKSecurityManagerInterface::USER_TOKEN_INTERFACE,statusCode));
            if(userInterface == (void*)NULL)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Getting usertoken interface failed\n");
                return STATUS_FAILED;
            }

            //Obtain the Auto-Processing usertoken
            SSDKUserTokenInterface* AutoUserToken = NULL;
            statusCode = userInterface->Authenticate(SSDKUserTokenInterface::TOKEN_CONTEXT_AUTOPROCESSING, AutoUserToken);
            if ((statusCode != OK))
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Failed to obtain auto processing token\n");
                return STATUS_FAILED;
            }
            //Creating an instance of config which will be used to get the password policy properties
            Ref<SSDKConfigInterface> configInterface = dynamic_cast<SSDKConfigInterface*> (ssdkSecurityManagerInterface->GetInterface(SSDKSecurityManagerInterface::CONFIG_INTERFACE, statusCode));
            if(OK!=statusCode|| configInterface==(void*)NULL)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Getting config interface failed\n");
                return STATUS_FAILED;
            }

            CString value;
            //Getting maxFailureCount property from ssdk
            if(boxbasepath==ITUT_BOXBASEPATH || boxbasepath==POLLING_BOXBASEPATH)
                value = configInterface->GetProperty(AutoUserToken, SSDKConfigInterface::SA_SERVFCODELOGINATTEMPTS, statusCode);
            else
                value = configInterface->GetProperty(AutoUserToken, SSDKConfigInterface::SA_SERVEFILINGLOGINATTEMPTS, statusCode);
            if(OK != statusCode)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Failed to get the maxFailureCount value\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::The maxFailureCount value is %s\n",value.c_str());
            maxFailureCount = atoi((char*)value.c_str());

            //Read the lock out setting values from SSDK
            CString lockOutVal;
            lockOutVal = configInterface->GetProperty(AutoUserToken, SSDKConfigInterface::SA_SERVEFILINGLOGINATTEMPTSENABLE, statusCode);
            if(OK != statusCode)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Failed to get the lock out setting value\n");
                return STATUS_FAILED;
            }

            DEBUGL8("CBoxDocument::GetPasswordProtectedBox:: lock out setting value = (%s)\n",lockOutVal.c_str());
            CString ENABLE = "1";
            CString DISABLE = "0";



            //Getting maxTimerVal property from ssdk
            value.clear();
            if(boxbasepath==ITUT_BOXBASEPATH || boxbasepath==POLLING_BOXBASEPATH)	
                value = configInterface->GetProperty(AutoUserToken, SSDKConfigInterface::SA_SERVFCODELOCKOUTTIME, statusCode);
            else
                value = configInterface->GetProperty(AutoUserToken, SSDKConfigInterface::SA_SERVEFILINGLOCKOUTTIME, statusCode);	
            if(OK != statusCode)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Failed to get the maxTimerVal value\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::The maxTimerVal value is %s\n",value.c_str());
            maxTimerVal=atoi((char*)value.c_str());


            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Password Policy setting values from ssdk - maxFailureCount<%d>,maxTimerVal<%llu>\n",maxFailureCount,maxTimerVal);	

            //Get administrator's hashed password via SSDK
            SSDKRBACMgmtInterface* RbacMgmtInterface = dynamic_cast<SSDKRBACMgmtInterface*> (ssdkSecurityManagerInterface->GetInterface (SSDKSecurityManagerInterface::RBAC_MGMT_INTERFACE,statusCode));	
            if(OK != statusCode || RbacMgmtInterface == (void *)NULL)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Failed to get the RbacMgmtInterface\n");
                return STATUS_FAILED;
            }

            CString super("Admin");
            SSDKRBACMgmtInterface::UserInfo userinfo;
            userinfo = RbacMgmtInterface->GetProperty(AutoUserToken,SSDKRBACMgmtInterface::USER_PASSWORD_HASH_PROPERTY, super,statusCode);
            if(OK != statusCode)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::failed to get the Administrator passowrd\n");
                return STATUS_FAILED;	
            }
            CString adminpassword = userinfo.m_UserPassword;	
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox: admin password from ssdk = (%s)\n", adminpassword.c_str());
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox: password from user = (%s)\n", boxpassword.c_str());

            //Release SSDK interfaces
            ssdkSecurityManagerInterface->ReleaseInterface(AutoUserToken);

            //Get the old ssdk authentication failure count and store it in temporary variable.
            uint iTempFailureCount;
            CString sTempFailureCount;
            uint oldfailcount  = 0;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","",AUTH_FAILURE_COUNT_SSDK, sTempFailureCount) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                return STATUS_FAILED;
            }
            if(!sTempFailureCount.empty())
            {
                std::istringstream iss2(sTempFailureCount);
                iss2 >> iTempFailureCount;
                DEBUGL8("CBoxDocument::GetPasswordProtectedBox:auth old failure count is %d\n",iTempFailureCount);			
                oldfailcount = iTempFailureCount;
            }
            //Set the latest SSDK failure count
            std::ostringstream oss;
            oss<< maxFailureCount;
            sTempFailureCount = oss.str();
            PropMap.clear();
            PropMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT_SSDK,sTempFailureCount));		
            sdf = Utility::SetProperties(boxPath,CString("boxproperties.xml"),PropMap);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount Failed\n");
                return STATUS_FAILED;
            }					

            //Get the new ssdk authentication failure count and store it in temporary variable.
            //uint iTempFailureCount;
            //CString sTempFailureCount;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","",AUTH_FAILURE_COUNT_SSDK, sTempFailureCount) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                return STATUS_FAILED;
            }
            std::istringstream iss3(sTempFailureCount);
            iss3 >> iTempFailureCount;
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox:auth new failure count is %d\n",iTempFailureCount);			
            uint newfailcount = iTempFailureCount;

            //If SSDK max lockcount is increased unlock the box
            if(maxFailureCount > oldfailcount)
            {

                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::ssdk failure count is increase. Unlock the box\n");					
                //Change state to IDLE
                PropMap.clear();
                PropMap.insert(property_pair::value_type(AUTH_STATE,"IDLE"));		
                sdf = Utility::SetProperties(boxPath,CString("boxproperties.xml"),PropMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState Failed\n");
                    return STATUS_FAILED;
                }					
            }

            //Check the authentication state of the box
            CString boxState;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","",AUTH_STATE,boxState)!= STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                return STATUS_FAILED;
            }
            if(boxState=="ACCOUNT_LOCKED")
            {
                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Account is Locked\n");

                //Check if certain period of time is passed
                CString current = Utility::GetUnixTime();
                uint32 curTime=0;
                std::istringstream iss(current);
                iss >> curTime;

                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Current time is %llu\n",curTime);			
                CString startTime("");
                if(proputils::GetProperty(boxbasepath,boxnumber,"","","",AUTH_TIMER,startTime) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                    return STATUS_FAILED;
                }
                uint32 stTime = atol((char*)startTime.c_str());
                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Box Authentication Timer elapsed is %llu\n",(curTime-stTime));		
                //If time period has not elapsed, return error			
                if((curTime-stTime)<maxTimerVal)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box is locked\n");
                    return STATUS_BOXISLOCKED;				
                }
                else
                {
                    //Change state to IDLE
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box Authentication Timer elapsed - Box state will be IDLE\n");
                    PropMap.clear();
                    PropMap.insert(property_pair::value_type(AUTH_STATE,"IDLE"));		
                    sdf = Utility::SetProperties(boxPath,CString("boxproperties.xml"),PropMap);
                    if(sdf != STATUS_OK)
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState failed because Disk is Full\n");
                            return STATUS_DISK_FULL;
                        }
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState Failed\n");
                        return STATUS_FAILED;
                    }					
                }				
            }

            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Input Box Password - <%s>\n",boxpassword.c_str());			

            //Remove password identifier from the admin password
            CString tBoxPassword = boxpassword;
            CString noPasswordIdentifier;
            if(!boxpassword.empty())
            {
                PasswordIdentifierRef passId;
                passId = PasswordIdentifier::Create();
                if(passId)
                {
                    if(passId->removePasswordIdentifier(tBoxPassword,noPasswordIdentifier) != STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox:: Removing password identifier failed\n");
                        return STATUS_FAILED;
                    }
                    else
                        DEBUGL8("CBoxDocument::GetPasswordProtectedBox::admin password after removing identifier (%s)", noPasswordIdentifier.c_str());	
                }
                else
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox:: Creation of password identifier failed\n");
                    return STATUS_FAILED;	
                }
            }

            //Authenticate the box password
            DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Password set on Box - <%s>\n",password.c_str());					

            if(password==boxpassword)
            {
                //Lock the box if lockOutVal has been reached on previous call of GetPasswordProtectedBox()API and correct password has been entered in the current call************************************************************STFR-5618************************************************************ 
                if(newfailcount < oldfailcount)
                {
                    if(lockOutVal == ENABLE)
                    {
                        //Change authentication state of box to ACCOUNT_LOCKED
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box Password Authentication Failed - Box will be locked\n");
                        PropMap.clear();
                        PropMap.insert(property_pair::value_type(AUTH_STATE,"ACCOUNT_LOCKED"));
                        CString start=Utility::GetUnixTime();
                        uint32 startTime =0;
                        startTime = atoi((char*)start.c_str());
                        PropMap.insert(property_pair::value_type(AUTH_TIMER,start));
                        sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                        if(sdf != STATUS_OK)
                        {
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState failed because Disk is Full\n");
                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState Failed\n");
                            return STATUS_FAILED;
                        }
                        return STATUS_BOXISLOCKED;
                    }
                    else
                        return STATUS_AUTHENTICATIONFAILS;
                }
                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Box Password authenticated\n");
                PropMap.clear();
                PropMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT,"0"));		
                PropMap.insert(property_pair::value_type(AUTH_TIMER,"0"));	
                //Reset the failure counter && Reset the timer
                sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty Failed\n");
                    return STATUS_FAILED;
                }	

                //Box instance
                box = new CBox(m_sessionID, boxbasepath, boxnumber);
                try
                { 
                    if(!box)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox: box object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Loading Box is failed\n");
                        box = NULL; 
                        return ret;
                    }		
                    DEBUGL4("CBoxDocument::GetPasswordProtectedBox::Exit\n");			
                    return STATUS_OK;			
                }
                catch(exception& e)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
            }
            //Authenticate for admin password
            else if(adminpassword==noPasswordIdentifier)
            {
                //Lock the box if lockOutVal has been reached on previous call of GetPasswordProtectedBox()API and correct password has been entered in the current call************************************************************STFR-5618************************************************************
                if(newfailcount < oldfailcount)
                {
                    if(lockOutVal == ENABLE)
                    {
                        //Change authentication state of box to ACCOUNT_LOCKED
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box Password Authentication Failed - Box will be locked\n");
                        PropMap.clear();
                        PropMap.insert(property_pair::value_type(AUTH_STATE,"ACCOUNT_LOCKED"));
                        CString start=Utility::GetUnixTime();
                        uint32 startTime =0;
                        startTime = atoi((char*)start.c_str());
                        PropMap.insert(property_pair::value_type(AUTH_TIMER,start));
                        sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                        if(sdf != STATUS_OK)
                        {
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState failed because Disk is Full\n");
                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState Failed\n");
                            return STATUS_FAILED;
                        }
                        return STATUS_BOXISLOCKED;
                    }
                    else
                        return STATUS_AUTHENTICATIONFAILS;
                }

                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Admin authenticated\n");							
                //Reset the failure counter	
                PropMap.clear();
                PropMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT,"0"));		
                PropMap.insert(property_pair::value_type(AUTH_TIMER,"0"));	
                sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount Failed\n");
                    return STATUS_FAILED;
                }	

                //Box instance
                box = new CBox(m_sessionID, boxbasepath, boxnumber);
                try
                {
                    if(!box)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox: box object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Loading Box is failed\n");
                        box = NULL; 
                        return ret;
                    }		
                }
                catch(exception &e)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }

                DEBUGL4("CBoxDocument::GetPasswordProtectedBox::Exit\n");
                return STATUS_OK;
            }
            //Authentication failed
            else
            {
                //Authentication failed		
                DEBUGL8("CBoxDocument::GetPasswordProtectedBox::Box password authentication failed\n");
                if(lockOutVal == ENABLE)
                {

                    //Check the timer
                    CString current = Utility::GetUnixTime();
                    uint64 curTime=0;
                    //curTime = atol((char*)current.c_str());
                    std::istringstream iss(current);
                    iss >> curTime;

                    CString startTime;
                    if(proputils::GetProperty(boxbasepath,boxnumber,"","","",AUTH_TIMER,startTime)!= STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                        return STATUS_FAILED;
                    }
                    DEBUGL8("CBoxDocument::GetPasswordProtectedBox startTime = (%s)\n",startTime.c_str());
                    //If the certain period has elapsed, reset failure count
                    uint32 stTime = atol((char*)startTime.c_str());
                    DEBUGL8("CBoxDocument::GetPasswordProtectedBox::curTime (%ld) stTime (%ld) maxTimerVal (%ld)\n",
                            curTime, stTime, maxTimerVal);
                    if(stTime!=0)
                        if((curTime-stTime)>=maxTimerVal)
                        {	
                            PropMap.clear();
                            PropMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT,"0"));		
                            sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                            if(sdf != STATUS_OK)
                            {
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount failed because Disk is Full\n");
                                    return STATUS_DISK_FULL;
                                }
                                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authFailureCount Failed\n");
                                return STATUS_FAILED;
                            }	
                        }

                    //Increment authentication failure count
                    CString iFailureCount;		
                    if(proputils::GetProperty(boxbasepath,boxnumber,CString(""),CString(""),CString(""),AUTH_FAILURE_COUNT,iFailureCount))
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox:GetProperty of password Failed\n");
                        return STATUS_FAILED;
                    }

                    uint32 iFlCount = atol((char*)iFailureCount.c_str());
                    DEBUGL8("CBoxDocument::GetPasswordProtectedBox:authFailureCount is %d\n",iFlCount);			
                    iFlCount++;
                    std::ostringstream oss;
                    oss << iFlCount;
                    iFailureCount = oss.str();
                    //Reset the timer && Set the incremented failure count
                    PropMap.clear();
                    PropMap.insert(property_pair::value_type(AUTH_TIMER,"0"));
                    PropMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT,iFailureCount));
                    sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);
                    if(sdf != STATUS_OK)		
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty failed because Disk is Full\n");
                            return STATUS_DISK_FULL;
                        }
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty Failed\n");
                        return STATUS_FAILED;
                    }					

                    //Check authentication failure count with max value obatined from ssdk
                    if(iFlCount<maxFailureCount)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box Password Authentication Failed - Count incremented\n");		
                        return STATUS_AUTHENTICATIONFAILS;				
                    }
                    else
                    {
                        //Change authentication state of box to ACCOUNT_LOCKED
                        DEBUGL1("CBoxDocument::GetPasswordProtectedBox::Box Password Authentication Failed - Box will be locked\n");
                        PropMap.clear();
                        PropMap.insert(property_pair::value_type(AUTH_STATE,"ACCOUNT_LOCKED"));
                        CString start=Utility::GetUnixTime();
                        uint32 startTime =0;
                        startTime = atoi((char*)start.c_str());			
                        PropMap.insert(property_pair::value_type(AUTH_TIMER,start));
                        sdf = Utility::SetProperties(boxPath,"boxproperties.xml",PropMap);         
                        if(sdf != STATUS_OK)
                        {
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState failed because Disk is Full\n");
                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox::SetProperty of authState Failed\n");
                            return STATUS_FAILED;
                        }
                        if(iFlCount == maxFailureCount) {
                            DEBUGL1("CBoxDocument::GetPasswordProtectedBox return STATUS_BOXISGETTINGLOCKED\n");
                            return STATUS_BOXISGETTINGLOCKED;
                        }				
                        return STATUS_BOXISLOCKED;				
                    }			
                }
                else
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedBox:: lock out is disabled. return authentication fail\n");			
                    return STATUS_AUTHENTICATIONFAILS;
                }
            }
        }

        /**
         * get a list of box
         * @param[out] list - list of boxes. This list have snapshot of each box
         *                     instances. the snapshot is independent from original
         *                     boxes. it means you can read properties only through
         *                     the snapshot. if you call other methods to the 
         *                     snapshot, it will fail.
         * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CBoxDocument::GetBoxList(BoxList &list, CString boxbasepath)
        {

            return GetBoxList(list, boxbasepath, 0, 65535);
        }

        /**
         * get a list of box
         * @param[out] list - list of boxes. This list have snapshot of each box
         *                     instances. the snapshot is independent from original
         *                     boxes. it means you can read properties only through
         *                     the snapshot. if you call other methods to the 
         *                     snapshot, it will fail.
         * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
         * @param[in] from - return list from this value.
         * @param[in] size - list size, if "from" + "size" is bigger than the 
         *                    number of all boxes, return list size will be smaller
         *                    than "size".
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CBoxDocument::GetBoxList(BoxList &list, CString boxbasepath,unsigned int from, unsigned int size) 
        {
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::GetBoxList: storage is already present in path\n");



            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::GetBoxList: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::GetBoxList: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }
            std::vector<CString> vec;
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetBoxList::Getting collection list is failed");
                return STATUS_FAILED;
            }

            list.clear();
            BoxRef box=NULL;
            for(unsigned int i = from, cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++) 
            {
                CString boxnumber = vec[i];
                // GetBox
                box=NULL;
                box = new CViewBox(m_sessionID, boxbasepath, boxnumber);
                if(box)
                    list.push_back(box);
            }

            DEBUGL4("CBoxDocument::GetBoxList: Exit\n");
            return STATUS_OK;
        }

        /**
         * delete the box
         * if documents in the box is using, it will fail(some documents are 
         *  deleted).
         * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[in] boxpassword - box password
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         */
        Status CBoxDocument::DeleteBox(CString boxbasepath, CString boxnumber, CString boxpassword)
        {
            DEBUGL4("CBoxDocument::DeleteBox::Enter\n");		

            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::DeleteBox: storage is already present in path\n");


            // confirm boxnumber folder exist
            if(!(ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath, boxnumber,"",""))))
            {
                DEBUGL1("CBoxDocument::DeleteBox::Box is not found %s\n",boxbasepath.c_str());
                return STATUS_RESOURCENOTFOUND;
            }

            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::DeleteBox: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::DeleteBox: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }
            //validate the password of the box Before the box is deleted.
            CString pFolderPath= Utility::GetResourcePath(boxbasepath,boxnumber,"","");
            CString isPwdProtected;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","","isPasswordProtected", isPwdProtected) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteBox::GetProperty of isPasswordProtected Failed\n");
                return STATUS_FAILED;
            }
            //For protected box validate the password
            if(isPwdProtected=="true")
            {
                BoxRef box;
                Status st = GetPasswordProtectedBox(box, boxbasepath, boxnumber, boxpassword);
                if(st != STATUS_OK) {
                    DEBUGL1("Gettting password proteced box failed\n");
                    return st;
                }
            }

            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,pFolderPath)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteBox::Getting collection list is failed");
                return STATUS_FAILED;
            }
            //Check if the extraction is in progress
            CString extractfilename = "";
            if(Utility::GetUniqueFile(boxbasepath+"/"+boxnumber, extractfilename, ".extractisinprogress_", false) != STATUS_OK)
                DEBUGL2("CBoxDocument::DeleteBox: Unable to get the file\n");

            if(!extractfilename.empty())
            {
                DEBUGL1("CBoxDocument::DeleteBox: Delete box of (%s) Box Failed... Extraction is in progress\n",boxnumber.c_str());
                return STATUS_USER_USING;
            }

            //Check if the save operation is in progress
            CString savefilename = "";
            if(Utility::GetUniqueFile(boxbasepath+"/"+boxnumber, savefilename, ".saveisinprogress_", false) != STATUS_OK)
                DEBUGL2("CBoxDocument::DeleteBox: Unable to get the file\n");

            if(!savefilename.empty())
            {
                DEBUGL1("CBoxDocument::DeleteBox: Delete box of (%s) Box Failed... Save is in progress\n",boxnumber.c_str());
                return STATUS_USER_USING;
            }

            CString documentPath;
            CString stsfile;
            for(dIt= vec.begin();dIt != vec.end(); dIt++) 
            {
                documentPath = Utility::GetResourcePath(boxbasepath,boxnumber,(*dIt),"");
                stsfile = documentPath + "/.document";
                if(Utility::ResourceExist(stsfile) ==true)
                {
                    stsfile = documentPath + "/ready.sts";
                    if(Utility::ResourceExist(stsfile) !=true)
                    {
                        //check if document is in editing state.
                        stsfile = documentPath + "/editing.sts";
                        if(Utility::ResourceExist(stsfile) == true)
                        {
                            DEBUGL1("CBoxDocument::DeleteBox::Document Status is EDITING return STATUS_USER_EDITING");
                            return STATUS_USER_EDITING;
                        }

                        //check if document is in using state
                        stsfile = documentPath + "/using.sts";
                        if(Utility::ResourceExist(stsfile)==true)
                        {
                            DEBUGL1("CBox::DeleteBox::Document Status is USING return STATUS_USER_USING");
                            return STATUS_USER_USING;				
                        }		
                        //check if document is in reserving state
                        stsfile = documentPath + "/reserving.sts";
                        if(Utility::ResourceExist(stsfile)==true)
                        {
                            DEBUGL1("CBox::DeleteBox::Document Status is RESERVING. return STATUS_USER_USING");
                            return STATUS_USER_USING;				
                        }		

                        DEBUGL1("CBoxDocument::DeleteBox::Document Status is not READY");				
                        return STATUS_FAILED;
                    }
                    CString flag="false";
                    //Check if document is being used by user.
                    if(proputils::GetProperty(boxbasepath,boxnumber,"",(*dIt),"","cutDocument",flag) == STATUS_OK)
                    {
                        if(flag == "true"){
                            DEBUGL1("CBox::DeleteBox::Document Status is READY and being used by the user. return STATUS_USER_USING");
                            return STATUS_USER_USING;
                        }

                    }
                }
                else
                {
                    std::vector<CString> foldervec;
                    std::vector<CString>::iterator fIt;
                    CString folderdoc;
                    CString foldersts;

                    //Now get the list of files present under the boxbasepath.
                    if(Utility::GetCollectionList(foldervec,documentPath)!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::DeleteBox::Getting collection list is failed");
                        return STATUS_FAILED;
                    }

                    for(fIt= foldervec.begin(); fIt != foldervec.end(); fIt++) 
                    {
                        folderdoc = Utility::GetResourcePath(boxbasepath,boxnumber,(*dIt),(*fIt));				
                        foldersts = folderdoc + "/ready.sts";
                        if(Utility::ResourceExist(foldersts) !=true)
                        {
                            //check if document is in editing state
                            foldersts = folderdoc + "/editing.sts";
                            if(Utility::ResourceExist(foldersts) == true)
                            {
                                DEBUGL1("CBoxDocument::DeleteBox::Document Status is EDITING return STATUS_USER_EDITING");
                                return STATUS_USER_EDITING;
                            }

                            //check if document is in using state
                            foldersts = folderdoc + "/using.sts";
                            if(Utility::ResourceExist(foldersts)==true)
                            {
                                DEBUGL1("CBoxDocument::DeleteBox::Document Status is USING  return STATUS_USER_USING");
                                return STATUS_USER_USING;				
                            }		
                            //check if document is in reserving state
                            foldersts = folderdoc + "/reserving.sts";
                            if(Utility::ResourceExist(foldersts)==true)
                            {
                                DEBUGL1("CBoxDocument::DeleteBox::Document Status is RESERVING. return STATUS_USER_USING");
                                return STATUS_USER_USING;				
                            }		

                            DEBUGL1("CBoxDocument::DeleteBox::Document Status is not READY");
                            return STATUS_FAILED;				
                        }

                        CString flag="false";
                        if(proputils::GetProperty(boxbasepath,boxnumber,(*dIt),(*fIt),"","cutDocument",flag) == STATUS_OK)
                        {
                            if(flag == "true") {
                                DEBUGL1("CBox::DeleteBox::Document Status is READY and being used by the user. return STATUS_USER_USING");
                                return STATUS_USER_USING;
                            }

                        }
                    }
                }
            }
            //Now delete the Box
            if((ci::operatingenvironment::Folder::Remove(pFolderPath,true) != STATUS_OK))
            {
                DEBUGL1("CBoxDocument::DeleteBox: Deleting %s Box Failed\n",boxnumber.c_str());
                return STATUS_FAILED;
            }

            DEBUGL4("CBoxDocument::DeleteBox::Exit\n");		
            return STATUS_OK;	
        }

        /**
         * get protected MailBox instance by path
         * @param[out] box - instance of Box class 
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[in] context - access context enum    
         * @param[in] boxpassword - box password
         * @return STATUS_OK on success,
         *		STATUS_FAILED on failure,
         *		STATUS_AUTHENTICATIONFAILS on authentication fails,
         *		STATUS_RESOURCENOTFOUND	if Box is not found     
         *		STATUS_NOT_ALLOWED if any invalid box operation is performed
         */
        Status CBoxDocument::GetMailBox(BoxRef &box, CString boxbasepath, CString boxnumber,
														AccessContext context,CString boxpassword, CString phoneno, bool enableAdminPass)
        {
            DEBUGL4("CBoxDocument::GetMailBox: Enter\n");
            box = NULL;
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::DeleteBox: storage is appened to path\n");



            if(!((boxbasepath==ITUT_BOXBASEPATH)||(boxbasepath==POLLING_BOXBASEPATH)))
            {
                DEBUGL1("CBoxDocument::GetMailBox::Box is not ITUTBox/PollingBox\n");
                return STATUS_FAILED;		
            }
            CString boxPath = Utility::GetResourcePath(boxbasepath, boxnumber);
            if(!ci::operatingenvironment::Folder::Exists(boxPath)) 
            {
                DEBUGL1("CBoxDocument::GetMailBox::Box is not found\n");
                return STATUS_RESOURCENOTFOUND;
            }
            boxPath+="/";

            //Get the password property set on the Box
            CString isPwdProtected;
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","","isPasswordProtected", isPwdProtected)  != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetMailBox::GetProperty of isPasswordProtected Failed\n");
                return STATUS_FAILED;
            }

            if(boxbasepath==ITUT_BOXBASEPATH)
            {	
                DEBUGL8("CBoxDocument::GetMailBox::ITUTBoxes\n");		
                //Get the documentType property set on the Box
                CString docType;
                if(proputils::GetProperty(boxbasepath,boxnumber,"","","","documentType", docType) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::GetMailBox:GetProperty of isPasswordProtected Failed\n");
                    return STATUS_FAILED;
                }

                if(!(docType=="Confidential"||docType=="BulletinBoard"||docType=="Relay"))
                {
                    DEBUGL1("CBoxDocument::GetMailBox:documentType is invalid \n");
                    return STATUS_FAILED;		
                }
                else if((docType=="Confidential"&&context==LOCAL_WRITE)||(docType=="Confidential"&&context==REMOTE_WRITE)
                        ||(docType=="BulletinBoard"&&context==LOCAL_READ)||(docType=="BulletinBoard"&&context==REMOTE_READ))
                {
                    //Box instance
                    box = new CBox(m_sessionID, boxbasepath, boxnumber);
                    try
                    { 
                        if(!box)
                        {
                            DEBUGL1("CBoxDocument::GetMailBox: box object is null\n");
                            return STATUS_FAILED;
                        }
                        Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                        if(ret != STATUS_OK) 
                        {
                            DEBUGL1("CBoxDocument::GetMailBox::Loading Box is failed\n");
                            box = NULL; 
                            return ret;
                        }
                    }
                    catch(exception &e)
                    {
                        DEBUGL1("CBoxDocument::GetMailBox: Caught exception (%s)\n",e.what());
                        return STATUS_FAILED;
                    }
                    return STATUS_OK;
                }

                //UnProtected Box	
                if(isPwdProtected=="false")
                {			
                    if((docType=="Confidential" && context==REMOTE_READ)||(docType=="BulletinBoard" && context==REMOTE_WRITE))
                    {
                        DEBUGL1("CBoxDocument::GetMailBox::Not Allowed\n");		
                        return STATUS_NOT_ALLOWED;
                    }
                    else if(docType=="Relay"||(docType=="Confidential" && context==LOCAL_READ)||(docType=="BulletinBoard" && context==LOCAL_WRITE))
                    {
                        box = new CBox(m_sessionID, boxbasepath, boxnumber);
                        try
                        {
                            if(!box)
                            {
                                DEBUGL1("CBoxDocument::GetMailBox: box object is null\n");
                                return STATUS_FAILED;
                            }
                            Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                            if(ret != STATUS_OK) 
                            {
                                DEBUGL1("CBoxDocument::GetMailBox::Loading Box is failed\n");
                                box = NULL; 
                                return ret;
                            }					
                        }
                        catch(exception &e)
                        {
                            DEBUGL1("CBoxDocument::GetMailBox: Caught exception (%s)\n",e.what());
                            return STATUS_FAILED;
                        }
                        return STATUS_OK;
                    }
                }
                //Protected Box	
                else
                {	
                    DEBUGL8("CBoxDocument::GetMailBox::Protected ITUTBox\n");	
                    Status ret = GetPasswordProtectedMailBox(box,boxbasepath, boxnumber,boxpassword,enableAdminPass);		
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetMailBox::GetPasswordProtectedBox failed\n");
                        return ret;
                    }				
                }
            }
            else if(boxbasepath==POLLING_BOXBASEPATH)
            {
                DEBUGL8("CBoxDocument::GetMailBox::PollingBoxes\n");	
                //Get the phoneNumber property set on the Box
                CString phNo;
                if(proputils::GetProperty(boxbasepath,boxnumber,"","","","phoneNumber", phNo) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::GetMailBox:GetProperty of phoneNumber Failed\n");
                    return STATUS_FAILED;
                }
                CString password;
                if(proputils::GetProperty(boxbasepath,boxnumber,"","","","password", password) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::GetMailBox:GetProperty of phoneNumber Failed\n");
                    return STATUS_FAILED;
                }

                if(context==LOCAL_WRITE||context==LOCAL_READ)
                {
                    //Box instance
                    box = new CBox(m_sessionID, boxbasepath, boxnumber);
                    if(!box)
                    {
                        DEBUGL1("CBoxDocument::GetMailBox: box object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetMailBox::Loading Box is failed\n");
                        box = NULL; 
                        return ret;
                    }
                }
                else if(context == REMOTE_READ || context == REMOTE_WRITE)
                {
                    if(phNo.empty() && password.empty())
                    {
                        DEBUGL8("CBoxDocument::GetMailBox:: phone number and password not set\n");	
                        //return box object
                        box = new CBox(m_sessionID, boxbasepath, boxnumber);
                        if(!box)
                        {
                            DEBUGL1("CBoxDocument::GetMailBox: box object is null\n");
                            return STATUS_FAILED;
                        }
                        Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                        if(ret != STATUS_OK) 
                        {
                            DEBUGL1("CBoxDocument::GetMailBox::Loading Box is failed\n");
                            box = NULL; 
                            return ret;
                        }							
                    }
                    else if(password.empty() && !(phNo.empty()))
                    {
                        DEBUGL8("CBoxDocument::GetMailBox:: phone number is set and password not set\n");	
                        if(phNo == phoneno)
                        {
                            DEBUGL8("CBoxDocument::GetMailBox:: phone number matches with user input\n");	
                            //return box object
                            box = new CBox(m_sessionID, boxbasepath, boxnumber);
                            if(!box)
                            {
                                DEBUGL1("CBoxDocument::GetMailBox: box object is null\n");
                                return STATUS_FAILED;
                            }
                            Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                            if(ret != STATUS_OK) 
                            {
                                DEBUGL1("CBoxDocument::GetMailBox::Loading Box is failed\n");
                                box = NULL; 
                                return ret;
                            }							
                        }
                        else
                        {
                            DEBUGL1("CBoxDocument::GetMailBox:: phone number doesnt matches with user input\n");	
                            box = NULL;
                            return STATUS_FAILED;
                        }
                    }
                    else if(!(password.empty()) && phNo.empty())
                    {
                        DEBUGL8("CBoxDocument::GetMailBox:: phone number not set password is set\n");	
                        if(boxpassword == password)
                        {
                            DEBUGL8("CBoxDocument::GetMailBox:: password matches with user password\n");	
                            //return password protected box object
                            Status ret = GetPasswordProtectedMailBox(box,boxbasepath, boxnumber,boxpassword, enableAdminPass);		
                            if(ret != STATUS_OK) 
                            {
                                DEBUGL1("CBoxDocument::GetMailBox::GetPasswordProtectedBox failed\n");
                                box = NULL; 					
                                return ret;
                            }
                        }
                        else
                        {
                            DEBUGL1("CBoxDocument::GetMailBox:: password doesnt matches with user password\n");	
                            box = NULL;
                            return STATUS_FAILED;
                        }
                    }
                    else if(!(password.empty()) && !(phNo.empty()))
                    {
                        DEBUGL8("CBoxDocument::GetMailBox:: phone number and password both are set\n");	
                        if(boxpassword == password && phNo == phoneno)
                        {
                            DEBUGL8("CBoxDocument::GetMailBox:: phone number and password matches with user input\n");	
                            //return password protected box object
                            Status ret = GetPasswordProtectedMailBox(box,boxbasepath, boxnumber,boxpassword, enableAdminPass);		
                            if(ret != STATUS_OK) 
                            {
                                DEBUGL1("CBoxDocument::GetMailBox::GetPasswordProtectedBox failed\n");
                                box = NULL; 					
                                return ret;
                            }
                        }
                        else
                        {
                            DEBUGL1("CBoxDocument::GetMailBox:: phone number and password doesnt matches with user input\n");	
                            box = NULL;
                            return STATUS_FAILED;
                        }
                    }
                }
                else
                {
                    DEBUGL1("CBoxDocument::GetMailBox: invalid context\n");
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CBoxDocument::GetMailBox: Exit\n");	
            return STATUS_OK;	
        }


        Status CBoxDocument::GetPasswordProtectedMailBox(BoxRef &box, CString boxbasepath, 
													CString boxnumber,CString boxpassword, bool enableAdminPass)
        {
            DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox::Enter\n");	

            if(!((boxbasepath==ITUT_BOXBASEPATH)||(boxbasepath==POLLING_BOXBASEPATH)))
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::Box is not ITUTBox/PollingBox\n");
                return STATUS_FAILED;		
            }
            //Get the password property set on the Box
            CString boxPath = Utility::GetResourcePath(boxbasepath, boxnumber)+"/";
            CString password;	
            if(proputils::GetProperty(boxbasepath,boxnumber,"","","","password", password) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox:GetProperty of password Failed\n");
                return STATUS_FAILED;
            }


            //Hash the input password and remove the password identifier from the admin password
            CString tBoxPassword = boxpassword;
            CString noPasswordIdentifier;
            if(!boxpassword.empty())
            {
                //Hash the input password
                CString hashedboxpassword("");
                PasswordIdentifierRef passId;
                passId = PasswordIdentifier::Create();
                if(passId)
                {
                    if(passId->hashPasswordwithIdentifier(tBoxPassword, hashedboxpassword)!=STATUS_OK)
                    {
                        DEBUGL1("BoxDocument::GetPasswordProtectedMailBox: Failed to hash the password\n");
                        return STATUS_FAILED;
                    }

                    //Remove the password identifier from hashed password
                    if(passId->removePasswordIdentifier(hashedboxpassword, noPasswordIdentifier) != STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox:: Removing password identifier failed\n");
                        return STATUS_FAILED;
                    }

                    DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox::admin password after removing identifier (%s)", noPasswordIdentifier.c_str());	
                }
                else
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox:: Creation of password identifier failed\n");
                    return STATUS_FAILED;	
                }
            }

            DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox::Input Box Password - <%s>\n",boxpassword.c_str());			

            //Creating an instance of usertoken which will be used to authorize the operation
            ssdk::SSDKStatus statusCode;
            Ref<SSDKSecurityManagerInterface> ssdkSecurityManagerInterface =ssdk::GetSecurityManager();
            if(!ssdkSecurityManagerInterface)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox: ssdkSecurityManagerInterface object is null\n");
                return STATUS_FAILED;
            }
            Ref<SSDKUserTokenInterface> userInterface = dynamic_cast<SSDKUserTokenInterface*> (ssdkSecurityManagerInterface->GetInterface(SSDKSecurityManagerInterface::USER_TOKEN_INTERFACE,statusCode));
            if(userInterface == (void*)NULL)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::Getting usertoken interface failed\n");
                return STATUS_FAILED;
            }

            //Obtain the Auto-Processing usertoken
            SSDKUserTokenInterface* AutoUserToken = NULL;
            statusCode = userInterface->Authenticate(SSDKUserTokenInterface::TOKEN_CONTEXT_AUTOPROCESSING, AutoUserToken);
            if ((statusCode != OK))
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::Failed to obtain auto processing token\n");
                return STATUS_FAILED;
            }	

            //Get administrator's hashed password via SSDK
            SSDKRBACMgmtInterface* RbacMgmtInterface = dynamic_cast<SSDKRBACMgmtInterface*> (ssdkSecurityManagerInterface->GetInterface (SSDKSecurityManagerInterface::RBAC_MGMT_INTERFACE,statusCode));	
            if(OK != statusCode || RbacMgmtInterface == (void *)NULL)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtecGetPasswordProtectedMailBoxtedBox::Failed to get the RbacMgmtInterface\n");
                return STATUS_FAILED;
            }

            CString super("Admin");
            SSDKRBACMgmtInterface::UserInfo userinfo;
            userinfo = RbacMgmtInterface->GetProperty(AutoUserToken,SSDKRBACMgmtInterface::USER_PASSWORD_HASH_PROPERTY, super,statusCode);
            if(OK != statusCode)
            {
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::failed to get the Administrator passowrd\n");
                return STATUS_FAILED;	
            }
            CString adminpassword = userinfo.m_UserPassword;	
            DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox: admin password from ssdk = (%s)\n", adminpassword.c_str());
            DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox: password from user = (%s)\n", boxpassword.c_str());

            //Release SSDK interfaces
            ssdkSecurityManagerInterface->ReleaseInterface(AutoUserToken);

            //Authenticate given password with the stored boxpassword and the admin password
            DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox::Password set on Box - <%s>\n",password.c_str());					
				if(password == boxpassword || (adminpassword == noPasswordIdentifier && enableAdminPass) || password == "") 
            {
                DEBUGL8("CBoxDocument::GetPasswordProtectedMailBox::User authenticated\n");	
                //Box instance
                box = new CBox(m_sessionID, boxbasepath, boxnumber);
                try
                {
                    if(!box)
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox: box object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CBox*>(box.operator->())->LoadProperties();
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::Loading Box is failed\n");
                        box = NULL; 
                        return ret;
                    }		
                    DEBUGL4("CBoxDocument::GetPasswordProtectedMailBox::Exit\n");			
                    return STATUS_OK;			
                }
                catch(exception &e)
                {
                    DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
            }
            else
            {
                //Authentication failed		
                DEBUGL1("CBoxDocument::GetPasswordProtectedMailBox::Box password authentication failed\n");		
                return STATUS_AUTHENTICATIONFAILS;				
            }
        }

        /**
         * delete the box
         * if documents in the box is using, it will fail(some documents are 
         *  deleted).
         * @param[in] boxbasepath - box type e.g. "/documentStore/eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[in] context - access context enum 
         * @param[in] boxpassword - box password
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         */
        Status CBoxDocument::DeleteMailBox(CString boxbasepath, CString boxnumber,AccessContext context,CString boxpassword)
        {
            DEBUGL4("CBoxDocument::DeleteMailBox::Enter\n");		
            Status ret;
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::DeleteMailBox: storage is appened to path\n");


            BoxRef box;
            ret = GetPasswordProtectedMailBox(box,boxbasepath, boxnumber,boxpassword, true);		
            if(ret != STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::DeleteMailBox: failed\n");
                return ret;
            }

            //check if any documents are present in the mail box. If yes then dont delete the box.
            std::vector<CString> vec;
            CString path = Utility::GetResourcePath(boxbasepath,boxnumber,"","");
            if((ret = Utility::GetCollectionList(vec,path))!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteMailBox::Getting CollectionList failed\n");
                return ret;		
            }

            std::vector<CString>::iterator pIt;
            std::vector<CString>::iterator fIt;
            CString documentPath;
            std::vector<CString> docvec;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;


            for(pIt=vec.begin();pIt!=vec.end();pIt++)
            {
                documentPath = "";
                documentPath = path+"/"+(*pIt);
                if(ci::operatingenvironment::File::Exists(documentPath+"/.document"))
                {
                    //Its a document
                    DEBUGL1("CBoxDocument::DeleteMailBox::Documents exist in the box\n");
                    return STATUS_DOCUMENTS_EXIST;			
                }
                else //it could be a folder
                {
                    FolderPtr = NULL;
                    FolderPtr = ci::operatingenvironment::Folder::Bind(documentPath);
                    docvec.clear();
                    if(FolderPtr->GetSubFolders(docvec)!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::DeleteMailBox::Getting Folders inside <%s> Folder Failed\n",documentPath.c_str());
                        return STATUS_FAILED;
                    }
                    if(docvec.size()>0)
                    {
                        //There are documents present inside the folder since the vector has some entries
                        DEBUGL1("CBoxDocument::DeleteMailBox::Documents exist in the box\n");
                        return STATUS_DOCUMENTS_EXIST;
                    }			
                }
            }

            if((ci::operatingenvironment::Folder::Remove(path,true))!=STATUS_OK)
                DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",path.c_str());
            return STATUS_OK;
        }

        Status CBoxDocument::Initialize()
        {
            DEBUGL4("CBoxDocument::Initialize Enter\n");
            Status st;
            //Creating shared memory to maintain a count of the users of BoxDocument instead of xml
				Ref<SharedMemory> userCountShmId = SharedMemory::Create((char*)USERCOUNT_MEMORY, (int32)sizeof(BoxCount), false, false);
				if(!userCountShmId)
				{
					DEBUGL2("CBoxDocument::Initialize::Creating shared memory to store user count failed..\n");
					//In case of failure Initialize() is called repeatedly. Shared memory
					//creation will fail when called second time since shared memory already exist. In this case
					//if STATUS_FAILED is returned from this point it may lead to infinite looping.
					//return STATUS_FAILED;
				} 
				else 
				{
					void* userCountAddr = NULL;
					userCountShmId->Map(userCountAddr);
					if(userCountAddr != NULL)
					{
						memset(userCountAddr, '\0', sizeof(BoxCount));
						userCountShmId->Unmap();
					}
					else
					{
						DEBUGL1("CBoxDocument::Initialize::Mapping to Shared Memory failed..\n");
						userCountShmId->Destroy();
						return STATUS_FAILED;
					}
				} 
            //If documents are extracted partially read from the file and delete them.
            ci::operatingenvironment::Ref<ByteStream> bytestreamRef = 
                ci::operatingenvironment::File::Open(TEMPORARY_EXTRACT_DOC_LIST);
            if(bytestreamRef)
            {
                CString str = "dummy";
                while(!str.empty())
                {
                    str = bytestreamRef->ReadLine();
                    str = str.substr(0, str.length() - 1);
                    DEBUGL8("CBoxDocument::Initialize: Remove extracted document (%s)\n", str.c_str());						
                    if(Utility::RemoveResource(str)!=STATUS_OK)
                        DEBUGL2("CBoxDocument::Initialize: failed to remove the half extracted document\n");						
                }

            }
            else
                DEBUGL8("CBoxDocument::Initialize: No partially extracted documents exist\n");

            Utility::RemoveResource(TEMPORARY_EXTRACT_DOC_LIST);
            st = Initialize(EFILING_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for EFILING_BOXBASEPATH\n");	
                if(RemoveStatusFile(EFILING_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(POLLING_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for POLLING_BOXBASEPATH\n");	
                if(RemoveStatusFile(POLLING_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(ITUT_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for ITUT_BOXBASEPATH\n");		
                if(RemoveStatusFile(ITUT_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(PAGELOG_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for PAGELOG_BOXBASEPATH\n");		
                if(RemoveStatusFile(PAGELOG_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(OVERLAY_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for OVERLAY_BOXBASEPATH\n");		
                if(RemoveStatusFile(OVERLAY_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(TEMP_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for TEMP_BOXBASEPATH\n");		
                if(RemoveStatusFile(TEMP_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            st = Initialize(FAXRXPREVIEW_BOXBASEPATH);
            if(st != STATUS_OK)
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for FAXRXPREVIEW_BOXBASEPATH\n");		
                if(RemoveStatusFile(FAXRXPREVIEW_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
			//Check if /imagedata/WorkSpace are symblic link to /work/sec_WorkSpace
			CString workspacepath, clipboardpath;
			struct stat wfileInfo;
			struct stat cfileInfo;
			if(lstat(WORKSPACE_PATH.c_str(), &wfileInfo) < 0)
			{
				DEBUGL1("CBoxDocument::Initialize: failed to stat the file\n");
				return STATUS_FAILED;
			}
			else if(S_ISLNK(wfileInfo.st_mode))
			{
				DEBUGL8("CBoxDocument::Initialize: /imagedata/WorkSpace is a symbolic link\n");
				workspacepath = "/imagedata/sec_WorkSpace";
			}
			else
				workspacepath = WORKSPACE_PATH;

			//Check if /imagedata/ClipBoard are symblic link to /work/sec_ClipBoard
			if(lstat(CLIPBOARD_PATH.c_str(), &cfileInfo) < 0)
			{
				DEBUGL1("CBoxDocument::Initialize: failed to stat the file\n");
				return STATUS_FAILED;
			}
			else if(S_ISLNK(cfileInfo.st_mode))
			{
				DEBUGL8("CBoxDocument::Initialize: /imagedata/ClipBoard is a symbolic link\n");
				clipboardpath = "/imagedata/sec_ClipBoard";
			}
			else
				clipboardpath = CLIPBOARD_PATH;

            //Clear clipboard, workspace and create the public box
            Status wst,wcst,cst,ccst;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr=NULL;
			//remove and create workspace path
            wst = ci::operatingenvironment::Folder::Folder::Remove(workspacepath, true);
            wcst= ci::operatingenvironment::Folder::Folder::CreateFolder(FolderPtr,workspacepath);

			//remove and create clipboard path
            cst = ci::operatingenvironment::Folder::Folder::Remove(clipboardpath, true);
            ccst= ci::operatingenvironment::Folder::Folder::CreateFolder(FolderPtr,clipboardpath);

            if((wst != STATUS_OK)|| (wcst != STATUS_OK)||(cst != STATUS_OK)||(ccst != STATUS_OK))
            {
                DEBUGL2("CBoxDocument::Initialize : Initialization failed for WORKSPACE/CLIPBOARD path\n");		
                if(RemoveStatusFile(EFILING_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(ITUT_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(POLLING_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(PAGELOG_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(OVERLAY_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(TEMP_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");
                if(RemoveStatusFile(FAXRXPREVIEW_BOXBASEPATH) != STATUS_OK)
                    DEBUGL2("CBoxDocument::Initialize : Initialization removing of status file failed\n");

                return st;
            }
            DEBUGL4("CBoxDocument::Initialize Exit\n");
            return STATUS_OK;
        }

        Status CBoxDocument::ClearClipboardWorkspace() 
        {
            DEBUGL4("CBoxDocument::ClearClipboardWorkspace: Enter\n");

            //Clear the WorkSpace and ClipBoard		
            DEBUGL8("CBoxDocument::ClearClipboardWorkspace:Now clearing WorkSpace and ClipBoard\n");		
            std::vector<CString> vec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::ClearClipboardWorkspace: Getting collection list failed");
                return STATUS_FAILED_INITIALIZATION;
            }
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                DEBUGL8("CBoxDocument::ClearClipboardWorkspace: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());	  

                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                if(ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true)!=STATUS_OK) 
                {
                    DEBUGL1("CBoxDocument::Initialize: Deleting <%s> is failed\n", resourceKey.c_str());
                    return STATUS_FAILED_INITIALIZATION;
                }
            }		
            vec.clear();
            //Get the List of Documents in WorkSpace
            if(Utility::GetCollectionList(vec,WORKSPACE_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::ClearClipboardWorkspace: Getting collection list failed");
                return STATUS_FAILED_INITIALIZATION;
            }
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                DEBUGL8("CBoxDocument::ClearClipboardWorkspace: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());	  

                CString resourceKey=WORKSPACE_PATH+fulldocumentname+"/";
                if(ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true)!=STATUS_OK) 
                {
                    DEBUGL1("CBoxDocument::ClearClipboardWorkspace: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    return STATUS_FAILED_INITIALIZATION;
                }
            }		
            DEBUGL4("CBoxDocument::ClearClipboardWorkspace: Exit\n");	
            return STATUS_OK;
        }

        /**
         * Initialize all Documents.
         * If Document status is CREATING or DELETING, it is changed to WAITING.
         * WAITING Document is deleted when Cleanup() is called. If Document status
         * is EDITING or USING or RESERVING, it is changed to READY. Also the method clean up 
         * box clipboard.
         * Till finishing initialization, BoxDocument::GetStatus returns 
         * INITIALIZING. And BoxDocument returns STATUS_FAILED_INITIALIZATION 
         * on the other methods. 
         * @return STATUS_OK on success.
         *         STATUS_FAILED_INITIALIZATION on INITIALIZING.
         */

        Status CBoxDocument::Initialize(CString boxbasepath)
        {
            //CString boxbasepath=EFILING_BOXBASEPATH;
            DEBUGL4("CBoxDocument::Initialize: Enter\n");
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            Status status = STATUS_OK;

	    CString ORG_TEMP_BOXBASEPATH = TEMP_BOXBASEPATH;
            if(boxbasepath == TEMP_BOXBASEPATH)
            {
                //Check if the resource exists..
                if(ci::operatingenvironment::Folder::Exists(ORG_TEMP_BOXBASEPATH)) 
                {
                    //Remove tembox
                    status = ci::operatingenvironment::Folder::Remove(ORG_TEMP_BOXBASEPATH,true);
                }
                else
                    DEBUGL6("CBoxDocument::Initialize::Tempboxes does not exist..create it\n");


                //Create tempbox
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> folderRef;
                status = ci::operatingenvironment::Folder::CreateFolder(folderRef, ORG_TEMP_BOXBASEPATH);
                if(status == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBoxDocument::Initialize: error disk is full\n");
                    return STATUS_DISK_FULL;
                }
                else if(status == STATUS_FAILED)
                {
                    DEBUGL1("CBoxDocument::Initialize: unable to create tempboxes\n");	
                    return STATUS_FAILED;
                }

                //Change the status to initialized
                ci::operatingenvironment::Ref<ci::operatingenvironment::File> FilePtr = NULL;
                Status st = ci::operatingenvironment::File::CreateFile(FilePtr,boxdocstatusfilename::INITIALIZED, folderRef);
                if(st!=STATUS_OK)
					 {
						 DEBUGL1("CBoxDocument::Initialize::Creating initializing.sts file Failed\n");
						 return STATUS_FAILED_INITIALIZATION;		
					 }
				}
            else
            {
                CString boxNumber("");
                CString folderName("");
                CString docName("");		
                std::vector<CString> boxVec;
                std::vector<CString> folderVec;			
                std::vector<CString> docVec;

                //Get the BoxDoc status
                BoxDocStatus btStatus = GetStatus(boxbasepath);
                if(btStatus==INITIALIZING)
                {
                    DEBUGL1("CBoxDocument::Initialize: BoxDoc Status of %s is INITIALIZING",boxbasepath.c_str());
                    return STATUS_FAILED_INITIALIZATION;			
                }
                else if(btStatus == DELETING_ALL)
                {
                    DEBUGL1("CBoxDocument::Initialize: BoxDoc Status of %s isDELETING_ALL",boxbasepath.c_str());
                    return STATUS_DELETINGALL;				
                }
                CString path = Utility::GetResourcePath(boxbasepath) + "/";;
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
                ci::operatingenvironment::Ref<ci::operatingenvironment::File> FilePtr = NULL;
                FolderPtr = ci::operatingenvironment::Folder::Bind(path);
                if(!FolderPtr)
                {
                    DEBUGL1("CBoxDocument::Initialize::<%s> Folder Binding Failed\n",path.c_str());
                    return STATUS_FAILED;
                }

                Status st = ci::operatingenvironment::File::CreateFile(FilePtr,boxdocstatusfilename::INITIALIZING, FolderPtr);
                if(st!=STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::Initialize::Creating initializing.sts file Failed\n");
                    return STATUS_FAILED_INITIALIZATION;		
                }

                boxVec.clear();
		/*
		   Fix for EBX_DTFR_18627
		   As deletion of unique file was failing if it contained special character. 
		   After SoftwareUpgrade on first boot-up cboxdocument::Initialize() is called and it is added in the code flow as fix to get all the ".delete_*" unique file 
		   from all the corresponding boxes in all boxbasepath and delete the same.
		*/
	        Status ret;	
		std::vector<CString> deleteUniqueFile;
		std::vector<CString>::iterator unique_pIt; 
		if(!ci::operatingenvironment::File::Exists("/storage/box/CI_Box_SWUpdateDetectionFlag"))	
		{
			ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> new_folderPtr = NULL;
			ci::operatingenvironment::Ref<ci::operatingenvironment::File> new_filePtr = NULL;
			if(FolderPtr->GetFiles(deleteUniqueFile, ".delete_", true) != STATUS_OK)
			{
				DEBUGL1("CBoxDocument::Initialize::Getting DeleteUniqueFiles inside Folder Failed\n");
			}
			for(unique_pIt = deleteUniqueFile.begin(); unique_pIt != deleteUniqueFile.end(); unique_pIt++)
			{
				if(ci::operatingenvironment::File::Exists(path + (*unique_pIt)))
				{
					if((ret = ci::operatingenvironment::File::DeleteFile(path + (*unique_pIt))) != STATUS_OK)
					{
						DEBUGL1("CBoxDocument::Initialize::Getting Files inside <%s> Folder Failed\n",(path + (*unique_pIt)).c_str());
					}
				}
			}
			new_folderPtr = ci::operatingenvironment::Folder::Bind("/storage/box/");
			if(!new_folderPtr)
			{
				DEBUGL1("CBoxDocument::Initialize:: Folder Binding Failed for /storage/box path\n");
			}
			Status sts = ci::operatingenvironment::File::CreateFile(new_filePtr,"CI_Box_SWUpdateDetectionFlag", new_folderPtr);
			if(sts!=STATUS_OK)
			{
				DEBUGL1("CBoxDocument::Initialize::Creating CI_Box_SWUpdateDetectionFlag file Failed/already existing\n");
			}
		}
		deleteUniqueFile.clear();
                //List of Boxes
                if(Utility::GetDocumentList(boxVec,path)!=STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::Initialize::GetDocumentList failed for BoxBasePath<%s>",boxbasepath.c_str());
                    return STATUS_FAILED_INITIALIZATION;
                }

                std::vector<CString>::iterator pIt;
                CString docpath;
                for(pIt = boxVec.begin(); pIt != boxVec.end(); pIt++)
                {
                    docpath = (*pIt);
                    DEBUGL8("CBoxDocument::Initialize: document name = (%s)\n",docpath.c_str());
                    if(!Utility::ResourceExist(docpath + "/ready.sts"))
                    {
                        if(Utility::InitSts(docpath)!=STATUS_OK)
                        {
                            DEBUGL1("CBoxDocument::Initialize::InitSts failed for BoxBasePath<%s>",boxbasepath.c_str());
                            continue;
                        }						
                    }

                    //reset the sessionID and CutFlag for all the documents.
                    CString xmlfile = "documentproperties.xml";
                    std::map<CString, CString> PropertyMap;
                    PropertyMap.clear();
                    PropertyMap.insert(property_pair::value_type("sessionID",""));
                    PropertyMap.insert(property_pair::value_type("cutDocument",""));	
                    if(Utility::SetProperties(docpath,xmlfile,PropertyMap)!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::Initialize::SetProperties Failed\n");
                        //It could be because xml file would have corrupted. Move such documents to /$Eb2/tmp/for removal after bootup.
                        CString pTmppath = Utility::GetTmpPath();
                        status = ci::operatingenvironment::Folder::MoveDir(docpath.c_str(),pTmppath.c_str());
                        if(status != STATUS_OK)
                        {
                            DEBUGL2("CBoxDocument::Initialize::Could not Move the %s folder ::Delete Manually\n",docpath.c_str());
                        }
                        continue;
                    }			
                }
                //Change the status of BoxDocument to INITIALIZED on completion
                CString from = path + boxdocstatusfilename::INITIALIZING;
                CString to = path + boxdocstatusfilename::INITIALIZED;
                if(ci::operatingenvironment::File::MoveFile(from,to) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::Initialize:Changing status to INITIALIZED failed\n");
                    return STATUS_FAILED_INITIALIZATION;
                }		
            }
            if(boxbasepath != ITUT_BOXBASEPATH)
            {
                DEBUGL8("CBoxDocument::Initialize:Creating Public Boxes\n");	  		
                BoxRef boxRef=NULL;
                CString publicBox("00000");
                CString boxName("Public Box");
                Status ret;
                // confirm publicBox doesn't exist
                CString ePublicbox = boxbasepath;
                ePublicbox += "/" + publicBox;
                if(!ci::operatingenvironment::Folder::Exists(ePublicbox)) 
                {	
                    ret = CreateBox(boxRef, boxbasepath,publicBox);
                    if(ret!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::Initialize:Failed to create PublicBox under EFilingBoxes\n");
                        return ret;
                    }
                    if(boxRef->SetName(boxName)!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::Initialize:Renaming PublicBox under EFilingBoxes failed\n");
                        return STATUS_FAILED;
                    }
                }
            }

            DEBUGL4("CBoxDocument::Initialize: Exit\n");		
            return STATUS_OK;
        }

        Status CBoxDocument::RemoveStatusFile(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::RemoveStatusFile Enter\n");
            //Remove status files present if any
            CString statusFilePath = boxbasepath + "/"+ boxdocstatusfilename::INITIALIZING;
            if(Utility::ResourceExist(statusFilePath)) {
                Status st = ci::operatingenvironment::File::DeleteFile(statusFilePath);
                if(st != STATUS_OK) {
                    DEBUGL1("CBoxDocument::RemoveStatusFile: Error while deleting initializing.sts the status file\n");
                    return STATUS_FAILED;
                }
            }
            statusFilePath = boxbasepath + "/" + boxdocstatusfilename::INITIALIZED;
            if(Utility::ResourceExist(statusFilePath)) {	
                Status st = ci::operatingenvironment::File::DeleteFile(statusFilePath);
                if(st != STATUS_OK) {
                    DEBUGL1("CBoxDocument::RemoveStatusFile: Error while deleting the initialized.sts status file\n");
                    return STATUS_FAILED;
                }
            }

            statusFilePath = boxbasepath + "/"+ boxdocstatusfilename::DELETINGALL;
            if(Utility::ResourceExist(statusFilePath)) {		
                Status st = ci::operatingenvironment::File::DeleteFile(statusFilePath);
                if(st != STATUS_OK) {
                    DEBUGL1("CBoxDocument::RemoveStatusFil: Error while deleting the deletingall.sts status file\n");
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CBoxDocument::RemoveStatusFile Exit\n");	
            return STATUS_OK;
        }
        /**
         * Cleanup all WAITING Documents.
         * The method search each box and delete WAITING Document.
         * @return STATUS_OK on success.
         *         STATUS_FAILED_INITIALIZATION when uninitialized
         */
        Status CBoxDocument::Cleanup()
        {
           DEBUGL4("CBoxDocument::Cleanup: Start Enter\n");
           Status retStatus = STATUS_OK;
           retStatus = Cleanup(EFILING_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for EFilingBoxes failed\n");
           }
           retStatus = Cleanup(ITUT_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for ITUTBoxes failed\n");
           }
           retStatus = Cleanup(POLLING_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for PollingBoxes failed\n");
           }
           retStatus = Cleanup(PAGELOG_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for PageLogBoxes failed\n");
           }
           retStatus = Cleanup(OVERLAY_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for OverlayBoxes failed\n");
           }
           retStatus = Cleanup(FAXRXPREVIEW_BOXBASEPATH);
           if(retStatus != STATUS_OK)
           {
              DEBUGL1("CBoxDocument::Cleanup: for FaxRxPreviewBoxes failed\n");
           }
           DEBUGL4("CBoxDocument::Cleanup: Start Exit\n");
           return retStatus;
        }        

        /**
         * Cleanup all WAITING Documents.
         * The method search each box and delete WAITING Document.
         * @return STATUS_OK on success.
         *         STATUS_FAILED_INITIALIZATION when uninitialized
         */
        Status CBoxDocument::Cleanup(CString boxbasepath)
        {
            //CString boxbasepath=EFILING_BOXBASEPATH;
            DEBUGL4("CBoxDocument::Cleanup: Enter\n");
            
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            std::vector<CString> docListVec;
            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::Cleanup: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::Cleanup: BoxDoc Status of %s isDELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }				
            docListVec.clear();
            //List of Boxes
            if(Utility::GetDocumentList(docListVec,path)!=STATUS_OK)
            {
               DEBUGL1("CBoxDocument::Cleanup: failed for BoxBasePath<%s>",boxbasepath.c_str());
               return STATUS_FAILED;
            }

            std::vector<CString>::iterator pIt;
            CString docpath;
            for(pIt = docListVec.begin(); pIt != docListVec.end(); pIt++)
            {
               docpath = (*pIt);
               DEBUGL8("CBoxDocument::Cleanup: document name = (%s)\n",docpath.c_str());
               if(Utility::ResourceExist(docpath + "/waiting.sts"))
               {
                  if(Utility::RemoveResource(docpath) !=STATUS_OK )
                  {
                     DEBUGL1("CBoxDocument::Cleanup: failed to delete resource <%s>",docpath.c_str());
                     continue;
                  }						
               }
            }
            return STATUS_OK;
        }

        BoxDocStatus CBoxDocument::GetStatus(CString boxbasepath)
        { 	
            BoxDocStatus st = INITIALIZED;	
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::GetStatus: storage is appened to path\n");

            if(boxbasepath == TEMP_BOXBASEPATH)
            {
                DEBUGL8("CBoxDocument::GetStatus::BoxDocstatus for TempBoxes return status initialized\n");
                return st;
            }
            else
            {
                CString path = Utility::GetResourcePath(boxbasepath) + "/";
                DEBUGL8("CBoxDocument::GetStatus path <%s> \n",path.c_str());			
                if(ci::operatingenvironment::File::Exists(path + boxdocstatusfilename::INITIALIZING))
                {
                    DEBUGL8("BoxDocstatus is INITIALIZING\n");
                    st = INITIALIZING;
                }
                else if(ci::operatingenvironment::File::Exists(path + boxdocstatusfilename::INITIALIZED))
                {
                    DEBUGL8("BoxDocstatus is INITIALIZED\n");
                    st = INITIALIZED;
                }
                else if(ci::operatingenvironment::File::Exists(path + boxdocstatusfilename::DELETINGALL))
                {
                    DEBUGL8("BoxDocstatus is DELETINGALL\n");
                    st = DELETING_ALL;
                }		
                else
                {
                    // if file is not found, document status is considered as UNINITIALIZED.
                    DEBUGL8("BoxDocstatus is UNINITIALIZED\n");
                    st = UNINITIALIZED;				
                }
                return st;	
            }

        }

        /**
         * confirm Box exists or not
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @return true if box exists
         *         false if box doesn't exist.
         */
        bool CBoxDocument::BoxExist(CString boxbasepath, CString boxnumber)
        {
            //Get the BoxDoc status
            if(boxbasepath.find("/storage") == std::string::npos)		
                boxbasepath = BOXPATH + "/" + boxbasepath;		
            else
                DEBUGL8("CBoxDocument::BoxExist: storage is appened to path\n");


            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::BoxExist: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return false;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::BoxExist: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return false;				
            }		

            return ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath,boxnumber));		    
        }

        /**
         * Delete all folders/documents and delete all boxes except public box
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @return STATUS_OK on success,
         *         STATUS_AUTHENTICATIONFAILS on Authentication failure.
         *         STATUS_NOTREADY if Box is not READY
         *         STATUS_FAILED if Failed.
         */
        Status CBoxDocument::DeleteAll(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::DeleteAll: Enter\n");		
            if(boxbasepath.find("/storage") == std::string::npos)		
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
					DEBUGL8("CBoxDocument::DeleteAll: storage is appened to path\n");
	    CString tempPath;
	    dom::DocumentRef domDocRef;
	    ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
	    pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
	    if (!pHDB)
	    {
		    DEBUGL1("CBoxDocument::CreateBox: Failed to Acquire HierarchicalDB\n");
		    return STATUS_FAILED;
	    }

            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::DeleteAll: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::DeleteAll: BoxDoc Status of %s isDELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }				
            //Change the status of BoxDocument to INITIALIZED on completion
            CString path = Utility::GetResourcePath(boxbasepath) + "/";		
            CString from = path + boxdocstatusfilename::INITIALIZED;
            CString to = path + boxdocstatusfilename::DELETINGALL;
            if(ci::operatingenvironment::File::MoveFile(from,to) != STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::DeleteAll:Changing status to DELETING_ALL failed\n");
                return STATUS_FAILED;
            }

            //Now Get the status of the Each document under the all Boxes.
            Status st=CheckStatus(boxbasepath);
            if(st!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteAll::CheckStatus Failed");

                //Change the status of BoxDocument to INITIALIZED on completion			
                from = path + boxdocstatusfilename::DELETINGALL;
                to = path + boxdocstatusfilename::INITIALIZED;
                if(ci::operatingenvironment::File::MoveFile(from,to)!=STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::DeleteAll:Changing status to INITIALIZED failed\n");
                    return STATUS_FAILED;
                }				
                return st;
            }

            // Now Change all the Document Status to deleting and Delete the Document.
            st = StartDeletion(boxbasepath);
            if(st!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteAll::StartDeletion Failed");

                //Change the status of BoxDocument to INITIALIZED on completion			
                from = path + boxdocstatusfilename::DELETINGALL;
                to = path + boxdocstatusfilename::INITIALIZED;
                if(ci::operatingenvironment::File::MoveFile(from,to)!=STATUS_OK) 
                {
                    DEBUGL1("CBoxDocument::DeleteAll:Changing status to INITIALIZED failed\n");
                    return STATUS_FAILED;
                }			
                return st;
            }

            if(boxbasepath != ITUT_BOXBASEPATH)
            {
                //Create Public boxes
                DEBUGL8("CBoxDocument::DeleteAll:Creating Public Boxes\n");	  		
                BoxRef boxRef=NULL;
                CString publicBox("00000");
                CString boxName("Public Box");

                // confirm publicBox doesn't exist
                if(!ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath,publicBox))) 
                {	
                    ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> BoxpathPtr = NULL;
                    path = path + publicBox + "/";

                    //Now create the Box in the given path
                    Status ds = ci::operatingenvironment::Folder::CreateFolder(BoxpathPtr,path.c_str());	
                    if((ds==::STATUS_DISK_FULL) || ds != STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::DeleteAll::Creation of %s Failed\n", path.c_str());
                        return ds;	
                    }
                    else if(!BoxpathPtr)
                    {
                        DEBUGL1("CBoxDocument::DeleteAll::<%s> Folder Creation Failed\n",path.c_str());
                        return STATUS_FAILED;
                    }


                    //Copy boxproperties.xml file to box path
                    CString origPropertyPath = Utility::GetEB2ROOTPath() + "/bin/boxproperties.xml"; 
                    DEBUGL8("CBoxDocument::DeleteAll: origPropertyPath = (%s)\n",origPropertyPath.c_str());
                    DEBUGL8("CBoxDocument::DeleteAll: to path = (%s)\n",path.c_str());
		    ds = pHDB->CreateDocumentFromFile(path, "boxproperties_dom", domDocRef, origPropertyPath);
                    if(ds != STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::DeleteAll::Creation of %s Failed\n", path.c_str());
                        return ds;	
                    }

                    // get box instance
                    BoxRef box = new CBox(m_sessionID, boxbasepath, publicBox);
                    try
                    {
                        if(!box)
                        {
                            DEBUGL1("CBoxDocument::DeleteAll: box object is null\n");
                            return STATUS_FAILED;
                        }
                        Status ret = dynamic_cast<CBox*>(box.operator->())->SaveProperties();
                        if(ret != STATUS_OK)
                        {
                            DEBUGL1("CBoxDocument::DeleteAll::SaveProperties failed\n");
                            box = NULL; // release
                            return ret;
                        }				
                    }
                    catch(exception &e)
                    {
                        DEBUGL1("CBoxDocument::DeleteAll: Caught exception (%s)\n",e.what());
                        return STATUS_FAILED;
                    }
                    if(box->SetName(boxName)!=STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::DeleteAll:Renaming PublicBox under %s failed\n",boxbasepath.c_str());
                        return STATUS_FAILED;
                    }
                }
            }
            //Change the status of BoxDocument to INITIALIZED on completion
            from = boxbasepath + "/" + boxdocstatusfilename::DELETINGALL;
            to = boxbasepath + "/" + boxdocstatusfilename::INITIALIZED;
            if(ci::operatingenvironment::File::MoveFile(from,to) != STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::DeleteAll:Changing status to INITIALIZED failed\n");
                return STATUS_FAILED;
            }	


            DEBUGL4("CBoxDocument::DeleteAll: Exit\n");		
            return STATUS_OK;
        }

        Status CBoxDocument::CheckStatus(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::CheckStatus: Enter\n");		
            if(boxbasepath.find("/storage") == std::string::npos)		
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::CheckStatus: storage is appened to path\n");


            CString boxNumber("");
            CString folderName("");
            CString docName("");		
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            std::vector<CString> boxVec;
            std::vector<CString> folderVec;			
            std::vector<CString> docVec;

            boxVec.clear();
            //List of Boxes
            if(Utility::GetCollectionList(boxVec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::CheckStatus::GetCollectionList failed for BoxBasePath<%s>",boxbasepath.c_str());
                return STATUS_FAILED;
            }
            CString boxPath("");
            std::vector<CString>::iterator fIt;
            CString folderPath("");
            DocumentRef doc=NULL;
            DocStatus st;
            for(unsigned int i = 0, cnt = 0; (i < boxVec.size()) && (cnt < 65535); i++, cnt++) 
            {
                boxNumber.clear();
                boxNumber = boxVec[i];	
                DEBUGL8("CBoxDocument::CheckStatus: BoxNumber<%s>\n",boxNumber.c_str());	  

                folderVec.clear();
                //List of folders under Box
                boxPath = Utility::GetResourcePath(boxbasepath, boxNumber) + "/";
                if(Utility::GetCollectionList(folderVec,boxPath)!=STATUS_OK) 
                {
                    DEBUGL2("CBoxDocument::CheckStatus: GetCollectionList of folder failed for BoxNumber<%s>",boxNumber.c_str());
                    continue;
                }

                for(unsigned int i = 0, cnt = 0; (i < folderVec.size()) && (cnt < 65535); i++, cnt++) 
                {
                    folderName.clear();			
                    folderName = folderVec[i];
                    CString fullPath = boxPath + folderName + "/.document";				
                    if(!Utility::ResourceExist(fullPath))
                    {

                        DEBUGL8("CBoxDocument::CheckStatus: BoxNumber<%s>, FolderName<%s>\n",boxNumber.c_str(),folderName.c_str());	  							
                        docVec.clear();			
                        //List of documents under Folder
                        folderPath = Utility::GetResourcePath(boxbasepath, boxNumber,folderName) + "/";
                        if(Utility::GetCollectionList(docVec,folderPath)!=STATUS_OK) 
                        {
                            DEBUGL2("CBoxDocument::CheckStatus::GetCollectionList failed for FolderName<%s>",folderName.c_str());
                            continue;
                        }
                        for(unsigned int i = 0, cnt = 0; (i < docVec.size()) && (cnt < 65535); i++, cnt++) 
                        {
                            docName.clear();							
                            docName= docVec[i];
                            DEBUGL8("CBoxDocument::CheckStatus:BoxNumber<%s>, FolderName<%s>, DocumentName<%s>\n",boxNumber.c_str(),folderName.c_str(),docName.c_str());
                            doc=NULL;
                            doc = new CDocument(m_sessionID, boxbasepath, boxNumber, folderName, docName);
                            try
                            {
                                if(!doc)
                                {
                                    DEBUGL1("CBoxDocument::CheckStatus: doc object is null\n");
                                    return STATUS_FAILED;
                                }
                                if(dynamic_cast<CDocument*>(doc.operator->())->LoadProperties() != STATUS_OK) 
                                {
                                    DEBUGL2("CBoxDocument::CheckStatus::Loading Document<%s> is failed\n",docName.c_str());
                                    continue;
                                }					
                                if(dynamic_cast<CDocument*>(doc.operator->())->GetStatus(st)!=STATUS_OK)
                                {
                                    DEBUGL1("CBoxDocument::CheckStatus: GetStatus failed for Document<%s>",docName.c_str());
                                    return STATUS_FAILED;											
                                }
                            }
                            catch(exception &e)
                            {
                                DEBUGL1("CBoxDocument::CheckStatus: Caught exception (%s)\n",e.what());
                                return STATUS_FAILED;											
                            }															
                            //check the status of the document if its not READY/DELETING/WAITING then return STATUS_NOTREADY.
                            if(!((st == READY) || (st == DELETING || (st == WAITING)))) 
                            {
                                DEBUGL1("CBoxDocument::CheckStatus::<%s> Document Status is not READY,DELETING or WAITING\n",docName.c_str());
                                return STATUS_NOTREADY;
                            }					
                        }	
                    }
                }

                docVec.clear();			
                //List of documents under Box
                if(Utility::GetCollectionList(docVec,boxPath)!=STATUS_OK) 
                {
                    DEBUGL2("CBoxDocument::CheckStatus::GetCollectionList failed for BoxNumber<%s>",boxNumber.c_str());
                    continue;
                }

                for(unsigned int i = 0, cnt = 0; (i < docVec.size()) && (cnt < 65535); i++, cnt++) 
                {
                    docName.clear();							
                    docName= docVec[i];
                    CString fullPath = boxPath + docName + "/.document";				
                    if(Utility::ResourceExist(fullPath))
                    {					
                        DEBUGL8("CBoxDocument::CheckStatus:BoxNumber<%s>, DocumentName<%s>\n",boxNumber.c_str(),docName.c_str());
                        doc=NULL;
                        doc = new CDocument(m_sessionID, boxbasepath, boxNumber, folderName, docName);
                        try
                        {
                            if(!doc)
                            {
                                DEBUGL1("CBoxDocument::CheckStatus: doc object is null\n");
                                return STATUS_FAILED;
                            }
                            if(dynamic_cast<CDocument*>(doc.operator->())->LoadProperties() != STATUS_OK) 
                            {
                                DEBUGL2("CBoxDocument::CheckStatus::Loading Document<%s> is failed\n",docName.c_str());
                                continue;
                            }					
                            if(dynamic_cast<CDocument*>(doc.operator->())->GetStatus(st)!=STATUS_OK)
                            {
                                DEBUGL1("CBoxDocument::CheckStatus: GetStatus failed for Document<%s>",docName.c_str());
                                return STATUS_FAILED;											
                            }										
                            //check the status of the document if its not READY/DELETING/WAITING then return STATUS_NOTREADY.
                            if(!((st == READY) || (st == DELETING || (st == WAITING)))) 
                            {
                                DEBUGL1("CBoxDocument::CheckStatus::<%s> Document Status is not READY,DELETING or WAITING\n",docName.c_str());
                                return STATUS_NOTREADY;
                            }
                        } 
                        catch(exception &e)
                        {
                            DEBUGL1("CBoxDocument::CheckStatus: Caught exception (%s)\n",e.what());
                            return STATUS_FAILED;
                        }
                    }
                }

            }

            DEBUGL4("CBoxDocument::CheckStatus: Exit\n");				
            return STATUS_OK;
        }

        Status CBoxDocument::StartDeletion(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::StartDeletion: Enter\n");
            if(boxbasepath.find("/storage") == std::string::npos)		
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::StartDeletion: storage is appened to path\n");


            CString boxNumber("");
            CString folderName("");
            CString docName("");		
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            std::vector<CString> boxVec;
            std::vector<CString> folderVec;			
            std::vector<CString> docVec;
            CString boxdelpath;
            boxVec.clear();
            //List of Boxes
            if(Utility::GetCollectionList(boxVec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::StartDeletion::GetCollectionList failed for BoxBasePath<%s>",boxbasepath.c_str());
                return STATUS_FAILED;
            }

            CString boxPath("");
            std::vector<CString>::iterator fIt;
            std::vector<CString>::iterator dIt;
            DocumentRef doc=NULL;
            CString folderPath("");
            for(unsigned int i = 0, cnt = 0; (i < boxVec.size()) && (cnt < 65535); i++, cnt++) 
            {
                boxNumber.clear();
                boxNumber = boxVec[i];
                DEBUGL8("CBoxDocument::StartDeletion: BoxNumber<%s>\n",boxNumber.c_str());	  

                folderVec.clear();
                //List of folders under Box
                boxPath = Utility::GetResourcePath(boxbasepath, boxNumber) + "/";
                if(Utility::GetCollectionList(folderVec,boxPath)!=STATUS_OK) 
                {
                    DEBUGL2("CBoxDocument::StartDeletion: GetCollectionList of folder failed for BoxNumber<%s>",boxNumber.c_str());
                    continue;
                }

                for(unsigned int i = 0, cnt = 0; (i < folderVec.size()) && (cnt < 65535); i++, cnt++) 
                {
                    folderName.clear();			
                    folderName = folderVec[i];//.substr(pre + 1, last - (pre + 1));
                    CString fullPath = boxPath + folderName + "/.document";
                    if(!Utility::ResourceExist(fullPath))
                    {
                        DEBUGL8("CBoxDocument::StartDeletion: BoxNumber<%s>, FolderName<%s>\n",boxNumber.c_str(),folderName.c_str());	  							
                        docVec.clear();			
                        //List of documents under Folder
                        folderPath = Utility::GetResourcePath(boxbasepath, boxNumber,folderName) + "/";
                        if(Utility::GetCollectionList(docVec,folderPath)!=STATUS_OK) 
                        {
                            DEBUGL2("CBoxDocument::StartDeletion::GetCollectionList failed for FolderName<%s>",folderName.c_str());
                            continue;
                        }
                        try
                        {
                            for(unsigned int i = 0, cnt = 0; (i < docVec.size()) && (cnt < 65535); i++, cnt++) 
                            {
                                docName.clear();							
                                docName= docVec[i];//.substr(pre + 1, last - (pre + 1));
                                DEBUGL8("CBoxDocument::StartDeletion:BoxNumber<%s>, FolderName<%s>, DocumentName<%s>\n",boxNumber.c_str(),folderName.c_str(),docName.c_str());
                                doc=NULL;
                                doc = new CDocument(m_sessionID, boxbasepath, boxNumber, folderName, docName);
                                if(!doc)
                                {
                                    DEBUGL1("CBoxDocument::StartDeletion: doc object is null\n");
                                    return STATUS_FAILED;
                                }
                                if(dynamic_cast<CDocument*>(doc.operator->())->LoadProperties() != STATUS_OK) 
                                {
                                    DEBUGL2("CBoxDocument::StartDeletion::Loading Document<%s> is failed\n",docName.c_str());
                                    continue;
                                }					

                                // Start to Delete
                                if(dynamic_cast<CDocument*>(doc.operator->())->Delete() != STATUS_OK) 
                                {
                                    DEBUGL1("CBoxDocument::StartDeletion::Deleting document is failed\n");
                                    return STATUS_FAILED;
                                }
                            }
                        }
                        catch(exception &e)
                        {
                            DEBUGL1("CBoxDocument::StartDeletion:: Caught exception (%s)\n",e.what());
                            return STATUS_FAILED;
                        }		
                    }
                }

                docVec.clear();			
                //List of documents under Box
                if(Utility::GetCollectionList(docVec,boxPath)!=STATUS_OK) 
                {
                    DEBUGL2("CBoxDocument::StartDeletion::GetCollectionList failed for BoxNumber<%s>",boxNumber.c_str());
                    continue;
                }

                for(unsigned int i = 0, cnt = 0; (i < docVec.size()) && (cnt < 65535); i++, cnt++) 
                {
                    docName.clear();							
                    docName= docVec[i];//.substr(pre + 1, last - (pre + 1));
                    CString fullPath = boxPath + docName + "/.document";
                    if(Utility::ResourceExist(fullPath))
                    {
                        DEBUGL8("CBoxDocument::StartDeletion:BoxNumber<%s>, DocumentName<%s>\n",boxNumber.c_str(),docName.c_str());
                        doc=NULL;
                        doc = new CDocument(m_sessionID, boxbasepath, boxNumber, "", docName);
                        try
                        {
                            if(!doc)
                            {
                                DEBUGL1("CBoxDocument::StartDeletion: doc object is null\n");
                                return STATUS_FAILED;
                            }
                            if(dynamic_cast<CDocument*>(doc.operator->())->LoadProperties() != STATUS_OK) 
                            {
                                DEBUGL2("CBoxDocument::StartDeletion::Loading Document<%s> is failed\n",docName.c_str());
                                continue;
                            }					

                            // Start to Delete
                            if(dynamic_cast<CDocument*>(doc.operator->())->Delete() != STATUS_OK) 
                            {
                                DEBUGL1("CBoxDocument::StartDeletion::Deleting document is failed\n");
                                return STATUS_FAILED;
                            }
                        }
                        catch(exception &e)
                        {
                            DEBUGL1("CBoxDocument::StartDeletion: Caught exception (%s)\n",e.what());
                            return STATUS_FAILED;
                        }
                    }
                }

                //Delete the Box as its validation is Over
                boxdelpath = Utility::GetResourcePath(boxbasepath, boxNumber) + "/";

                // delete whole folder
                if(ci::operatingenvironment::Folder::Remove(boxdelpath.c_str(),true)!=STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::StartDeletion::DeleteResource %s is failed\n",boxdelpath.c_str());
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CBoxDocument::StartDeletion: Exit\n");		
            return STATUS_OK;
        }

        /**
         * deletes all documents which are copied to clipboard during clipboard operations.
         * This API only deletes document in clipboard related to a particular session. 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure
         */
        Status CBoxDocument::ClearClipBoard()
        {
            DEBUGL4("CBoxDocument::ClearClipBoard: Enter\n");
            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(EFILING_BOXBASEPATH);
            if(btStatus==UNINITIALIZED||btStatus==INITIALIZING)
            {
                DEBUGL1("CBoxDocument::ClearClipBoard: BoxDoc Status is UNINITIALIZED/INITIALIZING");
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::ClearClipBoard: BoxDoc Status DELETING_ALL");
                return STATUS_DELETINGALL;				
            }				

            //Delete Clipboard documents,if any
            std::vector<CString> vec;
            CString sid("");	
            uint last;	
            CString documentname("");
            CString resourceKey("");

            //const CString CLIPBOARD_PATH = "/ClipBoard/";
            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBoxDocument::ClearClipboard::Getting collection list failed\n");
                return STATUS_FAILED;
            }

            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                last = fulldocumentname.rfind("_");
                documentname = fulldocumentname.substr(last+1);
                DEBUGL8("CBoxDocument::ClearClipboard: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

                //Check if the clipborad document is of the same user
                resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid) != STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::ClearClipboard::Getting SessionID property failed\n");
                    return STATUS_FAILED;
                }
                DEBUGL8("CBoxDocument::ClearClipboard:SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());
                if(sid!=m_sessionID)
                    continue;
                if(ci::operatingenvironment::Folder::Remove(resourceKey.c_str(),true)!=STATUS_OK)
                {
                    DEBUGL1("CBoxDocument::ClearClipboard:DeleteResource <%s> is failed\n", resourceKey.c_str());
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CBoxDocument::ClearClipBoard: Enter\n");				
            return STATUS_OK;
        }

        /**
         * This method search for each box present in the EFilingBoxes and unlock the box if it is locked. 
         * @return STATUS_OK
         *		STATUS_FAILED
         */
        Status CBoxDocument::UnlockAllBoxes()
        {
            DEBUGL4("CBoxDocument::UnlockAllBoxes: Enter\n");
            BoxList list;
            std::map<CString, CString> PropMap;		
            if(GetBoxList(list, EFILING_BOXBASEPATH) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::UnlockAllBoxes: Failed to get the boxlist\n");
                return STATUS_FAILED;	
            }

            //Iterate through box list and unlock the boxes
            BoxList::const_iterator    itemIterator;
            BoxRef  boxRef;
            for (itemIterator = list.begin(); itemIterator != list.end(); itemIterator++)
            {
                boxRef = *itemIterator;
                if(boxRef)
                {
                    if(boxRef->IsLocked())
                    {
                        DEBUGL8("CBoxDocument::UnlockAllBoxes: Box is locked unlock the box\n");
                        if(boxRef->Unlock() != STATUS_OK)
                        {
                            DEBUGL1("CBoxDocument::UnlockAllBoxes: Failed to unlock the box\n");
                            return STATUS_FAILED;
                        }
                    }
                }
                else
                {
                    DEBUGL1("CBoxDocument::UnlockAllBoxes: Invalid box reference\n");
                    return STATUS_FAILED;				
                }		
            }
            DEBUGL4("CBoxDocument::UnlockAllBoxes: Exit\n");		
            return STATUS_OK;
        }
        /**
         * Delete all folders/documents and delete all boxes
         * @param[in] boxbasepath - box type e.g. "eFilingboxes"
         * @param[in] publicbox - create public box
         * @return STATUS_OK on success. 
         *         STATUS_FAILED on Failure	
         */
        Status CBoxDocument::DeleteAll(CString boxbasepath, bool publicbox)
		{
			DEBUGL4("CBoxDocument::DeleteAll Enter\n");
			if(boxbasepath.find("/storage") == std::string::npos)		
				boxbasepath = BOXPATH + "/" + boxbasepath;

			ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
				DEBUGL8("CBoxDocument::DeleteAll deleting without creating public box\n");
				Status st = ci::operatingenvironment::Folder::Folder::Remove(boxbasepath + "/", true);
				if(st != STATUS_OK)
				{
					DEBUGL1("CBoxDocument::DeleteAll: Failed to delete the contents of boxbasepath\n");
					return st;
				}
				//Create the boxbasepath
				st = ci::operatingenvironment::Folder::Folder::CreateFolder(FolderPtr, boxbasepath);
				if(st != STATUS_OK)
				{
					DEBUGL1("CBoxDocument::DeleteAll: Failed to create the boxbasepath\n");
					return st;
				}
			if(publicbox == true)
			{
				DEBUGL8("CBoxDocument::DeleteAll: public box creation is true\n");
				//Create Public boxes
				DEBUGL8("CBoxDocument::DeleteAll:Creating Public Boxes\n");
				if(boxbasepath != ITUT_BOXBASEPATH)
				{
					//Create Public boxes
					DEBUGL8("CBoxDocument::DeleteAll:Creating Public Boxes\n");
					BoxRef boxRef=NULL;
					CString publicBox("00000");
					CString boxName("Public Box");


					// confirm publicBox doesn't exist
					if(!ci::operatingenvironment::Folder::Exists(Utility::GetResourcePath(boxbasepath,publicBox)))
					{
						ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> BoxpathPtr = NULL;

						CString path = boxbasepath + "/" + publicBox;
						//Now create the Box in the given path
						Status ds = ci::operatingenvironment::Folder::CreateFolder(BoxpathPtr,path.c_str());
						if((ds==::STATUS_DISK_FULL) || ds != STATUS_OK)
						{
							DEBUGL1("CBoxDocument::DeleteAll::Creation of %s Failed\n", path.c_str());
							return ds;	
						}
						else if(!BoxpathPtr)
						{
							DEBUGL1("CBoxDocument::DeleteAll::<%s> Folder Creation Failed\n",path.c_str());
							return STATUS_FAILED;
						}


						//Copy boxproperties.xml file to box path
						CString origPropertyPath = Utility::GetEB2ROOTPath() + "/bin/boxproperties.xml";
						DEBUGL8("CBoxDocument::DeleteAll: origPropertyPath = (%s)\n",origPropertyPath.c_str());
						DEBUGL8("CBoxDocument::DeleteAll: toath = (%s)\n",path.c_str());
						ds = ci::operatingenvironment::File::CopyFile(origPropertyPath,path,true);
						if((ds==::STATUS_DISK_FULL) || ds != STATUS_OK)
						{
							DEBUGL1("CBoxDocument::DeleteAll::Creation of %s Failed\n", path.c_str());
							return ds;	
						}
						// get box instance
						BoxRef box = new CBox(m_sessionID, boxbasepath, publicBox);
						try
						{
							if(!box)
							{
								DEBUGL1("CBoxDocument::DeleteAll: box object is null\n");
								return STATUS_FAILED;
							}
							Status ret = dynamic_cast<CBox*>(box.operator->())->SaveProperties();
							if(ret != STATUS_OK)
							{
								DEBUGL1("CBoxDocument::DeleteAll::SaveProperties failed\n");
								box = NULL; // release
								return ret;
							}
						}
						catch(exception &e)
						{
							DEBUGL1("CBoxDocument::DeleteAll: Caught exception (%s)\n",e.what());
							return STATUS_FAILED;
						}
						//Set totalBoxSize to 0
						if(box->SetWebDAVProperty("totalBoxSize","0")!=STATUS_OK)
						{
							DEBUGL1("CBoxDocument::DeleteAll::SetProperty Failed\n");
							box = NULL; // release
							return STATUS_FAILED;
						}
						if(box->SetName(boxName)!=STATUS_OK)
						{
							DEBUGL1("CBoxDocument::DeleteAll:Renaming PublicBox under %s failed\n",boxbasepath.c_str());
							return STATUS_FAILED;
						}
					}
				}
			}

			//Create the initialized.sts file
			ci::operatingenvironment::Ref<ci::operatingenvironment::File> FilePtr = NULL;
			st = ci::operatingenvironment::File::CreateFile(FilePtr, boxdocstatusfilename::INITIALIZED, FolderPtr);
			if(st!=STATUS_OK)
			{
				DEBUGL1("CBoxDocument::DeleteAll::Creating initializing.sts file Failed\n");
				return st;
			}

			DEBUGL4("CBoxDocument::DeleteAll: Exit\n");
			return STATUS_OK;
		}

        /**
         * confirm the BoxBasePath is used.
         * @param[in] boxbasepath - box type e.g. "EFilingboxes"
         * @return true if the boxbasepath is used.
         *         false if the boxbasepath is NOT used.
         */
        bool CBoxDocument::isUsed(CString boxbasepath)		
        {
            DEBUGL4("CBoxDocument::isUsed Enter\n");	
            if(boxbasepath.find("/storage") == std::string::npos)		
                boxbasepath = BOXPATH + "/" + boxbasepath;

            bool ret = false;			
            int32 count = 0;
            CString xpath = boxbasepath.erase(0,13);
            void* userCountAddr = NULL;
            BoxCount bc;
            memset(&bc, '\0', sizeof(BoxCount));
            Ref<SharedMemory> userCountShmName = SharedMemory::Bind((char*)USERCOUNT_MEMORY, false);
            if(!userCountShmName)
            {
                DEBUGL1("CBoxDocument::incrementUserCount::Binding to Shared Memory failed..\n");
                return STATUS_FAILED;
            }
            userCountShmName->Acquire();
            userCountShmName->Map(userCountAddr);
            if(userCountAddr == NULL)
            {
                DEBUGL1("CBoxDocument::incrementUserCount::Mapping to Shared Memory failed..\n");
                return STATUS_FAILED;
            }
            bc = *((BoxCount*)userCountAddr);
            userCountShmName->Unmap(userCountAddr);
            userCountShmName->Release();
            if(xpath == "EFilingBoxes"){
                DEBUGL4("CBoxDocument::isUsed: count (%d)\n", bc.efilingCount);
                count =  bc.efilingCount;
                //DEBUGL4("CBoxDocument::incrementUserCount: count (%d)\n", bc.efilingCount);
                }
            else if(xpath == "TempBoxes")
                count = bc.tempCount;
            else if(xpath == "OverlayBoxes")
                count = bc.overlayCount;
            else if(xpath == "PollingBoxes")
                count = bc.pollingCount;
            else if(xpath == "PageLogBoxes")
                count = bc.pagelogCount;
            else if(xpath == "ITUTBoxes")
                count = bc.itutCount;
            else if(xpath == "FaxRxPreviewBoxes")
                count = bc.faxrxCount;

            count != 0 ? ret = true : ret = false;			
            DEBUGL4("CBoxDocument::isUsed Exit\n");
            return ret;
        }

        Status CBoxDocument::incrementUserCount(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::incrementUserCount: Enter\n");
            if(boxbasepath == WORKSPACE_PATH || boxbasepath == CLIPBOARD_PATH) {
                DEBUGL8("Need not increment for workspace/clipboard\n");
                return STATUS_OK;
            }

            CString xpath = boxbasepath.erase(0,13);
            void* userCountAddr = NULL;
            BoxCount bc;
            memset(&bc, '\0', sizeof(BoxCount));
            Ref<SharedMemory> userCountShmName = SharedMemory::Bind((char*)USERCOUNT_MEMORY, false);
            if(!userCountShmName)
            {
                DEBUGL1("CBoxDocument::incrementUserCount::Binding to Shared Memory failed..\n"); 
                return STATUS_FAILED;
            }
            userCountShmName->Acquire();
            userCountShmName->Map(userCountAddr);
            if(userCountAddr == NULL)
            {
                DEBUGL1("CBoxDocument::incrementUserCount::Mapping to Shared Memory failed..\n");
                return STATUS_FAILED;
            }
            bc = *((BoxCount*)userCountAddr);

            if(xpath == "EFilingBoxes"){
                DEBUGL8("CBoxDocument::incrementUserCount: count (%d)\n", bc.efilingCount);
                bc.efilingCount++;
                DEBUGL8("CBoxDocument::incrementUserCount: count (%d)\n", bc.efilingCount);
            }
            else if(xpath == "TempBoxes")
                bc.tempCount++;
            else if(xpath == "OverlayBoxes")
                bc.overlayCount++;
            else if(xpath == "PollingBoxes")
                bc.pollingCount++;
            else if(xpath == "PageLogBoxes")
                bc.pagelogCount++;
            else if(xpath == "ITUTBoxes")
                bc.itutCount++;
            else if(xpath == "FaxRxPreviewBoxes")
                bc.faxrxCount++;
            *((BoxCount*)userCountAddr) = bc;
            userCountShmName->Unmap(userCountAddr);
            userCountShmName->Release();
            DEBUGL4("CBoxDocument::incrementUserCount: Exit\n");		
            return STATUS_OK;
        }
        Status CBoxDocument::decrementUserCount(CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::decrementUserCount: Enter\n");
            if(boxbasepath == WORKSPACE_PATH || boxbasepath == CLIPBOARD_PATH) {
                DEBUGL8("CBoxDocument::decrementUserCount: Need not decrement for workspace/clipboard\n");
                return STATUS_OK;
            }
            CString xpath = boxbasepath.erase(0,13);
            void* userCountAddr = NULL;
            BoxCount bc;
            memset(&bc, '\0', sizeof(BoxCount));
            Ref<SharedMemory> userCountShmName = SharedMemory::Bind((char*)USERCOUNT_MEMORY, false);
            if(!userCountShmName)
            {
                DEBUGL1("CBoxDocument::decrementUserCount::Binding to Shared Memory failed..\n");
                return STATUS_FAILED;
            }
            userCountShmName->Acquire();
            userCountShmName->Map(userCountAddr);
            if(userCountAddr == NULL)
            {
                DEBUGL1("CBoxDocument::decrementUserCount::Mapping to Shared Memory failed..\n");
                return STATUS_FAILED;
            }
            bc = *((BoxCount*)userCountAddr);

            if(xpath == "EFilingBoxes"){
                DEBUGL4("CBoxDocument::decrementUserCount: count (%d)\n", bc.efilingCount);
                bc.efilingCount--;
                DEBUGL4("CBoxDocument::decrementUserCount: count (%d)\n", bc.efilingCount);
            }
            else if(xpath == "TempBoxes")
                bc.tempCount--;
            else if(xpath == "OverlayBoxes")
                bc.overlayCount--;
            else if(xpath == "PollingBoxes")
                bc.pollingCount--;
            else if(xpath == "PageLogBoxes")
                bc.pagelogCount--;
            else if(xpath == "ITUTBoxes")
                bc.itutCount--;
            else if(xpath == "FaxRxPreviewBoxes")
                bc.faxrxCount--;

            *((BoxCount*)userCountAddr) = bc;
            userCountShmName->Unmap(userCountAddr);
            userCountShmName->Release();
            DEBUGL4("CBoxDocument::decrementUserCount: Exit\n");		
            return STATUS_OK;
        }	

        /**
         * get a list of box.
         * @param[out] boxView - this structure contains total number of boxes and for each box name and number of the box.
         * @param[in] boxbasepath - box base path	 
         * @return STATUS_OK on success,
         * STATUS_FAILED on failure.
         */
        Status CBoxDocument::GetBoxList(BoxList &list, int &totalBoxes, CString boxbasepath)
        {
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::GetBoxList: storage is appened to path\n");

            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus == UNINITIALIZED||btStatus == INITIALIZING)
            {
                DEBUGL1("CBoxDocument::GetBoxList: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::GetBoxList: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }
            std::vector<CString> vec;
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetBoxList::Getting collection list is failed");
                return STATUS_FAILED;
            }

            list.clear();
            BoxRef box=NULL;
            totalBoxes = vec.size();
            for(unsigned int i = 0, cnt = 0; (i < vec.size()) && (cnt < 65535); i++, cnt++) 
            {
                CString boxnumber = vec[i];
                // GetBox
                box=NULL;
                box = new CMIBViewBox(m_sessionID, boxbasepath, boxnumber);
                if(box)
                    list.push_back(box);
            }

            DEBUGL4("CBoxDocument::GetBoxList: Exit\n");
            return STATUS_OK;	
        }	

        /**
         * get a list of mailbox.
         * @param[out] boxView - this structure contains total number of mailboxes and for each box name, number, documentType, userName and comment of the mailbox.
         * @param[in] boxbasepath - boxbasepath	 
         * @return STATUS_OK on success,
         * STATUS_FAILED on failure.
         */
        Status CBoxDocument::GetMailBoxList(BoxList &list, int &totalBoxes, CString boxbasepath)
        {
            DEBUGL4("CBoxDocument::GetMAILBoxList: Enter\n");
            if(boxbasepath.find("/storage") == std::string::npos)	
                boxbasepath = BOXPATH + "/" + boxbasepath;
            else
                DEBUGL8("CBoxDocument::GetMAILBoxList: storage is appened to path\n");

            //Get the BoxDoc status
            BoxDocStatus btStatus = GetStatus(boxbasepath);
            if(btStatus == UNINITIALIZED||btStatus == INITIALIZING)
            {
                DEBUGL1("CBoxDocument::GetMAILBoxList: BoxDoc Status of %s is UNINITIALIZED/INITIALIZING",boxbasepath.c_str());
                return STATUS_FAILED_INITIALIZATION;			
            }
            else if(btStatus == DELETING_ALL)
            {
                DEBUGL1("CBoxDocument::GetMAILBoxList: BoxDoc Status of %s is DELETING_ALL",boxbasepath.c_str());
                return STATUS_DELETINGALL;				
            }
            std::vector<CString> vec;
            CString path = Utility::GetResourcePath(boxbasepath) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetMAILBoxList::Getting collection list is failed");
                return STATUS_FAILED;
            }

            list.clear();
            BoxRef box=NULL;
            totalBoxes = vec.size();
            for(unsigned int i = 0, cnt = 0; (i < vec.size()) && (cnt < 65535); i++, cnt++) 
            {
                CString boxnumber = vec[i];
                // GetBox
                box=NULL;
                box = new CMAILViewBox(m_sessionID, boxbasepath, boxnumber);
                if(box)
                    list.push_back(box);
            }

            DEBUGL4("CBoxDocument::GetMAILBoxList: Exit\n");
            return STATUS_OK;	
        }	
    };
}; // end of namespace ci
