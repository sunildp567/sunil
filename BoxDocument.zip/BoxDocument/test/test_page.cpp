#include<iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

PageRef GetPage(CString boxbasepath, CString boxnumber, CString foldername, CString documentname, int pageno) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }

	BoxRef box;
	if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

    ci::boxdocument::DocumentRef doc;
	if(!foldername.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,foldername)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc, documentname) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc, documentname) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}
    
    PageRef page;
    if(doc->GetPage(pageno, page) != STATUS_OK) {
        DEBUGL1("Document::GetPage() is failed\n");
        return NULL;
    }
    return page;
}

bool test_GetImage(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname, int pageno) {
    PageRef page = GetPage(boxbasepath, boxnumber, foldername, documentname, pageno);
    if(!page) {
        return false;
    }
    CString image;
    if(page->GetImage(image) != STATUS_OK) {
        DEBUGL1("Page::GetImage() is failed\n");
        return false;
    }
    DEBUGL6("Image - %s\n", image.c_str());
    return true;
}

bool test_GetSubsampling(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname, int pageno) {
    PageRef page = GetPage(boxbasepath, boxnumber, foldername, documentname, pageno);
    if(!page) {
        return false;
    }
    CString image;
    if(page->GetSubsamplingImage(image) != STATUS_OK) {
        DEBUGL1("Page::GetISubsamplingmage() is failed\n");
        return false;
    }
    DEBUGL6("Image - %s\n", image.c_str());
    return true;
}

bool test_GetThumbnail(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname, int pageno) {
    PageRef page = GetPage(boxbasepath, boxnumber, foldername, documentname, pageno);
    if(!page) {
        return false;
    }
    CString image;
    if(page->GetThumbnailImage(image) != STATUS_OK) {
        DEBUGL1("Page::GetISubsamplingmage() is failed\n");
        return false;
    }
    DEBUGL6("Image - %s\n", image.c_str());
    return true;
}

bool test_GetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname, int pageno) {
    PageRef page = GetPage(boxbasepath, boxnumber, foldername, documentname, pageno);
    if(!page) {
        return false;
    }
    CString key, value;
    char* keylist[7] = {"jobType", "horizontalResolution", "verticalResolution", "imageWidth", "imageHeight", "paperSize", "fileSize"};
    for(int i = 0; i < 7; i++) {
        key = keylist[i];
        page->GetWebDAVProperty(key, value);
        DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    }
    return true;
}

bool test_SetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername, CString documentname, int pageno) {
    PageRef page = GetPage(boxbasepath, boxnumber, foldername, documentname, pageno);
    if(!page) {
        return false;
    }
    CString key, value;
    cout << "Enter Document property (KEY)" << endl;
    cin >> key;
    cout << "Enter Document property (VALUE)" << endl;
    cin >> value;
    if(page->SetWebDAVProperty(key, value) != STATUS_OK) {
        DEBUGL1("Page::SetWebDAVProperty() is failed\n");
        return false;
    }
    return true;
}

bool test_page(CString boxbasepath, CString boxnumber, CString foldername, CString documentname, int pageno) {
    bool result;
    while(1) {
        int i = 0;
        cout << "Page: /" << boxbasepath << "/" << boxnumber << "/";
        if(foldername != "") {
            cout << foldername << "/";
        }
        cout << documentname << " Page:" << pageno << endl;
        cout << "1. Get Image Path" << endl;
        cout << "2. Get Subsampling Image Path" << endl;
        cout << "3. Get Thumbnail Image Path" << endl;
        cout << "4. Get WebDAV property" << endl;
        cout << "5. Set WebDAV property" << endl;
        cout << "0. exit" << endl;
        cin >> i;
        result = false;
        switch(i) {
        case 0: return true;
        case 1: result = test_GetImage(boxbasepath, boxnumber, foldername, documentname, pageno); break;
        case 2: result = test_GetSubsampling(boxbasepath, boxnumber, foldername, documentname, pageno); break;
        case 3: result = test_GetThumbnail(boxbasepath, boxnumber, foldername, documentname, pageno); break;
        case 4: result = test_GetWebDAVProperty(boxbasepath, boxnumber, foldername, documentname, pageno); break;
        case 5: result = test_SetWebDAVProperty(boxbasepath, boxnumber, foldername, documentname, pageno); break;
        } 
        cout << "result = " << result << endl;
    }
    return true;
}
