#include <iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>
#include "systemdatafile.h"
#include <CI/IndexedDB/Mash/include/comPar.h>
//#include  <DL/include/imStr.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

#define COPY_JPEG 0
//-----------------------------------------------------------------------------
// test case of inBox
// SL side
bool test_inbox_SL(CString BoxBasePath, 
                   CString BoxNumber, 
                   CString FolderName, 
                   CString &DocumentName)
{
    // SL knowledge
    dom::NodeRef WEP;
    
    //Create a HierarchicalDBRef object
    ci::hierarchicaldb::HierarchicalDBRef phdb = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
    //Have a string for the Documet name.
    CString sDoc = "tempdoc1";
    dom::DocumentRef pDoc;
    FILE* fd = fopen("/home/SYSROM_SRC/bin/Resource/options.xml", "r");
    if (fd) {
        struct stat statBuf; 
        stat("/home/SYSROM_SRC/bin/Resource/options.xml", &statBuf); 
        char* sz = new char[statBuf.st_size + 1];
        if (sz != NULL) {
            //reading and writing the XML file contents into the Buffer
            memset(sz, '\0', statBuf.st_size + 1); 
            fread(sz, statBuf.st_size, 1, fd); 
            fclose(fd);
            //Create a memory based DOM tree
            Status ret = phdb->CreateTempDocument(sDoc, pDoc ,sz);
            delete[] sz;
            if(ret != STATUS_OK) {
                DEBUGL1("\n Creating the Document with the document name <%s> FAILED",sDoc.c_str());
                return false;
            } else {
                DEBUGL4("\n create temp document suceeded\n");
            }
        }
    } else {
        DEBUGL1("\n Opeing the XML file failed");
        return false;
    }
    WEP = pDoc->getDocumentElement();
    
    // 6.1: Acquire the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	BoxRef box;
	if(boxdoc->GetBox(box,BoxBasePath,BoxNumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

    ci::boxdocument::DocumentRef doc;
	if(!FolderName.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,FolderName)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc, DocumentName) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc, DocumentName) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}
	
    // 6.3: Put WEP DOM object
    if(doc->SetWEPDocument(WEP) != STATUS_OK) {
        DEBUGL1("Document::SetWEPDocument() is failed\n");
        return false;
    }
    

    // 6.4: Complete to create the document
    if(doc->EndCreating() != STATUS_OK) {
        DEBUGL1("Document::EndCreating() is failed\n");
        return false;
    }

    return true;
}

bool test_inbox_SL_ByLink(CString BoxBasePath, 
                   CString BoxNumber, 
                   CString FolderName, 
                   CString &DocumentName)
{
    // SL knowledge
    dom::NodeRef WEP;
    
    //Create a HierarchicalDBRef object
    ci::hierarchicaldb::HierarchicalDBRef phdb = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
    //Have a string for the Documet name.
    CString sDoc = "tempdoc1";
    dom::DocumentRef pDoc;
    FILE* fd = fopen("/storage/box/Resource/options.xml", "r");
    if (fd) {
        struct stat statBuf; 
        stat("/storage/box/Resource/options.xml", &statBuf); 
        char* sz = new char[statBuf.st_size + 1];
        if (sz != NULL) {
            //reading and writing the XML file contents into the Buffer
            memset(sz, '\0', statBuf.st_size + 1); 
            fread(sz, statBuf.st_size, 1, fd); 
            fclose(fd);
            //Create a memory based DOM tree
            Status ret = phdb->CreateTempDocument(sDoc, pDoc ,sz);
            delete[] sz;
            if(ret != STATUS_OK) {
                DEBUGL1("\n Creating the Document with the document name <%s> FAILED",sDoc.c_str());
                return false;
            } else {
                DEBUGL4("\n create temp document suceeded\n");
            }
        }
    } else {
        DEBUGL1("\n Opeing the XML file failed");
        return false;
    }
    WEP = pDoc->getDocumentElement();
    
    // 6.1: Acquire the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	BoxRef box;
	if(boxdoc->GetBox(box,BoxBasePath,BoxNumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

    ci::boxdocument::DocumentRef doc;
	if(!FolderName.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,FolderName)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc, DocumentName) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc, DocumentName) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}
	
    // 6.3: Put WEP DOM object
    if(doc->SetWEPDocument(WEP) != STATUS_OK) {
        DEBUGL1("Document::SetWEPDocument() is failed\n");
        return false;
    }
    

    // 6.4: Complete to create the document
    if(doc->EndCreating() != STATUS_OK) {
        DEBUGL1("Document::EndCreating() is failed\n");
        return false;
    }
	

	
    return true;
}

// DL side
bool test_inbox_DL(CString BoxBasePath, 
                   CString BoxNumber, 
                   CString FolderName, 
                   CString &DocumentName) 
{
    // DL knowledge
    const int total = 3;
    CString image[] = {"/home/SYSROM_SRC/build/release/bin/Resource/image1.mmr", "/home/SYSROM_SRC/build/release/bin/Resource/image2.mmr", "/home/SYSROM_SRC/build/release/bin/Resource/image3.mmr"};
    CString subsampling[] = {"/home/SYSROM_SRC/build/release/bin/Resource/s_image1.mmr", "/home/SYSROM_SRC/build/release/bin/Resource/s_image2.mmr", "/home/SYSROM_SRC/build/release/bin/Resource/s_image3.mmr"};
    CString thumbnail[] = {"/home/SYSROM_SRC/build/release/bin/Resource/t_image1.png", "/home/SYSROM_SRC/build/release/bin/Resource/t_image2.png", "/home/SYSROM_SRC/build/release/bin/Resource/t_image3.png"};
    CString jobtype = "Scan";
    CString systemfilepath = "/home/SYSROM_SRC/build/release/bin/Resource/ummySystemDataFile_Image.000";
	 CString thumbnailsystemfilepath	 = "/home/SYSROM_SRC/build/release/bin/Resource/dummySystemDataFile_Thumb.000";
    FL_FILE_MAN_FILE systemfile,thumbnailsystemfile;
    CString docname;
    
    // ---- test start ----
    BoxDocumentRef boxdoc;
	BoxRef box;
	FolderRef folder;
    DocumentRef doc;
    
    // 3. get the instance of BoxDocument
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	if(!boxdoc->BoxExist(BoxBasePath,BoxNumber))
	{
	    CString boxpassword;
	    cout<<"\nEnter the box password:\nEnter 'n' for no password\n";
	    cin>>boxpassword;
	    if(boxpassword=="N")
			boxpassword="";
		 
		if(boxdoc->CreateBox(box,BoxBasePath,BoxNumber,boxpassword)!=STATUS_OK)
		{
			DEBUGL1("BoxDocument::CreateBox() failed\n");
			return false;
		}
	}
	else
	{
		if(boxdoc->GetBox(box,BoxBasePath,BoxNumber)!=STATUS_OK)
		{
			DEBUGL1("BoxDocument::GetBox() failed\n");
			return false;
		}
	}
	
	if(!FolderName.empty())
	{	
		if(!box->FolderExist(FolderName))
		{
			if(box->CreateFolder(folder,FolderName)!=STATUS_OK)
			{
				DEBUGL1("Box::CreateFolder() failed\n");
				return false;
			}			
		}
		else
		{
			if(box->GetFolder(folder,FolderName)!=STATUS_OK)
			{
				DEBUGL1("Box::GetFolder() failed\n");
				return false;
			}
		}
	
	    // 3.1: Create New Document in folder
	    if(folder->CreateDocument(doc,DocumentName) != STATUS_OK) {
	        DEBUGL1("Folder::CreateDocument() is failed\n");
	        return false;	
	    }				  
	}
	else
	{
	    // 3.1: Create New Document in box
	    if(box->CreateDocument(doc,DocumentName) != STATUS_OK) {
	        DEBUGL1("Box::CreateDocument() is failed\n");
	        return false;	
	    }				  		
	}
		 
    DEBUGL8("created DocumentName : %s\n", DocumentName.c_str());
    
    PageRef page;
    for(int i = 0; i < total; i++) {
        
        // 4: get the instance of new page
        if(doc->CreatePage(page) != STATUS_OK) {
            DEBUGL1("Document::CreatePage() is failed\n");
            return false;
        }
        
        // 4.1: Put Page Image
        if(page->PutImage(image[i]) != STATUS_OK) {
            DEBUGL1("Page::PutImage(%s) is failed\n", image[i].c_str());
            return false;
        }
//        if(page->PutSubsamplingImage(subsampling[i]) != STATUS_OK) {
//            DEBUGL1("Page::PutSubsamplingImage(%s) is failed\n", subsampling[i].c_str());
//            return false;
//        }
        if(page->PutThumbnailImage(thumbnail[i]) != STATUS_OK) {
            DEBUGL1("Page::PutThumbnailImage(%s) is failed\n", thumbnail[i].c_str());
            return false;
        }
        
        // 4.2: Put Page Properties (WebDAV Property)
        if(page->SetWebDAVProperty("jobType", jobtype) != STATUS_OK) {
            DEBUGL1("Page::SetWebDAVProperty is failed\n");
            return false;
        }
        if(page->SetWebDAVProperty("colorMode", "Color") != STATUS_OK) { 
            DEBUGL1("Page::SetWebDAVProperty is failed\n"); 
            return false; 
        }
	// 4.2.1
#if 0
        IM_EX_0615_OUT param;
        unsigned short aa =1;
        param.regXSIZE[1] = aa;
        if(page->SetCopyJpegParameter(&param)!=STATUS_OK)
        {
            DEBUGL1("Page::SetCopyJpegParameter failed\n");
            return false;
        }
#endif

        // 4.4: Register System File Properties (On memory) for preview
        // Open SystemFile
        FILE* inputFP;
        inputFP = fopen(systemfilepath.c_str(), "rb");
        if(inputFP == NULL) {
            DEBUGL1("    Error: Could not open the input file\n");
            exit(0);
        };
        
        if(fread(&systemfile, sizeof(FL_FILE_MAN_FILE), 1, inputFP) != 1) {
            printf("    Error: Could not load data.\n");
            fclose(inputFP);
            exit(1);
        }
        fclose(inputFP);

        // 4.4: Register System File Properties (On memory) for preview
        // Open SystemFile
        inputFP = fopen(thumbnailsystemfilepath.c_str(), "rb");
        if(inputFP == NULL) {
            DEBUGL1("    Error: Could not open the input file\n");
            exit(0);
        };
        
        if(fread(&thumbnailsystemfile, sizeof(FL_FILE_MAN_FILE), 1, inputFP) != 1) {
            printf("    Error: Could not load data.\n");
            fclose(inputFP);
            exit(1);
        }
        fclose(inputFP);

        if(page->SetSystemFile(&systemfile.sPageManTbl[i]) != STATUS_OK) {
            DEBUGL1("Page::SetSystemFile is failed\n");
            return false;
        }
        if(page->SetThumbnailSystemFile(&thumbnailsystemfile.sPageManTbl[i]) != STATUS_OK) {
            DEBUGL1("Page::SetSystemFile is failed\n");
            return false;
        }

        // 4.3: add page to Document as last page
        if(doc->AppendPage(page) != STATUS_OK) {
            DEBUGL1("Document::Appendpage is failed\n");
            return false;
        }
        
        //doc->SetWebDAVPropertyFromSystemFile(&systemfile);
    }
#if 0	 
    // 5:  Put System File
    if(doc->PutSystemFile(systemfilepath) != STATUS_OK) {
        DEBUGL1("Document::PutSystemFile() is failed\n");
        return false;
    }
    
    if(doc->PutThumbnailSystemFile(systemfilepath) != STATUS_OK) {
        DEBUGL1("Document::PutThumbnailSystemFile() is failed\n");
        return false;
    }
#endif	 
    // 5.1 : Put Document Property
    doc->SetWebDAVProperty("documentName", DocumentName);
    doc->SetWebDAVProperty("jobType", jobtype);
    
    return true;
}
bool test_inbox_DL_ByLink(CString BoxBasePath, 
                   CString BoxNumber, 
                   CString FolderName, 
                   CString &DocumentName) 
{
    CString systemfilepath = "/storage/box/Resource/dummySystemDataFile_Image.000";
	 CString thumbnailsystemfilepath	 = "/storage/box/Resource/dummySystemDataFile_Thumb.000";
	 
    FL_FILE_MAN_FILE systemfile,thumbnailsystemfile;

    // DL knowledge
    const int total = 5;
    CString image[] = {"/storage/box/Resource/image1.mmr", "/storage/box/Resource/image2.mmr", "/storage/box/Resource/image3.mmr", "/storage/box/Resource/image4.mmr","/storage/box/Resource/image5.mmr"};
    CString subsampling[] = {"/storage/box/Resource/s_image1.mmr", "/storage/box/Resource/s_image2.mmr", "/storage/box/Resource/s_image3.mmr"};
    CString thumbnail[] = {"/storage/box/Resource/t_image1.png", "/storage/box/Resource/t_image2.png", "/storage/box/Resource/t_image3.png", "/storage/box/Resource/t_image4.png","/storage/box/Resource/t_image5.png"};
    CString jobtype = "Scan";
    CString docname;
    
    // ---- test start ----
    BoxDocumentRef boxdoc;
	BoxRef box;
	FolderRef folder;
    DocumentRef doc;
    
    // 3. get the instance of BoxDocument
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	if(!boxdoc->BoxExist(BoxBasePath,BoxNumber))
	{
	    CString boxpassword;
	    cout<<"\nEnter the box password:\nEnter 'n' for no password\n";
	    cin>>boxpassword;
	    if(boxpassword=="N")
			boxpassword="";
		 
		if(boxdoc->CreateBox(box,BoxBasePath,BoxNumber,boxpassword)!=STATUS_OK)
		{
			DEBUGL1("BoxDocument::CreateBox() failed\n");
			return false;
		}
	}
	else
	{
		if(boxdoc->GetBox(box,BoxBasePath,BoxNumber)!=STATUS_OK)
		{
			DEBUGL1("BoxDocument::GetBox() failed\n");
			return false;
		}
	}
	
	if(!FolderName.empty())
	{	
		if(!box->FolderExist(FolderName))
		{
			if(box->CreateFolder(folder,FolderName)!=STATUS_OK)
			{
				DEBUGL1("Box::CreateFolder() failed\n");
				return false;
			}			
		}
		else
		{
			if(box->GetFolder(folder,FolderName)!=STATUS_OK)
			{
				DEBUGL1("Box::GetFolder() failed\n");
				return false;
			}
		}
	
	    // 3.1: Create New Document in folder
	    if(folder->CreateDocument(doc,DocumentName) != STATUS_OK) {
	        DEBUGL1("Folder::CreateDocument() is failed\n");
	        return false;	
	    }				  
	}
	else
	{
	    // 3.1: Create New Document in box
	    if(box->CreateDocument(doc,DocumentName) != STATUS_OK) {
	        DEBUGL1("Box::CreateDocument() is failed\n");
	        return false;	
	    }				  		
	}
		 
    DEBUGL8("created DocumentName : %s\n", DocumentName.c_str());
    
    PageRef page;
	for(int i = 0; i < total; i++) {
	        
	        // 4: get the instance of new page
	        if(doc->CreatePage(page) != STATUS_OK) {
	            DEBUGL1("Document::CreatePage() is failed\n");
	            return false;
	        }
	        
	        // 4.1: Put Page Image
	        if(page->PutImage(image[i]) != STATUS_OK) {
	            DEBUGL1("Page::PutImage(%s) is failed\n", image[i].c_str());
	            return false;
	        }
	//        if(page->PutSubsamplingImage(subsampling[i]) != STATUS_OK) {
	//            DEBUGL1("Page::PutSubsamplingImage(%s) is failed\n", subsampling[i].c_str());
	//            return false;
	//        }
	        if(page->PutThumbnailImage(thumbnail[i]) != STATUS_OK) {
	            DEBUGL1("Page::PutThumbnailImage(%s) is failed\n", thumbnail[i].c_str());
	            return false;
	        }
	        
	        // 4.2: Put Page Properties (WebDAV Property)
	        if(page->SetWebDAVProperty("jobType", jobtype) != STATUS_OK) {
	            DEBUGL1("Page::SetWebDAVProperty is failed\n");
	            return false;
	        }
	        if(page->SetWebDAVProperty("colorMode", "Color") != STATUS_OK) { 
	            DEBUGL1("Page::SetWebDAVProperty is failed\n"); 
	            return false; 
	        }
		// 4.2.1
#if 0
	        IM_EX_0615_OUT param;
	        unsigned short aa =1;
	        param.regXSIZE[1] = aa;
	        if(page->SetCopyJpegParameter(&param)!=STATUS_OK)
	        {
	            DEBUGL1("Page::SetCopyJpegParameter failed\n");
	            return false;
	        }
#endif

	        // 4.4: Register System File Properties (On memory) for preview
	        // Open SystemFile
	        FILE* inputFP;
	        inputFP = fopen(systemfilepath.c_str(), "rb");
	        if(inputFP == NULL) {
	            DEBUGL1("    Error: Could not open the input file\n");
	            exit(0);
	        };
	        
	        if(fread(&systemfile, sizeof(FL_FILE_MAN_FILE), 1, inputFP) != 1) {
	            printf("    Error: Could not load data.\n");
	            fclose(inputFP);
	            exit(1);
	        }
	        fclose(inputFP);

	        // 4.4: Register System File Properties (On memory) for preview
	        // Open SystemFile
	        inputFP = fopen(thumbnailsystemfilepath.c_str(), "rb");
	        if(inputFP == NULL) {
	            DEBUGL1("    Error: Could not open the input file\n");
	            exit(0);
	        };
	        
	        if(fread(&thumbnailsystemfile, sizeof(FL_FILE_MAN_FILE), 1, inputFP) != 1) {
	            printf("    Error: Could not load data.\n");
	            fclose(inputFP);
	            exit(1);
	        }
	        fclose(inputFP);

	        if(page->SetSystemFile(&systemfile.sPageManTbl[i]) != STATUS_OK) {
	            DEBUGL1("Page::SetSystemFile is failed\n");
	            return false;
	        }
	        if(page->SetThumbnailSystemFile(&thumbnailsystemfile.sPageManTbl[i]) != STATUS_OK) {
	            DEBUGL1("Page::SetSystemFile is failed\n");
	            return false;
	        }
			
		if(i < 3) {
		        // 4.3: add page to Document as last page
		        if(doc->AppendPageByLink(page) != STATUS_OK) {
		            DEBUGL1("Document::Appendpage is failed\n");
		            return false;
		        }
		}
		if(i > 2)
		{
			char option,option1;
			cout << "Do you want to test insertpage and replace page by link (y/n): " << endl;
			cin >> option;		
			if(option == 'y'){
				cout << "Insert/Replace (i/r): ";
				cin >> option1;
				if(option1 == 'i' && i == 3){
				        if(doc->InsertPageByLink(3, page) != STATUS_OK) {
				            DEBUGL1("Document::Insertpage by link is failed\n");
				            return false;
				       }
				}
				else if(option1 == 'r' && i == 3) {
			        	if(doc->ReplacePageByLink(3, page) != STATUS_OK) {
				            DEBUGL1("Document::Replace page by link is failed\n");
				            return false;
		       		}
				}
				 else 
				 	break;			 
			}
		}
	}
        //doc->SetWebDAVPropertyFromSystemFile(&systemfile);
    doc->SetWebDAVProperty("documentName", DocumentName);
    doc->SetWebDAVProperty("jobType", "Scan");
	
    return true;
}


bool test_Init()
{
    // get the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) 
    {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    if((boxdoc->Initialize())!=STATUS_OK)
    {
	DEBUGL1("BoxDocument:: Initialize() failed ");
	return false;
    }	
    DEBUGL6("\nInitialize succesfull");

	int i;
	scanf("%d",&i);	 
    if((boxdoc->Cleanup())!=STATUS_OK)
    {
	DEBUGL1("BoxDocument:: Cleanup() failed ");
	return false;
    }	
    DEBUGL6("\nCleanup succesfull");
    return true;
}

bool test_inbox() {
    CString option;
    cout<<"\nEnter the option:\n1.Initialize and CleanUp\n2.Box Sequence\n";
    cin>>option;
    if(option=="1")
    	return test_Init();
    else 
    {	 	
	    CString BoxBasePath = "EFilingBoxes";
	    CString BoxNumber = "00023";;
	    cout << "Enter BoxNumber" << endl;
	    cin >> BoxNumber;
	    CString FolderName = "";
	    cout << "Enter FolderName - 'n' for empty foldername" << endl;
	    cin >> FolderName;
	    if(FolderName == "n")
	       FolderName = "";
	    CString DocumentName = "00000";
	    cout << "Enter DocumentName" << endl;
	    cin >> DocumentName;

	    return test_inbox_DL(BoxBasePath, BoxNumber, FolderName, DocumentName) &&
		           test_inbox_SL(BoxBasePath, BoxNumber, FolderName, DocumentName);
	}
}
bool test_inboxByLink() {
    CString option;
    cout<<"\nEnter the option:\n1.Initialize and CleanUp\n2.Box Sequence\n";
    cin>>option;
    if(option=="1")
    	return test_Init();
    else 
    {	 	
	    CString BoxBasePath = "EFilingBoxes";
	    CString BoxNumber = "00023";;
	    cout << "Enter BoxNumber" << endl;
	    cin >> BoxNumber;
	    CString FolderName = "";
	    cout << "Enter FolderName - 'n' for empty foldername" << endl;
	    cin >> FolderName;
	    if(FolderName == "n")
	       FolderName = "";
	    CString DocumentName = "00000";
	    cout << "Enter DocumentName" << endl;
	    cin >> DocumentName;

	    return test_inbox_DL_ByLink(BoxBasePath, BoxNumber, FolderName, DocumentName) &&
		           test_inbox_SL_ByLink(BoxBasePath, BoxNumber, FolderName, DocumentName);
	}
}

