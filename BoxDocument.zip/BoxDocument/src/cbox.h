/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cbox.h
Revision: com_t#4
File Spec: EBX:MA6031.A-DEV_SRC;com_t#4
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:28:40

Outline : 

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
1:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
Creation Date: 13-JAN-2009 19:36:02
Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA

2:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
Creation Date: 13-JAN-2009 18:00:09
Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA

3:
Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
Creation Date: 13-JAN-2009 15:14:46
Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA

------------------------------------------------------------------------------
History:
 * Revision com_t#4 (APPROVED)
 *   Created:  09-JAN-2009 21:28:41      CHANDRAMOHAN.PUJARI
 *     Added CreateArchive and Extract functions
 *   Updated:  09-JAN-2009 21:28:41      CHANDRAMOHAN.PUJARI
 *     Added CreateArchive and Extract functions
 *   Updated:  09-JAN-2009 21:28:41      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#4 created from revision com_t#3 with status
 *     $TO_BE_DEFINED
 *   Updated:  09-JAN-2009 21:28:41      CHANDRAMOHAN.PUJARI
 *     Added CreateArchive and Extract functions
 * 
 * Revision com_t#3 (APPROVED)
 *   Updated:  19-DEC-2008 22:14:45      CHANDRAMOHAN.PUJARI
 *     code indentation done
 *   Created:  19-DEC-2008 22:14:44      CHANDRAMOHAN.PUJARI
 *     code indentation done
 *   Updated:  19-DEC-2008 22:14:44      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#3 created from revision com_t#2 with status
 *     $TO_BE_DEFINED
 *   Updated:  19-DEC-2008 22:14:44      CHANDRAMOHAN.PUJARI
 *     code indentation done
 * 
 * Revision com_t#2 (APPROVED)
 *   Updated:  08-DEC-2008 20:18:42      CHANDRAMOHAN.PUJARI
 *     Added private data member and header files for Box Usage and
 *     Last Access and Modified dates
 *   Created:  08-DEC-2008 20:18:41      CHANDRAMOHAN.PUJARI
 *     Added private data member and header files for Box Usage and
 *     Last Access and Modified dates
 *   Updated:  08-DEC-2008 20:18:41      CHANDRAMOHAN.PUJARI
 *     Added private data member and header files for Box Usage and
 *     Last Access and Modified dates
 *   Updated:  08-DEC-2008 20:18:41      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#2 created from revision com_t#1 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#1 (APPROVED)
 *   Created:  17-NOV-2008 21:47:16      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s in Box class
 *   Updated:  17-NOV-2008 21:47:16      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s in Box class
 *   Updated:  17-NOV-2008 21:47:16      CHANDRAMOHAN.PUJARI
 *     Added derived functions for New Interface API s in Box class
 *   Updated:  17-NOV-2008 21:47:16      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#1 created from revision com_m#1.2 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.2 (APPROVED)
 *   Updated:  01-SEP-2008 17:15:57      13848
*     Updated attribute(s)
   *   Created:  01-SEP-2008 17:14:33      13848
   *     Update for Ph3.5 1st build
   *   Updated:  01-SEP-2008 17:13:12      13848
   *     Item revision com_m#1.2 created from revision com_m#1.1 with
   *     status $TO_BE_DEFINED
   * 
* Revision com_m#1.1 (UNIT TESTED)
   *   Updated:  01-SEP-2008 16:51:15      13848
*     Updated attribute(s)
   *   Created:  25-AUG-2008 20:11:35      13848
   *     BoxDocument 2nd release
   *   Updated:  25-AUG-2008 20:06:58      13848
   *     Item revision com_m#1.1 created from revision com_m#1 with
   *     status $TO_BE_DEFINED
   * 
* Revision com_m#1 (UNDER WORK)
   *   Created:  19-AUG-2008 14:33:17      13848
   *     Initial revision
   ========================== End of Source Header =============================*/

#ifndef __CI_CBOX_H__
#define __CI_CBOX_H__

#include <map>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/bytestream.h>
#include <CI/SystemInformation/systeminformation.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/box.h>

   namespace ci {
      namespace boxdocument {

         using namespace operatingenvironment;
         const CString WEP_FILENAME = "wep.xml";
#define PROGRESS_COMPLETED 100

         class CBox : public Box
         {
            private:
               ci::hierarchicaldb::HierarchicalDBRef m_pHDB;
               CString m_BoxBasePath;
               CString m_BoxNumber;
               std::map<CString, CString> m_WebDAVProperties;
               CString m_BoxName;

               Ref<Thread> m_ThreadID;
               static std::vector<CString> m_CutVecofDocs;
               CString m_CutProgShmName;
               CString m_CutErrfile;

               static std::vector<CString> m_CopyVecofDocs;
               CString m_CopyProgShmName;
               CString m_CopyErrfile;

               CString m_PasteProgShmName;
               CString m_PasteErrfile;
               //to hold the status of documents in a folder
               bool m_isIterFolder;

               static CString m_DelDoc;
               CString m_DelDocProgShmName;
               CString m_DeleteDocErrfile;
               Ref<CProgress> m_cprogress;
               CString m_sessionID;

               Status SetProperty(CString key, CString value);

               Status GetProperty(CString key, CString &value);
               //Shared memory ref to handle the shm for cut,copy,paste,etc., progress
               Ref<SharedMemory> m_prgShmid; 

	       static std::vector<CString> m_PastedVecofDocs;
	       bool m_returnpastedocname;
            public:
                /**
                * constructor
                */
               CBox(CString sessionID, CString boxbasepath,CString boxnumber);

               // destructor
               virtual ~CBox();

               /**
                * get document instance in the container.
                * @param[out] doc - instance of Document class
                * @param[in] documentname - serial number from "00000".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetDocument(DocumentRef &doc, CString documentname);

               /**
                * get a list of document
                * @param[out] list - list of documents. 
                *                     This list have snapshot of each documents instances.
                *                     the snapshot is independent from original documents
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetDocumentList(DocumentList &list);

               /**
                * get a list of document
                * @param[out] list - list of documents. 
                *                     This list have snapshot of each documents instances.
                *                     the snapshot is independent from original documents
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @param[in] from - return list from this value.
                * @param[in] size - list size, if "from" + "size" is bigger than the 
                *                    number of all documents, return list size will be 
                *                    smaller than "size".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetDocumentList(DocumentList &list,unsigned int from, unsigned int size);
               /**
                * get a list of document. Using these document objects user can access the following
                * document properties.
                * documentName
                * jobType
                * totalPages
                * creationDate
                * lastModifiedDate
                * Size
                * thumbnail
                * cutDocument
                * document status
                * jobTypeColorMap
                * paperSizeMap
                *
                * @param[out] list - list of documents.
                *                     This list have snapshot of each documents instances.
                *                     the snapshot is independent from original documents
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetViewDocumentList(DocumentList &list);

               /**
                * get a list of document. Using these document objects user can access the following
                * document properties.
                * documentName
                * jobType
                * totalPages
                * creationDate
                * lastModifiedDate
                * Size
                * thumbnail
                * cutDocument
                * document status
                * jobTypeColorMap
                * paperSizeMap
                * @param[out] list - list of documents.
                *                     This list have snapshot of each documents instances.
                *                     the snapshot is independent from original documents
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @param[in] from - return list from this value.
                * @param[in] size - list size, if "from" + "size" is bigger than the
                *                    number of all documents, return list size will be
                *                    smaller than "size".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetViewDocumentList(DocumentList &list,unsigned int from, unsigned int size);

               /**
                * Get a list of document. This returns the CViewDocument class object to the user.
                * Using this documentRef, user can access only name of the document.
                * @param[out] list - list of documents.
                * This list have snapshot of each documents instances.
                * @return STATUS_OK on success,
                * STATUS_FAILED on failure.
                **/
               Status GetDocumentListToDelete(DocumentList &list);
               /**
                * create new folder
                * if Folder object call this function, it will fail.
                * @param[in] foldername - new folder name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if total files reached MAx number.         
                *         STATUS_RESOURCE_WITH_SAME_NAME_EXISTS if the resource already exists
                */
               Status CreateFolder(CString foldername);

               /**
                * create new folder
                * if Folder object call this function, it will fail.
                * @param[out] folder - instance of Folder class     
                * @param[in] foldername - new folder name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if total files reached MAx number.          
                *         STATUS_RESOURCE_WITH_SAME_NAME_EXISTS if the resource already exists
                */
               Status CreateFolder(FolderRef& folder, CString foldername);

               /**
                * get folder instance by folder name
                * @param[out] folder - reference to folder instance
                * @param[in] foldername - target folder name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetFolder(FolderRef& folder, CString foldername);

               /**
                * get a list of folder
                * @param[out] list - list of folders. 
                *                     this list have snapshot of each folder instances.
                *                     the snapshot is independent from original folders.
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetFolderList(FolderList &list);

               /**
                * get a list of folder
                * @param[out] list - list of folders. 
                *                     this list have snapshot of each folder instances.
                *                     the snapshot is independent from original folders.
                *                     it means you can read properties only through the
                *                     snapshot. if you call other methods to the snapshot,
                *                     it will fail.
                * @param[in] from - return list from this value.
                * @param[in] size - list size, if "from" + "size" is bigger than the 
                *                    number of all lists, return list size will be smaller
                *                    than "size".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetFolderList(FolderList &list,unsigned int from, unsigned int size);

               /**
                * delete the folder
                * if documents in the box is using, it will fail(some documents are 
                *  deleted).
                * @param[in] foldername - target folder name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status DeleteFolder(CString foldername);

               /**
                * set box property
                * @param[in] key - the property name to be set
                * @param[in] value - the property value to be set
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status SetWebDAVProperty(CString key, CString value);

               /**
                * get box/folder property
                * @param[in] key - the property name to be set
                * @param[out] value - the property value
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetWebDAVProperty(CString key, CString &value);

               /**
                * set a name of the container
                * @param[in] name - a name to be set
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_RESOURCE_WITH_SAME_NAME_EXISTS if the resource already exists
                */
               Status SetName(CString name);

               /**
                * get a name of the container
                * @param[out] name - a name of the container
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetName(CString &name);

               /**
                * get a number of the box
                * @param[out] number - a number of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetNumber(CString &number);

               /**
                * cut the documents to clipboard
                * if document status is NOT READY, it will fail.
                * @param[in] docname - source document name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *	     STATUS_DISK_FULL if enough storage space is not available.
                */
               Status CutDocument(CString docname);

               /**
                * cut the documents to clipboard
                * if document status is NOT READY, it will fail.
                * @param[in] documents - source document names
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *	     STATUS_DISK_FULL if enough storage space is not available.	 
                */
               Status CutDocument(std::vector<CString> documents);

               /**
                * copy the documents to clipboard
                * if document status is NOT READY or USING 
                *    or RESERVING or EDITING, it will fail.
                * @param[in] docname - source document name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *	     STATUS_DISK_FULL if enough storage space is not available.
                */
               Status CopyDocument(CString docname);

               /**
                * copy the documents to clipboard
                * if document status is NOT READY or USING 
                *    or RESERVING or EDITING, it will fail.
                * @param[in] documents - source document names
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *	     STATUS_DISK_FULL if enough storage space is not available.
                */
               Status CopyDocument(std::vector<CString> documents);

               /**
                * paste the document from clipboard
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the partition. 
                */
               Status PasteDocument();

               // CBox methods

               /**
                * load properties from WebDAV
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status LoadProperties();

               /**
                * load properties from WebDAV
                * @param[in] WebDAVpropertyMap - webDAV property map				 
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status LoadProperties(std::map<CString, CString> WebDAVpropertyMap);


               /**
                * save properties to WebDAV
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status SaveProperties();

               /**
                * get size of the containers
                * It includes the size of all files that compose Document.
                * @param[out] total - total size (byte) of the container
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *	     STATUS_DISK_FULL if enough storage space is not available.
                **/
               Status GetSize(uint64 &size);


               /**
                * set HDB Document of Workflow Execution Parameter to Box. 
                * @param[in] node - WEP node to save
                * @return STATUS_OK on success,
                * STATUS_FAILED on failure,
                * STATUS_DISK_FULL if there is not enough space on the disk.
                **/
               Status SetWEPDocument(dom::NodeRef node);

               /**
                * get WEP document ID
                * BoxDocument create HDB document and return document ID.
                * @param[out] documentID - HDB document ID
                * @return STATUS_OK on success,
                * STATUS_FAILED on failure,
                * STATUS_DISK_FULL if there is not enough space on the disk.
                * @note user need to delete this document using document ID.
                **/
               Status GetWEPDocument(CString& documentID);

               /**
                * create archive
                * @param[out] archiver - created Archiver object.
                * @param[in] target - archive file path / file name
                * @param[in] documentname - document name to be archived
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, CString documentname);

               /**
                * create archive
                * @param[out] archiver - created Archiver object.
                * @param[in] target - archive file path / file name
                * @param[in] documentlist - list of document name to be archived
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, std::vector<CString> documentlist);

               /**
                * extract archive
                * @param[out] extractor - created Extractor object
                * @param[in] archiverpath - path of the archive to be extracted
                * @param[in] extractorpath - path to which the archived files needs to extracted
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status ExtractArchive(operatingenvironment::Ref<Extractor> &extractor,CString archiverpath,CString extractorpath);

               /**
                * Delete Archive 
                * @param[in] archivepath - path of the archive file that needs to be deleted
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                */
               Status DeleteArchive(CString archivepath);

               /**
                * cut the documents to clipboard
                * if document status is NOT READY, it will fail.
                * @param[out] progress - user can get operation progress from this.
                * @param[in] docname - source document name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CutDocument(ProgressRef& progress, CString docname);

               /**
                * cut the documents to clipboard
                * if document status is NOT READY, it will fail.
                * @param[out] progress - user can get operation progress from this.
                * @param[in] documents - source document names
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CutDocument(ProgressRef& progress,std::vector<CString> documents);

               /**
                * copy the documents to clipboard
                * if document status is NOT READY or USING 
                *    or RESERVING or EDITING, it will fail.
                * @param[out] progress - user can get operation progress from this.
                * @param[in] docname - source document name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CopyDocument(ProgressRef& progress, CString docname);

               /**
                * copy the documents to clipboard
                * if document status is NOT READY or USING 
                *    or RESERVING or EDITING, it will fail.
                * @param[out] progress - user can get operation progress from this.
                * @param[in] documents - source document names
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status CopyDocument(ProgressRef& progress,std::vector<CString> documents);

               /**
                * paste the document from clipboard
                * @param[out] progress - user can get operation progress from this.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                */
               Status PasteDocument(ProgressRef& progress);

	       // Support for EBX_RCR_235 : Start
	       /**
		* paste the document from clipboard to the Box or to the folder present under the Box	
		* @param[out] documentnames - names of the documents that's been pasted
		* @return STATUS_OK on success,
		*         STATUS_FAILED on failure,
		*         STATUS_DISK_FULL if there is not enough space on the disk.
		*         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the Resource Limit is reached.
		**/
	       // Support for EBX_RCR_235 : End
	       Status PasteDocument(std::vector<CString> &documentnames);
               Status CreateThread(ThreadFun funcName,ThreadArg funcArgument,Ref<Thread> threadID);

              
               Status CreateCutThread(CBox* cutBoxObj, std::vector<CString> documents);

               /**
                * Launch or Start a new thread for Cut operation 
                */
               static void* StartCutThread(void *arg);

               Status CreateCopyThread(CBox* copyBoxObj, std::vector<CString> documents);

               /**
                * Launch or Start a new thread for Copy operation 
                */
               static void* StartCopyThread(void *arg);

               Status CreatePasteThread(CBox* pasteBoxObj);

               /**
                * Launch or Start a new thread for Paste operation 
                */
               static void* StartPasteThread(void *arg);

               void ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid);

               /**
                * set the m_isiterFolder flag
                * @param[in] val - set it to true/false
                * @return NONE
                */				
               void SetIterFolder(bool val){m_isIterFolder=val;}

               /**
                * create document instance on the container
                * the name of document is least number of non-exist documents. 
                * @param[out] doc - instance of Document class 
                * @param[in/out] documentname - on input, it is document name expected by 
                *                                users. on output, it's created document 
                *                                name. if document has the same name
                *                                exists, suffix will be added.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                *         STATUS_DISK_FULL if there is not enough space on the disk.
                *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the resource limit is reached
                */
               Status CreateDocument(DocumentRef& doc, 
                     CString &documentname);

               /**
                * delete document
                * document status will be changed to DELETING. after that, document will
                * be deleted. 
                * if document status is NOT READY or EDITING, it will fail.
                * @param[in] documentname - serial number from "00000".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status DeleteDocument(CString documentname);

               /**
                * delete document
                * document status will be changed to DELETING. after that, document will
                * be deleted. 
                * if document status is NOT READY or EDITING, it will fail.
                * @param[out] progress - user can get operation progress from this.
                * @param[in] documentname - serial number from "00000".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status DeleteDocument(ProgressRef& progress,
                     CString documentname);

               /**
                * Creating the thread for Delete operation i.e. to Delete page.
                * @param[in] docObj - Instance of the CBoxDocument Class.
                * @param[in] documentname - serial number from "00000".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure
                */
               Status CreateDeleteDocumentThread(CBox* docelemObj,CString documentname);				 

               /**
                * Launch or Start a new thread for Delete Document operation 
                */
               static void* StartDeleteDocumentThread(void* arg);

               /**
                * confirm the box.is protected or not.
                * @return true if the box is protected.
                *         false if NOT.
                */
               bool IsPasswordProtected();

               /**
                * get document preserve days
                * @param[out] days - document preserve days
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetDocumentPreserveDays(CString &days);

               /**
                * get document preserve flag
                * @param[out] days - document preserve flag
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetPreservationPeriodFlag(CString &flag);

               /**
                * get last modified date
                * @param[out] date - last modified date of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetLastModifiedDate(CString &date);

               /**
                * change box password
                * @param[in] boxpassword - new box password. If empty, remove protection 
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status ChangePassword(CString boxpassword);

               /**
                * confirm Folder exists or not
                * @param[in] foldername - folder name.
                * @return true if folder exists
                *         false if folder doesn't exist.
                */
               bool FolderExist(CString foldername);

               /**
                * unlock box
                * @return STATUS_OK on success
                */
               Status Unlock();	

               /**
                * Undo the cut/copy document operation
                * @param[in] docname - source document name
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                */
               Status UndoEditDocument(CString docname);

               /**
                * Undo the cut/copy document operation
                * @param[in] documents - source document names     
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure,
                */
               Status UndoEditDocument(std::vector<CString> documents);	

               /**
                * Get MailBoxType (documentType). 
                * @param[in] boxtype - box type
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetBoxType(CString &boxtype);

               /**
                * set user name. 
                * @param[in] boxpassword - new box password. If empty, remove protection 
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status SetUserName(CString username);

               /**
                * get user name. 
                * @param[in] boxpassword - new box password. If empty, remove protection 
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetUserName(CString &username);

               /**
                * set comment. 
                * @param[in] boxpassword - new box password. If empty, remove protection 
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status SetComment(CString comment);

               /**
                * get comment. 
                * @param[in] boxpassword - new box password. If empty, remove protection 
                *                          for the box.
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                */
               Status GetComment(CString &comment);


               /**
                * confirm the box.is locked or not.
                * @return true if the box is locked.
                *         false if NOT.
                */
               bool IsLocked();			

               /**
                * get a list of document properties
                * @param[out] list - list of document properties.
                * @return   STATUS_OK on success,
                *           STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                **/
               Status GetDocumentPropertiesList(DocumentPropertiesList &list);

               /**
                * get a list of document
                * @param[out] list - list of document properties.
                * @param[in] from - return list from this value. (0-origin)
                * @param[in] size - list size, if "from" + "size" is bigger than the
                *                    number of all documents, return size will be
                *                    smaller than "size".
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                **/
               Status GetDocumentPropertiesList(DocumentPropertiesList &list,unsigned int from, unsigned int size);

               /**
                * get relay report destination.
                * @param[out] destination - destination address for relay report
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetRelayReportDestination(CString &destination);

               /**
                * get relay report destination type.
                * @param[out] dsttype - destination type for relay report
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetRelayReportDestinationType(CString &dsttype);

               /**
                * get relay report contact id.
                * @param[out] id - contact id for relay report
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetRelayReportContactId(CString &id);

               /**
                * set last backup date
                * @param[in] date - last backup date of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status SetLastBackupDate(CString date);

               /**
                * get last backup date
                * @param[out] date - last backup date of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetLastBackupDate(CString &date);

               /**
                * get a password of the mail box
                * @param[out] password - a number of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on invalid box base path.
                * @NOTE - It is available via GetBoxList
                */
               Status GetPassword(CString &password);
               /*
                * get the boxcreation date
                * @param[out] date - creation date of the box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetCreationDate(CString &date);

               /**
                * get the notification email id
                * @param[out] emailId - get the nofication email id
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetNotificationEmailId(CString &emailId);	
               /**
                * get the number of document present inside a box
                * @param[out] numDoc - get the number of documents in a box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetDocumentCount(uint &numDoc);	
               /**
                * get the number of folder inside a box
                * @param[out] numFolder - get the number of folder in a box
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetFolderCount(uint &numFolder);			
               /**
                * set the file name format for the received forwarding
                * @param[in] fnf - set the file name for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_DISK_FULL if there is not enough space in the partition.
                * @NOTE - It is available via GetBoxList
                */
               Status SetFileNameFormat(RFFileNameFormat fnf);   

               /**
                * get the file name format for the received forwarding
                * @param[out] fnf - get the file name for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetFileNameFormat(RFFileNameFormat &fnf);  

               /**
                * set the date format for the received forwarding
                * @param[in] df - get the date for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_DISK_FULL if there is not enough space in the partition.
                * @NOTE - It is available via GetBoxList
                */
               Status SetDateFormat(RFDateFormat df);   

               /**
                * get the date format for the received forwarding
                * @param[out] df - get the date for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetDateFormat(RFDateFormat &df);  

               /**
                * set the page number format for the received forwarding
                * @param[in] pnf - get the page number format for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_DISK_FULL if there is not enough space in the partition.
                * @NOTE - It is available via GetBoxList
                */
               Status SetPageNumberFormat(RFPageNumberFormat pnf);  

               /**
                * get the page number format for the received forwarding
                * @param[out] pnf - get the page number format for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetPageNumberFormat(RFPageNumberFormat &pnf); 

               /**
                * set the sub ID for the received forwarding
                * @param[in] sid - get the Sub ID for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_DISK_FULL if there is not enough space in the partition.
                * @NOTE - It is available via GetBoxList
                */
               Status SetSubID(RFSubID sid);   

               /**
                * get the sub ID for the received forwarding
                * @param[out] sid - get the sub ID for the received forwarding
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetSubID(RFSubID &sid);  

               /**
                * set comment for the received forwarding. 
                * @param[in] comment - comment to be set
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                *         STATUS_DISK_FULL if there is not enough space in the partition.
                * @NOTE - It is available via GetBoxList
                */
               Status SetRFComment(CString comment);

               /**
                * get comment for the received forwarding.. 
                * @param[out] comment - return the comment
                * @return STATUS_OK on success,
                *         STATUS_FAILED on failure.
                * @NOTE - It is available via GetBoxList
                */
               Status GetRFComment(CString &comment);	
         }; // class CBox
      }; // end of namespace boxdocument
   }; // end of namespace ci

#endif // __CI_CBOX_H__
