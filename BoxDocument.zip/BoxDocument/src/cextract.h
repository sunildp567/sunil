/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cextract.h
 Revision: com_t#1
 File Spec: EBX:TA8450.A-DEV_SRC;com_t#1
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 22:00:01

  Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#1 (APPROVED)
     Created:  09-JAN-2009 22:00:01      CHANDRAMOHAN.PUJARI
       Initial Version
========================== End of Source Header =============================*/

#ifndef __CI_CEXTRACT_H__
#define __CI_CEXTRACT_H__


#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/archive.h>
#include "msgdefs.h"
#include "CI/MessagingSystem/msg.h"
#include "CI/MessagingSystem/msgport.h"
#include <CI/OperatingEnvironment/thread.h>
#include "CI/OperatingEnvironment/threadpool.h"
#include "CI/OperatingEnvironment/cuuid.h"
#include "CI/OperatingEnvironment/sharedmemory.h"

#define UUID_CONTENT_LENGTH 100
#define PROGRESS_COMPLETED 100
#define PROGRESS_ERROR -1

#if CI_MASH
	#define PRODUCT_TYPE "H-14x V1.0"
#elif CI_BP
	#define PRODUCT_TYPE "H-13x V1.0"
#elif CI_LOIRE
   #define PRODUCT_TYPE "e-STUDIO 456 Series 3.0"
#elif CI_ALABAMA
   #define PRODUCT_TYPE "e-STUDIO 856 Series 3.0"
#elif CI_MOSEL
	#define PRODUCT_TYPE "e-STUDIO 477 Series 5.5"
#elif CI_WEISS2
	#define PRODUCT_TYPE "e-STUDIO 2000AC Series"
#elif CI_REUSS
	#define PRODUCT_TYPE "e-STUDIO 2508A Series"
#elif CI_SHASTA
	#define PRODUCT_TYPE "e-STUDIO 5506AC Series"
#elif CI_SHASTINA
	#define PRODUCT_TYPE "e-STUDIO 5508A Series"
#elif CI_CASPIAN
        #define PRODUCT_TYPE "e-STUDIO 3508LP Series"
#elif CI_MATTERHORN
        #define PRODUCT_TYPE "e-STUDIO 400AC Series"
#else
	#define PRODUCT_TYPE " "
#endif

typedef void *ThreadArgument;
typedef void *ThreadReturn;
typedef ThreadReturn (*ThreadFunction)(ThreadArgument);
using namespace ci::operatingenvironment;
namespace ci {
namespace boxdocument {

/**
 * Extractor class provides facilities to extract archive.
 */
class CExtractor: public Extractor
{
private:
	Extractor::ExtractStatus m_ExtractStatus;
	std::vector<CString> m_Documentpaths;		
	CString m_SourcePath;
	CString m_ExtractPath;
	CString m_BoxBasePath;
	CString m_BoxNumber;
	CString m_FolderName;
	int m_ExtractProgress;
   bool m_bExtractError;
	Ref<Thread> m_ThreadId;
	CString m_pProgressShmName;
	CString m_pStatusShmName;
	 CString m_sessionID;
	bool m_convertSystemFile;
	static bool m_ExtractFlag;
	/**	
	*Function: CreateThread
	* Description:
	*		This function creates a thread and returns the thread id to the user
	* @param1: the function name with which thread is to be created
	* @param2: the argument to be passed to the function
	* @param3: the thread id that is returned after the creation of the thread
	* Return Values:
	*   	STATUS_OK if successful
	*   	STATUS_FAILED on failure				
	*/					
	Status CreateThread(ThreadFunction functionName, ThreadArgument functionArgument, Ref<Thread> &threadId);
	
	/**
	* StartExtract -Extracts the given archive used as a thread routine
	* @param[in] arg - arguments if any
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*         STATUS_DISK_FULL on disk Full.	
	*/
	static void* StartExtract(void *arg);			
	
	/**
	 * Extracts the zip file to a local temporary path and then uploads the documents to the given box/folder 
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */				
	Status Extract(CExtractor *cextractorObj,void *pProgressMapAddr);
	
	/**
	 * The size of the resource on local path is calculated
	 * @param[in] filePath - the path of the resource
	 * @param[out] size - the size of the resource
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */	
	Status FileSize(CString filePath, int& size,CExtractor *cextractorObj,std::vector<CString> fileNames);
	
	/**
	 * Upload the douments to the specified box/folder on the webdav server
	 * @param[in] fileNames - the documents to be uploaded
	 * @param[out] totalSize - the estimated total size of the resource to be uploaded
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status UploadDocument(std::vector<CString> fileNames,int totalSize,CExtractor *cextractorObj,void *pProgressMapAddr);

public:
	/*con'tor*/
	CExtractor(CString sessionID, CString sourcepath, std::vector<CString>documentpaths,CString localpath);
    /** Virtual destructor */
    virtual ~CExtractor();
    
    /**
     * get extracting status
     * @param[out] status - extracting status
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetStatus(ExtractStatus &status);
    
    /**
     * get extracting progress
     * @param[out] progress - extracting progress [0-100] %
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetProgress(int &progress);
    
    /**
     * cancel to extract
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status Cancel();

	/**	
	*	Function: CreateThread
	* 	Description:
	*		This function creates a thread and that does the extracting job
	*   	@return: Status
	*/		
	Status CreateExtractThread();
    
}; // class Extractor

}; // end of namespace boxdocument
}; // end of namespace ci

#endif // #ifndef __CI_ARCHIVE_H__
