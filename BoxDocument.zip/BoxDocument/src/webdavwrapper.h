/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: webdavwrapper.h
 Revision: com#3.0
 File Spec: EBX:A10955.A-DEV_SRC;com#3.0
 Originator: 07475
 Last Changed: 27-MAY-2009 13:22:52

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Request
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE5_V22512_20090709_1008"
   	Creation Date: 09-JUL-2009 10:08:32
   	Description:   Baseline SCI_PHASE5_V22512_20090709_1008.AAAA
   
   2:
   	Baseline:      "EBX:BUILD_12"
   	Creation Date: 09-JUL-2009 05:01:29
   	Description:   Baseline BUILD_12.AAAA
   
   3:
   	Baseline:      "EBX:0.0.9.53"
   	Creation Date: 08-JUL-2009 12:31:33
   	Description:   Baseline 0.0.9.53.AAAA
   
   4:
   	Baseline:      "EBX:0.0.9.52"
   	Creation Date: 07-JUL-2009 15:31:22
   	Description:   Baseline 0.0.9.52.AAAA
   
   5:
   	Baseline:      "EBX:0.0.9.51"
   	Creation Date: 04-JUL-2009 14:30:52
   	Description:   Baseline 0.0.9.51.AAAA
   
   6:
   	Baseline:      "EBX:0.0.9.50"
   	Creation Date: 03-JUL-2009 14:30:40
   	Description:   Baseline 0.0.9.50.AAAA
   
   7:
   	Baseline:      "EBX:0.0.9.49"
   	Creation Date: 02-JUL-2009 07:30:30
   	Description:   Baseline 0.0.9.49.AAAA
   
   8:
   	Baseline:      "EBX:0.0.9.48"
   	Creation Date: 01-JUL-2009 14:30:21
   	Description:   Baseline 0.0.9.48.AAAA
   
   9:
   	Baseline:      "EBX:SCI_PHASE5_V22512_PRE"
   	Creation Date: 01-JUL-2009 11:00:47
   	Description:   Baseline SCI_PHASE5_V22512_PRE_20090701_1100.AAAA
   
   10:
   	Baseline:      "EBX:MONDAY"
   	Creation Date: 30-JUN-2009 12:30:00
   	Description:   Baseline MONDAY.AAAA
   
   11:
   	Baseline:      "EBX:SCI_PHASE5_V22512_PRE_20090630_1145"
   	Creation Date: 30-JUN-2009 11:45:30
   	Description:   Baseline SCI_PHASE5_V22512_PRE_20090630_1145.AAAA
   
   12:
   	Baseline:      "EBX:PREBUILD_12"
   	Creation Date: 30-JUN-2009 08:54:10
   	Description:   Baseline PREBUILD_12.AAAA
   
   13:
   	Baseline:      "EBX:0.0.9.47"
   	Creation Date: 28-JUN-2009 07:34:52
   	Description:   Baseline 0.0.9.47.AAAA
   
   14:
   	Baseline:      "EBX:0.0.9.46"
   	Creation Date: 27-JUN-2009 12:29:42
   	Description:   Baseline 0.0.9.46.AAAA
   
   15:
   	Baseline:      "EBX:0.0.9.45"
   	Creation Date: 26-JUN-2009 14:29:32
   	Description:   Baseline 0.0.9.45.AAAA
   
   16:
   	Baseline:      "EBX:0.0.9.44"
   	Creation Date: 25-JUN-2009 14:29:24
   	Description:   Baseline 0.0.9.44.AAAA
   
   17:
   	Baseline:      "EBX:TUESDAY"
   	Creation Date: 24-JUN-2009 12:29:00
   	Description:   Baseline TUESDAY.AAAA
   
   18:
   	Baseline:      "EBX:0.0.9.43"
   	Creation Date: 23-JUN-2009 14:29:12
   	Description:   Baseline 0.0.9.43.AAAA
   
   19:
   	Baseline:      "EBX:SUNDAY"
   	Creation Date: 22-JUN-2009 12:28:36
   	Description:   Baseline SUNDAY.AAAA
   
   20:
   	Baseline:      "EBX:SATURDAY"
   	Creation Date: 21-JUN-2009 12:28:26
   	Description:   Baseline SATURDAY.AAAA
   
   21:
   	Baseline:      "EBX:0.0.9.42"
   	Creation Date: 20-JUN-2009 14:28:31
   	Description:   Baseline 0.0.9.42.AAAA
   
   22:
   	Baseline:      "EBX:THURSDAY"
   	Creation Date: 19-JUN-2009 12:28:03
   	Description:   Baseline THURSDAY.AAAA
   
   23:
   	Baseline:      "EBX:SCI_PHASE5_V32511"
   	Creation Date: 18-JUN-2009 16:13:16
   	Description:   Baseline SCI_PHASE5_V32511_20090618_1610.AAAA
   
   24:
   	Baseline:      "EBX:0.0.9.41"
   	Creation Date: 18-JUN-2009 14:28:13
   	Description:   Baseline 0.0.9.41.AAAA
   
   25:
   	Baseline:      "EBX:SCI_PHASE5_V32511_20090618_1124"
   	Creation Date: 18-JUN-2009 11:24:31
   	Description:   Baseline SCI_PHASE5_V32511_20090618_1124.AAAA
   
   26:
   	Baseline:      "EBX:0.0.9.40"
   	Creation Date: 16-JUN-2009 12:27:46
   	Description:   Baseline 0.0.9.40.AAAA
   
   27:
   	Baseline:      "EBX:SCI_PHASE5_V22511"
   	Creation Date: 16-JUN-2009 11:46:41
   	Description:   Baseline SCI_PHASE5_V22511_20090616_1145.AAAA
   
   28:
   	Baseline:      "EBX:SCI_PHASE5_V22511_20090616_1055"
   	Creation Date: 16-JUN-2009 10:55:23
   	Description:   Baseline SCI_PHASE5_V22511_20090616_1055.AAAA
   
   29:
   	Baseline:      "EBX:BUILD_11"
   	Creation Date: 16-JUN-2009 05:49:41
   	Description:   Baseline BUILD_11.AAAA
   
   30:
   	Baseline:      "EBX:0.0.9.39"
   	Creation Date: 13-JUN-2009 05:52:12
   	Description:   Baseline 0.0.9.39.AAAA
   
   31:
   	Baseline:      "EBX:0.0.9.38"
   	Creation Date: 12-JUN-2009 16:28:01
   	Description:   Baseline 0.0.9.38.AAAA
   
   32:
   	Baseline:      "EBX:0.0.9.37"
   	Creation Date: 10-JUN-2009 16:27:30
   	Description:   Baseline 0.0.9.37.AAAA
   
   33:
   	Baseline:      "EBX:SCI_PHASE5_V22511_PRE"
   	Creation Date: 10-JUN-2009 10:47:24
   	Description:   Baseline SCI_PHASE5_V22511_PRE_20090610_1047.AAAA
   
   34:
   	Baseline:      "EBX:0.0.9.36"
   	Creation Date: 09-JUN-2009 18:49:14
   	Description:   Baseline 0.0.9.36.AAAA
   
   35:
   	Baseline:      "EBX:SCI_PHASE5_V22511PRE_20090609_1450"
   	Creation Date: 09-JUN-2009 15:18:21
   	Description:   Baseline SCI_PHASE5_V22511PRE_20090609_1450.AAAA
   
   36:
   	Baseline:      "EBX:SCI_PHASE5_V22511PRE_20090609_1117"
   	Creation Date: 09-JUN-2009 11:17:59
   	Description:   Baseline SCI_PHASE4_V22511_20090609_1117.AAAA
   
   37:
   	Baseline:      "EBX:SCI_PHASE4_V32410_20090604_1145"
   	Creation Date: 04-JUN-2009 11:44:12
   	Description:   Baseline SCI_PHASE4_V32410_20090604_1145.AAAA
   
   38:
   	Baseline:      "EBX:SCI_PHASE4_V32410_20090604_0901"
   	Creation Date: 04-JUN-2009 09:01:39
   	Description:   Baseline SCI_PHASE4_V32410_20090604_0901.AAAA
   
   39:
   	Baseline:      "EBX:MASH_PHASE4_V22410_20090603_1035"
   	Creation Date: 03-JUN-2009 10:34:58
   	Description:   Baseline MASH_PHASE4_V22410_20090603_1035.AAAA
   
   40:
   	Baseline:      "EBX:MASH_PHASE4_V22410_20090602_1330"
   	Creation Date: 02-JUN-2009 13:29:55
   	Description:   Baseline MASH_PHASE4_V22410_20090602_1330.AAAA
   
   41:
   	Baseline:      "EBX:MASH_PHASE4_V22410_20090602_0845"
   	Creation Date: 02-JUN-2009 08:44:35
   	Description:   Baseline MASH_PHASE4_V22410_20090602_0845.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com#3.0 (APPROVED)
     Updated:  27-MAY-2009 13:22:52      07475
       Migration Initial Revision
     Created:  27-MAY-2009 13:22:52      07475
       Migration Initial Revision
========================== End of Source Header =============================*/

#ifndef __CI_WEBDAVWRAPPER_H__
#define __CI_WEBDAVWRAPPER_H__

#include <vector>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/document.h>
#include "cboxdocument.h"

namespace ci {
namespace boxdocument {

using namespace operatingenvironment;

const CString BOXPATH = "/storage/box";

/**
 * WebDAVWrapper is helper function to use WebDAV
 */
class WebDAVWrapper {
public:
    /**
     * get document instance
     * @param[out] doc - instance of Document class 
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status GetDocument(Ref<documentstore::Session> session, 
                              DocumentRef& doc, 
                              CString boxbasepath,
                              CString boxnumber,
                              CString foldername,
                              CString documentname);
    /**
     * create folder on WebDAV server
     *  if boxnumber box is not found, create the box.
     * @param[in] session - WebDAV session 
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status CreateFolder(Ref<documentstore::Session> session, 
                               CString boxbasepath,
                               CString boxnumber,
                               CString foldername = "");

    /**
     * create folder on WebDAV server
     *  if boxnumber box is not found, create the box.
     * @param[in] session - WebDAV session 
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status CreateFile(Ref<documentstore::Session> session, 
                             CString path,
                             CString filename);
    
    /**
     * check resource (Box/Folder/Document/File)  exist on WebDAV server
     * @param[in] session - WebDAV session 
     * @param[in] path - resource path from WebDAV path.
                          e.g. "/DocumentStore/-"
     * @return true if resource exists,
     *         false if not exist.
     */
    static bool ResourceExist(Ref<documentstore::Session> session, CString path);
    
    /**
     * check resource (Box/Folder/Document) exist on WebDAV server
     * @param[in] session - WebDAV session 
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @return true if resource exists,
     *         false if not exist.
     */
    static bool ResourceExist(Ref<documentstore::Session> session, 
                              CString boxbasepath, 
                              CString boxnumber, 
                              CString foldername = "",
                              CString documentname = "");
    
    /**
     * get resource (Box/Folder/Document) path on WebDAV server
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @return resource path from WebDAV path.
     *          e.g. "/DocumentStore/-"
     */
    static CString GetResourcePath(CString boxbasepath, 
                                   CString boxnumber = "", 
                                   CString foldername = "",
                                   CString documentname = "");
    
    /**
     * get resource (Box/Folder/Document) full path on WebDAV server
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @return WebDAV path ("$(EB2)/data") + resource path from WebDAV path.
     */
    static CString GetResourceFullPath(CString boxbasepath, 
                                       CString boxnumber, 
                                       CString foldername = "",
                                       CString documentname = "");
    
    /**
     * get resource (Box/Folder/Document) full path on WebDAV server
     * @param[in] path - resource path from WebDAV path.
     * @return WebDAV path ("$(EB2)/data") + resource path from WebDAV path.
     */
    static CString GetResourceFullPath(CString path);
    
    /**
     * get collection list on WebDAV server
     *  list is sorted by collection name.
     * @param[out] vec - collection name list
     * @param[in] session - WebDAV session 
     * @param[in] path - resource path from WebDAV path.
                          e.g. "/DocumentStore/-"
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status GetCollectionList(std::vector<CString> &vec,
                                    Ref<ci::documentstore::Session> session,
                                    CString path);

	static Status GetInfiniteCollectionList(std::vector<CString> &vec,
                                        Ref<ci::documentstore::Session> session,
                                         CString path) ;
    /**
     * enter critical section
     *  arguments are used to distinguish which critical section will be used.
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @param[in] option - additional string to distinguish
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status EnterCriticalSection(CString boxbasepath, 
                                       CString boxnumber, 
                                       CString foldername = "",
                                       CString documentname = "",
                                       CString option = "");
    
    /**
     * enter critical section
     *  arguments are used to distinguish which critical section is used.
     * @param[in] path - to distinguish which critical section will be used.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status EnterCriticalSection(CString path);
    
    /**
     * leave critical section
     *  arguments are used to distinguish which critical section was used.
     * @param[in] boxbasepath - box type e.g. "DocumentStore/eFilingboxes"
     * @param[in] boxnumber - string of 1-20 digits box number
     * @param[in] foldername - folder name.
     * @param[in] documentname - serial number from "00000".
     * @param[in] option - additional string to distinguish
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status LeaveCriticalSection(CString boxbasepath, 
                                       CString boxnumber, 
                                       CString foldername = "",
                                       CString documentname = "",
                                       CString option = "");
    /**
     * leave critical section
     *  arguments are used to distinguish which critical section was used.
     * @param[in] path - to distinguish which critical section will be used.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    static Status LeaveCriticalSection(CString path);
    
    /**
     * convert from HTTP Status code 2xx to true
     * @param[in] ds - status code to be checked
     * @return true if argument is status code 2xx
     *         false if argument is not status code 2xx
     */
    static bool IsOK(documentstore::DSStatus ds);
    
    /**
     * get unused fileno in specified path
     *  find unused number from 00001 to 99999
     * @param[in] session - WebDAV session 
     * @param[in] path - search path
     * @return 5digit string of unused file No. 
     *         If not found, return empty string.
     */
    static CString GetUnusedFileNo(Ref<documentstore::Session> session, CString path);
    
}; // class WebDAVWrapper


/**
 * predicate object for confirm the folder is Folder
 */
class IsFolder {
private:
    Ref<documentstore::Session> m_Session;
public:
    IsFolder(Ref<ci::documentstore::Session> &session);
    
    bool operator()(CString path) const;
}; // class IsFolder

/**
 *  predicate object for confirm the folder is Document
 */
class IsDocument {
private:
    Ref<documentstore::Session> m_Session;
public:
    IsDocument(Ref<ci::documentstore::Session> &session);
    
    bool operator()(CString path) const;
}; // class IsDocument

/**
 * CtiticalSection class using GlobalMutex
 */
class CriticalSection {
private:
    CString key;
public:
    CriticalSection(CString path);
    CriticalSection(CString boxbasepath, 
                    CString boxnumber, 
                    CString foldername = "",
                    CString documentname = "",
                    CString option = "");
    ~CriticalSection();
}; // class CriticalSection
DECL_OBJ_REF(CriticalSection);

class Utility {
public:
	/**
	 * Get local time
	 */
	static CString GetLocalTime();

	/**
	 * get unix time
	 */
	static CString GetUnixTime();

	/**
	 * convert to zero-filling, 5-digit string
	 */
	static CString Get5DigitPageNo(int pageno);

	/**
	 * extract folder path from file name
	 */
	static CString GetFolderPath(CString filename);

	/**
	 * get temporary folder path
	 */
	static CString GetTmpPath();

	/**
	 * get temporary folder path meant for CI i,,e "/Work/CI/tmp"
	 */
	static CString GetCITmpPath();

	/**
	 * get HDB Root path
	 */
	static CString GetHDBROOTPath();
	
	/**
	 * get EB2 Root path
	 */
	static CString GetEB2ROOTPath();
	 /**
	 * convert to zero-filling, 3-digit string
	 * @return 3 digit hexadecimal Page number
	 **/
	 static CString GetHexadecimalPageNo(int pageno);

	/*
	* Calculate the size of the Resouce
	*/
	static Status ResourceSize(Ref<ci::documentstore::Session> session,CString boxbasepath, CString boxnumber, CString foldername,CString documentname, CString filename,uint64 &ressize);
	 
};

}; // end of namespace boxdocument
}; // end of namespace ci

#endif // #ifndef __CI_WEBDAVWRAPPER_H__
