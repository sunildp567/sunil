/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cprogress.cpp
 Revision: com_t#1
 File Spec: EBX:TA8451.A-DEV_SRC;com_t#1
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 22:01:11

  Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#1 (APPROVED)
     Created:  09-JAN-2009 22:01:11      CHANDRAMOHAN.PUJARI
       Initial Version
========================== End of Source Header =============================*/
#include <status.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/folder.h>
#include "cprogress.h"
#include "proputils.h"
using namespace ci::boxdocument;

namespace ci {
namespace boxdocument {

    CProgress::CProgress(CString progname,CString errname,CString sesseionID,CString BoxBasePath,CString BoxNumber,CString FolderName,CString diskFullFileName, CString resourceNotFoundFile,CString copypage2ndsession)
    {
		m_ProgShmName = progname;
		m_ProgErrName = errname;
		m_sessionID = sesseionID;
		m_BoxBasePath = BoxBasePath;
		m_BoxNumber = BoxNumber;
		m_FolderName = FolderName;
		m_DiskFullName = diskFullFileName;
		m_ResourceNotFound = resourceNotFoundFile;
      m_Copypage2ndsession = copypage2ndsession;
    }

    /* Destructor */
    CProgress::~CProgress() {
      //if the user didn't call GetProgress at all, once the object instance is out of scope, sharedmemory shall be deleted.
		Ref<SharedMemory> bBindProgName = SharedMemory::Bind(m_ProgShmName.c_str(),true);
      if(bBindProgName) {
         DEBUGL8("CProgress:~CProgress: SharedMemory exists, will be destroyed blindly\n");
         bBindProgName -> Destroy();
      }
      else
         DEBUGL8("CProgress:~CProgress: SharedMemory doesn't exist.\n");
    }
    
    /**
     * get archiving progress
     * @param[out] progress - archiving progress [0-100] %
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CProgress::GetProgress(int &progress)
 	{
		Status pRetStatus = STATUS_OK;
		DEBUGL4(" CProgress::GetProgress()-- Entered \n ");
		//Check if the File exist, 
		//If Exist, Indicates an Operation has failed.
		CString filePath = "";
		CString sCurrDirPath = Utility::GetTmpPath();
		filePath = sCurrDirPath + m_ProgErrName;
      CString DiskFulluniqfilename = "";
      CString resourceNotFoundUniqfilename = "";
      CString copypage2ndsession = "";
			
		DEBUGL9(" CProgress::GetProgress():: File Path is <%s> and file exist is <%d> \n",filePath.c_str(),File::Exists(filePath));
		
		//Bind to the Created Shared Segment to read the Updated progress Value
		void *pTmpShmPid;
		Ref<SharedMemory> bBindProgName = SharedMemory::Bind(m_ProgShmName.c_str(),true);
		if(!bBindProgName)
		{
			DEBUGL9(" CProgress::GetProgress() - Thread Exited Destroying the Created Shared Memory \n");
			if(File::Exists(filePath))
			{
				DEBUGL1(" CProgress::GetProgress() - Error.... File Exists  \n");
				pRetStatus = STATUS_FAILED;
				if ((File::DeleteFile(filePath))!= STATUS_OK)
					DEBUGL2(" CProgress::GetProgress()-- Failed to Delete the file\n");
				else
					DEBUGL2(" CProgress::GetProgress()-- Error file deleted successfully\n");
			}
			progress = 100;
			return pRetStatus;
		}
		else
		{

			// Map the binded segment to a address
			bBindProgName->Map(pTmpShmPid);
			if(!pTmpShmPid)
			{
				DEBUGL2(" CProgress::GetProgress() Mapping Failed for Prog Name\n");
				pRetStatus = STATUS_FAILED;
				return pRetStatus;
			}
			if(*((int32 *)pTmpShmPid) == -1) {
				bBindProgName->Destroy();
				pRetStatus = STATUS_FAILED;
				progress = 100;
				return pRetStatus;
			}
			if(File::Exists(filePath))
			{
				DEBUGL1(" CProgress::GetProgress() - Error.... File Exists  \n");
				pRetStatus = STATUS_FAILED;
				if ((File::DeleteFile(filePath))!= STATUS_OK)
					DEBUGL2(" CProgress::GetProgress()-- Failed to Delete the file\n");
				else
					DEBUGL2(" CProgress::GetProgress()-- Error file deleted successfully\n");
				*(int32 *)pTmpShmPid = -1;
				bBindProgName->Destroy();
				progress = 100;
				return pRetStatus;

			}

		}
      
		if(!m_DiskFullName.empty())
		{
			if(Utility::GetUniqueFile(m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName, DiskFulluniqfilename, m_DiskFullName + m_sessionID, false) != STATUS_OK)
			DEBUGL2("CProgress::GetProgress: Unable to get the file\n");
		}         
		
		if(!m_ResourceNotFound.empty())
		{
			if(Utility::GetUniqueFile(m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName, resourceNotFoundUniqfilename, m_ResourceNotFound + m_sessionID, false) != STATUS_OK)
			DEBUGL2("CProgress::GetProgress: Unable to get the file\n");
		}         

      if(!m_Copypage2ndsession.empty())
      {
         if(Utility::GetUniqueFile(m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName, copypage2ndsession, m_Copypage2ndsession + m_sessionID, false) != STATUS_OK)
         DEBUGL2("CProgress::GetProgress: Unable to get the file\n");
      }

		if(!DiskFulluniqfilename.empty())
		{
			DEBUGL1("CProgress::GetProgress(): Operation failed due to disk full\n");
			//Update the current state of the Progress.
			progress = *((int32*)pTmpShmPid);
			DEBUGL4(" CProgress::GetProgress() -- Progress is (%d) \n ", progress);

			pRetStatus = STATUS_DISK_FULL;
			CString delpath = m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName+"/";
			if(Utility::DeleteUniqueFile(delpath, m_DiskFullName + m_sessionID) != STATUS_OK)
				DEBUGL1("CProgress::GetProgress: Unable to delete the  Disk is Full uniquefile (%s)\n",DiskFulluniqfilename.c_str());
			bBindProgName -> Destroy(); //incase of diskfull, actual thread running the operation will not destroy.

			return pRetStatus;
		}

		if(!resourceNotFoundUniqfilename.empty())
		{
			DEBUGL1("CProgress::GetProgress(): Operation failed due to RESOURCE NOT FOUND\n");
			//Update the current state of the Progress.
			progress = *((int32*)pTmpShmPid);
			DEBUGL4(" CProgress::GetProgress() -- Progress is (%d) \n ", progress);

			pRetStatus = STATUS_RESOURCENOTFOUND;
			CString delpath = m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName+"/";
			if(Utility::DeleteUniqueFile(delpath, m_ResourceNotFound + m_sessionID) != STATUS_OK)
				DEBUGL1("CProgress::GetProgress: Unable to delete the  uniquefile (%s)\n",resourceNotFoundUniqfilename.c_str());
			bBindProgName -> Destroy(); //incase of diskfull, actual thread running the operation will not destroy.

			return pRetStatus;
		}
      
      if(!copypage2ndsession.empty())
      {
         DEBUGL1("CProgress::GetProgress(): Operation failed due to USER_EDITING\n");
         //Update the current state of the Progress.
         progress = *((int32*)pTmpShmPid);
         DEBUGL4(" CProgress::GetProgress() -- Progress is (%d) \n ", progress);

         pRetStatus = STATUS_USER_EDITING;
         CString delpath = m_BoxBasePath+"/"+m_BoxNumber+"/"+m_FolderName+"/";
         if(Utility::DeleteUniqueFile(delpath, m_Copypage2ndsession + m_sessionID) != STATUS_OK)
            DEBUGL1("CProgress::GetProgress: Unable to delete the  uniquefile (%s)\n",copypage2ndsession.c_str());
         bBindProgName -> Destroy(); //incase of diskfull, actual thread running the operation will not destroy.

         return pRetStatus;
      }
 

      
		//Update the current state of the Progress.
		progress = *((int32*)pTmpShmPid);
		DEBUGL4(" CProgress::GetProgress() -- Progress is (%d) \n ", progress);
		if(PROGRESS_COMPLETED == progress) {
			DEBUGL6("CProgress::GetProgress() -- Completed.. Destroying the SharedMemory\n");
			bBindProgName -> Destroy();
		}
		return pRetStatus;
	}

	

}; // end of namespace boxdocument
}; // end of namespace ci

