/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2009   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cviewbox.cpp
Revision: 
File Spec: 
Originator: LOCHANA.LINGEGOWDA
Last Changed: 

Outline : Initial revision
========================== End of Source Header =============================*/
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/DocumentStore/documentstore.h>
#include "cboxdocument.h"
#include <iostream>
#include <exception>
#include "cdocument.h"
#include "proputils.h"
#include "cviewbox.h"
#include "cbox.h"
#include <sys/stat.h>
#include "CI/OperatingEnvironment/cexception.h"

//using namespace ci::DocumentStore;
using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::hierarchicaldb;
using namespace dom;

namespace ci {
   namespace boxdocument {

      typedef std::map<CString, CString> property_pair;
      CViewBox::CViewBox(CString sessionID, CString boxbasepath,CString boxnumber) :
         m_BoxBasePath(boxbasepath),m_BoxNumber(boxnumber), m_sessionID(sessionID)
      {
         DEBUGL4("\nCViewBox::CViewBox CTOR: Enter\n ");
         if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
            DEBUGL2("\nCViewBox::CViewBox: Failed to increment the count\n ");
         DEBUGL4("\nCViewBox::CViewBox CTOR:: Exit\n ");
      }

      CViewBox::~CViewBox() 
      {
         DEBUGL4("\nCViewBox::CViewBox DTOR: Enter\n ");
         // release member variables
         if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
            DEBUGL2("\nCViewBox::~CViewBox: Failed to decrement the count\n ");
         DEBUGL4("\nCViewBox::CViewBox DTOR: Exit\n ");
      }

      Status CViewBox::GetName(CString &name) 
      {
         name="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","boxName",name)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetName::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         return STATUS_OK;
      }

      Status CViewBox::GetNumber(CString &number) 
      {
         number = m_BoxNumber;
         return STATUS_OK;
      }

      Status CViewBox::GetSize(uint64 &size)
      {
         //uint64 val;
         size=0;
         CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         if(Utility::ResourceSize(m_sessionID, m_BoxBasePath,m_BoxNumber,"","","",size)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetSizeResourceSize Failed\n");
            return STATUS_FAILED;
         }								
         DEBUGL8("CViewBox::GetSize:: Full Size of Box is %lld\n", size);
         return STATUS_OK;	

      }

      bool CViewBox::IsPasswordProtected()
      {
         CString val("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","isPasswordProtected",val)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::IsPasswordProtected::GetProperty Failed\n");
            return false;
         }		
         if(val=="false") 
            return false;
         else
            return true;
      }

      Status CViewBox::GetDocumentPreserveDays(CString &days)
      {
         days="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","documentPreserveDays",days)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetDocumentPreserveDays::GetProperty Failed\n");
            return STATUS_FAILED;
         }			
         return STATUS_OK;
      }

      Status CViewBox::GetPreservationPeriodFlag(CString &flag)
      {
         flag="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","preservationPeriodFlag",flag)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetPreservationPeriodFlag: GetProperty Failed\n");
            return STATUS_FAILED;
         }
         return STATUS_OK;
      }

      Status CViewBox::GetLastModifiedDate(CString &date)
      {
         date="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","lastModifiedDate",date)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetLastModifiedDate::GetProperty Failed\n");
            return STATUS_FAILED;
         }			

         return STATUS_OK;	
      }

      Status CViewBox::GetBoxType(CString &boxtype)
      {
         boxtype="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","documentType",boxtype)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetBoxType::GetProperty Failed\n");
            return STATUS_FAILED;
         }			
         return STATUS_OK;

      }

      Status CViewBox::SetUserName(CString username)
      {
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("userName", username.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
         return st;
      }

      Status CViewBox::GetUserName(CString &username)
      {
         username="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","userName",username)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetUserName::GetProperty Failed\n");
            return STATUS_FAILED;
         }				
         return STATUS_OK;
      }

      Status CViewBox::SetComment(CString comment)
      {
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("comment", comment.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
         return st;
      }

      Status CViewBox::GetComment(CString &comment)
      {
         comment="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","comment",comment)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetUserName::GetProperty Failed\n");
            return STATUS_FAILED;
         }				
         return STATUS_OK;

      }

      Status CViewBox::SetWEPDocument(dom::NodeRef node)
      {
         typedef std::map<CString, CString> pair;
         if(!node)
         {
            DEBUGL1("CViewBox::SetWEPDocument::dom Node argument is invalid(NULL)\n");
            return STATUS_FAILED;
         }

         // WEP must be set using WebDAV for file permission
         // serialize hdb document in temporary folder
         CString weppath = Utility::GetHDBROOTPath();
         weppath += WEP_FILENAME;
         try {
            HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
            if(!hdb)
            {
               DEBUGL1("CViewBox::SetWEPDocument: failed get hdb\n");
               return STATUS_FAILED;
            }
            if(hdb->SerializeToFile(node, weppath)!= STATUS_OK)
            {
               DEBUGL1("CViewBox::SetWEPDocument: settting wep document failed\n");
               return STATUS_FAILED;
            }
         }
         catch(CException & except)
         {
            DEBUGL1("\nCViewBox::SetWEPDocument: Caught HDB exception\n");
            return STATUS_FAILED;
         }
         catch(DOMException except)
         {
            DEBUGL1("\nCViewBox::SetWEPDocument: Failed due to DOM Exception\n");
            return STATUS_FAILED;
         }
         // put WEP to document folder
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+ "/";
         path += WEP_FILENAME;
         DEBUGL8("CViewBox::SetWEPDocument: Copy wep file to (%s)\n",path.c_str());
         Status retsts = ci::operatingenvironment::File::CopyFile(weppath,path);
         if (retsts !=STATUS_OK)	
         {
            DEBUGL1("CViewBox::SetWEPDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
            return retsts;
         }
         struct stat weppath_buf;
         bool wepsize = true;
         if(stat(weppath.c_str(), &weppath_buf) != 0)
         {
            DEBUGL2("CViewBox::SetWEPDocument:: Cannot stat wep file, setting size as 0\n");
            wepsize = false;
         }
         CString val;
         CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize",val)!=STATUS_OK)		
         {
            DEBUGL1("CBox::SetWEPDocument:GetProperty Failed\n");
            return STATUS_FAILED;
         }		

         DEBUGL8("CViewBox::SetWEPDocument:: Full Size of Box is %s\n", val.c_str());
         uint64 size = val.length()? atoi(val.c_str()): 0;
         size += (wepsize ? weppath_buf.st_size : 0);
         std::ostringstream boxsize;
         boxsize << size;

         //Reset the properties on the Original document			
         std::map<CString,CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         //update the sessionID and cutDocument flag 
         PropertyMap.insert(pair::value_type("totalBoxSize",boxsize.str()));
         PropertyMap.insert(pair::value_type("lastAccessDate",(Utility::GetUnixTime()).c_str()));
         PropertyMap.insert(pair::value_type("lastModifiedDate",(Utility::GetUnixTime()).c_str()));	
         if(Utility::SetProperties(propertypath,xmlfile,PropertyMap)!=STATUS_OK)	
         {	
            DEBUGL1("CViewBox::SetWEPDocument:SetProperty for totalBoxSize Failed\n");
            return STATUS_FAILED;
         }						
         File::DeleteFile(weppath);	
         return STATUS_OK;
      }

      Status CViewBox::GetWEPDocument(CString& documentID)
      {
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+"/";
         path += WEP_FILENAME;
         DEBUGL8("CViewBox::GetWEPDocument::path =%s\n",path.c_str());

         try {
            // Create HDB Document
            dom::DocumentRef doc;
            HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
            std::ostringstream oss;
            Ref<CUUID> uuid = new CUUID();
            oss << "WEP_" << uuid->toString();
            documentID = oss.str();

            CString folderpath = Utility::GetHDBROOTPath();
            Status st = hdb->CreateDocumentFromFile(folderpath, documentID, doc, path);
            if((st != STATUS_OK)||(!doc)) {
               DEBUGL1("CViewBox::GetWEPDocument::opening WEP.XML failed\n");
               return STATUS_FAILED;
            }
         }
         catch(CException & except)
         {
            DEBUGL1("\nCViewBox::GetWEPDocument: Caught HDB exception\n");
            return STATUS_FAILED;
         }
         catch(DOMException except)
         {
            DEBUGL1("\nCViewBox::GetWEPDocument: Failed due to DOM Exception\n");
            return STATUS_FAILED;
         }
         return STATUS_OK;
      }

      bool CViewBox::IsLocked()
      {
         CString boxState("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","",AUTH_STATE,boxState)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::IsLocked::GetProperty Failed\n");
            return false;
         }				
         if(boxState=="ACCOUNT_LOCKED")
            return true;
         else
            return false;
      }

      Status CViewBox::Unlock()
      {
         DEBUGL4("CViewBox::Unlock::Enter\n");
         std::map<CString,CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");

         //Change state to IDLE
         CString propertypath = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber) + "/";
         PropertyMap.insert(property_pair::value_type(AUTH_STATE,"IDLE"));
         PropertyMap.insert(property_pair::value_type(AUTH_TIMER,"0"));
         PropertyMap.insert(property_pair::value_type(AUTH_FAILURE_COUNT,"0"));	
         if(Utility::SetProperties(propertypath,xmlfile,PropertyMap)!=STATUS_OK)	
         {	
            DEBUGL1("CBox::SetWEPDocument:SetProperty for totalBoxSize Failed\n");
            return STATUS_FAILED;
         }	
         DEBUGL4("CViewBox::Unlock::Exit\n");	
         return STATUS_OK;
      }

      Status CViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list)
      {
         return GetDocumentPropertiesList(list, 0, 65535);
      }

      Status CViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list,unsigned int from, unsigned int size)
      {
         DEBUGL4("CViewBox::GetDocumentPropertiesList::Enter\n");

         std::vector<CString> vec;
         CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber) + "/";
         if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetDocumentPropertiesList::Getting collection list is failed");
            return STATUS_FAILED;
         }
         list.clear();
         for(unsigned int i = from, cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++) 
         {
            CString docName = vec[i];
            // GetDocument
            Ref<DocumentProperties> document = new CDocumentProperties(m_BoxBasePath, m_BoxNumber,"",docName);
#if 1
            DocStatus st;
            try
            {
               if(!document)
               {
                  DEBUGL1("CViewBox::Document object is NULL\n");
                  return STATUS_FAILED;
               }
               Status ret = dynamic_cast<ci::boxdocument::CDocumentProperties*>(document.operator->())->GetStatus(st);
               if( ret != STATUS_OK || st == DELETING) 
               {
                  DEBUGL2("CViewBox::GetDocumentPropertiesList::Getting document status failed or document is deleting\n");
                  continue;
               }
            }
            catch(exception &e)
            {
               DEBUGL1("CViewBox::GetDocumentPropertiesList: caught exception (%s)\n",e.what());
               return STATUS_FAILED;
            }

#endif		
            list.push_back(document);								
         }

         DEBUGL4("CViewBox::GetDocumentPropertiesList::Exit\n");		
         return STATUS_OK;	
      }

      Status CViewBox::GetRelayReportDestination(CString &destination)
      {
         destination="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","relayReportDestination",destination)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::IsLocked::GetProperty Failed\n");
            return false;
         }	
         return STATUS_OK;
      }

      Status CViewBox::GetRelayReportDestinationType(CString &dsttype)
      {
         dsttype="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","relayReportDestinationType",dsttype)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::IsLocked::GetProperty Failed\n");
            return false;
         }	
         return STATUS_OK;
      }

      Status CViewBox::GetRelayReportContactId(CString &id)
      {
         id="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","relayReportContactId",id)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::IsLocked::GetProperty Failed\n");
            return false;
         }	
         return STATUS_OK;
      }
      Status CViewBox::SetLastBackupDate(CString date)
      {
         DEBUGL4(" CViewBox::SetLastBackupDate: Enter\n");
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("lastBackupDate",date.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
         DEBUGL4(" CViewBox::SetLastBackupDate: Exit\n");
         return st;
      }

      Status CViewBox::GetLastBackupDate(CString &date)
      {
         DEBUGL4(" CViewBox::GetLastBackupDate: Enter\n");
         date="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","lastBackupDate",date)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::SetLastBackupDate::GetProperty Failed\n");
            return STATUS_FAILED;
         }			
         DEBUGL4(" CViewBox::GetLastBackupDate: Exit\n");
         return STATUS_OK;
      }
      Status CViewBox::GetPassword(CString &password)
      {
         if((m_BoxBasePath != "/storage/box/ITUTBoxes") && (m_BoxBasePath != "/storage/box/PollingBoxes"))
         {
            DEBUGL1("CViewBox::GetPassword::Invalid BoxbasePath\n");
            return STATUS_FAILED;
         }
         else
         {
            password ="";
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","password", password)!= STATUS_OK)
            {
               DEBUGL1("CViewBox::GetPassword::failed to get the Password property\n");
               return STATUS_FAILED;
            }
         }
         return STATUS_OK;	
      }

      /*
       * get the boxcreation date
       * @param[out] date - creation date of the box
       * @return STATUS_OK on success,
       *         STATUS_FAILED on failure.
       * @NOTE - It is available via GetBoxList
       */
      Status CViewBox::GetCreationDate(CString &date)
      {
         date="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","creationDate",date)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetCreationDate::GetProperty Failed\n");
            return STATUS_FAILED;
         }			

         return STATUS_OK;	
      }

      /**
       * get the notification email id
       * @param[out] emailId - get the nofication email id
       * @return STATUS_OK on success,
       *         STATUS_FAILED on failure.
       * @NOTE - It is available via GetBoxList
       */
      Status CViewBox::GetNotificationEmailId(CString &emailId)
      {
         emailId="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","notificationEmailAddress",emailId)!=STATUS_OK)		
         {
            DEBUGL1("CViewBox::GetNotificationEmailId::GetProperty Failed\n");
            return STATUS_FAILED;
         }			
         if(emailId.empty())
            DEBUGL2("CViewBox::GetNotificationEmailId: email id is not present in boxproperties.xml file\n");

         return STATUS_OK;	
      }
      /**
       * get the number of document present inside a box
       * @param[out] numDoc - get the number of documents in a box
       * @return STATUS_OK on success,
       *         STATUS_FAILED on failure.
       * @NOTE - It is available via GetBoxList
       */
      Status CViewBox::GetDocumentCount(uint &numDoc)
      {
         numDoc = 0;
         bool underbox = true;
         if(Utility::GetDocumentCount(m_BoxBasePath, m_BoxNumber, "", numDoc, underbox) != STATUS_OK)
         {
            DEBUGL1("CViewBox::GetDocumentCount::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         else {
            DEBUGL8("CViewBox::GetDocumentCount:: number of documents = (%u)\n", numDoc);
            return STATUS_OK;
         }
      }
      /**
       * get the number of folder inside a box
       * @param[out] numFolder - get the number of folder in a box
       * @return STATUS_OK on success,
       *         STATUS_FAILED on failure.
       * @NOTE - It is available via GetBoxList
       */
      Status CViewBox::GetFolderCount(uint &numFolder)
      {
         numFolder = 0;
         if(Utility::GetFolderCount(m_BoxBasePath, m_BoxNumber, numFolder) != STATUS_OK)
         {
            DEBUGL1("CViewBox::GetFolderCount::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         else {
            DEBUGL8("CViewBox::GetFolderCount:: number of folder = (%u)\n", numFolder);
            return STATUS_OK;
         }

      }

      Status CViewBox::SetFileNameFormat(RFFileNameFormat fnf)
      {
         std::ostringstream name;
         CString nameFormat("");
         name << fnf;
         nameFormat = name.str();
         DEBUGL8("CViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str());
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("fileNameFormat", nameFormat.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
         return st;
      }

      Status CViewBox::GetFileNameFormat(RFFileNameFormat &fnf)
      {
         std::istringstream name;
         CString nameFormat("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","fileNameFormat",nameFormat)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetFileNameFormat::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         name.str(nameFormat);
         int val = 0;
         name >> val;
         fnf = (RFFileNameFormat)val;
         DEBUGL8("CViewBox::GetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str()); 
         return STATUS_OK;            
      }

      Status CViewBox::SetDateFormat(RFDateFormat df)
      {
         std::ostringstream date;
         CString dateFormat("");
         date << df;
         dateFormat = date.str();
         DEBUGL8("CViewBox::SetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("dateFormat", dateFormat.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
         return st;
      }

      Status CViewBox::GetDateFormat(RFDateFormat &df)
      {
         std::istringstream date;
         CString dateFormat("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","dateFormat",dateFormat)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetDateFormat::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         date.str(dateFormat);
         int val = 0;
         date >> val;
         df = (RFDateFormat)val;
         DEBUGL8("CViewBox::GetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());
         return STATUS_OK;
      }

      Status CViewBox::SetPageNumberFormat(RFPageNumberFormat pnf)
      {
         std::ostringstream pagenum;
         CString pageNumber("");
         pagenum << pnf;
         pageNumber = pagenum.str();
         DEBUGL8("CViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("pageNumberFormat", pageNumber.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
         return st;
      }

      Status CViewBox::GetPageNumberFormat(RFPageNumberFormat &pnf)
      {
         std::istringstream pagenum;
         CString pageNumber("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","pageNumberFormat",pageNumber)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetPageNumberFormat::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         pagenum.str(pageNumber);
         int val = 0;
         pagenum >> val;
         pnf = (RFPageNumberFormat)val;
         DEBUGL8("CViewBox::GetPageNumberFormat::Page number format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
         return STATUS_OK;
      }

      Status CViewBox::SetSubID(RFSubID sid)
      {
         std::ostringstream sub;
         CString subid("");
         sub << sid;
         subid = sub.str();
         DEBUGL8("CViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", sid, subid.c_str());
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("subID", subid.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
         return st;
      }

      Status CViewBox::GetSubID(RFSubID &sid)
      {
         std::istringstream sub;
         CString subid("");
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","subID",subid)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetSubID::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         sub.str(subid);
         int val = 0;
         sub >> val;
         sid = (RFSubID)val;
         DEBUGL8("CViewBox::GetPageNumberFormat::Page number format:as int = <%d> as str = (%s)\n", sid, subid.c_str());
         return STATUS_OK;
      }

      Status CViewBox::SetRFComment(CString comment)
      {
         std::map<CString, CString> PropertyMap;
         PropertyMap.clear();
         CString xmlfile("boxproperties.xml");
         PropertyMap.insert(property_pair::value_type("rfComment", comment.c_str()));
         CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
         Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
         return st;
      }

      Status CViewBox::GetRFComment(CString &comment)
      {
         comment="";
         if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","rfComment",comment)!=STATUS_OK)
         {
            DEBUGL1("CViewBox::GetRFComment::GetProperty Failed\n");
            return STATUS_FAILED;
         }
         return STATUS_OK;
      }

      Status CViewBox::GetDocument(DocumentRef &doc, CString documentname) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetDocumentList(DocumentList &list) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetDocumentList(DocumentList &list, 
            unsigned int from, unsigned int size) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetDocumentListToDelete(DocumentList &list)
      {
         return STATUS_FAILED;
      }
      Status CViewBox::CreateFolder(CString foldername)
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CreateFolder(FolderRef& folder, CString foldername) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetFolder(FolderRef& folder, CString foldername) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetFolderList(FolderList &list) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetFolderList(FolderList &list,
            unsigned int from, unsigned int size) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::DeleteFolder(CString foldername) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::SetWebDAVProperty(CString key, CString value) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::GetWebDAVProperty(CString key, CString &value) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::SetName(CString name) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CutDocument(CString docname) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CutDocument(std::vector<CString> documents) 
      {
         return STATUS_FAILED;
      }

	  Status CViewBox::CopyDocument(CString docname) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CopyDocument(std::vector<CString> documents) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::PasteDocument() 
      {
         return STATUS_FAILED;
      }
      Status CViewBox::PasteDocument(std::vector<CString> &documentnames) 
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CreateArchive(ArchiverRef &archiver, CString target, CString documentname)
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CreateArchive(ArchiverRef &archiver, CString target, std::vector<CString> documentlist)
      {
         return STATUS_FAILED;
      }

      Status CViewBox::ExtractArchive(operatingenvironment::Ref<Extractor> &extractor,CString archiverpath,CString extractorpath)
      {
         return STATUS_FAILED;
      }

      Status CViewBox::DeleteArchive(CString archivepath)
      {
         return STATUS_FAILED;
      }


      Status CViewBox::CutDocument(ProgressRef& progress, CString docname)
      {
         return STATUS_FAILED;
      }

      Status CViewBox::CutDocument(ProgressRef& progress, std::vector<CString> documents)
      {
         return STATUS_FAILED;
      }
 
      Status CViewBox::CopyDocument(ProgressRef& progress, CString docname)
      {
         return STATUS_FAILED;}

         Status CViewBox::CopyDocument(ProgressRef& progress, std::vector<CString> documents)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::PasteDocument(ProgressRef& progress)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::CreateDocument(DocumentRef& doc, CString &documentname)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::DeleteDocument(CString documentname)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::DeleteDocument(ProgressRef& progress,CString documentname)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::ChangePassword(CString boxpassword)
         {
            return STATUS_FAILED;
         }

         bool CViewBox::FolderExist(CString foldername)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::UndoEditDocument(CString docname)
         {
            return STATUS_FAILED;
         }

         Status CViewBox::UndoEditDocument(std::vector<CString> documents)
         {
            return STATUS_FAILED;
         }	
        Status CViewBox::GetViewDocumentList(DocumentList &list) 
        {
            return GetViewDocumentList(list, 0, 65535);
        }

        Status CViewBox::GetViewDocumentList(DocumentList &list,unsigned int from, unsigned int size) 
        {
           DEBUGL4("CViewBox::GetViewDocumentList: Enter\n");
           //Now get the list of the documents inside the boxpath and then check the status of the documents.
           std::vector<CString> vec;
           std::vector<CString>::iterator dIt;
           CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
           //Now get the list of files present under the boxbasepath.
           if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
           {
              DEBUGL1("CViewBox::GetViewDocumentList::Getting collection list is failed");
              return STATUS_FAILED;
           }
           CString documentname,documentPath;
           CString stsfile;
           DocumentRef pDocRef = NULL;
           Status ret;
           std::map<CString, CString>::iterator propIterator;
           std::map<CString, CString> WebDAVpropertyMap;
           typedef std::map<CString, CString> property_pair;
		   CString stringArray[7] = {"documentName", "jobType", "totalSize", "totalPages", "creationDate", 
										"lastModifiedDate", "cutDocument"};
           for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
           {
              documentname = vec[i];
              documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,documentname,"");
              stsfile = documentPath + "/.document";

              WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
              WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));

              if(Utility::ResourceExist(stsfile) ==true)
              {
                 DEBUGL8("CViewBox::GetViewDocumentList:document Name = %s\n",documentname.c_str());
                 //Read the properties from the xml file and update the same to local map of document class.
                 Utility::GetPropertyMaps(documentPath,"documentproperties.xml",WebDAVpropertyMap,stringArray, 7);
                 WebDAVpropertyMap["documentName"]=  documentname;
              }
              else
              {
                 DEBUGL8("CViewBox::GetViewDocumentList:Folder found hence skipping\n");
                 continue;
              }
              // GetDocument
              pDocRef = NULL;
              try 
              {
                 pDocRef = new CViewDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"",documentname);
                 if(!pDocRef)
                 {
                    DEBUGL8("CViewBox::GetViewDocumentList: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 ret = dynamic_cast<CViewDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CViewBox::GetViewDocumentList::Loading Box is failed\n");
                    continue;
                 }
              }  
              catch(exception &e)
              {
                 DEBUGL1("CViewBox::GetViewDocumentList: Caught exception (%s)\n",e.what());
                 pDocRef = NULL;
                 return STATUS_FAILED;
              }
              list.push_back(pDocRef);								
           }
           DEBUGL4("CViewBox::GetViewDocumentList: Exit\n");			
           return STATUS_OK;
        }


         /**
          * constructor
          */
         CMIBViewBox::CMIBViewBox(CString sessionID, CString boxbasepath,CString boxnumber) :
            m_BoxBasePath(boxbasepath),m_BoxNumber(boxnumber), m_sessionID(sessionID)
      	{
      	}
         CMIBViewBox::~CMIBViewBox() { }

         Status CMIBViewBox::GetName(CString &name)
         {
            name="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","boxName",name)!=STATUS_OK)		
            {
               DEBUGL1("CMIBViewBox::GetName::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;

         }

         /**
          * get a number of the box
          * @param[out] number - a number of the box
          * @return STATUS_OK on success,
          *         STATUS_FAILED on failure.
          */
         Status CMIBViewBox::GetNumber(CString &number)
         {
            number = m_BoxNumber;
            return STATUS_OK;
         }		

         //Following API's are not supported by CMIBViewBox. So returning failed
         Status CMIBViewBox::GetDocument(DocumentRef &doc, CString documentname) {return STATUS_FAILED;}
         Status CMIBViewBox::GetDocumentList(DocumentList &list){return STATUS_FAILED;}
         Status CMIBViewBox::GetDocumentList(DocumentList &list,unsigned int from, unsigned int size){return STATUS_FAILED;}
         Status CMIBViewBox::GetDocumentListToDelete(DocumentList &list){return STATUS_FAILED;}			
         Status CMIBViewBox::CreateFolder(CString foldername){return STATUS_FAILED;}
         Status CMIBViewBox::CreateFolder(FolderRef& folder, CString foldername){return STATUS_FAILED;}
         Status CMIBViewBox::GetFolder(FolderRef& folder, CString foldername){return STATUS_FAILED;}
         Status CMIBViewBox::GetFolderList(FolderList &list){return STATUS_FAILED;}
         Status CMIBViewBox::GetFolderList(FolderList &list,
               unsigned int from, unsigned int size) {return STATUS_FAILED;}
         Status CMIBViewBox::DeleteFolder(CString foldername) {return STATUS_FAILED;}
         Status CMIBViewBox::SetWebDAVProperty(CString key, CString value) {return STATUS_FAILED;}
         Status CMIBViewBox::GetWebDAVProperty(CString key, CString &value) {return STATUS_FAILED;}
         Status CMIBViewBox::SetName(CString name) {return STATUS_FAILED;}
         Status CMIBViewBox::CutDocument(CString docname) {return STATUS_FAILED;}
         Status CMIBViewBox::CutDocument(std::vector<CString> documents) {return STATUS_FAILED;}
		 Status CMIBViewBox::CopyDocument(CString docname) {return STATUS_FAILED;}
         Status CMIBViewBox::CopyDocument(std::vector<CString> documents) {return STATUS_FAILED;}
         Status CMIBViewBox::PasteDocument() {return STATUS_FAILED;}
         Status CMIBViewBox::PasteDocument(std::vector<CString> &documentnames) {return STATUS_FAILED;}
         Status CMIBViewBox::LoadProperties() {return STATUS_FAILED;}
         Status CMIBViewBox::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) {return STATUS_FAILED;}
         Status CMIBViewBox::SaveProperties() {return STATUS_FAILED;}
         Status CMIBViewBox::GetSize(uint64 &size) {return STATUS_FAILED;}
         Status CMIBViewBox::SetWEPDocument(dom::NodeRef node) {return STATUS_FAILED;}
         Status CMIBViewBox::GetWEPDocument(CString& documentID) {return STATUS_FAILED;}
         Status CMIBViewBox::CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, CString documentname) {return STATUS_FAILED;}
         Status CMIBViewBox::CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, std::vector<CString> documentlist) {return STATUS_FAILED;}
         Status CMIBViewBox::ExtractArchive(operatingenvironment::Ref<Extractor> &extractor,CString archiverpath,CString extractorpath) {return STATUS_FAILED;}
         Status CMIBViewBox::DeleteArchive(CString archivepath) {return STATUS_FAILED;}
         Status CMIBViewBox::CutDocument(ProgressRef& progress, CString docname) {return STATUS_FAILED;}
         Status CMIBViewBox::CutDocument(ProgressRef& progress, 
               std::vector<CString> documents) {return STATUS_FAILED;}
		 Status CMIBViewBox::CopyDocument(ProgressRef& progress, CString docname) {return STATUS_FAILED;}
         Status CMIBViewBox::CopyDocument(ProgressRef& progress,std::vector<CString> documents) {return STATUS_FAILED;}
         Status CMIBViewBox::PasteDocument(ProgressRef& progress){return STATUS_FAILED;}
         Status CMIBViewBox::CreateDocument(DocumentRef& doc, CString &documentname) {return STATUS_FAILED;}
         Status CMIBViewBox::DeleteDocument(CString documentname) {return STATUS_FAILED;}
         Status CMIBViewBox::DeleteDocument(ProgressRef& progress,CString documentname) {return STATUS_FAILED;}
         bool CMIBViewBox::IsPasswordProtected() {return false;}
         Status CMIBViewBox::GetDocumentPreserveDays(CString &days) {return STATUS_FAILED;}
		 Status CMIBViewBox::GetPreservationPeriodFlag(CString &falg){ return STATUS_FAILED; }
         Status CMIBViewBox::GetLastModifiedDate(CString &date) {return STATUS_FAILED;}
         Status CMIBViewBox::ChangePassword(CString boxpassword) {return STATUS_FAILED;}
         bool CMIBViewBox::FolderExist(CString foldername) {return STATUS_FAILED;}
         Status CMIBViewBox::Unlock() {return STATUS_FAILED;}
         Status CMIBViewBox::UndoEditDocument(CString docname) {return STATUS_FAILED;}
         Status CMIBViewBox::UndoEditDocument(std::vector<CString> documents) {return STATUS_FAILED;}	
         Status CMIBViewBox::GetBoxType(CString &boxtype) {return STATUS_FAILED;}
         Status CMIBViewBox::SetUserName(CString username) {return STATUS_FAILED;}
         Status CMIBViewBox::GetUserName(CString &username) {return STATUS_FAILED;}
         Status CMIBViewBox::SetComment(CString comment) {return STATUS_FAILED;}
         Status CMIBViewBox::GetComment(CString &comment) {return STATUS_FAILED;}
         bool CMIBViewBox::IsLocked() {return false;}	
         Status CMIBViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list) {return STATUS_FAILED;}
         Status CMIBViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list,unsigned int from, unsigned int size) {return STATUS_FAILED;}
         Status CMIBViewBox::GetRelayReportDestination(CString &destination) {return STATUS_FAILED;}
         Status CMIBViewBox::GetRelayReportDestinationType(CString &dsttype) {return STATUS_FAILED;}
         Status CMIBViewBox::GetRelayReportContactId(CString &id) {return STATUS_FAILED;}											 
         Status CMIBViewBox::SetLastBackupDate(CString date) {return STATUS_FAILED;}
         Status CMIBViewBox::GetLastBackupDate(CString &date) {return STATUS_FAILED;}
         Status CMIBViewBox::GetPassword(CString &password) {return STATUS_FAILED;}
         Status CMIBViewBox::GetCreationDate(CString &date) {return STATUS_FAILED;}
         Status CMIBViewBox::GetNotificationEmailId(CString &emailId) {return STATUS_FAILED;}
         Status CMIBViewBox::GetDocumentCount(uint &numDoc) {return STATUS_FAILED;}
         Status CMIBViewBox::GetFolderCount(uint &numFolder) {return STATUS_FAILED;}				



         /**
          * constructor
          */
         CMAILViewBox::CMAILViewBox(CString sessionID, CString boxbasepath,CString boxnumber) :
            m_BoxBasePath(boxbasepath),m_BoxNumber(boxnumber), m_sessionID(sessionID)
      {
      }

         CMAILViewBox::~CMAILViewBox() { }
         Status CMAILViewBox::GetName(CString &name)
         {
            name="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","boxName",name)!=STATUS_OK)		
            {
               DEBUGL1("CMAILViewBox::GetName::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;

         }

         /**
          * get a number of the box
          * @param[out] number - a number of the box
          * @return STATUS_OK on success,
          *         STATUS_FAILED on failure.
          */
         Status CMAILViewBox::GetNumber(CString &number)
         {
            number = m_BoxNumber;
            return STATUS_OK;
         }

         Status CMAILViewBox::GetUserName(CString &username)
         {  
            username="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","userName",username)!=STATUS_OK)		
            {
               DEBUGL1("CMAILViewBox::GetUserName::GetProperty Failed\n");
               return STATUS_FAILED;
            }				
            return STATUS_OK;
         }

         Status CMAILViewBox::GetComment(CString &comment)
         {  
            comment="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","comment",comment)!=STATUS_OK)		
            {
               DEBUGL1("CMAILViewBox::GetUserName::GetProperty Failed\n");
               return STATUS_FAILED;
            }				
            return STATUS_OK;
         }  

         Status CMAILViewBox::GetBoxType(CString &boxtype)
         {
            boxtype="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","documentType",boxtype)!=STATUS_OK)		
            {
               DEBUGL1("CMAILViewBox::GetBoxType::GetProperty Failed\n");
               return STATUS_FAILED;
            }			
            return STATUS_OK;
         }

         Status CMAILViewBox::GetWEPDocument(CString& documentID)
         {
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+"/";
            path += WEP_FILENAME;
            DEBUGL8("CMailViewBox::GetWEPDocument::path =%s\n",path.c_str());
            try {
               //Create HDB Document
               dom::DocumentRef doc;
               HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
               std::ostringstream oss;
               Ref<CUUID> uuid = new CUUID();
               oss << "WEP_" << uuid->toString();
               documentID = oss.str();
               CString folderpath = Utility::GetHDBROOTPath();
               Status st = hdb->CreateDocumentFromFile(folderpath, documentID, doc, path);
               if((st != STATUS_OK)||(!doc)) {
                  DEBUGL1("CMailViewBox::GetWEPDocument::opening WEP.XML failed\n");
                  return STATUS_FAILED;
               }
            }
            catch(CException & except)
            {
               DEBUGL1("\nCMailViewBox::GetWEPDocument: Caught HDB exception\n");
               return STATUS_FAILED;
            }
            catch(DOMException except)
            {
               DEBUGL1("\nCMailViewBox::GetWEPDocument: Failed due to DOM Exception\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
         }

         Status CMAILViewBox::SetFileNameFormat(RFFileNameFormat fnf)
         {
            std::ostringstream name;
            CString nameFormat("");
            name << fnf;
            nameFormat = name.str();
            DEBUGL8("CMAILViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str());
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            PropertyMap.insert(property_pair::value_type("fileNameFormat", nameFormat.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            return st;
         }

         Status CMAILViewBox::GetFileNameFormat(RFFileNameFormat &fnf)
         {
            std::istringstream name;
            CString nameFormat("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","fileNameFormat",nameFormat)!=STATUS_OK)
            {
               DEBUGL1("CMAILViewBox::GetFileNameFormat::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            name.str(nameFormat);
            int val = 0;
            name >> val;
            fnf = (RFFileNameFormat)val;
            DEBUGL8("CMAILViewBox::GetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str());
            return STATUS_OK;
         }

         Status CMAILViewBox::SetDateFormat(RFDateFormat df)
         {
            std::ostringstream date;
            CString dateFormat("");
            date << df;
            dateFormat = date.str();
            DEBUGL8("CMAILViewBox::SetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            PropertyMap.insert(property_pair::value_type("dateFormat", dateFormat.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            return st;
         }

         Status CMAILViewBox::GetDateFormat(RFDateFormat &df)
         {
            std::istringstream date;
            CString dateFormat("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","dateFormat",dateFormat)!=STATUS_OK)
            {
               DEBUGL1("CMAILViewBox::GetDateFormat::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            date.str(dateFormat);
            int val = 0;
            date >> val;
            df = (RFDateFormat)val;
            DEBUGL8("CMAILViewBox::GetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());
            return STATUS_OK;
         }

         Status CMAILViewBox::SetPageNumberFormat(RFPageNumberFormat pnf)
         {
            std::ostringstream pagenum;
            CString pageNumber("");
            pagenum << pnf;
            pageNumber = pagenum.str();
            DEBUGL8("CMAILViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            PropertyMap.insert(property_pair::value_type("pageNumberFormat", pageNumber.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            return st;
         }

         Status CMAILViewBox::GetPageNumberFormat(RFPageNumberFormat &pnf)
         {
            std::istringstream pagenum;
            CString pageNumber("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","pageNumberFormat",pageNumber)!=STATUS_OK)
            {
               DEBUGL1("CMAILViewBox::GetPageNumberFormat::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            pagenum.str(pageNumber);
            int val = 0;
            pagenum >> val;
            pnf = (RFPageNumberFormat)val;
            DEBUGL8("CMAILViewBox::GetPageNumberFormat::Page number format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
            return STATUS_OK;
         }

         Status CMAILViewBox::SetSubID(RFSubID sid)
         {
            std::ostringstream sub;
            CString subid("");
            sub << sid;
            subid = sub.str();
            DEBUGL8("CMAILViewBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", sid, subid.c_str());
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            PropertyMap.insert(property_pair::value_type("subID", subid.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            return st;
         }

         Status CMAILViewBox::GetSubID(RFSubID &sid)
         {
            std::istringstream sub;
            CString subid("");
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","subID",subid)!=STATUS_OK)
            {
               DEBUGL1("CMAILViewBox::GetSubID::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            sub.str(subid);
            int val = 0;
            sub >> val;
            sid = (RFSubID)val;
            DEBUGL8("CMAILViewBox::GetPageNumberFormat::Page number format:as int = <%d> as str = (%s)\n", sid, subid.c_str());
            return STATUS_OK;
         }

         Status CMAILViewBox::SetRFComment(CString comment)
         {
            std::map<CString, CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            PropertyMap.insert(property_pair::value_type("rfComment", comment.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);
            return st;
         }

         Status CMAILViewBox::GetRFComment(CString &comment)
         {
            comment="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","rfComment",comment)!=STATUS_OK)
            {
               DEBUGL1("CMAILViewBox::GetRFComment::GetProperty Failed\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
         }

         //Following API's are not supported by CMAILViewBox. So returning failed
         Status CMAILViewBox::GetDocument(DocumentRef &doc, CString documentname) {return STATUS_FAILED;}
         Status CMAILViewBox::GetDocumentList(DocumentList &list){return STATUS_FAILED;}
         Status CMAILViewBox::GetDocumentList(DocumentList &list,unsigned int from, unsigned int size){return STATUS_FAILED;}
         Status CMAILViewBox::GetDocumentListToDelete(DocumentList &list)	{return STATUS_FAILED;}
         Status CMAILViewBox::CreateFolder(CString foldername){return STATUS_FAILED;}
         Status CMAILViewBox::CreateFolder(FolderRef& folder, CString foldername){return STATUS_FAILED;}
         Status CMAILViewBox::GetFolder(FolderRef& folder, CString foldername){return STATUS_FAILED;}
         Status CMAILViewBox::GetFolderList(FolderList &list){return STATUS_FAILED;}
         Status CMAILViewBox::GetFolderList(FolderList &list,unsigned int from, unsigned int size) {return STATUS_FAILED;}
         Status CMAILViewBox::DeleteFolder(CString foldername) {return STATUS_FAILED;}
         Status CMAILViewBox::SetWebDAVProperty(CString key, CString value) {return STATUS_FAILED;}
         Status CMAILViewBox::GetWebDAVProperty(CString key, CString &value) {return STATUS_FAILED;}
         Status CMAILViewBox::SetName(CString name) {return STATUS_FAILED;}
         Status CMAILViewBox::CutDocument(CString docname) {return STATUS_FAILED;}
         Status CMAILViewBox::CutDocument(std::vector<CString> documents) {return STATUS_FAILED;}
		 Status CMAILViewBox::CopyDocument(CString docname) {return STATUS_FAILED;}
         Status CMAILViewBox::CopyDocument(std::vector<CString> documents) {return STATUS_FAILED;}
         Status CMAILViewBox::PasteDocument() {return STATUS_FAILED;}
         Status CMAILViewBox::PasteDocument(std::vector<CString> &documentnames) {return STATUS_FAILED;}
         Status CMAILViewBox::LoadProperties() {return STATUS_FAILED;}
         Status CMAILViewBox::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) {return STATUS_FAILED;}
         Status CMAILViewBox::SaveProperties() {return STATUS_FAILED;}
         Status CMAILViewBox::GetSize(uint64 &size) {return STATUS_FAILED;}
         Status CMAILViewBox::SetWEPDocument(dom::NodeRef node) {return STATUS_FAILED;}
         //Status CMAILViewBox::GetWEPDocument(CString& documentID) {return STATUS_FAILED;}
         Status CMAILViewBox::CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, CString documentname) {return STATUS_FAILED;}
         Status CMAILViewBox::CreateArchive(operatingenvironment::Ref<Archiver> &archiver, CString target, std::vector<CString> documentlist) {return STATUS_FAILED;}
         Status CMAILViewBox::ExtractArchive(operatingenvironment::Ref<Extractor> &extractor,CString archiverpath,CString extractorpath) {return STATUS_FAILED;}
         Status CMAILViewBox::DeleteArchive(CString archivepath) {return STATUS_FAILED;}
         Status CMAILViewBox::CutDocument(ProgressRef& progress, CString docname) {return STATUS_FAILED;}
         Status CMAILViewBox::CutDocument(ProgressRef& progress, std::vector<CString> documents) {return STATUS_FAILED;}
		 Status CMAILViewBox::CopyDocument(ProgressRef& progress, CString docname) {return STATUS_FAILED;}
         Status CMAILViewBox::CopyDocument(ProgressRef& progress,std::vector<CString> documents) {return STATUS_FAILED;}
         Status CMAILViewBox::PasteDocument(ProgressRef& progress){return STATUS_FAILED;}
         Status CMAILViewBox::CreateDocument(DocumentRef& doc, CString &documentname) {return STATUS_FAILED;}
         Status CMAILViewBox::DeleteDocument(CString documentname) {return STATUS_FAILED;}
         Status CMAILViewBox::DeleteDocument(ProgressRef& progress,CString documentname) {return STATUS_FAILED;}
         bool CMAILViewBox::IsPasswordProtected() {return false;}
         Status CMAILViewBox::GetDocumentPreserveDays(CString &days) {return STATUS_FAILED;}
		 Status CMAILViewBox::GetPreservationPeriodFlag(CString &falg){ return STATUS_FAILED; }
         Status CMAILViewBox::GetLastModifiedDate(CString &date) {return STATUS_FAILED;}
         Status CMAILViewBox::ChangePassword(CString boxpassword) {return STATUS_FAILED;}
         bool CMAILViewBox::FolderExist(CString foldername) {return STATUS_FAILED;}
         Status CMAILViewBox::Unlock() {return STATUS_FAILED;}
         Status CMAILViewBox::UndoEditDocument(CString docname) {return STATUS_FAILED;}
         Status CMAILViewBox::UndoEditDocument(std::vector<CString> documents) {return STATUS_FAILED;}	
         //Status CMAILViewBox::GetBoxType(CString &boxtype) {return STATUS_FAILED;}
         Status CMAILViewBox::SetUserName(CString username) {return STATUS_FAILED;}
         //Status CMAILViewBox::GetUserName(CString &username) {return STATUS_FAILED;}
         Status CMAILViewBox::SetComment(CString comment) {return STATUS_FAILED;}
         //Status CMAILViewBox::GetComment(CString &comment) {return STATUS_FAILED;}
         bool CMAILViewBox::IsLocked() {return false;}	
         Status CMAILViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list) {return STATUS_FAILED;}
         Status CMAILViewBox::GetDocumentPropertiesList(DocumentPropertiesList &list,unsigned int from, unsigned int size) {return STATUS_FAILED;}
         Status CMAILViewBox::GetRelayReportDestination(CString &destination) {return STATUS_FAILED;}
         Status CMAILViewBox::GetRelayReportDestinationType(CString &dsttype) {return STATUS_FAILED;}
         Status CMAILViewBox::GetRelayReportContactId(CString &id) {return STATUS_FAILED;}											 
         Status CMAILViewBox::SetLastBackupDate(CString date) {return STATUS_FAILED;}
         Status CMAILViewBox::GetLastBackupDate(CString &date) {return STATUS_FAILED;}
         Status CMAILViewBox::GetPassword(CString &password) {return STATUS_FAILED;}
         Status CMAILViewBox::GetCreationDate(CString &date) {return STATUS_FAILED;}
         Status CMAILViewBox::GetNotificationEmailId(CString &emailId) {return STATUS_FAILED;}
         Status CMAILViewBox::GetDocumentCount(uint &numDoc) {return STATUS_FAILED;}
         Status CMAILViewBox::GetFolderCount(uint &numFolder) {return STATUS_FAILED;}				

   }; // namespace boxdocument
}; // namespace ci

