/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: webdavwrapper.cpp
 Revision: com_t#3
 File Spec: EBX:MA6040.A-DEV_SRC;com_t#3
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 19-DEC-2008 21:47:32

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
   4:
   	Baseline:      "EBX:SCI_PHASE4_V3246"
   	Creation Date: 25-DEC-2008 14:32:20
   	Description:   Baseline SCI_PHASE4_V3246_20081225_1431.AAAA
   
   5:
   	Baseline:      "EBX:SCI_PHASE4_V2246"
   	Creation Date: 22-DEC-2008 18:49:55
   	Description:   Baseline SCI_PHASE4_V2246_20081222_1849.AAAA
   
   6:
   	Baseline:      "EBX:SCI_PHASE4_V2246_20081222_1518"
   	Creation Date: 22-DEC-2008 15:19:04
   	Description:   Baseline SCI_PHASE4_V2246_20081222_1518.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#3 (APPROVED)
     Updated:  19-DEC-2008 21:47:33      CHANDRAMOHAN.PUJARI
       support for clipboard and workspace paths
     Created:  19-DEC-2008 21:47:32      CHANDRAMOHAN.PUJARI
       support for clipboard and workspace paths
     Updated:  19-DEC-2008 21:47:32      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
     Updated:  19-DEC-2008 21:47:32      CHANDRAMOHAN.PUJARI
       support for clipboard and workspace paths
   
   Revision com_t#2 (APPROVED)
     Created:  08-DEC-2008 21:08:46      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,BoxUsuage and Error Codes
     Updated:  08-DEC-2008 21:08:46      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,BoxUsuage and Error Codes
     Updated:  08-DEC-2008 21:08:46      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
     Updated:  08-DEC-2008 21:08:46      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,BoxUsuage and Error Codes
   
   Revision com_t#1 (APPROVED)
     Updated:  03-NOV-2008 18:57:51      CHANDRAMOHAN.PUJARI
       Received updated code from MSM. Checking in on behalf of MSM
     Created:  03-NOV-2008 18:57:48      CHANDRAMOHAN.PUJARI
       Received updated code from MSM. Checking in on behalf of MSM
     Updated:  03-NOV-2008 18:57:48      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
     Updated:  03-NOV-2008 18:57:48      CHANDRAMOHAN.PUJARI
       Received updated code from MSM. Checking in on behalf of MSM
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:59      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:34      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:15      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:17      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:41      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:08:31      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:34:51      13848
       Initial revision
========================== End of Source Header =============================*/
#include <map>
#include <algorithm>
#include <exception>
#include <iomanip>
#include <sstream>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/globalmutex.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <CI/SystemInformation/systeminformation.h>
#include "webdavwrapper.h"
#include "cdocument.h"
#include <CI/OperatingEnvironment/folder.h>
#include <stdlib.h>

using namespace ci::operatingenvironment;
using namespace ci::documentstore;
using namespace ci::systeminformation;
namespace ci {
namespace boxdocument {


Status WebDAVWrapper::GetDocument(Ref<ci::documentstore::Session> session, 
                                  DocumentRef& doc, 
                                  CString boxbasepath,
                                  CString boxnumber,
                                  CString foldername,
                                  CString documentname) {
    if(documentname.empty()) {
        DEBUGL1("WebDAVWrapper::GetDocument::Document name is empty\n");
        return STATUS_FAILED;
    }
    
    if(!ResourceExist(session, boxbasepath, boxnumber, foldername, documentname)) {
        DEBUGL1("WebDAVWrapper::GetDocument::Document is not found\n");
        return STATUS_FAILED;
    }
    CriticalSectionRef cs = new CriticalSection(boxbasepath, 
                                                boxnumber, 
                                                foldername,
                                                documentname);
    
    doc = new CDocument(session, boxbasepath, boxnumber, foldername, documentname);
    Status ret = dynamic_cast<CDocument*>(doc.operator->())->LoadProperties();
    if(ret != STATUS_OK) {
        DEBUGL1("WebDAVWrapper::GetDocument::Loading Document is failed\n");
        doc = NULL; // release
        return ret;
    }
    DocStatus st;
    if(doc->GetStatus(st) != STATUS_OK) {
        DEBUGL1("WebDAVWrapper::GetDocument::Getting document status is failed\n");
        doc = NULL;
        return STATUS_FAILED;
    }
    if(st == DELETING) {
        DEBUGL9("WebDAVWrapper::GetDocument::Document is deleting\n");
        doc = NULL;
        return STATUS_FAILED;
    }
    DEBUGL4("WebDAVWrapper::GetDocument:Exit\n");		
    return STATUS_OK;
}

Status WebDAVWrapper::CreateFolder(Ref<ci::documentstore::Session> session, 
                                   CString boxbasepath,
                                   CString boxnumber,
                                   CString foldername) {
    DSStatus ds;
    // get actual folder of boxbasepath
    CString path = "/" + boxbasepath + "/";
    if(!ResourceExist(session, path)) {
        DEBUGL1("WebDAVWrapper::CreateFolder::Invalid BoxBasePath\n");
        return STATUS_FAILED;
    }
    // confirm boxnumber folder exists
    if(!boxnumber.empty()) {
        path = path + boxnumber + "/";
        if(!ResourceExist(session, path)) {
            // if boxnumber folder doesn't exist, create the folder
            ds = session->CreateCollection(path.c_str());
            if(ds != DS_STATUS_CREATED)
				{
					 if((ds==ci::documentstore::STATUS_DISK_FULL)||(ds == DS_STATUS_INSUFFICIENT_STORAGE))
					 {
                	DEBUGL1("WebDAVWrapper::CreateFolder::Create folder %s return STATUS_DISK_FULL\n", path.c_str());
						return (::STATUS_DISK_FULL);
					 }
					 else
					 {
                	DEBUGL1("WebDAVWrapper::CreateFolder::Create folder %s is failed\n", path.c_str());
	               return STATUS_FAILED;
					 }
            }
        }
    } else {
        DEBUGL1("WebDAVWrapper::CreateFolder::Box number is empty()\n");
        return STATUS_FAILED;
    }
    
    // confirm foldername folder exists
    if(!foldername.empty()) {
        path = path + foldername + "/";
        if(!ResourceExist(session, path)) {
            // if foldername folder doesn't exist, create the folder
            ds = session->CreateCollection(path.c_str());
            if(ds != DS_STATUS_CREATED) {
					 if((ds==ci::documentstore::STATUS_DISK_FULL)||(ds == DS_STATUS_INSUFFICIENT_STORAGE))
					 {
                	DEBUGL1("WebDAVWrapper::CreateFolder::Create folder %s return STATUS_DISK_FULL\n", path.c_str());
						return (::STATUS_DISK_FULL);
					 }
					 else
					 {
                	DEBUGL1("WebDAVWrapper::CreateFolder::Create folder %s is failed\n", path.c_str());
	               return STATUS_FAILED;
					 }
            }
        }
    }
    
    DEBUGL4("WebDAVWrapper::CreateFolder::Exit\n");		
    return STATUS_OK;
}

Status WebDAVWrapper::CreateFile(Ref<ci::documentstore::Session> session, 
                                 CString path,
                                 CString filename) {
    // create file in temporary folder
    CString statuspath = getenv("EB2");
    statuspath += "/tmp/" + filename;
    CString createstatusfile = "touch " + statuspath;
    int r;
    ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
    sysinfo->RunCmd(createstatusfile, r);
    
    // put status file to document folder
    CString filepath = path + filename;
    DSStatus ds = session->PutResource(filepath.c_str(), statuspath.c_str());
    if((ds != DS_STATUS_OK) && (ds != DS_STATUS_CREATED)) {
					 if((ds==ci::documentstore::STATUS_DISK_FULL)||(ds == DS_STATUS_INSUFFICIENT_STORAGE))
					 {
                	DEBUGL1("WebDAVWrapper::CreateFile::Create file %s return STATUS_DISK_FULL\n", filepath.c_str());
						return (::STATUS_DISK_FULL);
					 }
					 else
					 {
        				DEBUGL1("WebDAVWrapper::CreateFile::put resource document %s is failed\n", filepath.c_str());
	               return STATUS_FAILED;
					 }
    }
    
    // delete file
    File::DeleteFile(statuspath);
    
    DEBUGL4("WebDAVWrapper::CreateFile::Exit\n");		
    return STATUS_OK;
}

bool WebDAVWrapper::ResourceExist(Ref<ci::documentstore::Session> session, CString path) {
    CString value;
    //phani: if the property value doesn't exist, it returns DS_STATUS_FAILED.
    //          if the resource itself is not found, 
    //			then webdav status is returned 404 Not Found(DS_STATUS_NOT_FOUND)
    if(session->GetProperty(path.c_str(), "resourceexists", value) == DS_STATUS_NOT_FOUND) {
        return false;
    }
    return true;
}

bool WebDAVWrapper::ResourceExist(Ref<ci::documentstore::Session> session, 
                              CString boxbasepath, 
                              CString boxnumber, 
                              CString foldername,
                              CString documentname)
{
    return ResourceExist(session, GetResourcePath(boxbasepath, boxnumber, foldername, documentname));
}

CString WebDAVWrapper::GetResourcePath(CString boxbasepath, 
                                       CString boxnumber, 
                                       CString foldername,
                                       CString documentname) {

CString docpath("");


	docpath = "/" + boxbasepath;

    if(boxnumber != "") {
        docpath += "/" + boxnumber;
    }
    if(foldername != "") {
        docpath += "/" + foldername;
    }
    if(documentname != "") {
        docpath +=  "/" + documentname;
    }
    return docpath;
}

CString WebDAVWrapper::GetResourceFullPath(CString boxbasepath, 
                                           CString boxnumber, 
                                           CString foldername,
                                           CString documentname) {
return GetResourceFullPath(GetResourcePath(boxbasepath, boxnumber, foldername, documentname));
}

CString WebDAVWrapper::GetResourceFullPath(CString path) 
{
	CString retPath;
	DEBUGL6("\nPath<%s>",path.c_str());
	size_t w=path.find("WorkSpace/");
	size_t c=path.find("ClipBoard/");
	if((w!=CString::npos)||(c!=CString::npos))
	     retPath = "/work" + path;		
	else	
    		retPath = BOXPATH + path;
	
	return retPath;
}

Status WebDAVWrapper::GetCollectionList(std::vector<CString> &vec,
                                        Ref<ci::documentstore::Session> session,
                                         CString path) {
    Ref<StringStream> stream = StringStream::Create();
    if(session->GetAllProperties(path.c_str(),1,stream) 
                                                != DS_STATUS_MULTI_STATUS) {
        DEBUGL1("WebDAVWrapper::GetCollectionList::Getting properties is failed\n");
        return STATUS_FAILED;
    }
    
    hierarchicaldb::HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
    hierarchicaldb::DocumentRef doc = NULL;
    Status st = hdb->CreateTempDocumentFromString(doc, stream->getStr());
    if (st != STATUS_OK) {
        DEBUGL1("WebDAVWrapper::GetCollectionList::create HDB document is failed\n");
        return st;
    }
    dom::NodeListRef nodelist = hdb->FindNodes(doc, "D:response/D:href");
    // get node name from nodelist
    for(unsigned int i = 0; i < nodelist->getLength(); i++) {
        dom::NodeRef node = nodelist->item(i);
		CString textVal = node->getTextContent();
        if(!((path == textVal)||(textVal == (path+"initializing.sts"))||(textVal == (path+"initialized.sts")))) {
	        DEBUGL1("WebDAVWrapper::GetCollectionList::inputPath<%s>,textVal<%s>\n",path.c_str(),textVal.c_str());				  	
            vec.push_back(textVal);
        }
    }
    std::sort(vec.begin(), vec.end());
    DEBUGL4("WebDAVWrapper::GetCollectionList::Exit\n");
    return STATUS_OK;
}


Status WebDAVWrapper::GetInfiniteCollectionList(std::vector<CString> &vec,
                                        Ref<ci::documentstore::Session> session,
                                         CString path) {
    Ref<StringStream> stream = StringStream::Create();
    if(session->GetAllProperties(path.c_str(), 2, stream) 
                                                != DS_STATUS_MULTI_STATUS) {
        DEBUGL1("getting properties is failed\n");
        return STATUS_FAILED;
    }
    
    hierarchicaldb::HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
    hierarchicaldb::DocumentRef doc = NULL;
    Status st = hdb->CreateTempDocumentFromString(doc, stream->getStr());
    if (st != STATUS_OK) {
        DEBUGL1("create HDB document is failed\n");
        return st;
    }
    dom::NodeListRef nodelist = hdb->BindToElementList(doc, "D:response/D:href");
    // get node name from nodelist
    for(unsigned int i = 0; i < nodelist->getLength(); i++) {
        dom::NodeRef node = nodelist->item(i);
        if(path != node->getTextContent()) {
            vec.push_back(node->getTextContent());
        }
    }
    std::sort(vec.begin(), vec.end());
    DEBUGL4("WebDAVWrapper::GetInfiniteCollectionList::Exit\n");
    return STATUS_OK;
}


Status WebDAVWrapper::EnterCriticalSection(CString boxbasepath, 
                                            CString boxnumber, 
                                            CString foldername,
                                            CString documentname,
                                            CString option) {
    CString path = boxbasepath + ":" + boxnumber + ":" + foldername + ":" + documentname + ":" + option;
    return EnterCriticalSection(path);
}

Status WebDAVWrapper::EnterCriticalSection(CString path) {
    CString moniker_str = "BoxDocMutex" + path;
    GlobalMutexRef mutex = GlobalMutex::Create(moniker_str);
    if(!mutex) {
        MonikerRef moniker = Moniker::Create(SCHEMA_IPMUTEX, moniker_str.c_str());
        mutex = GlobalMutex::Bind(moniker); 
    }
	if(mutex) 
	    return mutex->Acquire();
	else
	{
		DEBUGL1("WebDAVWrapper::EnterCriticalSection - Mutex is empty\n");
		return STATUS_FAILED;
	}
}

Status WebDAVWrapper::LeaveCriticalSection(CString boxbasepath, 
                                           CString boxnumber, 
                                           CString foldername,
                                           CString documentname,
                                           CString option) {
    CString path = boxbasepath + ":" + boxnumber + ":" + foldername + ":" + documentname + ":" + option;
    return LeaveCriticalSection(path);
}

Status WebDAVWrapper::LeaveCriticalSection(CString path) {
    CString moniker_str = "BoxDocMutex" + path;
    GlobalMutexRef mutex = GlobalMutex::Create(moniker_str);
    if(!mutex) {
        MonikerRef moniker = Moniker::Create(SCHEMA_IPMUTEX, moniker_str.c_str());
        mutex = GlobalMutex::Bind(moniker); 
    }
	 
	if(mutex) 
	{	
	    mutex->Release();
	    return mutex->Destroy();
	} 
	else
	{
		DEBUGL1("WebDAVWrapper::LeaveCriticalSection - Mutex is empty\n");
		return STATUS_FAILED;	
	}
}

bool WebDAVWrapper::IsOK(DSStatus ds) {
    return (ds >= 200) && (ds < 300);
}

CString WebDAVWrapper::GetUnusedFileNo(Ref<ci::documentstore::Session> session, 
                                       CString path) {
    int fileno = 1;
    CString filenostr;
    CString imagepath;
    while(true) {
        filenostr = Utility::GetHexadecimalPageNo(fileno);
        imagepath = path + filenostr;
        if(!ResourceExist(session, imagepath)) {
            break;
        }
        fileno++;
        if(fileno > 99999) {
            DEBUGL1("the number of pages reaches to limit\n");
            return "";
        }
    }
    return filenostr;
}

//-----------------------------------------------------------------------------
IsFolder::IsFolder(Ref<ci::documentstore::Session> &session) : 
                                                m_Session(session)
{
    
}

bool IsFolder::operator()(CString path) const {
    return !WebDAVWrapper::ResourceExist(m_Session, path + ".document");
}

//-----------------------------------------------------------------------------
IsDocument::IsDocument(Ref<ci::documentstore::Session> &session) : 
                                                m_Session(session)
{
    
}

bool IsDocument::operator()(CString path) const {
    return WebDAVWrapper::ResourceExist(m_Session, path + ".document");
}

//-----------------------------------------------------------------------------
CriticalSection::CriticalSection(CString path) : key(path) {
    WebDAVWrapper::EnterCriticalSection(key); // TODO: Error check
}

CriticalSection::CriticalSection(CString boxbasepath, 
                                 CString boxnumber, 
                                 CString foldername,
                                 CString documentname,
                                 CString option) {
    key = boxbasepath + ":" + boxnumber + ":" + foldername + ":" + documentname + ":" + option;
    WebDAVWrapper::EnterCriticalSection(key); // TODO: Error check
}

CriticalSection::~CriticalSection() {
    WebDAVWrapper::LeaveCriticalSection(key);
}

//-----------------------------------------------------------------------------
CString Utility::GetLocalTime() {
    CString local;
    SysInfoRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
    try {
        sysinfo->Get("System/Clock:localtime", local);
    } catch (std::exception e) {
        local = "";
    }
    return local;
}

CString Utility::GetUnixTime() {
    CString unixtime;
    SysInfoRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
    try {
        sysinfo->Get("System/Clock:time", unixtime);
    } catch (std::exception e) {
        unixtime = "";
    }
    return unixtime;
}

CString Utility::Get5DigitPageNo(int pageno) {
    std::ostringstream strm;
    strm << std::setfill('0') << std::setw(5) << pageno;
    return strm.str();
}

CString Utility::GetFolderPath(CString filename) {
    int idx = filename.rfind("/");
    return filename.substr(0, idx);
}

CString Utility::GetTmpPath() {
    CString tmppath = getenv("EB2");
    tmppath += "/tmp/";
    return tmppath;
}

CString Utility::GetCITmpPath() {
    CString tmppath = "/work/ci/tmp/";
    return tmppath;
}

CString Utility::GetHDBROOTPath() {
    CString hdbrootpath = getenv("EB2");
    hdbrootpath += "/HDBROOT/";
    return hdbrootpath;
}

CString Utility::GetEB2ROOTPath() {
    CString eb2rootpath = getenv("EB2");
    return eb2rootpath;
}

CString Utility::GetHexadecimalPageNo(int pageno)
{
	std::ostringstream strm;
	strm << std::setfill('0') << std::setw(3) << std::hex << pageno;
	return strm.str();
}

Status Utility::ResourceSize(Ref<ci::documentstore::Session> session,CString boxbasepath, CString boxnumber, CString foldername,CString documentname, CString filename,uint64 &ressize)
{

	int size=0;
	CString path = WebDAVWrapper::GetResourcePath(boxbasepath,boxnumber,foldername,documentname) + "/";
	CString resourceKey=path+filename;

	CString tmppath = Utility::GetCITmpPath();
	tmppath+="BoxDocument" + CBoxDocument::m_sessionID;
	ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> pFolder;
	DEBUGL1("Utility::ResourceSize - TmpPath <%s>\n",tmppath.c_str());

	Status retStat = STATUS_OK;
	if ((retStat = ci::operatingenvironment::Folder::CreateFolder(pFolder, tmppath)) != STATUS_OK)
	{
		if( retStat == ::STATUS_DISK_FULL)
			DEBUGL1("Utility::ResourceSize - Cannot create directory, disk is full\n");
		return retStat;
	}

	CString uniqueStr = boxbasepath+"_"+boxnumber+"_"+foldername+"_"+documentname+"_";
	CString localPath = tmppath+"/"+uniqueStr+"tmpfile";

	//Execute WebDav GET command to download the resource to Temp Path
	DSStatus ds = session->GetResource(resourceKey.c_str(),localPath.c_str());
	if((ds==ci::documentstore::STATUS_DISK_FULL)||(ds == DS_STATUS_INSUFFICIENT_STORAGE))
	{
		DEBUGL1("Utility::ResourceSize - GetResource returned DISKFULL Error\n");
		if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
			DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());

		return (::STATUS_DISK_FULL);
	}
	else
	{
		if(!WebDAVWrapper::IsOK(ds))
		{
			DEBUGL1("Utility::ResourceSize - GetResource (Downloading) failed\n");
			if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
				DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());

		return STATUS_FAILED;
		}
	}	

	//Form the path to execute System command to read the file size
	CString filepath = tmppath+"/"+uniqueStr+"size";
	CString cmd = "du -b "+localPath+" | cut -f1 >"+filepath;
	DEBUGL6("Utility::ResourceSize - Command that being executed is %s\n",cmd.c_str());
	system(cmd.c_str());

	//Now the Size of the Box is present in a file
	//Open this file and read the size
	pFolder = ci::operatingenvironment::Folder::Bind(tmppath);
	if(pFolder)
		DEBUGL6("Utility::ResourceSize - Tmp Folder Bind successful\n");
	else
	{
		DEBUGL1("Utility::ResourceSize - Tmp Folder Bind failed\n");
		if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
			DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());

		return STATUS_FAILED;
	}

	CString fileBindPath = uniqueStr+"size";
	FilePtr fp = File::Bind(fileBindPath ,pFolder,"r");
	if (fp)
		DEBUGL6("Utility::ResourceSize - File bind successfull\n");
	else
	{	
		DEBUGL1("Utility::ResourceSize - Unable to locate xml file!\n");
		if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
			DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());

		return STATUS_FAILED;
	}
	CString filecontent;
	char *content;
	uint32 filesize=250;
	content = new char[filesize];
	memset(content,'\0',filesize);	

	if(fp->Read(content,filesize)!=STATUS_OK)
	{
		DEBUGL1("Utility::ResourceSize - Error reading file %s\n",filepath.c_str());
		if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
			DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());
		return STATUS_FAILED;
	}
	else
	{	
		//Now convert String to Int and return the Value
		filecontent=content;
		std::istringstream iss(filecontent);
		iss >> size;
		DEBUGL6("Utility::ResourceSize - Content of file is = %s and its integer value =%d\n",filecontent.c_str(),size);
	}

	//Delete the tmp Folder created
	if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
		DEBUGL2("Utility::ResourceSize - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());

	ressize=size;
    	DEBUGL4("Utility::ResourceSize::Exit\n");
	return STATUS_OK;
}
}; // end of namespace boxdocument
}; // end of namespace ci


