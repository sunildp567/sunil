#include <iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>
#include "systemdatafile.h"

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

//-----------------------------------------------------------------------------
// test case of insert page
// DL side
bool test_insertpage_DL(CString BoxBasePath1, 
                        CString BoxNumber1, 
                        CString FolderName1, 
                        CString DocumentName1,
                        int from,
                        CString BoxBasePath2, 
                        CString BoxNumber2, 
                        CString FolderName2, 
                        CString DocumentName2,
                        int to) 
{
    // Acquire the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // Get source document instance
    ci::boxdocument::DocumentRef doc1;
    if(boxdoc->GetDocument(doc1, BoxBasePath1, 
                                BoxNumber1, 
                                FolderName1, 
                                DocumentName1) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetDocument() is failed\n");
        return false;
    }
    
    // Get source page
    PageList pages;
    if(doc1->GetPageList(pages) != STATUS_OK) {
        DEBUGL1("getting page list is failed\n");
        return false;
    }
    PageList::iterator it = pages.begin();
    for(int i = 1; it != pages.end(); i++, it++) {
        if(i == from) {
            break;
        }
    }
    
    // Get destination document instance
    ci::boxdocument::DocumentRef doc2;
    if(boxdoc->GetDocument(doc2, BoxBasePath2, 
                                BoxNumber2, 
                                FolderName2, 
                                DocumentName2) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetDocument() is failed\n");
        return false;
    }
    if(doc2->InsertPage(to, (*it)) != STATUS_OK) {
        DEBUGL1("Document::InsertPage() is failed\n");
        return false;
    }
    
    return true;
}

bool test_insertpage() {
    CString BoxBasePath = "EFilingBoxes";
    CString BoxNumber1, FolderName1, DocumentName1;
    CString BoxNumber2, FolderName2, DocumentName2;
    int from, to;
    cout << "Enter Source BoxNumber" << endl;
    cin >> BoxNumber1;
    cout << "Enter Source FolderName" << endl;
    cin >> FolderName1;
    cout << "Enter Source DocumentName" << endl;
    cin >> DocumentName1;
    cout << "Enter Source Page Number" << endl;
    cin >> from;
    
    cout << "Enter Destination BoxNumber" << endl;
    cin >> BoxNumber2;
    cout << "Enter Destination FolderName" << endl;
    cin >> FolderName2;
    cout << "Enter Destination DocumentName" << endl;
    cin >> DocumentName2;
    cout << "Enter Destination Page Number" << endl;
    cin >> to;
    
    return test_insertpage_DL(BoxBasePath, 
                              BoxNumber1, 
                              FolderName1, 
                              DocumentName1,
                              from,
                              BoxBasePath, 
                              BoxNumber2, 
                              FolderName2, 
                              DocumentName2,
                              to);
}
