// test case of edit document

#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>

using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

// AL side
bool test_editdocument_AL() {
    // AL knowledge
    CString BoxBasePath = "EFilingBoxes";
    CString BoxNumber = "00000";
    CString FolderName = "";
    CString DocumentName = "00000";
    
    // 1: get an instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(!boxdoc) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // 1.1: get an instance of Document
    DocumentRef doc;
    if(boxdoc->GetDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetDocument() is failed\n");
        return false;
    }
    
    // 1.2: edit document
    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
    /*
    // editing the document
    if(doc->CutPage(2)) {
        DEBUGL1("Document::CutPage() is failed\n");
        return false;
    }
    
    if(doc->PastePage(1)) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }
    
    // 3: reflect delta document to original document
    if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }
    */
    if(doc->CancelEdit() != STATUS_OK) {
        DEBUGL1("Document::CancelEdit() is failed\n");
        return false;
    }
    return true;
}

bool test_editdocument() {
    return test_editdocument_AL();
}


