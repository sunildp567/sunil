// Copyright 2008 TOSHIBA TEC CORPORATION All rights reserved //

/* TODO: A class that implements CPU reservation for System Resource Manager
 * 
 * Note: Not required for CP3 and features/kind of support in Linux Kernel may impact CPU part of SRM design
 */
#include <cpu.h>

namespace ci
{
namespace systemresourcemanager
{
	Cpu::Cpu(ci::hierarchicaldb::HierarchicalDBRef mainHDBRef, dom::DocumentRef mainDomRef)
	{
	}
	
	Cpu::~Cpu()
	{
	}
	
	
} //SystemResourceManager
} //CI

