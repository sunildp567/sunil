#include "flconverter.h"
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>

using namespace ci::operatingenvironment;
namespace ci {
	namespace boxdocument {
		int FLConverter::ConvertSystemFile(CString inputFile, CString outputFile) 
		{
			FL_FILE_MAN_FILE fl;
			if(readFLStructure(fl, (char *)inputFile.c_str())) 
			{
				return -1;
			}
			convertFL_FILE_MAN_FILE(fl);
			if(writeFLStructure(fl, (char *)outputFile.c_str()) < 0) {
				return -1;
			}
			return 0;
		}
	}
}
