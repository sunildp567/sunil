/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: proputils.cpp
========================== End of Source Header =============================*/

#include <map>
#include <algorithm>
#include <exception>
#include <iomanip>
#include <sstream>
#include <errno.h>
#include <sys/file.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/globalmutex.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <CI/SystemInformation/systeminformation.h>
#include "proputils.h"
#include "cdocument.h"
#include <CI/OperatingEnvironment/folder.h>
#include <iostream>
#include <exception>
#include <stdlib.h>
#include "CI/OperatingEnvironment/cexception.h"
#include "CI/SystemInformation/systeminformation.h"

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::systeminformation;
using namespace ci::hierarchicaldb;
using namespace dom;
namespace ci {
    namespace boxdocument {

        using namespace statusfilename;
        /**
         * Retrieve all the properties for the given box.
         * @param[in] boxbasepath - base path for the box e.g. "EFilingBoxes" or "ITUTBoxes"
         * @param[in] boxnumber - string of 1-20 digits box number
         * @param[out] PropertyMap - Map containing all properties related to given box.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status proputils::GetAllBoxProperties(CString boxbasepath,CString boxnumber, std::map<CString, CString> &PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,"","") ;
            CString xmlfile = "boxproperties.xml";
            st = Utility::GetAllProperties(folderpath, xmlfile,PropertyMap);
            return st;

        }

        Status proputils::GetAllFolderProperties(CString boxbasepath,CString boxnumber,CString foldername,std::map<CString, CString> &PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,foldername,"") ;
            CString xmlfile = "folderproperties.xml";
            st = Utility::GetAllProperties(folderpath, xmlfile,PropertyMap);
            return st;
        }

        Status proputils::GetAllDocumentProperties(CString boxbasepath,CString boxnumber,CString folder,CString documentpath,std::map<CString, CString> &PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,folder,documentpath);
            CString xmlfile = "documentproperties.xml";
            st = Utility::GetAllProperties(folderpath, xmlfile,PropertyMap);
            return st;
        }

        Status proputils::GetAllPageProperties(CString boxbasepath,
                CString boxnumber,
                CString folder,
                CString documentpath,
                CString pagepath,
                std::map<CString, CString> &PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,folder,documentpath);
            folderpath += "/"+pagepath;
            CString xmlfile = "pageproperties.xml";
            st = Utility::GetAllProperties(folderpath, xmlfile,PropertyMap);
            return st;
        }

        Status proputils::GetProperties(CString boxbasepath,
                CString boxnumber,
                CString folder,
                CString documentpath,
                CString pagepath,
                std::map<CString, CString> &PropertyMap)
        {
            std::map<CString, CString>::iterator PropertyMapIter;
            for(PropertyMapIter=PropertyMap.begin();PropertyMapIter!=PropertyMap.end();PropertyMapIter++)
            {	
                CString NodeName=PropertyMapIter->first;
                CString Value="";
                GetProperty(boxbasepath,boxnumber,folder,documentpath,pagepath,NodeName,Value);
                PropertyMapIter->second = Value;
                DEBUGL8("proputils::GetProperties: Value of Nodename (%s)  is (%s)\n",NodeName.c_str(),Value.c_str());
            }
            return STATUS_OK;
        }
        Status proputils::GetProperty(CString boxbasepath,
                CString boxnumber,
                CString folder,
                CString documentpath,
                CString pagepath,
                CString NodeName,
                CString &Value)
        {

            Status st;
            CString docpath("");
            CString xmlfile("");

            std::vector <CString> val;
            st=Utility::Getxmlfile(boxbasepath,boxnumber,folder,documentpath,pagepath,val);
            if(st!=STATUS_OK)
            {
                DEBUGL1("proputils::GetProperty::Getxmlfile failed\n");
                return STATUS_FAILED;
            }

            std::vector<CString>::iterator it;
            it = val.begin();
            docpath = *it;
            *it++;
            xmlfile =*it;

            CString fullpath = boxbasepath +"/"+ boxnumber;
            if(folder != "")
                fullpath += "/" + folder;
            if(documentpath != "")
                fullpath += "/" + documentpath;
            if(pagepath != "")
                fullpath += "/" + pagepath;

            CString pLockpath = fullpath;
            fullpath += "/" + xmlfile;

	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
	    hierarchicaldb::HierarchicalDBRef hdb;
	    dom::DocumentRef doc;
	    DEBUGL8("proputils::GetProperty:: fullpath = (%s)\n",fullpath.c_str());
	    try {
		    if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
		    {
			    DEBUGL8("proputils::GetProperty::failed to open %s\n",fullpath.c_str());
		    }
		    else
			    DEBUGL8("proputils::GetProperty::successfully opened %s\n",fullpath.c_str());

		    if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eREAD, true) != STATUS_OK)
		    {
			    DEBUGL1("proputils::GetProperty::Failed BeginTransaction element\n");
			    return STATUS_FAILED;
		    }
		    NodeRef rootNode = doc->getDocumentElement();
		    if(!rootNode)
		    {
			    DEBUGL1("proputils::GetProperty::Failed to get document element\n");
			    if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			    {
				    DEBUGL1("proputils::GetProperty::Failed EndTransaction element\n");
				    return STATUS_FAILED;
			    }
			    return STATUS_FAILED;
		    }
		    NodeRef node = hdb->BindToElement(rootNode,NodeName);
		    if(!node)
		    {
			    DEBUGL1("proputils::GetProperty:: Invalid node name\n");
			    if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			    {
				    DEBUGL1("proputils::GetProperty::Failed EndTransaction element\n");
				    return STATUS_FAILED;
			    }
			    return STATUS_FAILED;
		    }

		    Value = node->getTextContent();
		    if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
		    {
			    DEBUGL1("proputils::GetProperty::Failed EndTransaction element\n");
			    return STATUS_FAILED;
		    }
	    }
            catch(CException & except)
            {
		    DEBUGL1("\nproputils::GetProperty: Caught HDB exception\n");
		    hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                    return STATUS_FAILED;
            }
            catch(DOMException except)
            {
		    DEBUGL1("\nproputils::GetProperty: Failed due to DOM Exception\n");
		    hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                    return STATUS_FAILED;
            }
            DEBUGL8("proputils::GetProperty:: Value of (%s) = (%s)\n",NodeName.c_str(),Value.c_str());
            return STATUS_OK;
        }
        Status proputils::SetProperty(CString boxbasepath,
                CString boxnumber,
                CString folder,
                CString documentpath,
                CString pagepath,
                CString NodeName,
                CString Value)
        {
            Status st;
            CString docpath("");
            CString xmlfile("");

            std::vector <CString> val;
            st=Utility::Getxmlfile(boxbasepath,boxnumber,folder,documentpath,pagepath,val);
            if(st!=STATUS_OK)
            {
                DEBUGL1("proputils::SetProperty::Getxmlfile failed\n");
                return STATUS_FAILED;
            }

            std::vector<CString>::iterator it;
            it = val.begin();
            docpath = *it;
            *it++;
            xmlfile =*it;

            CString fullpath = boxbasepath +"/"+ boxnumber;
            if(folder != "")
                fullpath += "/" + folder;
            if(documentpath != "")
                fullpath += "/" + documentpath;
            if(pagepath != "")
                fullpath += "/" + pagepath;

            CString pLockpath = fullpath;

            fullpath += "/" + xmlfile;
	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
	    CString serializedFilePath = pLockpath + "/" + xmlfile;
	    hierarchicaldb::HierarchicalDBRef hdb;
	    dom::DocumentRef doc = NULL;
	    NodeRef rootNode = NULL;
	    DEBUGL8("proputils::SetProperty:: fullpath = (%s)\n",fullpath.c_str());
            try {
		    if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
		    {
			    DEBUGL8("proputils::SetProperty::failed to open %s\n",fullpath.c_str());
		    }
		else
			DEBUGL8("proputils::SetProperty::successfully opened %s\n",fullpath.c_str());

		if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eWRITE, true) != STATUS_OK)
                {
			DEBUGL1("proputils::SetProperty::Failed BeginTransaction element\n");
			return STATUS_FAILED;
                }
		rootNode = doc->getDocumentElement();
		if(!rootNode)
		{
			DEBUGL1("proputils::SetProperty::Failed to get document element\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
                        {
				DEBUGL1("proputils::SetProperty::Failed EndTransaction element\n");
				return STATUS_FAILED;
                        }
			return STATUS_FAILED;
                }
		NodeRef node = hdb->BindToElement(rootNode,NodeName);
		if(!node)
		{
			DEBUGL1("Utility::SetProperty:: Invalid node name\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
			{
				DEBUGL1("proputils::SetProperty::Failed EndTransaction element\n");
				return STATUS_FAILED;
                        }
                        return STATUS_FAILED;
                    }
		node->setTextContent(Value);
		if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
                {
			DEBUGL1("proputils::SetProperty::Failed EndTransaction element\n");
			return STATUS_FAILED;
                }
		DEBUGL8("proputils::SetProperty:: set name (%s) with value (%s) in (%s)\n\n",NodeName.c_str(), Value.c_str(),fullpath.c_str());
		if(hdb->SerializeToFile(rootNode, serializedFilePath) != STATUS_OK)
		{
			DEBUGL1("proputils::SetProperty:: SerializeToFile Failed\n");
			return STATUS_FAILED;
		}
            }
            catch(CException & except)
            {
                DEBUGL1("\nproputils::SetProperty: Caught HDB exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE);
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nproputils::SetProperty: Failed due to DOM Exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE);
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }


        Status proputils::GetPageProperty(CString path,
                CString xmlfile,
                CString NodeName,
                CString &propertyvalue)
        {
		CString fullpath = path + "/" + xmlfile;
		size_t pos = xmlfile.rfind(".");
		CString domfilename = xmlfile.substr(0,pos) + "_dom";
		DEBUGL8("proputils::GetPageProperty:: fullpath = (%s)\n",fullpath.c_str());
		Status st;
		CString pLockpath(path);
		CString serializedFilePath = pLockpath + "/" + xmlfile;
		hierarchicaldb::HierarchicalDBRef hdb;
		dom::DocumentRef doc;
		try {
			if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
			{
				DEBUGL8("proputils::GetPageProperty::failed to open %s\n",fullpath.c_str());
			}
			else
				DEBUGL8("proputils::GetPageProperty::successfully opened  %s\n",fullpath.c_str());

			if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eREAD, true) != STATUS_OK)
			{
				DEBUGL1("proputils::GetPageProperty::Failed BeginTransaction element\n");
				return STATUS_FAILED;
			}
			NodeRef rootNode = doc->getDocumentElement();
			if(!rootNode)
			{
				DEBUGL1("proputils::GetPageProperty::Failed to get document element\n");
				if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
				{
					DEBUGL1("proputils::GetPageProperty::Failed EndTransaction element\n");
					return STATUS_FAILED;
				}
				return STATUS_FAILED;
			}
			NodeRef node = hdb->BindToElement(rootNode,NodeName);
			if(!node)
			{
				DEBUGL1("Utility::GetPageProperty:: Invalid node name\n");
				return STATUS_FAILED;
			}
			propertyvalue = node->getTextContent();
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("proputils::GetPageProperty::Failed EndTransaction element\n");
				return STATUS_FAILED;
			}
		}
		catch(CException & except)
		{
			DEBUGL1("\nproputils::GetPageProperty::Caught HDB exception\n");
			hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
			return STATUS_FAILED;
		}
		catch(DOMException except)
		{
			DEBUGL1("\nproputils::GetPageProperty::Failed due to DOM Exception\n");
			hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
			return STATUS_FAILED;
		}
            DEBUGL8("proputils::GetPageProperty:: Value = (%s)\n",propertyvalue.c_str());	
            return STATUS_OK;
        }


        Status proputils::SetBoxProperties(CString boxbasepath,CString boxnumber,std::map<CString, CString> PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,"","") ;
            CString xmlfile = "boxproperties.xml";
            st = Utility::SetProperties(folderpath,xmlfile,PropertyMap);	
            return st;

        }
        Status proputils::SetFolderProperties(CString boxbasepath,CString boxnumber,CString foldername,std::map<CString, CString> PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,foldername,"") ;
            CString xmlfile = "folderproperties.xml";
            st = Utility::SetProperties(folderpath,xmlfile,PropertyMap);
            return st;

        }

        Status proputils::SetDocumentProperties(CString boxbasepath, CString boxnumber, CString foldername, CString documentname,  std::map< CString, CString > PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,foldername,documentname) ;
            CString xmlfile = "documentproperties.xml";
            st = Utility::SetProperties(folderpath,xmlfile,PropertyMap);	
            return st;

        }

        Status proputils::SetPageProperties(CString boxbasepath, CString boxnumber, CString foldername, CString documentname, CString PageNum,  std::map< CString, CString > PropertyMap)
        {
            Status st;
            CString folderpath = Utility::GetResourcePath(boxbasepath,boxnumber,foldername,documentname) ;
            folderpath += "/"+PageNum;
            CString xmlfile = "pageproperties.xml";
            st = Utility::SetProperties(folderpath,xmlfile,PropertyMap);	
            return st;
        }

        /**
         *	UTILITY CLASSS FUNCTIONALITIES
         *
         **/
        Status Utility::GetFolderCount(CString boxbasepath,CString boxnumber,unsigned int &count)
        {
            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            count =0;
            CString Path = Utility::GetResourcePath(boxbasepath,boxnumber,"","");
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,Path) != STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetFolderCount::Getting collection list is failed");
                return STATUS_FAILED;
            }

            CString documentPath;
            CString stsfile;
            for(dIt= vec.begin();dIt != vec.end(); dIt++) 
            {
                documentPath = Utility::GetResourcePath(boxbasepath,boxnumber,(*dIt),"");
                stsfile = documentPath + "/.document";
                if(Utility::ResourceExist(stsfile) !=true)
                {
                    count++;
                }
            }	
            return STATUS_OK;
        }

        Status Utility::GetDocumentCount(CString boxbasepath, CString boxNumber, CString folderpath, unsigned int & count, bool underbox)
        {
            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString> vecDocUnderFolder;
            std::vector<CString>::iterator dIt;
            std::vector<CString>::iterator dItDocUnderFolder;
            count = 0;
            CString Path;
            if(folderpath.empty())
                Path = Utility::GetResourcePath(boxbasepath,boxNumber,"","");
            else
                Path = Utility::GetResourcePath(boxbasepath,boxNumber,folderpath,"");

            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,Path)!= STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetDocumentCount::Getting collection list is failed");
                return STATUS_FAILED;
            }

            CString documentPath;
            CString stsfile;
            for(dIt= vec.begin();dIt != vec.end(); dIt++) 
            {
                if(folderpath.empty())
                {
                    documentPath = Utility::GetResourcePath(boxbasepath,boxNumber,(*dIt),"");
                    DEBUGL8("CBoxDocument::GetDocumentCount: Documents from box path = (%s)\n", documentPath.c_str());
                }
                else
                {
                    documentPath = Utility::GetResourcePath(boxbasepath,boxNumber,folderpath, (*dIt));
                    DEBUGL8("CBoxDocument::GetDocumentCount: Documents from folder path = (%s)\n", documentPath.c_str());
                }

                stsfile = documentPath + "/.document";
                if(Utility::ResourceExist(stsfile) ==true)
                    count++;
                else if(underbox == true)
                {
                    vecDocUnderFolder.clear();
                    if(Utility::GetCollectionList(vecDocUnderFolder, documentPath)!= STATUS_OK)
                    {
                        DEBUGL1("CBoxDocument::GetDocumentCount::Getting collection list is failed");
                        return STATUS_FAILED;
                    }
                    for(dItDocUnderFolder = vecDocUnderFolder.begin();dItDocUnderFolder != vecDocUnderFolder.end(); dItDocUnderFolder++)
                    { 
                        DEBUGL8("CBoxDocument::GetDocumentCount: Documents from folder path = (%s)\n", (*dItDocUnderFolder).c_str());
                        //Document under folder
                        CString documentPathUnderFolder = Utility::GetResourcePath(boxbasepath,boxNumber,(*dIt),(*dItDocUnderFolder));
                        CString docunderfoldersts = documentPathUnderFolder + "/.document";

                        if(Utility::ResourceExist(docunderfoldersts))
                            count++;
                    }
                }
            }
            return STATUS_OK;
        }

        Status Utility::GetDocument(CString sessionID, DocumentRef& doc,CString boxbasepath,CString boxnumber,CString foldername,CString documentname) 
        {
            DEBUGL4("Utility::GetDocument Enter\n");
            if(documentname.empty()) 
            {
                DEBUGL1("Utility::GetDocument::Document name is empty\n");
                return STATUS_FAILED;
            }

            if(!(Utility::ResourceExist(boxbasepath, boxnumber, foldername, documentname))) 
            {
                DEBUGL1("Utility::Document is not found\n");
                return STATUS_RESOURCENOTFOUND;
            }
            try
            {
                doc = new CDocument(sessionID, boxbasepath, boxnumber, foldername, documentname);
                if(!doc)
                {
                    DEBUGL1("Utility::Document object is NULL\n");
                    return STATUS_FAILED;
                }
                Status ret = dynamic_cast<CDocument*>(doc.operator->())->LoadProperties();
                if(ret != STATUS_OK) 
                {
                    DEBUGL1("Utility::GetDocument::Loading Document is failed\n");
                    doc = NULL; // release
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("Utility::GetDocument: caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }
            DocStatus st;
            if(doc->GetStatus(st) != STATUS_OK) 
            {
                DEBUGL1("Utility::GetDocument::Getting document status is failed\n");
                doc = NULL;
                return STATUS_FAILED;
            }
            if(st == ci::boxdocument::DELETING) 
            {
                DEBUGL1("Utility::GetDocument::Document is deleting\n");
                doc = NULL;
                return STATUS_FAILED;
            }
            DEBUGL4("Utility::GetDocument:Exit\n");		
            return STATUS_OK;
        }

        Status Utility::Getxmlfile(CString boxbasepath,
                CString boxnumber,
                CString folder,
                CString documentpath,
                CString pagepath,
                std::vector<CString> &values)
        {
            CString docpath("");
            CString xmlfile("");

            docpath = boxbasepath;
            if(documentpath!= "")
            {
                if(folder!= "")
                    docpath +=  "/" + boxnumber+"/" +folder+"/"+documentpath;
                else
                    docpath +=  "/" + boxnumber+ "/" +documentpath;

                if(pagepath != "") 
                {
                    docpath += "/" + pagepath;
                    xmlfile = "pageproperties.xml";
                }
                else		
                    xmlfile = "documentproperties.xml";
            }
            else
            {
                if(folder!= "")
                {
                    docpath +=  "/" + boxnumber+ "/" +folder;
                    xmlfile = "folderproperties.xml";
                }
                else
                {
                    docpath += "/" +  boxnumber;
                    xmlfile = "boxproperties.xml";
                }

            }
            values.clear();
            values.push_back(docpath);
            values.push_back(xmlfile);
            DEBUGL8("Utility::Getxmlfile:: Documentpath - %s and xmlfile - %s \n",docpath.c_str(),xmlfile.c_str());
            return STATUS_OK;	
        }
        Status Utility::GetCollectionList(std::vector<CString> &vec,CString path) 
        {
            DEBUGL4("Utility::GetCollectionList::Enter\n");
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
            FolderPtr = ci::operatingenvironment::Folder::Bind(path);
            if(!FolderPtr)
            {
                DEBUGL1("Utility::GetCollectionList::<%s> Folder Binding Failed\n",path.c_str());
                return STATUS_FAILED;
            }
            if(FolderPtr->GetSubFolders(vec)!=STATUS_OK)
            {
                DEBUGL1("Utility::GetCollectionList::Getting Files inside <%s> Folder Failed\n",path.c_str());
                return STATUS_FAILED;
            }
            std::vector<CString>::iterator pIt;
            for(pIt = vec.begin(); pIt != vec.end();)
            {
                DEBUGL8("Utility::GetCollectionList::Boxname is %s\n",(*pIt).c_str());
                if(((*pIt).compare("initializing.sts")==0)||(((*pIt).compare("initialized.sts")==0))){
                    vec.erase(pIt);
		}
		else{
		    pIt++;
		}
            }
            std::sort(vec.begin(), vec.end());
            DEBUGL4("Utility::GetCollectionList::Exit\n");
            return STATUS_OK;
        }

        Status Utility::GetDocumentList(std::vector<CString> &vec,CString path) 
        {
           DEBUGL4("Utility::GetDocumentList::Enter\n");
           int Ret;
           int Ret1;
           std::vector<CString>::iterator pIt;
           std::vector<CString>::iterator pIt1;
           std::vector<CString>::iterator pIt2;
	   std::vector<CString>::iterator pfirstvecIt;
	   std::vector<CString>::iterator psecvecIt;
	   std::vector<CString>::iterator pflatfilesvecIt;

           CString boxpath;
           CString folderpath;
           CString docpath;

           std::vector<CString> boxvec;
           std::vector<CString> folddocvec;
           std::vector<CString> docvec;
	   std::vector<CString> firstvec;
	   std::vector<CString> secvec;
	   std::vector<CString> flatfilesvec;
	
	   std::size_t found;

	   CString valstring="";
	   CString findstring = "" ;

	   CString uniq = ".delete_*";
	   CString saveuniq = ".saveisinprogress_*";
	   CString diskfulluniq = ".*DiskFullBox_*";
	   CString resourcenotfounduniq = ".*ResourceNotFound_*";
	   CString copyuniq = ".copypage2ndsession_*";

           ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
           ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr1 = NULL;
           ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr2 = NULL;
           ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtrforUfiles = NULL;

           FolderPtr = ci::operatingenvironment::Folder::Bind(path);
           if(!FolderPtr)
           {
              DEBUGL1("Utility::GetDocumentList::<%s> Folder Binding Failed\n",path.c_str());
              return STATUS_FAILED;
           }
           if(FolderPtr->GetSubFolders(boxvec)!=STATUS_OK)
           {
              DEBUGL1("Utility::GetDocumentList::Getting Files inside <%s> Folder Failed\n",path.c_str());
              return STATUS_FAILED;
           }
	  
           for(pIt = boxvec.begin(); pIt != boxvec.end(); pIt++)
           {
              boxpath = path + (*pIt);
              FolderPtr1 = ci::operatingenvironment::Folder::Bind(boxpath);
              if(!FolderPtr1)
              {
                 DEBUGL1("Utility::GetDocumentList::<%s> Folder Binding Failed\n",boxpath.c_str());
                 return STATUS_FAILED;
              }
	      // Fix for EBX_DTFR_17238
	      // Get all the files ".delete_*" present under the Box directly(and not under Box->folder)
	      // Eg., Get all the ".delete_*" under 00000
	      firstvec.clear();
	      if(FolderPtr1->GetFiles(firstvec, uniq)!=STATUS_OK)
	      {
		      DEBUGL1("Utility::GetDocumentList::Getting Files inside <%s> Folder Failed\n",path.c_str());
	      }

              //Removing .saveisinprogress_*,.cutDiskFullBox_*,.copyDiskFullBox_*,.pasteDiskFullBox_*,.deleteDiskFullBox_*,.cutResourceNotFound_*,.copyResourceNotFound_* unique files if they exist for L2.1 in every Box 
	      flatfilesvec.clear();
	      if(FolderPtr1->GetFiles(flatfilesvec, saveuniq)!=STATUS_OK)
		      DEBUGL1("Utility::GetDocumentList::Getting saveisinprogresis unique files inside <%s> Failed\n",path.c_str());
	      if(FolderPtr1->GetFiles(flatfilesvec, diskfulluniq)!=STATUS_OK)
		      DEBUGL1("Utility::GetDocumentList::Getting diskfull unique files inside <%s> Failed\n",path.c_str());
	      if(FolderPtr1->GetFiles(flatfilesvec, resourcenotfounduniq )!=STATUS_OK)
		      DEBUGL1("Utility::GetDocumentList::Getting resource not found unique files inside <%s> Failed\n",path.c_str());
	      if(FolderPtr1->GetFiles(flatfilesvec, copyuniq )!=STATUS_OK)
		      DEBUGL1("Utility::GetDocumentList::Getting copy 2nd session unique files inside <%s> Failed\n",path.c_str());

	      for (pflatfilesvecIt = flatfilesvec.begin(); pflatfilesvecIt != flatfilesvec.end(); ++pflatfilesvecIt )
	      {
		      if(ci::operatingenvironment::File::DeleteFile( boxpath + "/" + *pflatfilesvecIt )!=STATUS_OK)
			      DEBUGL2("Utility::GetDocumentList::Failed to remove %s flat file \n",*pflatfilesvecIt);

	      }

              folddocvec.clear();
              if(FolderPtr1->GetSubFolders(folddocvec)!=STATUS_OK)
              {
                 DEBUGL1("Utility::GetDocumentList::Getting Files inside <%s> Folder Failed\n",boxpath.c_str());
                 return STATUS_FAILED;
              }

              for(pIt1 = folddocvec.begin(); pIt1 != folddocvec.end(); pIt1++)
              {
                 folderpath = boxpath + "/" + (*pIt1);
                 //Check to see if unique file created for delete document exists or not
		 
		 // Get the Unique File particular to the document(Box -> Document) that is under deletion
                 CString DelDocName("");
		 if(!firstvec.empty())
		 {
			 for (pfirstvecIt = firstvec.begin(); pfirstvecIt != firstvec.end(); ++pfirstvecIt)
			 {
				 valstring = *pfirstvecIt; // Assign .delete_documentname_uniqueid to valstring
				 findstring = ".delete_"+*pIt1+"_";  // Assign findstring with ".delete_documentname_"
				 found = valstring.rfind("_"); //Trying to find the uniqueid
				 if (found!=std::string::npos)
				 {
				 	 valstring.erase(valstring.begin()+found+1,valstring.end()); // Erase the uniqueid
					 if( valstring  == findstring )
					 {
						 DelDocName = *pfirstvecIt; // If found, update DelDocName
						 firstvec.erase(pfirstvecIt); // Remove it from the vector, so it is not used further to search
						 break;
					 }
				 }	
				 
			 }
		 }	
		 DEBUGL8("Utility::GetDocumentList::DelDocName = %s\n",DelDocName.c_str());
	         FolderPtrforUfiles = NULL;
		 flatfilesvec.clear();
		 FolderPtrforUfiles = ci::operatingenvironment::Folder::Bind(folderpath);
		 if(FolderPtrforUfiles)
		 {
			 if(FolderPtrforUfiles->GetFiles(flatfilesvec, saveuniq)!=STATUS_OK)
				 DEBUGL1("Utility::GetDocumentList::Getting saveisinprogresis unique files inside <%s> Failed\n",path.c_str());
			 if(FolderPtrforUfiles->GetFiles(flatfilesvec, diskfulluniq)!=STATUS_OK)
				 DEBUGL1("Utility::GetDocumentList::Getting diskfull unique files inside <%s> Failed\n",path.c_str());
			 if(FolderPtrforUfiles->GetFiles(flatfilesvec, resourcenotfounduniq )!=STATUS_OK)
				 DEBUGL1("Utility::GetDocumentList::Getting resource not found unique files inside <%s> Failed\n",path.c_str());
			 if(FolderPtrforUfiles->GetFiles(flatfilesvec, copyuniq )!=STATUS_OK)
				 DEBUGL1("Utility::GetDocumentList::Getting copy 2nd session unique files inside <%s> Failed\n",path.c_str());

			 for (pflatfilesvecIt = flatfilesvec.begin(); pflatfilesvecIt != flatfilesvec.end(); ++pflatfilesvecIt )
			 {
				 if(ci::operatingenvironment::File::DeleteFile( folderpath + "/" + *pflatfilesvecIt )!=STATUS_OK)
					 DEBUGL2("Utility::GetDocumentList::Failed to remove %s flat file \n",*pflatfilesvecIt);

			 }

		 }
                 if(Utility::ResourceExist(folderpath + "/.document"))
                 {
                    if(DelDocName != "")
                    {
                       //its a partially deleted document under box,so delete it
                       DEBUGL8("Utility::GetDocumentList::Unique file for partially deleted document found\n");
                       Status rst = Utility::RemoveResource(folderpath);
                       if(rst != STATUS_OK)
                          DEBUGL2("Utility::GetDocumentList::Failed to remove partially deleted document\n");

                       if(Utility::RemoveResource(boxpath + "/" + DelDocName) != STATUS_OK)
                          DEBUGL2("Utility::GetDocumentList::Failed to remove unique file created for delete document\n");

                       //continue with the next item in the vector
                       continue;
                    }
                    //Its a document under box, push into the vector;
                    vec.push_back(folderpath);
                 }
                 //else if(DelDocName != "")
                 //{
                 //}
                 else
                 {
                    if(DelDocName != "")
                    {
                       //its a partially deleted document under box,so delete it
                       DEBUGL8("Utility::GetDocumentList::Unique file for partially deleted document found\n");
                       Status rst = Utility::RemoveResource(folderpath);
                       if(rst != STATUS_OK)
                          DEBUGL2("Utility::GetDocumentList::Failed to remove partially deleted document\n");

                       if(Utility::RemoveResource(boxpath + "/" + DelDocName) != STATUS_OK)
                          DEBUGL2("Utility::GetDocumentList::Failed to remove unique file created for delete document\n");

                       //continue with the next item in the vector
                       continue;
                    }
                    FolderPtr2= ci::operatingenvironment::Folder::Bind(folderpath);
                    if(!FolderPtr2)
                    {
                       DEBUGL1("Utility::GetDocumentList::<%s> Folder Binding Failed\n",folderpath.c_str());
                       return STATUS_FAILED;
                    }
                    docvec.clear();
                    //Its a folder, so get the doucments under folder
                    if(FolderPtr2->GetSubFolders(docvec)!=STATUS_OK)
                    {
                       DEBUGL1("Utility::GetDocumentList::Getting Files inside <%s> Folder Failed\n",folderpath.c_str());
                       return STATUS_FAILED;
                    }
	      	    // Get all the files ".delete_*" present under the Box->Folder
		    // Eg., Get all ".delete_boxname_foldername_documentname_uniqueid" present under Box->Folder 
		    secvec.clear();
		    if(FolderPtr2->GetFiles(secvec, uniq)!=STATUS_OK)
		    {
			    DEBUGL1("Utility::GetDocumentList::Getting Files inside <%s> Folder Failed\n",path.c_str());
		    }
                    for(pIt2 = docvec.begin(); pIt2 != docvec.end(); pIt2++)
                    {
		       
		       DelDocName = "";
		       FolderPtrforUfiles = NULL;
		       flatfilesvec.clear();                        
		       FolderPtrforUfiles = ci::operatingenvironment::Folder::Bind(folderpath + "/" + (*pIt2));
		       if(FolderPtrforUfiles)
		       {
			       if(FolderPtrforUfiles->GetFiles(flatfilesvec, diskfulluniq)!=STATUS_OK)
				       DEBUGL1("Utility::GetDocumentList::Getting diskfull unique files inside <%s> Failed\n",path.c_str());                       
			       for (pflatfilesvecIt = flatfilesvec.begin(); pflatfilesvecIt != flatfilesvec.end(); ++pflatfilesvecIt )
			       {
				       if(ci::operatingenvironment::File::DeleteFile( folderpath + "/" +  (*pIt2) + "/" + *pflatfilesvecIt )!=STATUS_OK)
					       DEBUGL2("Utility::GetDocumentList::Failed to remove %s flat file \n",*pflatfilesvecIt);
			       }
		       }

		       // Get the Unique File particular to the document(Box -> Folder -> Document) that is under deletion
		       for (psecvecIt = secvec.begin(); psecvecIt != secvec.end(); ++psecvecIt)
		       {
			       valstring = *psecvecIt; // Assign .delete_documentname_uniqueid to valstring
			       findstring = ".delete_" + *pIt2 + "_" ; // Assign findstring with ".delete_documentname_"
			       found = valstring.rfind("_"); //Trying to find the uniqueid
			       if (found!=std::string::npos)
			       {
				       valstring.erase(valstring.begin()+found+1,valstring.end());
				       if( valstring == findstring )
				       {
					       DelDocName = *psecvecIt; // If found, update DelDocName
					       secvec.erase(psecvecIt); // Remove it from the vector, so it is not used further to search
					       break;
				       }
			       }
			}
		       
		       DEBUGL8("Utility::GetDocumentList:: DelDocName present under Box->Folder= %s\n",DelDocName.c_str());
                       if((DelDocName != "") && (Utility::ResourceExist(folderpath + "/" + (*pIt2) + "/.document")))
                       {
                          //its a partially deleted document under folder,so delete it
                          DEBUGL8("Utility::GetDocumentList::Unique file for partially deleted document found in folder\n");
                          Status rst = Utility::RemoveResource(folderpath + "/" + (*pIt2));
                          if(rst != STATUS_OK)
                             DEBUGL2("Utility::GetDocumentList::Failed to remove partially deleted document\n");

                          if(Utility::RemoveResource(folderpath + "/" + DelDocName) != STATUS_OK)
                             DEBUGL2("Utility::GetDocumentList::Failed to remove unique file created for delete document\n");
			  
                          continue;
                       }
                       vec.push_back(folderpath + "/" + (*pIt2));										
		    }
		    //Get & Delete all ".delete_documentname*" under Folder(Box->Folder) that were not deleted previously
		    for (psecvecIt = secvec.begin(); psecvecIt != secvec.end(); ++psecvecIt)
		    {
			 if(ci::operatingenvironment::File::DeleteFile( folderpath + "/" + *psecvecIt)!=STATUS_OK)
                             DEBUGL2("Utility::GetDocumentList::Failed to remove unique file created for delete document\n");

		    }

		 }
	      }
	      //Get & Delete all ".delete_documentname*" under Box that were not deleted previously
	      for (pfirstvecIt = firstvec.begin(); pfirstvecIt != firstvec.end(); ++pfirstvecIt)
	      {
		      if(ci::operatingenvironment::File::DeleteFile(boxpath + "/" + *pfirstvecIt)!=STATUS_OK)
                         DEBUGL2("Utility::GetDocumentList::Failed to remove unique file created for delete document\n");

	      }

	   }
	   std::sort(vec.begin(), vec.end());
           DEBUGL4("Utility::GetDocumentList::Exit\n");
           return STATUS_OK;
        }

        Status Utility::GetPageCollectionList(std::vector<CString> &vec,CString path) 
        {
            DEBUGL4("Utility::GetPageCollectionList::Enter\n");
            std::vector<CString> pTmpvec;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
            FolderPtr = ci::operatingenvironment::Folder::Bind(path);
            if(!FolderPtr)
            {
                DEBUGL1("Utility::GetPageCollectionList::<%s> Folder Binding Failed\n",path.c_str());
                return STATUS_FAILED;
            }
            if(FolderPtr->GetFiles(pTmpvec)!=STATUS_OK)
            {
                DEBUGL1("Utility::GetPageCollectionList::Getting Files inside <%s> Folder Failed\n",path.c_str());
                return STATUS_FAILED;
            }
            std::vector<CString>::iterator pIt;
            for(pIt = pTmpvec.begin(); pIt != pTmpvec.end(); pIt++)
            {
                DEBUGL8("Utility::GetPageCollectionList::Files is %s\n",(*pIt).c_str());
                if(((*pIt).find(".uniqid_")!=std::string::npos) || ((*pIt).find("_systemfilelock")!=std::string::npos))
                {
                    // skip unique file entry here.
                    DEBUGL1("Utility::GetPageCollectionList: Skipping (%s)\n",(*pIt).c_str());
                    continue;
                }
                else
                    vec.push_back(*pIt);
            }
            std::sort(vec.begin(), vec.end());
            DEBUGL4("Utility::GetPageCollectionList::Exit\n");
            return STATUS_OK;
        }

        bool Utility::ResourceExist(CString path) 
        {
            if(ci::operatingenvironment::Folder::Exists(path) == true || ci::operatingenvironment::File::Exists(path) == true)
                return true;
            else
                return false;
        }

        bool Utility::ResourceExist(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
        {
            return ResourceExist(GetResourcePath(boxbasepath, boxnumber, foldername, documentname));
        }

        CString Utility::GetResourcePath(CString boxbasepath,CString boxnumber,CString foldername,CString documentname) 
        {
            CString docpath("");

            DEBUGL8("Utility::GetResourcePath: m_BoxBasePath = (%s), m_BoxNumber = (%s), m_FolderName = (%s), m_DocumentName  = (%s)\n", 
                    boxbasepath.c_str(), boxnumber.c_str(), foldername.c_str(), documentname.c_str());;

            docpath = boxbasepath;

            if(boxnumber != "") 
            {
                docpath += "/" + boxnumber;
            }
            if(foldername != "") 
            {
                docpath += "/" + foldername;
            }
            if(documentname != "") 
            {
                docpath +=  "/" + documentname;
            }
            DEBUGL8("Utility::GetResourcePath: docpath = (%s)\n",docpath.c_str());
            return docpath;
        }

        Status Utility::GetAllProperties(CString path, CString xmlfile,  std::map<CString, CString > &PropertyMap)
        {
            Status st;
            CString pLockpath(path);
	    CString fullpath = path +"/"+ xmlfile;
	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
   	    CString serializedFilePath = pLockpath + "/" + xmlfile;
		hierarchicaldb::HierarchicalDBRef hdb;
		dom::DocumentRef doc;
		DEBUGL8("Utility::GetAllProperties:: Folder path is %s\n",path.c_str());
		try {
			if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
			{
				DEBUGL8("proputils::GetAllProperty::failed to open %s\n",fullpath.c_str());
			}
			else
				DEBUGL8("Utility::GetAllProperties:successfully opened %s\n",fullpath.c_str());

			if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eREAD, true) != STATUS_OK)
			{
				DEBUGL1("Utility::GetAllProperties :Failed for BeginTransaction element\n");
				return STATUS_FAILED;
			}
			NodeRef rootNode = doc->getDocumentElement();
			if(!rootNode)
			{
				DEBUGL1("Utility::GetAllProperties::Failed to get document element\n");
				if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
				{
					DEBUGL1("Utility::GetAllProperties :Failed EndTransaction element\n");
					return STATUS_FAILED;
				}
				return STATUS_FAILED;
			}

                Ref<NodeList> children = rootNode->getChildNodes();
                if(!children)
                {
                    DEBUGL8("Utility::GetAllProperties::There are no Child nodes under the given %s node", (rootNode->getNodeName()).c_str());
				if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
				{
					DEBUGL1("Utility::GetAllProperties::Failed EndTransaction element\n");
					return STATUS_FAILED;
				}
                    return STATUS_FAILED;
                }

                CString nodename("");
                CString nodeval("");
                Ref<Node> pNode;
                typedef std::map<CString, CString> pair;
                for (uint32 i = 0; i < children->getLength(); i++)
                {	
                    nodename = "";
                    nodeval = "";
                    DEBUGL8("Utility::GetAllProperties::node %d\n",i);		
                    Ref<Node> child = children->item(i);
                    if(!child)
                    {
                        DEBUGL8("Utility::GetAllProperties::There are no Child nodes under the given %s node", (children->item(i)->getNodeName()).c_str());
                        continue;
                    }
                    if (child->getNodeType() == Node::ELEMENT_NODE)
                    {
                        nodename = child->getNodeName();
                        DEBUGL8("Utility::GetAllProperties::nodename (%s)\n", nodename.c_str());		
                        pNode = child->getFirstChild();
                        if(pNode)
                        {
                            if (pNode->getNodeType() == Node::TEXT_NODE)
                            {
                                nodeval=((TextRef)pNode)->getNodeValue();
                                DEBUGL8("Utility::GetAllProperties::nodeval (%s)\n", nodeval.c_str());				
                            }
                        }
                        PropertyMap[nodename]= nodeval;
                    }
                }
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("Utility::GetAllProperties::Failed EndTransaction element\n");
				return STATUS_FAILED;
            }
		}
            catch(CException & except)
            {
                DEBUGL1("\nUtility::GetAllProperties: Caught HDB exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nUtility::GetAllProperties: Failed due to DOM Exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                return STATUS_FAILED;
	    }
            return STATUS_OK;
        }
        
        Status Utility::GetPropertyMaps(CString path, CString xmlfile, std::map<CString, CString> &PropertyMap, CString *stringArray, int stringArraySize, bool flag)
        {
            Status st;
            CString uniqFileName("");
            CString pLockpath(path);
	    CString fullpath = path +"/"+ xmlfile;
	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
	    CString serializedFilePath = pLockpath + "/" + domfilename;
	    hierarchicaldb::HierarchicalDBRef hdb;
	    dom::DocumentRef doc;
	    DEBUGL8("Utility::GetPropertyMaps:: Folder path is %s\n",path.c_str());
	    try 
	    {
		    if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
		    {
			    DEBUGL8("proputils::GetPropertyMaps::failed to open %s\n",fullpath.c_str());
		    }
		    else
			    DEBUGL8("Utility::GetPropertyMaps::successfully opened %s\n",fullpath.c_str());

		if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eREAD, true) != STATUS_OK)
		{
			DEBUGL1("Utility::GetPropertyMaps::Failed BeginTransaction element\n");
			return STATUS_FAILED;
		}
                NodeRef rootNode = doc->getDocumentElement();
                if(!rootNode)
                {
			DEBUGL1("Utility::GetPropertyMaps::Failed to get document element\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("Utility::GetPropertyMaps::Failed EndTransaction element\n");
                    return STATUS_FAILED;
                }
			return STATUS_FAILED;
		}

                Ref<NodeList> children = rootNode->getChildNodes();
                if(!children)
                {
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("Utility::GetPropertyMaps::Failed EndTransaction element\n");
				return STATUS_FAILED;
			}
                    DEBUGL8("Utility::GetPropertyMaps::There are no Child nodes under the given %s node", (rootNode->getNodeName()).c_str());
                    return STATUS_FAILED;
                }

                CString nodename("");
                CString nodeval("");
                Ref<Node> pNode;
                typedef std::map<CString, CString> pair;
                long index = 0;
                for (uint32 i = 0; i < stringArraySize; i++)
                {
                    nodename = "";
                    nodeval = "";
                    DEBUGL8("Utility::GetPropertyMaps::node name (%s)\n", stringArray[i].c_str());

                    index = children->indexOf(stringArray[i]);
                    nodeval = children->item(index)->getTextContent();
                    DEBUGL8("Utility::GetPropertyMaps::The node name of <%s> node is <%s>..",  stringArray[i].c_str(), nodeval.c_str());
                    PropertyMap[stringArray[i]] = nodeval;
                }
		if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
		{
			DEBUGL1("Utility::GetPropertyMaps::Failed EndTransaction element\n");
			return STATUS_FAILED;
            }
	    }
            catch(CException & except)
            {
                DEBUGL1("\nUtility::GetPropertyMaps: Caught HDB exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nUtility::GetPropertyMaps: Failed due to DOM Exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                return STATUS_FAILED;
	    }
            return STATUS_OK;
        }

        Status Utility::SetProperties(CString path,CString xmlfile, std::map<CString, CString> PropertyMap)
        {
            Status st;
            CString pLockpath(path);
	    CString fullpath = path + "/" + xmlfile;
	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
	    CString serializedFilePath = pLockpath + "/" + xmlfile;
	    hierarchicaldb::HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
	    if(!hdb)
	    {
		    DEBUGL1("Utility::SetProperties:: Acquiring hdb instance failed\n");
		    return STATUS_FAILED;
	    }

                dom::DocumentRef doc = NULL;
		NodeRef rootNode = NULL;
                DEBUGL8("Utility::SetProperties:: path is %s\n",path.c_str());
		try {
		    if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
		    {
			    DEBUGL8("Utility::SetProperties::failed to open dom %s\n",fullpath.c_str());
			    return STATUS_FAILED;
		    }
                else
			DEBUGL8("Utility::SetProperties::successfully opened %s\n",fullpath.c_str());

		if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eWRITE, true) != STATUS_OK)
		{
			DEBUGL1("Utility::SetProperties:Failed BeginTransaction element\n");
			return STATUS_FAILED;
		}
		if(doc)
			rootNode = doc->getDocumentElement();
		else{
			DEBUGL1("Utility::SetProperties:: doc object is NULL \n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
			{
				DEBUGL1("Utility::SetProperties::Failed EndTransaction element\n");
						 return STATUS_FAILED;
					 }
			return STATUS_FAILED;
		}
                if(!rootNode)
                {
                    DEBUGL1("Utility::SetProperties::Failed to get document element\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
			{
				DEBUGL1("Utility::SetProperties::Failed EndTransaction element\n");
				return STATUS_FAILED;
			}
                    return STATUS_FAILED;
                }

                std::map<CString,CString>::iterator pIt;
                CString pNodename("");
                CString pNodeval("");
                for(pIt = PropertyMap.begin();pIt != PropertyMap.end();pIt++)
                {
                    pNodename = pIt->first;
                    pNodeval = pIt->second;
		    if(pNodename == "inputTime")
		    {
			NodeRef child = NULL;
			NodeRef node = hdb->BindToElement(rootNode,pNodename);
			if(!node)
			{
			     DEBUGL2("Node [%s] doesn't exists in the documentproperties.xml\n", pNodename.c_str());
			     child = chelper::AppendElementNode(rootNode,"inputTime");
			     if(!child)
			     {
			     		DEBUGL2("Creating new node [%s] in the documentproperties.xml failed\n", pNodename.c_str());
					return STATUS_FAILED;
			     }		
			}
			else	
			     DEBUGL8("Node [%s] already exists in the documentproperties.xml\n", pNodename.c_str());
		    }

                    	chelper::SetNodeValue(rootNode,pNodename,pNodeval);
			DEBUGL8("Utility::SetProperties::Set node name (%s)  value (%s) in (%s)\n",pNodename.c_str(),pNodeval.c_str(),fullpath.c_str());
                }
		if(hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE) != STATUS_OK)
		{
			DEBUGL1("Utility::SetProperties::Failed EndTransaction element\n");
			return STATUS_FAILED;
                }
		if(hdb->SerializeToFile(rootNode, serializedFilePath) != STATUS_OK)
		{
			DEBUGL1("Utility::SetProperties:: SerializeToFile Failed\n");
			return STATUS_FAILED;
		}
	    }
            catch(CException & except)
            {
                DEBUGL1("\nUtility::SetProperties: Caught HDB exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE);
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nUtility::SetProperties: Failed due to DOM Exception\n");
		hdb->EndTransaction(doc, ci::hierarchicaldb::eWRITE);
                return STATUS_FAILED;
	    }
            return STATUS_OK;

        }
        Status Utility::GetProperty(CString path,CString xmlfile, CString NodeName, CString &value)
        {
            Status st;
            CString pLockpath(path);
	    CString fullpath = path + "/" + xmlfile;
	    size_t pos = xmlfile.rfind(".");
	    CString domfilename = xmlfile.substr(0,pos) + "_dom";
	    CString serializedFilePath = pLockpath + "/" + xmlfile;
	    hierarchicaldb::HierarchicalDBRef hdb;
	    dom::DocumentRef doc = NULL;
	    NodeRef rootNode = NULL;
	    try 
	    {
		    DEBUGL8("Utility::GetProperty:: path is %s\n",path.c_str());
		    if(Utility::GetDomDocumentRef(hdb, doc, domfilename, pLockpath, fullpath) != STATUS_OK)
		    {
			    DEBUGL8("Utility::GetProperty::failed to open %s\n",fullpath.c_str());
		    }
		    else
		    {
			    DEBUGL1("Utility::GetProperty:: successful to open dom file  %s\n",fullpath.c_str());
		    }
		if(hdb->BeginTransaction(doc,ci::hierarchicaldb::eREAD, true) != STATUS_OK)
		{
			DEBUGL1("Utility::GetProperty::Failed BeginTransaction element\n");
			return STATUS_FAILED;
		}
                rootNode = doc->getDocumentElement();
                if(!rootNode)
                {
                    DEBUGL1("Utility::GetProperty::Failed to get document element\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("Utility::GetProperty::Failed EndTransaction element\n");
                    return STATUS_FAILED;
                }
			return STATUS_FAILED;
		}
                NodeRef node = hdb->BindToElement(rootNode,NodeName);
                if(!node)
                {
                    DEBUGL1("Utility::GetProperty:: Invalid node name\n");
			if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
			{
				DEBUGL1("Utility::GetProperty::Failed EndTransaction element\n");
                    return STATUS_FAILED;
                }		
			return STATUS_FAILED;
		}		
		value = node->getTextContent();
		if(hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD) != STATUS_OK)
		{
			DEBUGL1("Utility::GetProperty::Failed EndTransaction element\n");
			return STATUS_FAILED;
            	}
	    }
            catch(CException & except)
            {
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                DEBUGL1("\nUtility::GetProperty: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
		hdb->EndTransaction(doc, ci::hierarchicaldb::eREAD);
                DEBUGL1("\nUtility::GetProperty: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
	    DEBUGL8("Utility::GetProperty:: Value of (%s) = (%s)\n",NodeName.c_str(),value.c_str());
            return STATUS_OK;
        }



        CString Utility::GetLocalTime() 
        {
            CString local;
            SysInfoRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
            try 
            {
                sysinfo->Get("System/Clock:localtime", local);
            }
            catch (std::exception e) 
            {
                local = "";
            }
            return local;
        }

        CString Utility::GetUnixTime() 
        {
            CString unixtime;
            SysInfoRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
            try 
            {
                sysinfo->Get("System/Clock:time", unixtime);
            }
            catch (std::exception e) 
            {
                unixtime = "";
            }
            return unixtime;
        }

        CString Utility::Get5DigitPageNo(int pageno) 
        {
            std::ostringstream strm;
            strm << std::setfill('0') << std::setw(5) << pageno;
            return strm.str();
        }

        CString Utility::GetFolderPath(CString filename) 
        {
            int idx = filename.rfind("/");
            return filename.substr(0, idx);
        }

        CString Utility::GetTmpPath() 
        {

            CString tmppath = "/registration/ci/tmp/";
            return tmppath;
        }

        CString Utility::GetCITmpPath() 
        {
				//modified temp path from /work/ci/tmp to /imagedata/ci/tmp
            //CString tmppath = "/work/ci/tmp/";
            CString tmppath = "/imagedata/ci/tmp/";
            return tmppath;
        }

        CString Utility::GetHDBROOTPath()
        {
            CString hdbrootpath = HierarchicalDB::GetHDBRoot();
            return hdbrootpath;
        }

        CString Utility::GetEB2ROOTPath() 
        {
            CString eb2rootpath = getenv("EB2");
            return eb2rootpath;
        }

        CString Utility::GetHexadecimalPageNo(int pageno)
        {
            std::ostringstream strm;
            strm << std::setfill('0') << std::setw(3) << std::hex << pageno;
            return strm.str();
        }

        Status Utility::ResourceSize(CString sessionID, CString boxbasepath, CString boxnumber, CString foldername,CString documentname, CString filename,uint64 &ressize)
        {
            DEBUGL4("Utility::ResourceSize::Enter\n");
            CString path = boxbasepath + "/"  + boxnumber + "/" + foldername + "/" + documentname;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
            FolderPtr = ci::operatingenvironment::Folder::Bind(path);
            uint64 size = 0;
            if(FolderPtr)
                FolderPtr->getFolderSize(size);
            else
                DEBUGL1("Utility::ResourceSize: Bind to the folder (%s) failed\n", path.c_str());	
            ressize = size;
            DEBUGL6("Utility::ResourceSize = (%lu)\n", ressize);	
            DEBUGL4("Utility::ResourceSize::Exit\n");
            return STATUS_OK;
        }
        Status Utility::GetStatus(CString boxpath, CString boxnum, CString foldername, CString documentname, DocStatus &st) 
        {
            CString path = Utility::GetResourcePath(boxpath, 
                    boxnum,
                    foldername,
                    documentname) + "/";
            DEBUGL8("CDocument::GetStatus path = (%s)\n",path.c_str());
            if(Utility::ResourceExist(path + statusfilename::CREATING)) {
                st =  ci::boxdocument::CREATING;
            } else if(Utility::ResourceExist(path + statusfilename::READY)) {
                st =  ci::boxdocument::READY;
            } else if(Utility::ResourceExist(path + statusfilename::USING)) {
                st =  ci::boxdocument::USING;
            } else if(Utility::ResourceExist(path + statusfilename::EDITING)) {
                st =  ci::boxdocument::EDITING;
            } else if(Utility::ResourceExist(path + statusfilename::DELETING)) {
                st =  ci::boxdocument::DELETING;
            } else if(Utility::ResourceExist(path + statusfilename::WAITING)) {
                st =  ci::boxdocument::WAITING;								
            } else if(Utility::ResourceExist(path + statusfilename::RESERVING)) {
                st =  ci::boxdocument::RESERVING;								
            } else {
                // if file is not found, document status is considered as CREATING.
                st =  ci::boxdocument::CREATING;

                if(Utility::CreateFile(path, statusfilename::CREATING) != STATUS_OK) {
                    DEBUGL1("CDocument::GetStatus::creating status file is failed\n");
                    return STATUS_FAILED;
                }
            }
            return STATUS_OK;
        }
        Status Utility::ChangeStatus(CString boxpath, CString boxnum, CString foldername, CString docName, DocStatus st) 
        {
            DocStatus current;
            if(Utility::GetStatus(boxpath, boxnum, foldername, docName, current) != STATUS_OK) {
                DEBUGL1("CDocument::ChangeStatus::getting document status is failed\n");
                return STATUS_FAILED;
            }

            // rename status file
            CString path = Utility::GetResourcePath(boxpath, 
                    boxnum,
                    foldername,
                    docName) + "/";

            CString from, to;
            switch(current) {
                case ci::boxdocument::CREATING : from =  path + statusfilename::CREATING; break;
                case ci::boxdocument::READY    : from =  path + statusfilename::READY; break;
                case ci::boxdocument::USING    : from =  path + statusfilename::USING; break;
                case ci::boxdocument::EDITING  : from =  path + statusfilename::EDITING; break;
                case ci::boxdocument::DELETING : from =  path + statusfilename::DELETING; break;
                case ci::boxdocument::WAITING : from =  path + statusfilename::WAITING; break;
                case ci::boxdocument::RESERVING : from =  path + statusfilename::RESERVING; break;
            }
            switch(st) {
                case ci::boxdocument::CREATING : to = path +  statusfilename::CREATING; break;
                case ci::boxdocument::READY    : to = path +  statusfilename::READY; break;
                case ci::boxdocument::USING    : to = path +  statusfilename::USING; break;
                case ci::boxdocument::EDITING  : to = path +  statusfilename::EDITING; break;
                case ci::boxdocument::DELETING : to = path +  statusfilename::DELETING; break;
                case ci::boxdocument::WAITING : to = path +  statusfilename::WAITING; break;
                case ci::boxdocument::RESERVING : to = path +  statusfilename::RESERVING; break;
            }

            Status ds = ci::operatingenvironment::File::MoveFile(from, to);
            if(ds != STATUS_OK) {
                DEBUGL1("CDocument::ChangeStatus::changing status is failed\n");
                return ds;
            }
            return STATUS_OK;
        }

        Status Utility::EnterCriticalSection(GlobalMutexRef& mutex,CString path) 
        {
            CString moniker_str = "BoxDocMutex" + path;
            mutex = GlobalMutex::Create(moniker_str);
            if(!mutex) 
            {
                MonikerRef moniker = Moniker::Create(SCHEMA_IPMUTEX, moniker_str.c_str());
                mutex = GlobalMutex::Bind(moniker); 
            }
            if(mutex) 
                return mutex->Acquire();
            else
            {
                DEBUGL1("Utility::EnterCriticalSection - Mutex is empty\n");
                return STATUS_FAILED;
            }
        }
        Status Utility::LeaveCriticalSection(GlobalMutexRef& mutex) 
        {
            if(mutex) 
            {	
                mutex->Release();
                return mutex->Destroy(false);
            } 
            else
            {
                DEBUGL1("Utility::LeaveCriticalSection - Mutex is empty\n");
                return STATUS_FAILED;	
            }
        }

        Status Utility::CreateFile(CString path,  CString filename) {
            // create file in temporary folder
            CString statuspath = Utility::GetTmpPath();         
	   statuspath +=  filename;
	    CString createstatusfile = "touch " + statuspath;
            int r;
            ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
            sysinfo->RunCmd(createstatusfile, r);

            // put status file to document folder
            CString filepath = path + filename;

            //Create a unique File if it does not exist, else get the unique file id and use it a a semaphore lock.
            CString uniqFileName("");
            CString pLockpath(path);

            if(Utility::GetUniqueFile(pLockpath,uniqFileName) != STATUS_OK)
            {
                DEBUGL1("proputils::CreateFile:: GetUniqueFile failed\n");
                return STATUS_FAILED;		
            }

            CriticalSectionRef cs = new CriticalSection(uniqFileName);

            Status ds = ci::operatingenvironment::File::CopyFile(statuspath, filepath);
            if(ds != STATUS_OK) 
            {
                if(ds==STATUS_DISK_FULL)
                {
                    DEBUGL1("Utility::CreateFile::Create file %s return STATUS_DISK_FULL\n", filepath.c_str());
                    return (::STATUS_DISK_FULL);
                }
                else
                {
                    DEBUGL1("Utility::CreateFile::put resource document %s is failed\n", filepath.c_str());
                    return STATUS_FAILED;
                }
            }

            // delete file
            File::DeleteFile(statuspath);

            DEBUGL4("Utility::CreateFile::Exit\n");		
            return STATUS_OK;
        }

        Status Utility::InitSts(CString path) 
        {
            DocStatus current;
            CString from("");
            if(Utility::ResourceExist(path + "/creating.sts")) 
            {
                current = ci::boxdocument::CREATING;
                from = path + "/creating.sts";
            }
            else if(Utility::ResourceExist(path + "/ready.sts")) 
            {
                current = ci::boxdocument::READY;
                from = path + "/ready.sts";		
            }
            else if(Utility::ResourceExist(path + "/using.sts"))
            {
                current = ci::boxdocument::USING;
                from = path + "/using.sts";		
            }
            else if(Utility::ResourceExist(path + "/editing.sts"))
            {
                current = ci::boxdocument::EDITING;
                from = path +  "/editing.sts";		
            }
            else if(Utility::ResourceExist(path + "/deleting.sts"))
            {
                current = ci::boxdocument::DELETING;
                from = path + "/deleting.sts";		
            }		
            else if(Utility::ResourceExist(path + "/waiting.sts"))
            {
                current = ci::boxdocument::WAITING;
                from = path + "/waiting.sts";		
            } 
            else if(Utility::ResourceExist(path + "/reserving.sts"))
            {
                current = ci::boxdocument::RESERVING;
                from = path + "/reserving.sts";		
            } 
            else 
            {
                if(Utility::RemoveResource(path) != STATUS_OK)
                {
                    DEBUGL1("Utility::InitSts: Removing of document failed\n");
                    return STATUS_FAILED;
                }
                return STATUS_OK;
            }		
            CString to(""); 				
            if((current==ci::boxdocument::CREATING)||(current==ci::boxdocument::DELETING))
            {
                to = path + "/waiting.sts";
                if(ci::operatingenvironment::File::MoveFile(from, to) != STATUS_OK) 
                {
                    DEBUGL1("Utility::InitSts::changing status is failed\n");
                    return STATUS_FAILED;
                }
            }
            else if(current==ci::boxdocument::EDITING)
            {	
                to = path + "/ready.sts";
                if(ci::operatingenvironment::File::MoveFile(from, to) != STATUS_OK) 
                {
                    DEBUGL1("Utility::InitSts::changing status is failed\n");
                    return STATUS_FAILED;
                }
            }	
            else if(current==ci::boxdocument::RESERVING)
            {	
                to = path + "/ready.sts";
                if(ci::operatingenvironment::File::MoveFile(from, to) != STATUS_OK) 
                {
                    DEBUGL1("Utility::InitSts::changing status is failed\n");
                    return STATUS_FAILED;
                }
            }	
            else	if (current==ci::boxdocument::USING)
            {	
                to = path + "/ready.sts";
                if(ci::operatingenvironment::File::MoveFile(from, to) != STATUS_OK) 
                {
                    DEBUGL1("Utility::InitSts::changing status is failed\n");
                    return STATUS_FAILED;
                }
                std::map<CString, CString> PropertyMap;
                typedef  std::map<CString, CString> pair;

                PropertyMap.clear();
                PropertyMap.insert(pair::value_type("count","0"));
                if(Utility::SetProperties(path, "documentproperties.xml", PropertyMap) != STATUS_OK)
                {
                    DEBUGL1("Utility::InitSts::Setting property to %s is failed\n", path.c_str());
                    //It could be because xml file would have corrupted. Move such documents to /$Eb2/tmp/for removal after bootup.
                    CString pTmppath = Utility::GetTmpPath();
                    Status status = ci::operatingenvironment::Folder::MoveDir(path.c_str(),pTmppath.c_str());
                    if(status != STATUS_OK)
                    {
                        DEBUGL2("Utility::InitSts::Could not Move the %s folder ::Delete Manually\n",path.c_str());
                    }
                    return STATUS_FAILED;
                }		
            }				
            return STATUS_OK;
        } 

        Status Utility::RemoveResource(CString path)
        {
            if(ci::operatingenvironment::Folder::Exists(path))
            {
                Status st = ci::operatingenvironment::Folder::Remove(path, true);
                if(st != STATUS_OK)
                {
                    DEBUGL1("Utility::RemoveResource: Failed to remove resource (%s)\n", path.c_str());
                    return st;
                }
            }
            else if(ci::operatingenvironment::File::Exists(path))
            {
                Status st = ci::operatingenvironment::File::DeleteFile(path);
                if(st != STATUS_OK)
                {
                    DEBUGL1("Utility::RemoveResource: Failed to remove resource (%s)\n", path.c_str());
                    return st;
                }	
            }
            return STATUS_OK;
        }

        Status Utility::CreateUniqueFile(CString path, CString uniqid)
        {
            DEBUGL4("Utility::CreateUniqueFile: Enter\n");
            CUUIDRef uid = new CUUID();
            CString uniq = uniqid;
            uniq += uid->toString();
            if(ci::operatingenvironment::Folder::Exists(path))
            {
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> folderPtr = NULL;
                folderPtr= ci::operatingenvironment::Folder::Bind(path);
                if(!folderPtr) {
                    DEBUGL1("Utility::CreateUniqueFile::Folder Binding Failed\n");
                    return STATUS_FAILED;
                }

                ci::operatingenvironment::Ref<ci::operatingenvironment::File> filePtr = NULL;
                Status st = ci::operatingenvironment::File::CreateFile(filePtr, uniq, folderPtr);
                if(st != STATUS_OK)
                {
                    DEBUGL1("Utility::CreateUniqueFile: Failed to remove resource (%s)\n", path.c_str());
                    return st;
                }
            }
            DEBUGL4("Utility::CreateUniqueFile: Exit\n");	
            return STATUS_OK;
        }

        Status Utility::CreateUniqueFile(CString path, CString *uniqid)
        {
            DEBUGL4("Utility::CreateUniqueFile: Enter\n");
            CUUIDRef uid = new CUUID();
            CString uniq = *uniqid;
            uniq += uid->toString();
	    *uniqid = path + uniq;
            if(ci::operatingenvironment::Folder::Exists(path))
            {
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> folderPtr = NULL;
                folderPtr= ci::operatingenvironment::Folder::Bind(path);
                if(!folderPtr) {
                    DEBUGL1("Utility::CreateUniqueFile::Folder Binding Failed\n");
                    return STATUS_FAILED;
                }

                ci::operatingenvironment::Ref<ci::operatingenvironment::File> filePtr = NULL;
                Status st = ci::operatingenvironment::File::CreateFile(filePtr, uniq, folderPtr);
                if(st != STATUS_OK)
                {
                    DEBUGL1("Utility::CreateUniqueFile: Failed to remove resource (%s)\n", path.c_str());
                    return st;
                }
            }
            DEBUGL4("Utility::CreateUniqueFile: Exit\n");	
            return STATUS_OK;
        }
        Status Utility::DeleteUniqueFile(CString path, CString uniqid)
        {
            DEBUGL4("Utility::DeleteUniqueFile: Enter\n");
            std::vector<CString> vec;
            CString uniq = uniqid;

            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
            FolderPtr = ci::operatingenvironment::Folder::Bind(path);
            if(!FolderPtr)
            {
                DEBUGL1("Utility::DeleteUniqueFile::<%s> Folder Binding Failed\n",path.c_str());
                return STATUS_FAILED;
            }
            uniq += "*";
            if(FolderPtr->GetFiles(vec, uniq)!=STATUS_OK)
            {
                DEBUGL1("Utility::DeleteUniqueFile::Getting uniq files inside <%s> Folder Failed\n",path.c_str());
                return STATUS_FAILED;
            }

            if(!vec.empty()) {
                std::vector<CString>::iterator pIt;
                for(pIt = vec.begin(); pIt != vec.end(); pIt++)
                {
                    DEBUGL8("Utility::DeleteUniqueFile::Files is %s\n",(*pIt).c_str());
                    if(Utility::RemoveResource(path + "/" + (*pIt)) != STATUS_OK)
                    {
                        DEBUGL1("Utility::DeleteUniqueFile:: Failed to remove the resource (%s)\n", (*pIt).c_str());
                        return STATUS_FAILED;
                    }
                }
            }
            DEBUGL4("Utility::DeleteUniqueFile: Exit\n");	
            return STATUS_OK;
        }

        Status Utility::GetUniqueFile(CString path, CString &uniqFileName,  CString uniqid, bool getuniqfile)
        {
            DEBUGL4("Utility::GetUniqueFile: Enter\n");
            std::vector<CString> vec;
            CString uniq = uniqid;

            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
            FolderPtr = ci::operatingenvironment::Folder::Bind(path);
            if(!FolderPtr)
            {
                DEBUGL1("Utility::GetUniqueFile::<%s> Folder Binding Failed\n",path.c_str());
                uniqFileName = "";
                return STATUS_FAILED;
            }
            //GetFiles uses grep & we end up 'grep' for DOC1* 
            //which should not be the case
            //uniq += "*";
            if(FolderPtr->GetFiles(vec, uniq)!=STATUS_OK)
            {
                if(vec.empty())
                    DEBUGL2("Utility::GetUniqueFile::Getting uniq files inside <%s> Folder Failed\n",path.c_str());

                uniqFileName = "";
            }	

            if(!vec.empty()) {
                std::vector<CString>::iterator pIt = vec.begin();
                uniqFileName = (*pIt);
                return STATUS_OK;
            }

            if(getuniqfile)
            {
                if(uniqFileName.compare("") == 0)
                {
                    if(Utility::CreateUniqueFile(path) != STATUS_OK)
                    {
                        DEBUGL1("Utility::GetUniqueFile::Getting uniq files inside <%s> Folder Failed\n",path.c_str());
                        return STATUS_FAILED;
                    }
                    if(Utility::GetUniqueFile(path,uniqFileName)!=STATUS_OK)
                    {
                        DEBUGL1("Utility::GetUniqueFile::Getting uniq files inside <%s> Folder Failed\n",path.c_str());
                        uniqFileName = "";
                        return STATUS_FAILED;
                    }
                }
            }

            DEBUGL8("Utility::GetUniqueFile:: uniqFileName = (%s)\n", uniqFileName.c_str());
            DEBUGL4("Utility::GetUniqueFile: Exit\n");
            return STATUS_OK;
        }
        //-----------------------------------------------------------------------------
        IsFolder::IsFolder()
        {
        }
        bool IsFolder::operator()(CString path) const 
        {
            DEBUGL8("IsFolder::operator path = (%s)\n",path.c_str());
            return !(ci::operatingenvironment::File::Exists(path + ".document"));
        }

        //-----------------------------------------------------------------------------
        IsDocument::IsDocument() 
        {
        }
        bool IsDocument::operator()(CString path) const 
        {
            DEBUGL8("IsDocument::operator path = (%s)\n",path.c_str());
            return ci::operatingenvironment::File::Exists(path + ".document");
        }

        //-----------------------------------------------------------------------------
        CriticalSection::CriticalSection(CString path) : key(path) 
        {
            while( Utility::EnterCriticalSection(m_mutex, key) != STATUS_OK)
                continue;
        }
        CriticalSection::~CriticalSection() 
        {
            Utility::LeaveCriticalSection(m_mutex);
        }
	CString Utility::GetSubProduct()
	{
		char *subProduct = getenv("SUB_PRODUCT");
		if(subProduct)
			return CString(subProduct);
		else
			return CString("");
	}

	CString Utility::GetEquipmentBrand()
	{
		char *equipmentBrand = getenv("EQUIPMENT_BRAND");
		if(equipmentBrand)
			return CString(equipmentBrand);
		else
			return CString("");

	}

	Status Utility::LimitTo64Characters(CString &documentname,CString &newpath, CString path)
		{
			DEBUGL8("Utility::LimitTo64Characters()Enter\n");
			uint docnum = 1;
			std::ostringstream strm;
			CString truncdocname = "";
			Status ret;
			// if documentname folder exist, add suffix to path
			while(true) 
			{
				strm.str("");
				strm << std::setfill('0') << std::setw(3) << docnum;
				newpath = path + documentname + "-" + strm.str()+ "/";
				DEBUGL8("Utility::LimitTo64Characters: newpath is %s\n",newpath.c_str());
				if(!Utility::ResourceExist(newpath))
				{
					documentname = documentname + "-" + strm.str();
					if(documentname.length()>64)
					{
						ret = TruncateDocumentName(documentname.c_str(),truncdocname,60);				
						if(ret != STATUS_OK)
							DEBUGL1("Utility::LimitTo64Characters:TruncateDocumentName failed to truncate the document name to 60\n");
						documentname = truncdocname;
						docnum = 1;
						while(true)
						{										
							strm.str("");
							strm << std::setfill('0') << std::setw(3) << docnum;
							newpath = path + documentname + "-" + strm.str();
							if(!Utility::ResourceExist(newpath))
							{
								documentname = documentname + "-" + strm.str();
								DEBUGL8("Utility::LimitTo64Characters:newpath %s and documentname %s\n",newpath.c_str(),documentname.c_str());
								break;
							}									
							docnum++;
						}
					}
					break;
				}
				docnum++;
			}

			DEBUGL8("Utility::LimitTo64Characters()Exit\n");
			return STATUS_OK;
		}

		Status Utility::TruncateDocumentName(const char *buff,CString &buff1,int trunc ) 
		{
			DEBUGL8("Utility::TruncateDocumentName()Enter\n");
			if( buff != NULL )
			{
				int count = 0;
				int pos = 0;
				int max_bytes = strlen( buff );
				// Skip BOM
				if( max_bytes >= 3 ) {
					if( static_cast<unsigned char>( buff[0] ) == 0xEF &&
							static_cast<unsigned char>( buff[1] ) == 0xBB &&
							static_cast<unsigned char>( buff[2] ) == 0xBF ) {
						pos += 3;
					}
				}

				while(( pos < max_bytes )&& count < trunc) {
					++count;
					if( ( buff[pos] & 0x80 ) == 0 ) { // 1 byte char
						++pos;
					} else {
						for( char tmp = buff[pos] & 0xfc; (tmp & 0x80); tmp = tmp << 1 ) { // multibyte char
							++pos;
						}
					}
				}
	
				char *buff2 = new char[pos+1];
				memset(buff2,0,pos+1);
				memcpy(buff2,buff,pos);
				buff1 = CString(buff2);
				delete []buff2;

				DEBUGL8("Utility::TruncateDocumentName()Exit\n");
				return STATUS_OK;
			}
			DEBUGL8("Utility::TruncateDocumentName()Buff is empty\n");
			return STATUS_FAILED;
		}

		Status Utility::CompareProductType(CString srcProduct, CString dstProduct, bool &convertSystemFile)
		{

			if(dstProduct == "e-STUDIO 2000AC Series")
			{
				if((srcProduct == " ")||(srcProduct == "H-14x V1.0"))
				{
					DEBUGL8("Utility::ConvertFLStructure()::Call flconverter as archived document is from MASH or Weiss\n");
					convertSystemFile = true;
				}
				else
				{
					if((srcProduct.compare(dstProduct)))
					{
						DEBUGL1("Utility::ConvertFLStructure()Product Codes Does not Match -- Archived code %s and Extracted code %s\n",srcProduct.c_str(),dstProduct.c_str());
						return Extractor::STATUS_INVALID_PRODUCTTYPE;
					}
				}
			}
			else if(dstProduct == "e-STUDIO 2508A Series")
			{
				if(srcProduct == "e-STUDIO 456 Series 3.0")
				{
					DEBUGL8("Utility::ConvertFLStructure()::Call flconverter as archived document is of Loire product type\n");
					convertSystemFile = true;
	
				}
				else
				{
					if((srcProduct.compare(dstProduct)))
					{
						DEBUGL1("Utility::ConvertFLStructure()Product Codes Does not Match -- Archived code %s and Extracted code %s\n",srcProduct.c_str(),dstProduct.c_str());
						return Extractor::STATUS_INVALID_PRODUCTTYPE;
					}
				}
			}
			else if(dstProduct == "e-STUDIO 5506AC Series")
			{
				if(srcProduct == "H-13x V1.0")
				{

					DEBUGL8("Utility::ConvertFLStructure()::Call flconverter as archived document is of BP product type\n");
					
					convertSystemFile = true;
				}
				else{
					if((srcProduct.compare(dstProduct)))
					{
						DEBUGL1("Utility::ConvertFLStructure()Product Codes Does not Match -- Archived code %s and Extracted code %s\n",srcProduct.c_str(),dstProduct.c_str());
						return Extractor::STATUS_INVALID_PRODUCTTYPE;
					}

				}
			}
			else if(dstProduct == "e-STUDIO 5508A Series")
			{
				if(srcProduct == "e-STUDIO 856 Series 3.0")
				{

					DEBUGL8("Utility::ConvertFLStructure()::Call flconverter as archived document is of ALABAMA product type\n");
					convertSystemFile = true;
	
				}
				else{
					if((srcProduct.compare(dstProduct)))
					{
						DEBUGL1("Utility::ConvertFLStructure()Product Codes Does not Match -- Archived code %s and Extracted code %s\n",srcProduct.c_str(),dstProduct.c_str());
						return Extractor::STATUS_INVALID_PRODUCTTYPE;
					}
				}
			}
			else
			{
				if((srcProduct.compare(dstProduct)))
				{
					DEBUGL1("Utility::ConvertFLStructure()Product Codes Does not Match -- Archived code %s and Extracted code %s\n",srcProduct.c_str(),dstProduct.c_str());
					return Extractor::STATUS_INVALID_PRODUCTTYPE;
				}
			}
			return STATUS_OK;
		}
		Status Utility::AcquireLockforSystemfile(CString path, int &fileDescriptor, bool openSystemFile)
		{
			DEBUGL4("Utility::AcquireLockforSystemfile - Enter\n");
			int errnum, ret;
			fileDescriptor =-1;
			fileDescriptor = open(path.c_str(),O_RDONLY|O_CREAT,0777);
			errnum=errno;
			DEBUGL8("Utility::AcquireLockforSystemfile path is [ %s ] and fileDescriptor is [ %d ]\n",path.c_str(),fileDescriptor);
			if(fileDescriptor < 0)
			{
				DEBUGL1("Utility::AcquireLockforSystemfile errno [ %d ] and error string  [ %s ]\n",errnum,strerror(errno));
				return STATUS_FAILED;
			}
			if(!openSystemFile)
			{
				ret = flock(fileDescriptor, LOCK_EX);
				errnum = errno;
			}
			else
			{
				ret = flock(fileDescriptor, LOCK_SH);
				errnum = errno;
			}
			if(ret < 0){
				DEBUGL1("Utility::AcquireLockforSystemfile errno [ %d ] and error string  [ %s ]\n",errnum,strerror(errno));
				close(fileDescriptor);
			  	errnum =0;
				return STATUS_FAILED;
			}
			DEBUGL4("Utility::AcquireLockforSystemfile - Exit\n");
			return STATUS_OK;
		}

		Status Utility::ReleaseLockforSystemfile(int &fileDescriptor)
		{
			DEBUGL4("Utility::ReleaseLockforSystemfile - Enter\n");
			int ret,errnum;
			ret = flock(fileDescriptor, LOCK_UN);
			errnum = errno;
			if(ret == -1)
			{
			  DEBUGL1("Utility::ReleaseLockforSystemfile errno [ %d ] and error string  [ %s ]\n",errnum,strerror(errno));
			  close(fileDescriptor);
			  errnum =0;
			  return STATUS_FAILED;
			}
			close(fileDescriptor);
			DEBUGL4("Utility::ReleaseLockforSystemfile - Exit\n");
			return STATUS_OK;
		}
		Status Utility::GetDomDocumentRef(hierarchicaldb::HierarchicalDBRef &hdb, dom::DocumentRef &doc, CString domfilename, CString pLockpath, CString fullpath)
		{
			DEBUGL4("Utility::GetDomDocumentRef - Enter\n");
			hdb = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
			if (!hdb)
			{
				DEBUGL1("Utility::GetDomDocumentRef: Failed to Acquire HierarchicalDB\n");
				return STATUS_FAILED;
			}
			Status st = hdb->OpenDocument(pLockpath, domfilename, doc);
			if(st != STATUS_OK)
			{
				if((st == STATUS_HDB_INVALID_DOCUMENT_STRUCTURE) || (File::Exists(pLockpath + "/" + domfilename)))
				{
					DEBUGL1("Utility::GetDomDocumentRef:OpenDocument Failed to open domfilename %s\n",domfilename.c_str());
					if(ci::operatingenvironment::File::DeleteFile(pLockpath + "/" + domfilename)!=STATUS_OK)
					{
						DEBUGL1("Utility::GetDomDocumentRef Failed to DeleteFile\n");
						return STATUS_FAILED;
					}
				}
				Status ds = hdb->CreateDocumentFromFile(pLockpath+"/", domfilename, doc, fullpath);
				if(ds != STATUS_OK)
				{
					DEBUGL1("Utility::GetDomDocumentRef Creation of DOM property file [%s] failed\n", fullpath.c_str());
					return ds;
				}
				else		
					DEBUGL8("Utility::GetDomDocumentRef: Created dom file from xmlfile %s\n",domfilename.c_str());
			}
			else
				DEBUGL8("Utility::GetDomDocumentRef: Opened existing dom document domfilename %s\n",domfilename.c_str());

			DEBUGL4("Utility::GetDomDocumentRef - Exit\n");
			return STATUS_OK;
		}

		Status Utility::IsStorageFull(bool &bHasAvailableSize) 
		{
			Status retStatus = STATUS_FAILED;
			uint64  available = 0;
			CString partitionName = STORAGE_PART_NAME;
			ci::systeminformation::SysInfoRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
			if(!sysinfo)
			{
				DEBUGL1("Utility::IsStorageFull: SysInfoRef is NULL\n");
				return STATUS_FAILED;
			}
			retStatus = sysinfo->GetAvailableSize(partitionName, available);
			if(STATUS_OK == retStatus) 
			{
				if (available <= STORAGE_NEAR_FULL_CHECK_SIZE) 
				{
					bHasAvailableSize = false;
				} 
				else 
				{
					bHasAvailableSize = true;
				}
			}
			else
			{
				DEBUGL1("Utility::IsStorageFull: sysinfo->GetAvailableSize failed\n");
				return STATUS_FAILED;
			}
			DEBUGL7("Utility::IsStorageFull available size is [%lld]\n", available);
			return retStatus;
		}	
		
    }; // end of namespace boxdocument
		}; // end of namespace ci

