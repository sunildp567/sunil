#ifndef __CI_FLCONVERT_H__
#define __CI_FLCONVERT_H__

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include "systemdatafile.h"
#include "types.h"
#include "flconverter.h"
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>

namespace ci {
	namespace boxdocument {
		using namespace ci::operatingenvironment;

		class FLConverter {

			private:

				inline static int16 bswap_16(int16 x) {
					return ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8));
				}

				inline static int32 bswap_32(int32 x) {
					return ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24));
				}

				inline static uint16 bswap_u16(uint16 x) {
					return ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8));
				}

				inline static uint32 bswap_u32(uint32 x) {
					return ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) | (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24));
				}

				inline static void update_16(int16 &x) {
					int16 y = x;
					x = bswap_16(y);
					return ;
				}

				inline static void update_32(int32 &x) {
					int32 y = x;
					x = bswap_32(y);
					return ;
				}

				inline static void update_u16(uint16 &x) {
					uint16 y = x;
					x = bswap_u16(y);
					return ;
				}

				inline static void update_u32(uint32 &x) {
					uint32 y = x;
					x = bswap_u32(y);
					return ;
				}

				inline static void update_time_t(time_t &x) {
					int32 y = (int32)x;
					x = bswap_32(y);
					return ;
				}

				static void convertPAR_TBL_RESOLUTION(PAR_TBL_RESOLUTION &par) {
					update_16(par.hMain);
					update_16(par.hSub);
					return ;
				}

				static void convertPAR_TBL_COLOR_INFO(PAR_TBL_COLOR_INFO &par) {
					update_16(par.hColorMode);
					update_16(par.hDataBit);
					update_16(par.hPlane);
					update_16(par.hDataForm);
					return;
				}

				static void convertPAR_TBL_TWOCOLORS(PAR_TBL_TWOCOLORS &par) {
					update_16(par.hMode);
					update_16(par.hTwoColors1);
					update_16(par.hTwoColors2);
					update_16(par.hBoundaryValue);
					return;
				}

				static void convertPAR_TBL_COLORBALANCEINFO(PAR_TBL_COLORBALANCEINFO &par) {
					update_16(par.hColorY);
					update_16(par.hColorM);
					update_16(par.hColorC);
					update_16(par.hColorBK);
					return;
				}

				static void convertPAR_TBL_RGBBALANCEINFO(PAR_TBL_RGBBALANCEINFO &par) {
					update_16(par.hColorR);
					update_16(par.hColorG);
					update_16(par.hColorB);
					return;
				}

				static void convertPAR_TBL_HUEINFO(PAR_TBL_HUEINFO &par) {
					update_16(par.hHue_Y);
					update_16(par.hHue_M);
					update_16(par.hHue_C);
					update_16(par.hHue_R);
					update_16(par.hHue_G);
					update_16(par.hHue_B);
					return;
				}

				static void convertPAR_TBL_SATURATIONINFO(PAR_TBL_SATURATIONINFO &par) {
					update_16(par.hSaturation_Y);
					update_16(par.hSaturation_M);
					update_16(par.hSaturation_C);
					update_16(par.hSaturation_R);
					update_16(par.hSaturation_G);
					update_16(par.hSaturation_B);
					return;
				}

				static void convertPAR_TBL_ALLCOLORINFO(PAR_TBL_ALLCOLORINFO &par) {
					for(int i = 0; i < 3; i++) {
						convertPAR_TBL_COLORBALANCEINFO(par.sColorBalance[i]);
					}
					convertPAR_TBL_HUEINFO(par.sHueinfo);
					convertPAR_TBL_SATURATIONINFO(par.sSaturationInfo);
					return;
				}

				static void convertFL_FILE_STATUS(FL_FILE_STATUS &fl) {
					update_16(fl.hVolMtd);
					update_32(fl.iTaskId);
					update_u32(fl.liFlSize);
					update_16(fl.hFlPageNum);
					update_16(fl.hFlPageNumS);
					update_16(fl.hFlPageNumE);
					update_16(fl.hFaxOrgExist);
					update_time_t(fl.iFlCreateTime);
					update_16(fl.hFlPageDelFlag);
					update_16(fl.hAPLInfoSize);
					update_16(fl.hParMNSize);
					for(int i = 0; i < 4; i++) {
						update_16(fl.hRfu[i]);
					}
					update_time_t(fl.iFlUpdateTime);
					for(int i = 0; i < 4; i++) {
						update_32(fl.iRfu[i]);
					}
					return ;
				}

				static void convertFL_FILE_COM_ATR(FL_FILE_COM_ATR &fl) {
					update_16(fl.hPageOrder);
					update_16(fl.hJobMixCondition);
					update_16(fl.hMixColor);
					update_16(fl.hReserved[0]);
					return ;
				}

				static void convertFL_FILE_IN_ATR(FL_FILE_IN_ATR &fl) {
					update_16(fl.hSts);
					update_16(fl.hInPageCount);
					update_16(fl.hInSize);
					update_16(fl.hInputSts);
					for(int i = 0; i < 4; i++) {
						update_16(fl.hReserved[i]);
					}
					return ;
				}

				static void convertFL_FILE_OUT_ATR(FL_FILE_OUT_ATR &fl) {
					update_16(fl.hOutOrder);
					update_16(fl.hPrnFace);
					convertPAR_TBL_RESOLUTION(fl.sPrnResolution);
					update_16(fl.hFaxDuplexFlag);
					for(int i = 0; i < 3; i++) {
						update_16(fl.hReserved[i]);
					}
					return ;
				}

				static void convertFU_FAX_ORG_INF(FU_FAX_ORG_INF &fu) {
					update_time_t(fu.sT);
					update_time_t(fu.sFaxStart);
					update_time_t(fu.sFaxEnd);
					update_time_t(fu.sDocKeep);
					update_16(fu.hTopPageIdx);
					update_16(fu.hEndPageIdx);
					update_16(fu.hAdrIdx);
					update_16(fu.hScanType);
					update_16(fu.hPageCount);
					update_16(fu.hComPageCount);
					update_16(fu.hAddressCnt);
					update_16(fu.hAddressEnd);
					update_16(fu.hRemainPage);
					update_16(fu.hStartPageIdx);
					update_16(fu.hDirectAddress);
					update_16(fu.hOrgInf);
					update_16(fu.hBoxId);
					update_16(fu.hBoxReceptCnt);
					update_16(fu.hBoxReceptEnd);
					update_16(fu.hSndChNo);
					update_16(fu.hClass);
					update_16(fu.hRelaySndKind);
					update_16(fu.hTsbOrgPwd);
					update_16(fu.hDssCnt);
					update_16(fu.hDssEnd);
					update_16(fu.hClientPC);
					update_16(fu.hDssRtyCount);
					update_16(fu.siDiscard);
					update_16(fu.siDiscardOnOff);
					return ;
				}

				static void convertFL_PAGE_HEADER(FL_PAGE_HEADER &fl) {
					update_16(fl.hPageTableCnt);
					update_16(fl.hPageTableSize);
					return ;
				}

				static void convertFL_PAGE_GROUP(FL_PAGE_GROUP &fl) {
					update_16(fl.hReserveMByte);
					update_16(fl.hFromPageNo);
					update_16(fl.hToPageNo);
					return ;
				}

				static void convertFL_PART_MAN(FL_PART_MAN &fl) {
					update_16(fl.hCurrentVolNo);
					update_16(fl.hRfu);
					for(int i = 0; i < 6; i++) {
						convertFL_PAGE_GROUP(fl.sPageGroup[i]);
					}
					return ;
				}

				static void convertFL_PAGE_MAN(FL_PAGE_MAN &fl) {
					update_u32(fl.liPgDataSize);
					update_16(fl.hPgStsFlag);
					for(int i = 0; i < 4; i++) {
						update_u32(fl.fl4PlaneSize[i]);
					}
					update_16(fl.hVolNo);
					update_16(fl.h4PlaneWriteSet);
					update_16(fl.h4PlaneReadSet);
					update_16(fl.hThumFile);
					update_u32(fl.liThumDataKSize);
					update_u32(fl.liThumDataCSize);
					update_u32(fl.liThumDataMSize);
					update_u32(fl.liThumDataYSize);
					update_16(fl.hDeleteRequestedCount);
					for(int i = 0; i < 7; i++) {
						update_16(fl.hReserve[i]);
					}
					return ;
				}

				static void convertFL_PAGE_THUM_INFO(FL_PAGE_THUM_INFO &fl) {
					update_16(fl.hCType);
					update_16(fl.hPgMLen);
					update_16(fl.hPgSLen);
					convertPAR_TBL_RESOLUTION(fl.sResolution);
					update_16(fl.hSize);
					update_16(fl.hInPgMLen);
					update_16(fl.hInPgSLen);
					convertPAR_TBL_COLOR_INFO(fl.sColorinf);
					update_16(fl.hYccForm);
					update_16(fl.hAngle);
					for(int i = 0; i < 27; i++) {
						update_16(fl.hReserved[i]);
					}
					return;
				}

				static void convertFL_PAGE_COM_ATR(FL_PAGE_COM_ATR &fl) {
					update_16(fl.hCType);
					update_16(fl.hKPara);
					update_16(fl.hPgMLen);
					update_16(fl.hPgSLen);
					convertPAR_TBL_RESOLUTION(fl.sResolution);
					update_16(fl.hSize);
					update_16(fl.hImgCoordinate);
					update_16(fl.hInPgMLen);
					update_16(fl.hInPgSLen);
					convertPAR_TBL_COLOR_INFO(fl.sEngColorInf);
					convertPAR_TBL_TWOCOLORS(fl.sEngTwoColors);
					update_16(fl.hYccForm);
					update_16(fl.hJobColorMode);
					update_16(fl.hAngle);
					update_16(fl.hOrientation);
					convertPAR_TBL_RESOLUTION(fl.sCopyResolution);
					for(int i = 0; i < 2; i++) {
						update_16(fl.hReserved2[i]);
					}
					convertPAR_TBL_RGBBALANCEINFO(fl.sRGBBalanceInfo);
					update_16(fl.hOriginalType);
					update_16(fl.hOneTouchMode);
					update_16(fl.hCenterCorner);
					update_16(fl.hPaperType);
					update_16(fl.hPDL);
					update_16(fl.hPrintScreen);
					update_16(fl.hTonerSave);
					update_16(fl.hSmoothing);
					update_16(fl.hValidity);
					update_16(fl.hScanMethod);
					convertFL_PAGE_THUM_INFO(fl.sPageThumInfo);
					convertPAR_TBL_ALLCOLORINFO(fl.sAllColorInfo);
					update_16(fl.hMonoColor);
					update_16(fl.hSharpness);
					update_16(fl.hImageQType);
					update_16(fl.hExtraImageQType);
					update_16(fl.hDFScanNoiseReduction);
					update_16(fl.hAutoTrapping);
					for(int i = 0; i < 4; i++) {
						update_16(fl.hReserved[i]);
					}
					update_16(fl.hContainedPage);
					update_16(fl.hMixImg);
					update_16(fl.hMixTransparent);
					update_16(fl.hMixFlg);
					update_16(fl.hSharpnessFlg);
					update_16(fl.hSmartCMMFlg);
					update_16(fl.hNegaposiReverse);
					update_16(fl.hDensityType);
					update_16(fl.hDensityVal);
					update_16(fl.hBackground);
					update_16(fl.hEditMode);
					update_16(fl.hOriginalSize);
					update_16(fl.hAlignmentAddInfo);
					return ;
				}

				static void convertFL_PAGE_IN_ATR(FL_PAGE_IN_ATR &fl) {
					update_16(fl.hPaperLength);
					update_16(fl.hDualFlag);
					update_u32(fl.liDataSize);
					update_16(fl.hSubPgNo);
					update_16(fl.hDetectedSize);
					for(int i = 0; i < 2; i++) {
						update_16(fl.hReserved2[i]);
					}
					return;
				}

				static void convertFL_PAGE_OUT_ATR(FL_PAGE_OUT_ATR &fl) {
					update_16(fl.hCopies);
					convertPAR_TBL_RESOLUTION(fl.sPrnResolution);
					update_16(fl.hPaperSize);
					update_16(fl.hMainMagnification);
					update_16(fl.hSubMagnification);
					update_16(fl.hCassette);
					update_16(fl.hSFBPaperSize);
					update_16(fl.hWhitePaperFlag);
					update_16(fl.hInsReverse);
					update_16(fl.hMoff);
					update_16(fl.hSoff);
					update_16(fl.hTabPaperFlag);
					update_16(fl.hTabMoff);
					update_16(fl.hTabSoff);
					update_16(fl.hTabWidth);
					update_16(fl.hPrnDuplex);
					update_16(fl.hMirror);
					update_16(fl.hInsPaperSize);
					update_16(fl.hInsPaperType);
					update_16(fl.hSpFeed);
					update_16(fl.hSpWidth);
					update_16(fl.hForceFrontSide);
					update_16(fl.hActMoff);
					update_16(fl.hActSoff);
					update_16(fl.hExpandPrnArea);
					update_16(fl.hCenteringCopy);
					for(int i = 0; i < 6; i++) {
						update_16(fl.hReserved[i]);
					}
					return;
				}

				static void convertFL_PAGE_MAN_TBL(FL_PAGE_MAN_TBL &fl) {
					convertFL_PAGE_MAN(fl.sPageMan);
					convertFL_PAGE_COM_ATR(fl.sPageComAtr);
					convertFL_PAGE_IN_ATR(fl.sPageInAtr);
					convertFL_PAGE_OUT_ATR(fl.sPageOutAtr);
					return ;
				}

				static void convertFL_FILE_MAN_FILE(FL_FILE_MAN_FILE &fl) {
					convertFL_FILE_STATUS(fl.sFileMan);
					convertFL_FILE_COM_ATR(fl.sFileComAtr);
					convertFL_FILE_IN_ATR(fl.sFileInAtr);
					convertFL_FILE_OUT_ATR(fl.sFileOutAtr);
					convertFU_FAX_ORG_INF(fl.sFaxOrgInf);
					convertFL_PAGE_HEADER(fl.sPageHeader);
					convertFL_PART_MAN(fl.sPartMan);
					for(int i = 0; i < FL_PAGE_MAX_COUNT; i++) {
						convertFL_PAGE_MAN_TBL(fl.sPageManTbl[i]);
					}
					return;
				}

				static int readFLStructure(FL_FILE_MAN_FILE &fl, char *filename) {
					int fd = open(filename, O_RDONLY);
					if(fd < 0) {
						printf("failed to open : %s\n", filename);
						return -1;
					}
					if(read(fd, &fl, sizeof(FL_FILE_MAN_FILE) ) < 0) {
						printf("failed to read : %s\n", filename);
						close(fd);
						return -1;
					}
					close(fd);
					return 0;
				}

				static int writeFLStructure(FL_FILE_MAN_FILE &fl, char *filename) {
					int fd = open(filename, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
					if(fd < 0) {
						printf("failed to open : %s\n", filename);
						return -1;
					}
					if(write(fd, &fl, sizeof(FL_FILE_MAN_FILE) ) < 0) {
						printf("failed to write : %s\n", filename);
						close(fd);
						return -1;
					}
					close(fd);
					return 0;
				}
			public:
				FLConverter::FLConverter() {
				}
				static int ConvertSystemFile(CString inputFile, CString outputFile);
		};
	}
}
#endif
