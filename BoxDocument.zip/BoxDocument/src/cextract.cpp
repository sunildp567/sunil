/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cextract.cpp
Revision: com_t#1
File Spec: EBX:TA8449.A-DEV_SRC;com_t#1
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:58:43

Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
  1:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
  	Creation Date: 13-JAN-2009 19:36:02
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
  
  2:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
  	Creation Date: 13-JAN-2009 18:00:09
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
  
  3:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
  	Creation Date: 13-JAN-2009 15:14:46
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
  
  ------------------------------------------------------------------------------
History:
 * Revision com_t#1 (APPROVED)
 *   Created:  09-JAN-2009 21:58:43      CHANDRAMOHAN.PUJARI
 *     Initial Version
========================== End of Source Header =============================*/

#include <vector>
#include <algorithm>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/Codecs/zip.h>
#include "cextract.h"
#include "cboxdocument.h"
#include "cbox.h"
#include "cfolder.h"
#include "cdocument.h"
#include "cpage.h"
#include "flconverter.h"
#include <iomanip>
#include <sstream>
#include <list>
#include <cerrno>
#include <map>
#include <CI/IndexedDB/Mash/include/comPar.h>
#include "proputils.h"
#include "CI/OperatingEnvironment/cexception.h"

//using namespace ci::DocumentStore;
using namespace ci::operatingenvironment;
using namespace ci::codecs;
using namespace ci::hierarchicaldb;
using namespace std;
using namespace dom;
#define EFBPASS "EFB@arc_ext#pass18"
#define OKI_EQUIPMENT_BRAND "OKI MFP Series"
namespace ci {
    namespace boxdocument {

        bool CExtractor::m_ExtractFlag;	


        /**
         * Extractor class provides facilities to extract archive.
         */
        /* Param c'tor */

        CExtractor::CExtractor(CString sessionID, CString sourcepath, std::vector<CString>documentpaths,CString localpath)
        {
            m_sessionID = sessionID;
            m_SourcePath	= sourcepath;
            m_Documentpaths=documentpaths;
            m_ExtractPath=localpath;
            m_ExtractStatus=READY;
            m_ExtractProgress = 0;
            m_bExtractError = false;
            std::vector<CString>::iterator it;
            it=m_Documentpaths.begin();
            m_BoxBasePath = (*it);
            it = it + 1;
            m_BoxNumber = (*it);
            it = it + 1;
            m_FolderName= (*it);		
            //Initialise the variables
            m_pProgressShmName = "";
            m_pStatusShmName = "";
            m_ThreadId = NULL;
	    m_convertSystemFile = false;
        }

        /** destructor */
        CExtractor::~CExtractor() {
            if(m_pStatusShmName.size()) {
                ExtractStatus sts;
                GetStatus(sts);
                DEBUGL6("CExtractor::~CExtractor::Status is %d\n",sts);
            }
            if(m_pProgressShmName.size()) {
                int progress;
                GetProgress(progress);
                DEBUGL6("CExtractor::~CExtractor::Progress is %d\n",progress);
            }
        }

        /**
         * get extracting status
         * @param[out] status - extracting status
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CExtractor::GetStatus(ExtractStatus &status)
        {
            void *pMapAddr;

            //Update to previous Status value
            status = m_ExtractStatus;

            // Bind to shared mem
            CString pShmName = m_pStatusShmName;
            DEBUGL8("CExtractor::GetStatus::shared memory name is %s\n",pShmName.c_str());
            Ref<SharedMemory> bBindshmName = SharedMemory::Bind(pShmName.c_str());
            if(!bBindshmName)		
            {
                switch(m_ExtractStatus) {
                    case Extractor::READY:
                    case Extractor::EXTRACTING:
                        break;
                    default:
                        return STATUS_OK;
                }
                DEBUGL1("CExtractor::GetStatus::Binding to Shared memory Failed, Current Status <%d>\n",status);				
                return STATUS_FAILED;
            }
            bBindshmName->Acquire();

            bBindshmName->Map(pMapAddr);
            if(pMapAddr==NULL)
            {
                DEBUGL1("CExtractor::GetStatus::Mapping Failed\n");
                bBindshmName = NULL;
                return STATUS_FAILED;
            }
            status = *((ExtractStatus*)pMapAddr);
            m_ExtractStatus = status;		
            bBindshmName->Unmap(pMapAddr);
            bBindshmName->Release();
            DEBUGL8("CExtractor::GetStatus::Status - %d\n",status);

	    switch (m_ExtractStatus){
		case Extractor::FINISHED :
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::FINISHED\n");
                	bBindshmName->Destroy();
                	return STATUS_OK;
		case Extractor::CANCEL_INITIATED:
			//As the extracting is in progress so during cancel process we are returning as extracting [Extractor::EXTRACTING]
			status = Extractor::EXTRACTING;
               		m_ExtractStatus = Extractor::EXTRACTING;
                	DEBUGL1("CExtractor::GetStatus:: Set Extractor::CANCEL_INITIATED\n");
                	bBindshmName =NULL;
                	return STATUS_OK; 
		case Extractor::CANCELED:
                	DEBUGL1("CExtractor::GetStatus:: Set Extractor::CANCELED\n");			
                	bBindshmName->Destroy();
                	return STATUS_OK;								
		case Extractor::READY:
                	DEBUGL1("CExtractor::GetStatus:: Set Extractor::READY\n");			
                	bBindshmName = NULL;
                	return STATUS_OK;									
		case Extractor::EXTRACTING:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::EXTRACTING\n");
			bBindshmName = NULL;
			return STATUS_OK;
		case Extractor::MAX_ALLOWED_RESOURCES_REACHED:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::MAX_ALLOWED_RESOURCES_REACHED\n");
			bBindshmName->Destroy();
			return STATUS_OK;
		case Extractor::UNIDENTIFIED_FILE_FORMAT:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::UNIDENTIFIED_FILE_FORMAT\n");
			bBindshmName->Destroy();
			return STATUS_OK;
		case Extractor::INVALID_ARCHIVE_FILE:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::INVALID_ARCHIVE_FILE\n");
			bBindshmName->Destroy();
			return STATUS_OK;
		case Extractor::ERROR:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::ERROR\n");
			bBindshmName->Destroy();
			return STATUS_OK;
		case Extractor::DISK_FULL:
			DEBUGL1("CExtractor::GetStatus:: Set Extractor::DISK_FULL\n");
			bBindshmName->Destroy();
			return STATUS_OK;
		default : //do nothing
	    }
        	
            bBindshmName = NULL;	
            return STATUS_OK;
        }

        /**
         * get extracting progress
         * @param[out] progress - extracting progress [0-100] %
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CExtractor::GetProgress(int &progress)
        {
            void *pMapAddr;

            //Update to previous progress value
            progress = m_ExtractProgress;

            // Bind to shared mem
            CString pShmName = m_pProgressShmName;
            DEBUGL8("CExtractor::GetProgress::Shared memory name is %s\n",pShmName.c_str());
            Ref<SharedMemory> bBindshmName = SharedMemory::Bind(pShmName.c_str());
            if(!bBindshmName)		
            {
                if(m_bExtractError) 
                     return STATUS_OK;
                if(PROGRESS_COMPLETED == m_ExtractProgress) 
                     return STATUS_OK; //on 100% completion, shared memory was destroyed.
                //just return 100% without binding to sharedmem.
                DEBUGL1("CExtractor::GetProgress::Binding to Shared memory Failed, Current Progress <%d>\n",progress);				
                return STATUS_FAILED;
            }		
            bBindshmName->Acquire();
            bBindshmName->Map(pMapAddr);
            if(pMapAddr==NULL)
            {		
                DEBUGL1("CExtractor::GetProgress::Mapping Failed\n");
                bBindshmName = NULL;
                return STATUS_FAILED;
            }
            progress = *((int*)pMapAddr);
            m_ExtractProgress = progress;
            bBindshmName->Unmap(pMapAddr);
            bBindshmName->Release();
            if(PROGRESS_COMPLETED == progress || m_ExtractStatus == Extractor::CANCELED) {
                DEBUGL6("CExtractor::GetProgress: Extraction completed. SharedMemory will be destroyed [%s]\n", pShmName.c_str());
                bBindshmName -> Destroy();
            }
            else if(PROGRESS_ERROR == progress) {
                m_bExtractError = true;
                DEBUGL6("CExtractor::GetProgress: Extraction failed..Status of operation may be incorrect..SharedMemory will be destroyed <%s>\n",pShmName.c_str());
                bBindshmName->Destroy();
            }
            bBindshmName = NULL;
            DEBUGL8("CExtractor::GetProgress::progress - %d\n",progress);
            return STATUS_OK;
        }

        /**
         * cancel to extract
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CExtractor::Cancel()
        {
            DEBUGL4("CExtractor::Cancel::Enter\n");

            if(m_ThreadId->Stop()!=STATUS_OK)
            {
                DEBUGL1("CExtractor::Cancel::Unable to stop the Thread!!!\n");
                return STATUS_FAILED;
            }
            DEBUGL8("CExtractor::Cancel::Thread Stopped successfully..\n");

      		
            DEBUGL8("CExtractor::Cancel::Clean up process initiated\n");
            CExtractor *cextractorObj = this;
            CString boxbasepath = cextractorObj->m_BoxBasePath;
            CString boxNumber = cextractorObj->m_BoxNumber;
            CString folderName = cextractorObj->m_FolderName;		
	     int cancelThreadRetryCnt = 1000;

            CString expath;
            if(cextractorObj->m_FolderName.empty())
                expath = cextractorObj->m_BoxBasePath + "/" + cextractorObj->m_BoxNumber + "/";
            else
                expath = cextractorObj->m_BoxBasePath + "/" + cextractorObj->m_BoxNumber + "/" + cextractorObj->m_FolderName;

            if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                DEBUGL2("CBox::ExtractArchive: Unable to create the file\n");

            //CleanUp of temporary files
            //changed the $EB2/tmp path to "/imagedata/ci/tmp/"
            CString tmppath = Utility::GetCITmpPath();
            CString basefolder =  "/storage/box/";
            CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
            /*	
               if(folderName.empty())
               tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
               else
               tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;		
               */
            tmppath += "ExtractDocument_" + cextractorObj->m_sessionID;

            //Initialize the statusShmid
            //If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetStatus() API		
	    bool bCreated;
            Ref<SharedMemory> pStatusShmid = SharedMemory::Bind(m_pStatusShmName.c_str(), SHM_CREATE_IF_BIND_FAILS|SHM_NO_AUTO_DESTROY, bCreated, UUID_CONTENT_LENGTH);
            if(!pStatusShmid)
            {
                DEBUGL1("CExtractor::Cancel: Failed to Create Status Shared Memory\n ");
                return STATUS_FAILED;
            }
            void *pStatusMapAddr;
            int iStatusShmPidSize = pStatusShmid->getSize();
            pStatusShmid->Map(pStatusMapAddr);
            if(pStatusMapAddr!=NULL)
                memset(pStatusMapAddr,'\0',iStatusShmPidSize);
            else if(pStatusMapAddr == NULL)
            {  
                DEBUGL1("CExtractor::Cancel::Shared memory Mapping Failed\n");
                return STATUS_FAILED;
            }
	     
            //Update the status		
            *((ExtractStatus*)pStatusMapAddr) = Extractor::CANCEL_INITIATED;

		  //Check if the status is updated to CANCELED from extracting thread
                DEBUGL8("CArchiver::Cancel: Archiving status=%d\n",*((ExtractStatus*)pStatusMapAddr));
                for (int i =0; i < cancelThreadRetryCnt; i++)   {
                        if (*((ExtractStatus*)pStatusMapAddr) == Extractor::CANCELED )   {
                                DEBUGL1("CArchiver::Cancel: CANCELED is set by archiving thread hence clean up process is started\n");
                                break;
                        }
                        usleep(100000);
                }

            //Delete the temporary folder containing the zips and documents
            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                DEBUGL2("CExtractor::Cancel - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());				

            //Update the status		
            *((ExtractStatus*)pStatusMapAddr) = Extractor::CANCELED;
	    pStatusShmid->Destroy();
            pStatusShmid = NULL;
			
		//If documents are extracted partially read from the file and delete them.
            ci::operatingenvironment::Ref<ByteStream> bytestreamRef =
                ci::operatingenvironment::File::Open(TEMPORARY_EXTRACT_DOC_LIST);

            if(bytestreamRef)
            {
                CString str = "dummy";
                while(!str.empty())
                {
                    str = bytestreamRef->ReadLine();
                    str = str.substr(0, str.length() - 1);
                    DEBUGL8("CExtractor::Cancel:: Remove extracted document (%s)\n", str.c_str());
                    if(Utility::RemoveResource(str)!=STATUS_OK)
                        DEBUGL2("CExtractor::Cancel:: failed to remove the half extracted document\n");
                }
            }
            else
                DEBUGL8("CExtractor::Cancel:: No partially extracted documents exist\n");
	        Utility::RemoveResource(TEMPORARY_EXTRACT_DOC_LIST);

            DEBUGL4("CExtractor::Cancel::Exit\n");		
            return STATUS_OK;
        }

        /**	
         *	Function: CreateThread
         * 	Description:
         *		This function creates a thread and that does the extracting job
         *   	@return: Status
         */		
        Status CExtractor::CreateExtractThread()
        {
            DEBUGL4("CExtractor::CreateExtractThread::Enter\n");		

            Status pRet;
            m_ThreadId = NULL;
            CString lockpath="lockingExtractThread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRet = Utility::EnterCriticalSection(threadMutex, lockpath);

            m_pProgressShmName = CUUID().toString();
            m_pStatusShmName = CUUID().toString();

            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
            m_ExtractFlag = FLAG_SET;

            CExtractor *extractorObj = this;		
            pRet=CreateThread(StartExtract,reinterpret_cast<void*>(extractorObj),m_ThreadId);
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CExtractor::CreateExtractThread::Could not Create a Thread\n");
                Utility::LeaveCriticalSection(threadMutex);
                return STATUS_FAILED;
            }
            else
                DEBUGL8("CExtractor::CreateExtractThread: Creation of thread Initiated\n");

            //Once local variable copied Flag is set to 0 and loop ends		
            while(1)
            {	
                if(m_ExtractFlag == FLAG_RESET)
                {
                    DEBUGL8("CDocument::CreateExtractThread: -- Flag is Reset <%d> \n",m_ExtractFlag);	
                    break;
                }
                DEBUGL8("CDocument::CreateExtractThread: -- Flag not reset \n");				
            }

            //exit criticalsection
            pRet = Utility::LeaveCriticalSection(threadMutex);
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CExtractor::CreateExtractThread: Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;			
            }

            DEBUGL4("CExtractor::CreateExtractThread::Exit\n");

            return pRet;
        }	

        /**	
         *Function: CreateThread
         * Description:
         *		This function creates a thread and returns the thread id to the user
         * @param1: the function name with which thread is to be created
         * @param2: the argument to be passed to the function
         * @param3: the thread id that is returned after the creation of the thread
         * Return Values:
         *   	STATUS_OK if successful
         *   	STATUS_FAILED on failure				
         */					
        Status CExtractor::CreateThread(ThreadFunction functionName, ThreadArgument functionArgument, Ref<Thread> &threadId)
	{
		DEBUGL4("CExtractor::CreateThread::Enter\n");		

		if(!(threadId = Thread::Create(functionName)))
		{
			DEBUGL1("CExtractor::CreateThread::Unable to create the thread\n");
			return STATUS_FAILED;
		}
		else
		{
			m_ThreadId = threadId;
			DEBUGL8("CExtractor::CreateThread::Thread created successfully\n");
			if(threadId->Start(functionArgument)!=STATUS_OK)
			{
				DEBUGL1("CExtractor::CreateThread::Unable to start the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL5("CExtractor::CreateThread::Thread started successfully\n");

			if(threadId->Detach()!=STATUS_OK)
			{
				DEBUGL1("CExtractor::CreateThread: -Unable to detach the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL8("CExtractor::CreateThread: -Thread detached successfully\n");
		}

		DEBUGL4("CExtractor::CreateThread::Exit\n");	
		return STATUS_OK;
	}

        /**
         * StartExtract -Extracts the given archive used as a thread routine
         * @param[in] arg - arguments if any
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *         STATUS_DISK_FULL on disk Full.	
         */
        void* CExtractor::StartExtract(void *arg)
        {
            DEBUGL4("CExtractor::StartExtract::Enter\n");

            Status ret;
            CExtractor *cextractorObj = ((CExtractor*)arg);
            //Ref <ci::DocumentStore::DocumentStore> ds;

            CString expath;
            if(cextractorObj->m_FolderName.empty())
                expath = cextractorObj->m_BoxBasePath + "/" + cextractorObj->m_BoxNumber + "/";
            else
                expath = cextractorObj->m_BoxBasePath + "/" + cextractorObj->m_BoxNumber + "/" + cextractorObj->m_FolderName;

            DEBUGL8("CExtractor::StartExtract::expath = (%s)\n", expath.c_str());

            if(Utility::CreateUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                DEBUGL2("CExtractor::StartExtract: Unable to create the file\n");

            void *pStatusMapAddr;
            // Bind to Status shared mem
            CString pStatusShmName = cextractorObj->m_pStatusShmName;
            DEBUGL8("CExtractor::StartExtract::shared memory name is %s\n",pStatusShmName.c_str());
            //If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetStatus() API		
            Ref<SharedMemory> pStatusShmid= SharedMemory::Create(pStatusShmName.c_str(),UUID_CONTENT_LENGTH, false, false);
            if(!pStatusShmid)
            {
                DEBUGL1("CExtractor::StartExtract:: Failed to Create Shared Memory for Status Operation\n ");
                if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
			DEBUGL2("CExtractor::StartExtract: Unable to delete the file\n");
                m_ExtractFlag = FLAG_RESET;
                return NULL;
            }

            int iStatusShmPidSize = pStatusShmid->getSize();
            pStatusShmid->Map(pStatusMapAddr);
            if(pStatusMapAddr!=NULL)
                memset(pStatusMapAddr,'\0',iStatusShmPidSize);
            else
            {
                DEBUGL1("CExtractor::StartExtract::Shared memory Mapping Failed\n");
                if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                pStatusShmid -> Destroy();
                        DEBUGL2("CExtractor::StartExtract: Unable to delete the file\n");
                m_ExtractFlag = FLAG_RESET;

                return NULL;
            }
            pStatusShmid->Acquire();
	     if (*((ExtractStatus*)pStatusMapAddr) == Extractor::CANCEL_INITIATED)   {
		 	*((ExtractStatus*)pStatusMapAddr) = Extractor::CANCELED;
			pStatusShmid->Release();
			m_ExtractFlag = FLAG_RESET;
			DEBUGL1("CExtractor::StartExtract: Found CANCEL_INITIATED so marked CANCELED and exiting exttract thread\n");
			return NULL;
	     }
            //Set Extract status to Extracting
            *((ExtractStatus*)pStatusMapAddr) = Extractor::EXTRACTING;
            pStatusShmid->Release();

            //set the initial value of Extract progress as 1% . The Start Extract thread will update it as and when documents are extracted
            void *pProgressMapAddr;
            // Bind to Progress shared mem
            CString pProgressShmName = cextractorObj->m_pProgressShmName;
            DEBUGL8("CExtractor::StartExtract::shared memory name is %s\n",pProgressShmName.c_str());
            //If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetProgress() API		
            Ref<SharedMemory> pProgressShmid = SharedMemory::Create(pProgressShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!pProgressShmid)
            {
                DEBUGL1("CExtractor::StartExtract: Failed to Create Shared Memory for Progress operation\n ");
                if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CExtractor::StartExtract: Unable to delete the file\n");
                pStatusShmid -> Destroy();
                m_ExtractFlag = FLAG_RESET;
                return NULL;
            }
            int iProgressShmPidSize = pProgressShmid->getSize();
            pProgressShmid->Map(pProgressMapAddr);
            if(pProgressMapAddr!=NULL)
                memset(pProgressMapAddr,'\0',iProgressShmPidSize);
            else
            {
                DEBUGL1("CExtractor::StartExtract::Shared memory Mapping Failed\n");
                if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                        DEBUGL2("CExtractor::StartExtract: Unable to delete the file\n");
                pStatusShmid -> Destroy();
                pProgressShmid -> Destroy();
                m_ExtractFlag = FLAG_RESET;
                return NULL;
            }
	    /* Fix for EBX_STFR_18418. Only after both Status & Progress Shared Memory is created reset the flag
	       So that ExtractArchive() will return to the User after both the SharedMemory's are created*/
            m_ExtractFlag = FLAG_RESET;
            pProgressShmid->Acquire();
            //Write here
            *((int*)pProgressMapAddr)=1;
            pProgressShmid->Release();

	     if (*((ExtractStatus*)pStatusMapAddr) == Extractor::CANCEL_INITIATED)   {
		 	pStatusShmid->Acquire();
		 	*((ExtractStatus*)pStatusMapAddr) = Extractor::CANCELED;
	              pStatusShmid->Release();
			DEBUGL1("CExtractor::StartExtract: Found CANCEL_INITIATED so marked CANCELED and exiting exttract thread\n");
			return NULL;
	     }
            //Extract the documents	
            ret = cextractorObj->Extract(cextractorObj,pProgressMapAddr);
	     if (*((ExtractStatus*)pStatusMapAddr) == Extractor::CANCEL_INITIATED)   {
		 	pStatusShmid->Acquire();
		 	*((ExtractStatus*)pStatusMapAddr) = Extractor::CANCELED;
	              pStatusShmid->Release();
			DEBUGL1("CExtractor::StartExtract: Found CANCEL_INITIATED so marked CANCELED and exiting exttract thread\n");
			return NULL;
	     }
            if(ret!=STATUS_OK)
            {
                DEBUGL1("CExtractor::StartExtract:: Extract Failed\n");
                if(ret == ::STATUS_DISK_FULL)
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::DISK_FULL\n");			
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::DISK_FULL;
                }
                else if(ret == STATUS_MAX_ALLOWED_RESOURCES_REACHED)
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::MAX_ALLOWED_RESOURCES_REACHED\n");			
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::MAX_ALLOWED_RESOURCES_REACHED;
                }
                else if(ret == STATUS_UNIDENTIFIED_FILE_FORMAT)
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::UNIDENTIFIED_FILE_FORMAT\n");
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::UNIDENTIFIED_FILE_FORMAT;
                }
                else if(ret == STATUS_INVALID_ARCHIVE_FILE)
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::INVALID_ARCHIVE_FILE\n");
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::INVALID_ARCHIVE_FILE;
                }	
                else if(ret == STATUS_INVALID_PRODUCTTYPE)
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::INVALID_ARCHIVE_FILE\n");
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::STATUS_INVALID_PRODUCTTYPE;
                }
                else
                {
                    DEBUGL1("CExtractor::StartExtract:: Set Extractor::ERROR\n");			
                    *((ExtractStatus*)pStatusMapAddr) = Extractor::ERROR;				
                }
                if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                    DEBUGL2("CExtractor::StartExtract: Unable to delete the file\n");

                pStatusShmid = NULL;
                pProgressShmid->Acquire();
                //Write here
                *((int*)pProgressMapAddr)=-1;
                pProgressShmid->Release();
                pProgressShmid = NULL;
                
                return NULL;
            }		
            pStatusShmid->Acquire();
            DEBUGL8("CExtractor::StartExtract::Updating status to finished\n");		
            *((ExtractStatus*)pStatusMapAddr) = Extractor::FINISHED;
            pStatusShmid->Release();
            pProgressShmid->Acquire();
            *((int*)pProgressMapAddr)=PROGRESS_COMPLETED;
            pProgressShmid->Release();
            DEBUGL8("CExtractor::StartExtract::Current progress <100>\n");		
            Utility::RemoveResource(TEMPORARY_EXTRACT_DOC_LIST);

            if(Utility::DeleteUniqueFile(expath, ".extractisinprogress_" + cextractorObj->m_sessionID) != STATUS_OK)
                DEBUGL2("CExtractor::StartExtract: Unable to delete file\n");
            if (cextractorObj->m_ExtractProgress == PROGRESS_COMPLETED)
	    	pProgressShmid->Destroy();
	    pProgressShmid = NULL;
	    if (cextractorObj->m_ExtractStatus == Extractor::FINISHED)
	    	pStatusShmid->Destroy();
            pStatusShmid = NULL;
            DEBUGL4("CExtractor::StartExtract::Exit\n");		
            return NULL;		
        }	

        /**
         * Extracts the zip file to a local temporary path and then uploads the documents to the given box/folder 
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */			
        Status CExtractor::Extract(CExtractor *cextractorObj,void *pProgressMapAddr)
        {
            DEBUGL4("CExtractor::Extract::Enter\n");	

            if(pProgressMapAddr==NULL)
            {
                DEBUGL1("CExtractor::Extract:sahred memory MAP Address is invalid\n");
                return STATUS_FAILED;
            }

            CString boxbasepath = cextractorObj->m_BoxBasePath;
            CString boxNumber = cextractorObj->m_BoxNumber;
            CString folderName = cextractorObj->m_FolderName;	
            CString archivePath = cextractorObj->m_SourcePath;

            Status ret;
            //changed the $EB2/tmp path to "/imagedata/ci/tmp/"
            CString tmppath = Utility::GetCITmpPath();
            CString basefolder =  "/storage/box/";
            CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
            DEBUGL8("CExtractor::Extract boxbasepath (%s) boxNumber (%s) folderName (%s) archivePath (%s) tmppath (%s) basefolder (%s) strboxbasepath (%s) \n",
                    boxbasepath.c_str(), boxNumber.c_str(), folderName.c_str(), archivePath.c_str(), tmppath.c_str(), basefolder.c_str(), strboxbasepath.c_str());

            /* 
               if(folderName.empty())
               tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
               else
               tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;
               */
            tmppath += "ExtractDocument_" + cextractorObj->m_sessionID;

            DEBUGL8("CExtractor::Extract tmppath (%s)\n", tmppath.c_str());
            //Download the Zip file
            CString localPath=archivePath;
            DEBUGL8("CExtractor::Extract localpath = (%s)\n",localPath.c_str());

            //Extract the Zip file 		
            ZipRef zipRef= Zip::Acquire();
            ret = zipRef->ExtractZip(localPath,tmppath);
            if(ret!=STATUS_OK)
            {
                DEBUGL1("CExtractor::Extract - Codecs::ExtractZip failed\n");
                if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                    DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());							
                if(ret == ::STATUS_DISK_FULL)
                    return ret;
                else 
                    return STATUS_INVALID_ARCHIVE_FILE;
            }
            int curProgress=5;
            *((int*)pProgressMapAddr)=curProgress;	

            //Bind to the temporary folder which holds the zips and documents
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> pFolder=NULL;
            pFolder=  ci::operatingenvironment::Folder::Bind(tmppath);
            if(!pFolder)
            {	
                DEBUGL1("CExtractor::Extract - Folder Bind failed\n");
                if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                    DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());							
                return STATUS_FAILED;
            }	

            std::vector<CString> fileNames;
            fileNames.clear();
            ret = pFolder->GetFiles(fileNames);
            if(ret!=STATUS_OK)
            {
                DEBUGL1("CExtractor::Extract - Folder::GetFiles failed\n");
                if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                    DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());				
                return ret;
            }

            if(fileNames.empty())
            {
                DEBUGL1("CExtractor::Extract - No Files present in main Zip\n");
                if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                    DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());								
                return STATUS_UNIDENTIFIED_FILE_FORMAT;			
            }
            try 
            {

                std::vector<CString>::iterator iter;
                int count=1;
                int numOfDocs = fileNames.size();
                DEBUGL8("CExtractor::Extract filenames.size  = (%d)\n",numOfDocs);
                for(iter=fileNames.begin();iter!=fileNames.end();iter++,count++)
                {
                    DEBUGL8("CExtractor::Extract - File Name is %s\n",iter->c_str());
                    if(iter->compare("ARCHIVE.XML")==0)
                    {
                        DEBUGL8("CExtractor::Extract - Archive.xml file\n");
                        hierarchicaldb::HierarchicalDBRef pHdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                        hierarchicaldb::DocumentRef pDoc = NULL;
                        CString filepath = tmppath+"/"+(*iter);

                        Status st = pHdb->CreateTempDocumentFromFile(pDoc,filepath);
                        if (st != STATUS_OK)
                        {
                            DEBUGL1("CExtractor::Extract::Create Temp HDB document Failed\n");
                            return st;
                        }
                        CString propValue;				
                        dom::NodeRef pNode = pHdb->BindToElement(pDoc,"ArchiveInfo/productType");
                        if(!pNode)
                        {
                            DEBUGL1("CExtractor::Extract::Unable to bind to ArchiveInfo/productType\n");
                            return STATUS_UNIDENTIFIED_FILE_FORMAT;
                        }
                        else
                            propValue = pNode->getTextContent();

                        DEBUGL8("CExtractor::Extract::PropVal = %s Product_Type = <%s>\n",propValue.c_str(),PRODUCT_TYPE);
                       
			CString equipmentbrand = Utility::GetEquipmentBrand();
			CString EQUIPMENT_BRAND("");
	
			if(equipmentbrand == "OKI")
				EQUIPMENT_BRAND = OKI_EQUIPMENT_BRAND;
			else
				EQUIPMENT_BRAND = PRODUCT_TYPE;
				st = Utility::CompareProductType(propValue,EQUIPMENT_BRAND, m_convertSystemFile);
			if(st == STATUS_INVALID_PRODUCTTYPE)
                        {
                            DEBUGL1("CExtractor::Extract::Product Codes Does not Match -- Archived code %s and Extracted code %s\n",propValue.c_str(),PRODUCT_TYPE);
                            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());
                            return STATUS_INVALID_PRODUCTTYPE;
                        }
                    }
                    else
                    {
                        CString zipFilePath = tmppath +"/";
                        zipFilePath += iter->c_str();
                        DEBUGL8("CExtractor::Extract - zipFilePath %s\n",zipFilePath.c_str());			
                        CString dPath = tmppath+"/";
                        dPath+="Document";
                        std::ostringstream oss;
                        oss << count;							
                        dPath+=oss.str();
                        ret = zipRef->ExtractZip(zipFilePath,dPath,EFBPASS);
                        if(ret!=STATUS_OK)
                        {
                            DEBUGL1("CExtractor::Extract - Codecs::ExtractInner ZIP failed\n");
                            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());	
                            if(ret == ::STATUS_DISK_FULL)
                                return ret;
                            else
                                return STATUS_UNIDENTIFIED_FILE_FORMAT;
                        }

                    }
                    curProgress=(int)((float)((((float)count)/((float)numOfDocs))*60) + 5);
                    if(curProgress < PROGRESS_COMPLETED)
                    {	
                        DEBUGL8("CExtractor::Extract - Current progress <%d>\n",curProgress);
                        *((int*)pProgressMapAddr)=curProgress;
                    }					
                }
            }
            catch(CException & except)
            {
                DEBUGL1("\nCExtractor::Extract: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCExtractor::Extract: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            int totalSize = 0;
            //Upload the files
            ret = UploadDocument(fileNames,totalSize,cextractorObj,pProgressMapAddr);
            if(ret!=STATUS_OK)
            {
                DEBUGL1("CExtractor::Extract - UploadDocument Failed\n");
                if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                    DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());							
                return ret;
            }

            //Delete the temporary folder containing the zips and documents
            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());				

            DEBUGL4("CExtractor::Extract::Exit\n");			
            return STATUS_OK;	
        }

        /**
         * The size of the resource on local path is calculated
         * @param[in] filePath - the path of the resource
         * @param[out] size - the size of the resource
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CExtractor::FileSize(CString filePath, int& size,CExtractor *cextractorObj,std::vector<CString> fileNames)
        {
            DEBUGL4("CExtractor::FileSize::Enter\n");	

            CString boxbasepath = cextractorObj->m_BoxBasePath;
            CString boxNumber = cextractorObj->m_BoxNumber;
            CString folderName = cextractorObj->m_FolderName;	
            uint64 filesize=0;
            std::vector<CString>::iterator iter;	

            int count=1;	
            for(iter=fileNames.begin();iter!=fileNames.end();iter++,count++)
            {
                DEBUGL8("CExtractor::FileSize - File Name is %s\n",iter->c_str());

                CString docName="Document";
                std::ostringstream oss;
                oss << count;							
                docName+=oss.str();

                DEBUGL8("CExtractor::FileSize - DocName is %s\n",docName.c_str());
                //changed the $EB2/tmp path to "/imagedata/ci/tmp/"
                //CString tmpFilePath = Utility::GetCITmpPath()+tmpFileName;
                //uint64 filesize;
                char stLine[1024];
                char ignore[1024];
                CString cmd = "du -bs "+ filePath+"/"+docName;// +" | cut -f1 > \'"+ tmpFilePath + "\'";
                FILE *p = popen(cmd.c_str(),"r");
                if(p)
                {
                    fgets(stLine,sizeof(stLine),p);
                    sscanf(stLine,"%llu %s",&filesize,ignore);
                    pclose(p);
                }
            }	

            size = filesize;
            DEBUGL4("CExtractor::FileSize size (%llu)\n", size);
            DEBUGL4("CExtractor::FileSize::Exit\n");				
            return STATUS_OK;		
        }

        /**
         * Upload the douments to the specified box/folder on the webdav server
         * @param[in] fileNames - the documents to be uploaded
         * @param[out] totalSize - the estimated total size of the resource to be uploaded
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CExtractor::UploadDocument(std::vector<CString> fileNames,int totalSize,CExtractor *cextractorObj,void *pProgressMapAddr)
        {
            DEBUGL4("CExtractor::UploadDocument::Enter\n");	
            CString boxbasepath = cextractorObj->m_BoxBasePath;
            CString boxNumber = cextractorObj->m_BoxNumber;
            CString folderName = cextractorObj->m_FolderName;	
            CString extractPath = cextractorObj->m_ExtractPath;
            CString pdocName("");
            //changed the $EB2/tmp path to "/imagedata/ci/tmp/"
            CString tmppath = Utility::GetCITmpPath();	
            CString basefolder =  "/storage/box/";
            CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
            Status sdf;

            DEBUGL8("CExtractor::UploadDocument - boxbasepath (%s) boxnumber (%s) foldername (%s) extractpath (%s)\n",
                    boxbasepath.c_str(), boxNumber.c_str(), folderName.c_str(), extractPath.c_str());				
            /*if(folderName.empty())
              tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
              else
              tmppath+="ExtractDocument_" + cextractorObj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;
              */
            tmppath += "ExtractDocument_" + cextractorObj->m_sessionID;

            //Add the documents extracted to the temporary file (/storage/box/EFilingBoxes/.extractedcontents)
            Ref<ci::operatingenvironment::Folder> folder = NULL;

            DEBUGL8("CExtractor::UploadDocument tmppath (%s)\n",tmppath.c_str());
            try 
            {
                uint64 completedFileSize=0;	
                std::vector<CString>::iterator iter;	
                typedef std::map<CString, CString> property_pair;
                int count=1;
                int numberOfFiles = fileNames.size();
                int curProgress = 65;
                *((int*)pProgressMapAddr) = curProgress;
                DEBUGL8("CExtractor::UploadDocument: numOfFiles = (%d)\n",numberOfFiles);
                for(iter=fileNames.begin();iter!=fileNames.end();iter++,count++)
                {
                    DEBUGL8("CExtractor::UploadDocument - File Name is %s\n",iter->c_str());
                    CString collPath = extractPath;
                    std::vector<CString> docVec;
                    DEBUGL8("CExtractor::UploadDocument - collPath is %s\n",collPath.c_str());

                    if(Utility::GetCollectionList(docVec, collPath)!=STATUS_OK) 
                    {
                        DEBUGL1("CExtractor::UploadDocument::GetCollectionList failed\n");
                        return STATUS_FAILED;
                    }
                    if(boxbasepath != "ITUTBoxes" && docVec.size() >= CBoxDocument::DOC_LIMIT) 
                    {
                        DEBUGL1("CExtractor::UploadDocument:: The number of documents reach limit\n");
                        return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                    }
                    if(iter->compare("ARCHIVE.XML")==0)
                    {
                        DEBUGL8("CExtractor::UploadDocument - Archive.xml file\n");				
                    }
                    else 
                    {
                        CString docPath = tmppath +"/";
                        docPath+="Document";				
                        std::ostringstream oss;
                        oss << count;							
                        docPath+=oss.str();
                        //Now Get the Details such as DocumentName etc..
                        //Bind to the temporary folder which holds the zips and documents
                        ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> pZipFolder=NULL;
                        pZipFolder=  ci::operatingenvironment::Folder::Bind(docPath);
                        if(!pZipFolder)
                        {	
                            DEBUGL1("CExtractor::UploadDocument - Folder Bind failed\n");
                            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());							
                            return STATUS_FAILED;
                        }	
                        pdocName = "";
                        Status ret = pZipFolder->GetFirstSubFolder(pdocName);
                        if(ret!=STATUS_OK)
                        {
                            DEBUGL1("CExtractor::UploadDocument - Folder::GetFolder failed\n");
                            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());				
                            return ret;
                        }
                        if(pdocName.empty())
                        {
                            DEBUGL1("CExtractor::UploadDocument - No Files present in Extracted Zip\n");
                            if((ci::operatingenvironment::Folder::Remove(tmppath,true))!=STATUS_OK)
                                DEBUGL2("CExtractor::Extract - Could not delete the %s folder :: Delete Manually\n",tmppath.c_str());								
                            return STATUS_UNIDENTIFIED_FILE_FORMAT;			
                        }
                        else
                            DEBUGL8("CExtractor::UploadDocument -Folder Name is <%s>\n",pdocName.c_str());
                        //Now remove any sts Files present in the path and create a creating.sts file.
                        CString eNewpath = docPath+"/"+pdocName+"/";
                        if(ci::operatingenvironment::File::Exists(eNewpath+"using.sts"))
                        {
                            Utility::RemoveResource(eNewpath+"using.sts");
                        }
                        else if(ci::operatingenvironment::File::Exists(eNewpath + "reserving.sts"))
                        {
                            Utility::RemoveResource(eNewpath + "reserving.sts");
                        }
                        //Create the status file
                        //CString statuspath = docPath + "/creating.sts";
                        CString statuspath = "'" + eNewpath + "creating.sts'";
                        CString createstatusfile = "touch " + statuspath;
                        int r;
                        ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
                        sysinfo->RunCmd(createstatusfile, r);
                        DEBUGL8("CExtractor::Extract - Status file (creating.sts) created\n");

                        //Update Property List
                        std::map<CString, CString> mWebDAVProperties;				
                        std::map<CString, CString>::iterator        propIterator;
                        mWebDAVProperties.clear();

                        // confirm documentname folder does not exist
                        CString path = extractPath+"/";
                        DEBUGL8("CExtractor::UploadDocument path<%s>\n",path.c_str());

                        CString docName(pdocName);
                        CString newpath = path + docName + "/";
                        DEBUGL8("CExtractor::UploadDocument newpath<%s>\n",newpath.c_str());


                        if(Utility::ResourceExist(newpath)) 
                        {
                            // if the document name already exists get the next available document Number
                            uint docnum = 1;
                            std::ostringstream strm;
                            // if documentname folder exist, add suffix to path
                            while(true) 
                            {
                                strm.str("");
                                strm << std::setfill('0') << std::setw(3) << docnum;
                                newpath = path + docName + "-" + strm.str() + "/";
                                if(!Utility::ResourceExist(newpath)) 
                                {
                                    docName = docName + "-" + strm.str();
                                    break;
                                }
                                docnum++;
                            }
                        }	
                        newpath = path + docName + "/";
                        DEBUGL8("CExtractor::UploadDocument newpath<%s>\n",newpath.c_str());

                        FILE *fp = fopen(TEMPORARY_EXTRACT_DOC_LIST, "a+");		
                        if(!fp) 						
                            DEBUGL2("CBoxDocument::Acquire: Failed to create the /storage/box/EFilingBoxes/.extractedfiles file\n");

                        if(fp)
                        {
                            CString content = newpath + "\n";
                            if(fwrite(content.c_str(), content.length(), 1, fp) == 0)
                                DEBUGL2("CBoxDocument::Acquire: Failed to write\n");

                            fflush(fp);
                            fsync(fileno(fp));
                            fclose(fp);
                        }

                        //Status ds = ci::operatingenvironment::Folder::CopyDir(docPath, newpath);
                        Status ds = ci::operatingenvironment::Folder::CopyDir(eNewpath, newpath);
                        if((ds !=STATUS_OK)) 
                        {
                            Utility::RemoveResource(newpath);
                            return ds;
                        }

			//Convert the system files for Image, Thumbnail and SubSampling if the document 
			//from eBX is getting extracted to eBN
			if(m_convertSystemFile)
			{
				CString convertSystemFile = newpath + "/Image/00000";
				int convertReturn = FLConverter::ConvertSystemFile(convertSystemFile,convertSystemFile);	
				if(convertReturn != 0)
				{
					DEBUGL1("CExtractor::UploadDocument:Failed to convert the image system file\n");
					if (STATUS_OK != ci::operatingenvironment::File::DeleteFile(convertSystemFile))
						DEBUGL1("CExtractor::UploadDocument: Failed to delete file: %s\n", convertSystemFile.c_str());
					return STATUS_FAILED;
				}
				convertSystemFile = newpath + "/Thumbnail/00000";
				convertReturn = FLConverter::ConvertSystemFile(convertSystemFile,convertSystemFile);	
				if(convertReturn != 0)
				{
					DEBUGL1("CExtractor::UploadDocument:Failed to convert the thumbnail system file\n");
					if (STATUS_OK != ci::operatingenvironment::File::DeleteFile(convertSystemFile))
						DEBUGL1("CExtractor::UploadDocument: Failed to delete file: %s\n", convertSystemFile.c_str());
					return STATUS_FAILED;
				}
				convertSystemFile = newpath + "/Subsampling/00000";

				convertReturn = FLConverter::ConvertSystemFile(convertSystemFile,convertSystemFile);	
				if(convertReturn != 0)
				{
					DEBUGL1("CExtractor::UploadDocument:Failed to convert the subsampling system file\n");
					if (STATUS_OK != ci::operatingenvironment::File::DeleteFile(convertSystemFile))
						DEBUGL1("CExtractor::UploadDocument: Failed to delete file: %s\n", convertSystemFile.c_str());
					return STATUS_FAILED;
				}

			}

                        //Setting document properties
                        //DocumentRef doc=NULL;				
                        //doc = new CDocument(m_sessionID, boxbasepath, boxNumber, folderName, docName);
                        // Save WebDAV properties
                        mWebDAVProperties["documentName"]= docName;
                        DEBUGL8("CExtractor::UploadDocument: documentName <%s>\n",(mWebDAVProperties["documentName"]).c_str());

                        CString local = Utility::GetUnixTime();

                        mWebDAVProperties.insert(property_pair::value_type("creationDate", local));
                        mWebDAVProperties.insert(property_pair::value_type("lastModifiedDate", local));			
                        mWebDAVProperties.insert(property_pair::value_type("lastAccessDate", local));	 	 						
                        mWebDAVProperties.insert(property_pair::value_type("lastArchiveDate", ""));
                        //Generate and save WorkspaceDocName
                        CString WorkspaceDocName = CUUID().toString();
                        mWebDAVProperties.insert(property_pair::value_type("WorkspaceDocName", WorkspaceDocName));

                        CString xmlfile = "documentproperties.xml";
                        sdf = Utility::SetProperties(newpath,xmlfile,mWebDAVProperties);
                        if(sdf != STATUS_OK) 
                        {
                            Status rst = Utility::RemoveResource(newpath);
                            if(rst != STATUS_OK)
                                DEBUGL1("CExtractor::UploadDocument: failed to remove the extracted document\n");
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CExtractor::UploadDocument -setting properties is failed because Disk is Full\n");

                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CExtractor::UploadDocument -setting properties is failed\n");

                            return STATUS_FAILED;
                        }	

                        uint64 size=0;
                        uint64 docSize=0;		
                        CString value="";

                        if(proputils::GetProperty(boxbasepath,boxNumber,folderName,docName,"","totalDocSize", value)!=STATUS_OK)
                        {
                            DEBUGL1("CExtractor::UploadDocument - GetProperty of totalDocSize Failed\n");					
                            return STATUS_FAILED;
                        }
                        std::istringstream totalDocSizeStr(value);
                        totalDocSizeStr >> docSize;				
                        DEBUGL8("CExtractor::UploadDocument - Size of the document %s is %llu\n",docName.c_str(),docSize);				

                        //Update the folder and box size
                        CString propertypath("");
                        if( folderName.length()) 
                        {
                            propertypath = Utility::GetResourcePath(boxbasepath,boxNumber,folderName) + "/";
                            CString val1;
                            if(proputils::GetProperty(boxbasepath,boxNumber,folderName,"","","totalFolderSize",val1)!=STATUS_OK)
                            {
                                DEBUGL1("CExtractor::UploadDocument - GetProperty of totalFolderSize Failed\n");					
                                return STATUS_FAILED;
                            }					
                            DEBUGL8("CExtractor::UploadDocument - Total Orig Folder Size: %s\n",val1.c_str());
                            size = val1.length()? atoi(val1.c_str()): 0;
                            size += docSize;
                            std::ostringstream foldsize;
                            foldsize << size;
                            std::map<CString, CString> PropertyMap;
                            PropertyMap.insert(property_pair::value_type("totalFolderSize", foldsize.str().c_str()));
                            sdf = Utility::SetProperties(propertypath,"folderproperties.xml",PropertyMap);
                            if(sdf != STATUS_OK)
                            {	
                                if(sdf == STATUS_DISK_FULL)
                                {
                                    DEBUGL1("CExtractor::UploadDocument - SetProperty of totalFolderSize failed because Disk is Full\n");
                                    return STATUS_DISK_FULL;
                                }
                                DEBUGL1("CExtractor::UploadDocument - SetProperty of totalFolderSize failed\n");
                                return STATUS_FAILED;
                            }						
                            DEBUGL8("CExtractor::UploadDocument - Total Folder Size: %s\n",foldsize.str().c_str());						
                        }
                        CString val;
                        propertypath = Utility::GetResourcePath(boxbasepath,boxNumber) + "/";
                        if(proputils::GetProperty(boxbasepath,boxNumber,"","","","totalBoxSize", val)!=STATUS_OK)
                        {
                            DEBUGL1("CExtractor::UploadDocument - GetProperty of totalBoxSize Failed\n");					
                            return STATUS_FAILED;
                        }				
                        DEBUGL8("CExtractor::UploadDocument - Total Orig Folder Size: %s\n",val.c_str());
                        size = val.length()? atoi(val.c_str()): 0;
                        size += docSize;
                        std::ostringstream boxsize;
                        boxsize << size;
                        std::map<CString, CString> PropertyMap;
                        PropertyMap.insert(property_pair::value_type("totalBoxSize", boxsize.str().c_str()));
                        sdf = Utility::SetProperties(propertypath,"boxproperties.xml",PropertyMap); 
                        if(sdf != STATUS_OK)				
                        {	
                            if(sdf == STATUS_DISK_FULL)
                            {
                                DEBUGL1("CExtractor::UploadDocument - SetProperty of totalBoxSize failed because Disk is Full\n");
                                return STATUS_DISK_FULL;
                            }
                            DEBUGL1("CExtractor::UploadDocument - SetProperty of totalBoxSize failed\n");
                            return STATUS_FAILED;
                        }					
                        DEBUGL8("CExtractor::UploadDocument - Total Box Size: %s\n",boxsize.str().c_str());						

                        //Calculate the current progress and update it				
                        size=docSize;				
                        DEBUGL8("CExtractor::UploadDocument - totalFileSize is %d\n",totalSize);

                        completedFileSize = size+completedFileSize;
                        DEBUGL8("CExtractor::UploadDocument - completedFileSize is %llu\n",completedFileSize);

                        curProgress = (int)((float)(((float)count/(float)numberOfFiles)) * 34) + 65;
                        if(curProgress < PROGRESS_COMPLETED)
                        {	
                            DEBUGL8("CExtractor::UploadDocument - Current progress <%d>\n",curProgress);
                            *((int*)pProgressMapAddr)=curProgress;
                        }
                        CString cStsfile = newpath+"creating.sts";
                        if(ci::operatingenvironment::File::Exists(cStsfile))
                        {
                            Status st = ci::operatingenvironment::File::DeleteFile(cStsfile);
                            if(st != STATUS_OK)
                                DEBUGL1("Utility::RemoveResource: Failed to remove resource (%s)\n", path.c_str());
                        }

                        statuspath = "'" + newpath+"ready.sts'";
                        createstatusfile = "touch " + statuspath;
                        sysinfo->RunCmd(createstatusfile, r);
                        DEBUGL8("CExtractor::Extract - Status file (ready.sts) created under path <%s>\n",statuspath.c_str());
                    }

                }		
            }
            catch(CException & except)
            {
                DEBUGL1("\nCExtractor::Extract: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCExtractor::Extract: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            DEBUGL4("CExtractor::UploadDocument::Exit\n");	
            return STATUS_OK;
        }	

    }; // end of namespace boxdocument
}; // end of namespace ci

