#include<iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

FolderRef GetFolder(CString boxbasepath, CString boxnumber, CString foldername) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }
    
    // get box instance
    BoxRef box;
    if(boxdoc->GetBox(box, boxbasepath, boxnumber) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBox() is failed\n");
        return NULL;
    }
    
    // get folder instance
    FolderRef folder;
    if(box->GetFolder(folder, foldername) != STATUS_OK) {
        DEBUGL1("Box::GetFolder() is failed\n");
        return NULL;
    }
    return folder;
}

bool test_GetDocumentList(CString boxbasepath, CString boxnumber, CString foldername) {
    FolderRef folder = GetFolder(boxbasepath, boxnumber, foldername);
    if(!folder) {
        return false;
    }
    
    // get document list
    DocumentList doclist;
    if(folder->GetDocumentList(doclist) != STATUS_OK) {
        DEBUGL1("Folder::GetDocumentList() is failed\n");
        return false;
    }
    CString name;
    for(DocumentList::iterator it = doclist.begin(); it != doclist.end(); it++) {
        (*it)->GetName(name);
        DEBUGL6("Document Name - %s\n", name.c_str());
    }
    return true;
}

bool test_GetViewDocumentList(CString boxbasepath, CString boxnumber, CString foldername){
    FolderRef folder = GetFolder(boxbasepath, boxnumber, foldername);
    if(!folder) {
        return false;
    }

    // get document list
    DocumentList doclist;
    if(folder->GetViewDocumentList(doclist) != STATUS_OK) {
        DEBUGL1("Folder::GetDocumentList() is failed\n");
        return false;
    }
    CString docname, jobtypeval, creationdate, lastmodifieddate, thumbpath, cutdoc;
    DocStatus st;
    JobTypeColorSet jcset;
    PaperSizeMap papermap;
    int totalpages;
    uint64 docsize;
    for(DocumentList::iterator docit = doclist.begin(); docit != doclist.end(); docit++)
    {
        (*docit)->GetName(docname);
        DEBUGL6("Document name = (%s)\n", docname.c_str());
        (*docit)->GetWebDAVProperty("jobType",jobtypeval);
        DEBUGL6("Document job type = (%s)\n", jobtypeval.c_str());
        (*docit)->GetWebDAVProperty("creationDate",creationdate);
        DEBUGL6("Document creation date = (%s)\n", creationdate.c_str());
        (*docit)->GetWebDAVProperty("lastModifiedDate",lastmodifieddate);
        DEBUGL6("Document last modified date = (%s)\n", lastmodifieddate.c_str());
        (*docit)->GetWebDAVProperty("cutDocument",cutdoc);
        DEBUGL6("Document cut document flag = (%s)\n", cutdoc.c_str());
        (*docit)->GetTotalPage(totalpages);
        DEBUGL6("Document total pages = (%d)\n", totalpages);
        (*docit)->GetTotalSize(docsize);
        DEBUGL6("Document total size = (%u)\n",docsize);
        (*docit)->GetThumbnailImage(thumbpath);
        DEBUGL6("Document path = (%s)\n", thumbpath.c_str());
        (*docit)->GetStatus(st);
        DEBUGL6("Document status = (%d)\n", st);
        if((*docit)->GetJobTypeColorSet(jcset) != STATUS_OK)
            DEBUGL1("Failed to get jobtypecolormap\n");
        if((*docit)->GetPaperSizeMap(papermap) != STATUS_OK)
            DEBUGL1("Failed to get papersizemap\n");

        PageList pagelist;
        if((*docit)->GetViewPageList(pagelist)!= STATUS_OK)
        {
            DEBUGL1("BoxDocument::Failed to get the page list \n");
            return false;
        }
        CString jobtype, creationdate, lastmodifieddate, cutpage, tpath, papersize;
        int hres, vres, width, height;
        uint64 filesize;
        ColorMode colormode;
        for(PageList::iterator pageit = pagelist.begin(); pageit != pagelist.end(); pageit++)
        {
            (*pageit)->GetWebDAVProperty("jobType", jobtype);
            DEBUGL6("Page job type = (%s)\n", jobtype.c_str());
            (*pageit)->GetWebDAVProperty("creationDate", creationdate);
            DEBUGL6("Page creation date = (%s)\n", creationdate.c_str());
            (*pageit)->GetWebDAVProperty("lastModifiedDate", lastmodifieddate);
            DEBUGL6("Page last modified date = (%s)\n", lastmodifieddate.c_str());
            (*pageit)->GetWebDAVProperty("cutPage", cutpage);
            DEBUGL6("Page cut page flag = (%s)\n", cutpage.c_str());
            (*pageit)->GetPaperSize(papersize);
            DEBUGL6("Page papersize = (%d)\n", papersize.c_str());
            (*pageit)->GetResolution(hres, vres);
            DEBUGL6("Page hres = (%d) vres = (%d)\n", hres, vres);
            (*pageit)->GetFileSize(filesize);
            DEBUGL6("Page file size = (%u)\n", filesize);
            (*pageit)->GetThumbnailImage(tpath);
            DEBUGL6("Page thumbnail path = (%s)\n", tpath.c_str());
            (*pageit)->GetColorMode(colormode);
            DEBUGL6("Page color mode = (%d)\n", colormode);
            (*pageit)->GetImageSize(width, height);
            DEBUGL6("Page image width = (%d) height = (%d)\n", width, height);
        }
    }
    return true;
}

extern bool test_document(CString, CString, CString, CString&);
bool test_GetDocument(CString boxbasepath, CString boxnumber, CString foldername) {
    CString name;
    cout << "Enter Document Name : " << endl;
    cin >> name;
    
    return test_document(boxbasepath, boxnumber, foldername, name);
}

bool test_RenameFolder(CString boxbasepath, CString boxnumber, CString &foldername) {
    FolderRef folder = GetFolder(boxbasepath, boxnumber, foldername);
    if(!folder) {
        return false;
    }
    
    CString new_name;
    cout << "Enter new folder name" << endl;
    cin >> new_name;
    
    if(folder->SetName(new_name) != STATUS_OK) {
        DEBUGL1("Folder::SetName() is failed\n");
        return false;
    }
    folder->GetName(foldername);
    return true;
}

bool test_GetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername) {
    FolderRef folder = GetFolder(boxbasepath, boxnumber, foldername);
    if(!folder) {
        return false;
    }
    CString key, value;
    char* keylist[3] = {"folderName", "creationDate", "lastModifiedDate"};
    for(int i = 0; i < 3; i++) {
        key = keylist[i];
        folder->GetWebDAVProperty(key, value);
        DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    }
    return true;
}

bool test_SetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername) {
    FolderRef folder = GetFolder(boxbasepath, boxnumber, foldername);
    if(!folder) {
        return false;
    }
    CString key, value;
    cout << "Enter Folder property (KEY)" << endl;
    cin >> key;
    cout << "Enter Folder property (VALUE)" << endl;
    cin >> value;
    if(folder->SetWebDAVProperty(key, value) != STATUS_OK) {
        DEBUGL1("Folder::SetWebDAVProperty() is failed\n");
        return false;
    }
    return true;
}
bool test_CopyDocument(CString boxbasepath,CString boxnumber, CString foldername)
{
    CString dstBox,dstFolder,Document;
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;
    FolderRef folder;
	
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Dst Folder Number: " << endl;
    cin >> dstFolder;

    cout << "Enter Document Number: " << endl;
    cin >> Document;

    ret = boxdoc->GetBox(box,boxbasepath,boxnumber);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }
	
   ret = box->GetFolder(folder,foldername);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }
    ret= folder->CopyDocument(Document);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

   ret = box->GetFolder(folder,dstFolder);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }

    ret = folder->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   return true;
}

bool test_CutDocument(CString boxbasepath,CString boxnumber, CString foldername)
{
    CString dstBox,dstFolder,Document;
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;
    FolderRef folder;
	
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Dst Folder Number: " << endl;
    cin >> dstFolder;

    cout << "Enter Document Number which needs to be CUT: " << endl;
    cin >> Document;

    ret = boxdoc->GetBox(box,boxbasepath,boxnumber);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }
	
   ret = box->GetFolder(folder,foldername);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }
    ret= folder->CutDocument(Document);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

   ret = box->GetFolder(folder,dstFolder);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }

    ret = folder->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   return true;
}

bool test_CopyVector(CString boxbasepath,CString boxnumber, CString foldername)
{
    std::vector<CString> m_doclist;
    CString dstFolder,dstBox;
     FolderRef folder =NULL;
	 
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter dest Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Dst Folder Number: " << endl;
    cin >> dstFolder;

 	CString Document,res;
	cout << "Enter Document Number to be copied: " << endl;
	cin >> Document;
	m_doclist.push_back(Document);
	
	cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
	cin >> res;
	while((res.compare("y")==0))
	{
		cout << "Enter Document Number: " << endl;
		cin >> Document;
		m_doclist.push_back(Document);
		cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
		cin >> res;
	}
   ret = boxdoc->GetBox(box,boxbasepath,boxnumber);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }
	
   ret = box->GetFolder(folder,foldername);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }
   ret= folder->CopyDocument(m_doclist);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

   ret = box->GetFolder(folder,dstFolder);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }

    ret = folder->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }
   return true;
}

bool test_CutVector(CString boxbasepath,CString boxnumber, CString foldername)
{
    std::vector<CString> m_doclist;
    CString dstFolder,dstBox;
    FolderRef folder =NULL;
	 
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter dest Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Dst Folder Number: " << endl;
    cin >> dstFolder;

 	CString Document,res;
	cout << "Enter Document Number to be copied: " << endl;
	cin >> Document;
	m_doclist.push_back(Document);
	
	cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
	cin >> res;
	while((res.compare("y")==0))
	{
		cout << "Enter Document Number: " << endl;
		cin >> Document;
		m_doclist.push_back(Document);
		cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
		cin >> res;
	}
   ret = boxdoc->GetBox(box,boxbasepath,boxnumber);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }
	
   ret = box->GetFolder(folder,foldername);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }
   ret= folder->CutDocument(m_doclist);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

   ret = box->GetFolder(folder,dstFolder);
    if(folder == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetFolder failed\n");
        return false;
    }

    ret = folder->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }
   return true;
}

bool test_CreateDocument(CString boxbasepath, CString boxnumber, CString foldername)
{
CString DocumentName;
Status ret;
BoxDocumentRef boxdoc=NULL;
DocumentRef doc=NULL;

boxdoc = BoxDocument::Acquire();
if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
}

cout<<"Enter DocumentName"<<endl;
cin>>DocumentName;

BoxRef box;
if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
{
	DEBUGL1("BoxDocument::GetBox() failed\n");
	return false;
}

FolderRef folder;
if(box->GetFolder(folder,foldername)!=STATUS_OK)
{
	DEBUGL1("Box::GetFolder() failed\n");
	return false;
}

ret = folder->CreateDocument(doc, DocumentName);
if(ret!=STATUS_OK)
{
        DEBUGL1("Create document failed\n");
        return false ;
}
return true;
}


bool test_ClipboardOpeartions(CString boxbasepath,CString boxnumber, CString foldername)
{
    int i;
    bool result;
//    boxbasepath = "/"+ boxbasepath;

    cout << "1. Copy Document sequence" << endl;
    cout << "2. Cut Document sequence" << endl;
    cout << "3. Copy more than 1 Document seq" << endl;
    cout << "4. Cut more than 1 Document seq" << endl;
    cout << "0. exit" << endl;
    cin >> i;
    result = false;
    switch(i) {
        case 0: return true;
        case 1: result = test_CopyDocument(boxbasepath,boxnumber, foldername); break;
        case 2: result = test_CutDocument(boxbasepath,boxnumber, foldername); break;
        case 3: result = test_CopyVector(boxbasepath,boxnumber, foldername); break;
        case 4: result = test_CutVector(boxbasepath,boxnumber, foldername); break;
        }
        cout << "result = " << result << endl;
    return result;
}

bool test_folder(CString boxbasepath, CString boxnumber, CString &foldername) {
    bool result;
    while(1) {
        int i = 0;
        cout << "Folder: /" << boxbasepath << "/" << boxnumber << "/" << foldername <<  endl;
        cout << "1. Get Document List" << endl;
        cout << "2. Get Document" << endl;
        cout << "3. Rename Folder" << endl;
        cout << "4. Get WebDAV property" << endl;
        cout << "5. ClipBoard Operations" << endl;		
        cout << "6. Set WebDAV property" << endl;
        cout << "7. Create Document" << endl;
        cout << "8. Get view document list" << endl;
	 cout << "0. exit" << endl;
        cin >> i;
        result = false;
        switch(i) {
        case 0: return true;
        case 1: result = test_GetDocumentList(boxbasepath, boxnumber, foldername);  break;
        case 2: result = test_GetDocument(boxbasepath, boxnumber, foldername);  break;
        case 3: result = test_RenameFolder(boxbasepath, boxnumber, foldername); break;
        case 4: result = test_GetWebDAVProperty(boxbasepath, boxnumber, foldername); break;
        case 5: result = test_ClipboardOpeartions(boxbasepath,boxnumber, foldername); break;
        case 6: result = test_SetWebDAVProperty(boxbasepath, boxnumber, foldername); break;
        case 7: result = test_CreateDocument(boxbasepath, boxnumber, foldername); break;
        case 8: result = test_GetViewDocumentList(boxbasepath, boxnumber, foldername); break;
        }
        cout << "result = " << result << endl;
    }
    return true;
}
