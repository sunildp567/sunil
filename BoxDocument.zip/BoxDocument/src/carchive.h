/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: carchive.h
Revision: com_t#1
File Spec: EBX:TA8448.A-DEV_SRC;com_t#1
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:56:47

Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
  1:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
  	Creation Date: 13-JAN-2009 19:36:02
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
  
  2:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
  	Creation Date: 13-JAN-2009 18:00:09
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
  
  3:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
  	Creation Date: 13-JAN-2009 15:14:46
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
  
  ------------------------------------------------------------------------------
History:
 * Revision com_t#1 (APPROVED)
 *   Created:  09-JAN-2009 21:56:47      CHANDRAMOHAN.PUJARI
 *     Initial Version
========================== End of Source Header =============================*/

#ifndef __CI_CARCHIVE_H__
#define __CI_CARCHIVE_H__

#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/archive.h>
#include "msgdefs.h"
#include "CI/MessagingSystem/msg.h"
#include "CI/MessagingSystem/msgport.h"
#include <CI/OperatingEnvironment/thread.h>
#include "CI/OperatingEnvironment/threadpool.h"
#include "CI/OperatingEnvironment/cuuid.h"
#include "CI/OperatingEnvironment/sharedmemory.h"

#define UUID_CONTENT_LENGTH 100
#define PROGRESS_COMPLETED 100

#if CI_MASH
	#define PRODUCT_CODE "H-14x V1.0"
#elif CI_BP
	#define PRODUCT_CODE "H-13x V1.0"
#elif CI_LOIRE
	#define PRODUCT_CODE "e-STUDIO 456 Series 3.0"
#elif CI_ALABAMA
	#define PRODUCT_CODE "e-STUDIO 856 Series 3.0"
#elif CI_MOSEL
	#define PRODUCT_CODE "e-STUDIO 477 Series 5.5"
#elif CI_WEISS2
	#define PRODUCT_CODE "e-STUDIO 2000AC Series"
#elif CI_REUSS
	#define PRODUCT_CODE "e-STUDIO 2508A Series"
#elif CI_SHASTA
	#define PRODUCT_CODE "e-STUDIO 5506AC Series"
#elif CI_SHASTINA
	#define PRODUCT_CODE "e-STUDIO 5508A Series"
#elif CI_CASPIAN
	#define PRODUCT_CODE "e-STUDIO 3508LP Series"
#elif CI_MATTERHORN
        #define PRODUCT_CODE "e-STUDIO 400AC Series"
#else
	#define PRODUCT_CODE " "
#endif

typedef void *ThreadArgument;
typedef void *ThreadReturn;
typedef ThreadReturn (*ThreadFunction)(ThreadArgument);
using namespace ci::operatingenvironment;

namespace ci 
{
	namespace boxdocument
	{
		class CArchiver : public Archiver
		{
			private:
				CString m_ArchivePath;
				std::vector<CString> m_Documentlist;
				std::vector<CString> m_Documentpaths;
				Archiver::ArchiveStatus m_ArchiveStatus;				
				int m_ArchiveProgress;
				Ref<Thread> m_ThreadId;
				CString m_BoxBasePath;
				CString m_BoxNumber;
				CString m_FolderName;
				CString m_pProgressShmName;
				CString m_pStatusShmName;
				CString m_sessionID;
				static bool m_ArchiveFlag;
				/**	
				*Function: CreateThread
				* Description:
				*		This function creates a thread and returns the thread id to the user
				* @param1: the function name with which thread is to be created
				* @param2: the argument to be passed to the function
				* @param3: the thread id that is returned after the creation of the thread
				* Return Values:
				*   	STATUS_OK if successful
				*   	STATUS_FAILED on failure				
				*/					
				Status CreateThread(ThreadFunction functionName, ThreadArgument functionArgument, Ref<Thread> &threadId);

				/**
				* StartArchive -Archives the given document list used as a thread routine
				* @param[in] arg - arguments if any
				* @return STATUS_OK on success,
				*         STATUS_FAILED on failure.
				*         STATUS_DISK_FULL on disk Full.	
				*/
				static void* StartArchive(void *arg);		
				/**
				 * Download the documents from the given list to a local temporary path. The downloaded documents can then be zipped.
				 * @param[in] tmppath - the local path where the documents will be downloaded to
				 * @param[in] totalSize - the estimated total size of the documents to be downloaded
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */				
				Status DownloadDocument(CArchiver *carchiverobj,CString tmppath,uint64 totalSize,void *pMapAddr);

				/**
				 * Download the files from the webdav server to the local path 
				 * @param[in] files - the list of files to be downloaded
				 * @param[in] tmppath - the local path
				 * @param[in] srcpath - the path on the server
				 * @param[inout] completedFileSize - the completed file download size
				 * @param[in] totalFileSize - the total file size to be downloaded
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status DownloadFiles(CArchiver carchiverobj,std::vector<CString> files,CString tmppath,CString srcpath,uint64& completedFileSize,uint64 totalFileSize,void *pMapAddr);

				/**
				 * The size of the resource on local path is calculated
				 * @param[in] filePath - the path of the resource
				 * @param[out] size - the size of the resource
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status FileSize(CArchiver carchiverobj,CString filePath, int& size);
				
				/**
				 * Zips the documents given to the desired target location
				 * @param[in] tmppath - the local path where the file to be zipped are present
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */				
				Status ZipDocument(CArchiver *carchiverobj,CString tmppath, void *pMapAddr);

				/**
				 * Create the main zip file containing the archive.xml file and the document efb's
				 * @param[in] folderPath - the local path that contains all the documents
				 * @param[in] count - number of documents
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */				
				Status CreateMainZip(CArchiver *carchiverobj,CString folderPath,int count);

			public:
				/*con'tor*/
				CArchiver(CString sessionID, CString archivedpath,std::vector<CString>documentpaths, std::vector<CString>documentlist);
				virtual ~CArchiver();

				/**
				 * get archiving status
				 * @param[out] status - archiving status
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetStatus(Archiver::ArchiveStatus &status);

				/**
				 * get archiving progress
				 * @param[out] progress - archiving progress [0-100] %
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetProgress(int &progress);

				/**
				 * get a path of created archive
				 * @param[out] path - archive path
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status GetPath(CString &path);

				/**
				 * cancel to archive
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status Cancel();

				/**
				 * delete created archive
				 * @return STATUS_OK on success,
				 *         STATUS_FAILED on failure.
				 */
				Status Delete();
				
				/**	
				*	Function: CreateThread
				* 	Description:
				*		This function creates a thread and that does the archiving job
				*   	@return: Status
				*/		
				Status CreateArchiveThread();

				Status RevertStatus(CArchiver *carchiverobj);
		}; // class Archiver
	}; // end of namespace boxdocument
}; // end of namespace ci

#endif // #ifndef __CI_ARCHIVE_H__
