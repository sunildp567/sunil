/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2006   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: %PM%
 Revision: %PR%
 File Spec: %PID%
 Originator: %PO%
 Last Changed: %PRT%
 Outline[by EA]: */
 /**
 * Pipe利用のために、eB2のflから流用する変数を宣言するヘッダファイル
 * ※このヘッダファイルは、EAからの生成ではなく、別途ファイルでの提供です
 * @version 3.0
 * @created 26-Feb-2007 17:57:08
 */
/*----------------------------------------------------------------------------
 Related Change Documents:
   %PIRC%
------------------------------------------------------------------------------
 Related Baselines:
   %PIRB%
------------------------------------------------------------------------------
 History:
   %PL%
========================== End of Source Header =============================*/


#ifndef __CI_SYSTEMDATAFILE_PAGE_H__
#define __CI_SYSTEMDATAFILE_PAGE_H__

#include <time.h>
#include "types.h"

  typedef struct  PAR_TBL_RESOLUTION /* 解像度情報             */
  {
  int16  hMain;        /* 主走査解像度           */
                    /* COM_RES_300   :300dpi      */
                    /* COM_RES_400   :400dpi      */
                    /* COM_RES_600   :600dpi(PPC)   */
                    /* COM_RES_600_PRT:600dpi(PRINT)  */
                    /* COM_RES_385LPM:3.85dot/mm    */
                    /* COM_RES_77LPM :7.7dot/mm     */
                    /* COM_RES_8LPM  :8dot/mm     */
                    /* COM_RES_154LPM:15.4dot/mm    */
                    /* COM_RES_16LPM :16dot/mm      */
  int16  hSub;         /* 副走査解像度           */
                    /* COM_RES_300   :300dpi      */
                    /* COM_RES_400   :400dpi      */
                    /* COM_RES_600   :600dpi(PPC)   */
                    /* COM_RES_600_PRT:600dpi(PRINT)  */
                    /* COM_RES_385LPM:3.85dot/mm    */
                    /* COM_RES_77LPM :7.7dot/mm     */
                    /* COM_RES_8LPM  :8dot/mm     */
                    /* COM_RES_154LPM:15.4dot/mm    */
                    /* COM_RES_16LPM :16dot/mm      */
  } PAR_TBL_RESOLUTION;

  typedef struct PAR_TBL_COLOR_INFO /* カラー情報 */
  {
    int16 hColorMode;  /* カラーモード */
    int16 hDataBit;    /* データビット */
    int16 hPlane;      /* プレーン数 */
    int16 hDataForm;   /* データ形式 */
  } PAR_TBL_COLOR_INFO;

  typedef struct PAR_TBL_TWOCOLORS /* ２色カラー情報 */
  {
    int16 hMode;             /* ２色カラーモード   *//* Mck004 */
    int16 hTwoColors1;       /* ２色カラー情報１   */
    int16 hTwoColors2;       /* ２色カラー情報２   */
    int16 hBoundaryValue;    /* 赤/黒境界調整値    *//* KK013 */
                          /*   -3 ～ +3     */
  } PAR_TBL_TWOCOLORS;

  typedef struct PAR_TBL_COLORBALANCEINFO /* カラーバランス情報 */
  {
    int16 hColorY;       /* カラーバランスＹ                 */
    int16 hColorM;       /* カラーバランスＭ                 */
    int16 hColorC;       /* カラーバランスＣ                 */
    int16 hColorBK;      /* カラーバランスＫ                 */
  } PAR_TBL_COLORBALANCEINFO;

  typedef struct PAR_TBL_RGBBALANCEINFO /* ＲＧＢ情報 */
  {
    int16 hColorR;       /* Redバランス情報                  */
    int16 hColorG;       /* Greenバランス情報                */
    int16 hColorB;       /* Buleバランス情報                 */
  } PAR_TBL_RGBBALANCEINFO;
  
  typedef struct PAR_TBL_HUEINFO{   /* 色相レベルテーブル         */
    int16 hHue_Y;                      /* 色相レベル  Y  (-3 ～ +3)      */
    int16 hHue_M;                      /* 色相レベル  M  (-3 ～ +3)      */
    int16 hHue_C;                      /* 色相レベル  C  (-3 ～ +3)      */
    int16 hHue_R;                      /* 色相レベル  R  (-3 ～ +3)      */
    int16 hHue_G;                      /* 色相レベル  G  (-3 ～ +3)      */
    int16 hHue_B;                      /* 色相レベル  B  (-3 ～ +3)      */
  } PAR_TBL_HUEINFO;
  
  typedef struct PAR_TBL_SATURATIONINFO{  /* 彩度レベルテーブル       */
    int16 hSaturation_Y;                 /* 彩度レベル  Y  (-3 ～ +3)      */
    int16 hSaturation_M;                 /* 彩度レベル  M  (-3 ～ +3)      */
    int16 hSaturation_C;                 /* 彩度レベル  C  (-3 ～ +3)      */
    int16 hSaturation_R;                 /* 彩度レベル  R  (-3 ～ +3)      */
    int16 hSaturation_G;                 /* 彩度レベル  G  (-3 ～ +3)      */
    int16 hSaturation_B;                 /* 彩度レベル  B  (-3 ～ +3)      */
  } PAR_TBL_SATURATIONINFO;

  typedef struct {  /* カラー情報テーブル     */
    PAR_TBL_COLORBALANCEINFO sColorBalance[3]; /* カラーバランス情報  [0] 低濃度   *//* KK000 */
                                               /* カラーバランス情報  [1] 中濃度   *//* KK000 */
                                               /* カラーバランス情報  [2] 高濃度   *//* KK000 */
    PAR_TBL_HUEINFO      sHueinfo;             /* 色相レベルテーブル         *//* KK001 */
    PAR_TBL_SATURATIONINFO   sSaturationInfo;  /* 彩度レベルテーブル         *//* KK001 */
  } PAR_TBL_ALLCOLORINFO;
  
  /********************************************/
  /* ファイルステータス情報                   */
  /*  flFileAtrGet()で使用                    */
  /********************************************/
  typedef struct FL_FILE_STATUS {
    int16      hVolMtd;                        /* 使途番号                         */
    int8       aFlName[255];                   /* システムファイル名               *//* M006 */
    /* int8       aFlName[MAX_LEN_FLNAME+1]; *//* システムファイル名               */
    int32     iTaskId;                        /* システムファイル作成タスク名ＩＤ */
    uint32     liFlSize;                       /* ファイルデータサイズ             */
    int16      hFlPageNum;                     /* 有効頁数                         */
    int16      hFlPageNumS;                    /* 有効頁先頭番号                   */
    int16      hFlPageNumE;                    /* 有効頁最終番号                   */
    int8       aFlPageStrS[5];                 /* 有効頁先頭拡張子                 */
    int8       aFlPageStrE[5];                 /* 有効頁最終拡張子                 */
    int16      hFaxOrgExist;                   /* ＦＡＸ原稿情報の有無             */
    time_t  iFlCreateTime;                  /* ファイル作成時間                 */
    int16      hFlPageDelFlag;                 /* 頁ファイル削除中フラグ           */
    int16      hAPLInfoSize;                   /* タスク別固有情報サイズ           */
    int16      hParMNSize;                     /* parMN情報サイズ                  */
    int16      hRfu[4];                        /* reserve for future use           */
    time_t  iFlUpdateTime;                  /* 画像ファイル更新日付             */
    int32     iRfu[4];                        /* reserve for future use           */

  } FL_FILE_STATUS;

  /********************************************/
  /* 入力結果情報                             */
  /*  flFileAtrPut()                          */
  /*  flFileAtrGet()で使用                    */
  /********************************************/
  typedef struct FL_FILE_COM_ATR {
    int16      hPageOrder;                     /* ファイル化順:  昇順、降順 */
    int16      hJobMixCondition;               /* 2ビット画像混載の有無     *//* M004 */
    int16      hMixColor;                      /* カラー情報混載の有無      *//* M004 */
    int16      hReserved[1];                   /* reserved */ 

  } FL_FILE_COM_ATR;

  /********************************************/
  /* 入力情報                                 */
  /********************************************/
  typedef struct FL_FILE_IN_ATR {
    int16      hSts;                           /* 受信状態(t.b.d.)              */
    int16      hInPageCount;                   /* 受信/入力完了総頁数           */
    int16      hInSize;                        /* 原稿検知サイズ                */
    int16      hInputSts;                      /* Input processing status       *//* Add for eBX L3.25 */
	time_t  iInputTime;                     /* Input/Received Time. Prepared for RTI date field. EBX_RCR_235 - 20171012 */
    int16      hReserved[2];                   /* reserved */
  }   FL_FILE_IN_ATR;  

  /********************************************/
  /* 出力情報                                 */
  /********************************************/
  typedef struct FL_FILE_OUT_ATR {
    int16      hOutOrder;                      /* 出力順 昇順/降順              */
    int16      hPrnFace;                       /* フェースアップ/フェースダウン */
    PAR_TBL_RESOLUTION  sPrnResolution;     /* 印刷用解像度                  */
    int16      hFaxDuplexFlag;                 /* FAX両面印刷フラグ             *//* Add  EX-Mash/BP 1st */
    int16      hReserved[3];                   /* reserved */

  }   FL_FILE_OUT_ATR;

  /********************************************/
  /* サムネイル情報                           */
  /********************************************/
  typedef struct FL_PAGE_THUM_INFO{
    int16      hCType;                         /* 符号化方式                 */
    int16      hPgMLen;                        /* 主走査画素数               */
    int16      hPgSLen;                        /* 副走査画素数               */
    PAR_TBL_RESOLUTION sResolution;         /* 主／副走査解像度           */
    int16      hSize;                          /* ファイル化定型サイズコード */
    int16      hInPgMLen;                      /* 主走査転送画素数           */
    int16      hInPgSLen;                      /* 副走査転送画素数           */
    PAR_TBL_COLOR_INFO sColorinf;           /* カラー情報                 */
    int16      hYccForm;                       /* YCC情報                    */
    int16      hAngle;                         /* イメージの向き             */
    int16      hReserved[27];                  /*  UserTrace用Reserve        */
  } FL_PAGE_THUM_INFO; /* K001 */

  /********************************************/
  /* 頁入力結果情報                           */
  /*  flPageWrite()                           */
  /*  flPageAtrPut()                          */
  /*  flPageAtrGet()で使用                    */
  /********************************************/
  typedef struct FL_PAGE_COM_ATR {
    int16      hCType;                             /* 符号化方式                       */
    int16      hKPara;                             /* Ｋパラメータ                     */
    int16      hPgMLen;                            /* 主走査画素数　　                 */
    int16      hPgSLen;                            /* 副走査画素数 　　                */
    PAR_TBL_RESOLUTION  sResolution;            /* 主／副走査解像度                 */
    int16      hSize;                              /* ファイル化定型サイズコード       */
    int16      hImgCoordinate;                     /* 画像回転角度 0,90,180,270度      */
    int16      hInPgMLen;                          /* 主走査転送画素数 98/09/24        */
    int16      hInPgSLen;                          /* 副走査転送画素数 98/09/24        */
    PAR_TBL_COLOR_INFO  sEngColorInf;           /* カラー情報                       *//* M004 */
    PAR_TBL_TWOCOLORS   sEngTwoColors;          /* 2色カラー情報                    *//* M004 */
    int16      hYccForm;                           /* YCC情報                          *//* M005 */
    int16      hJobColorMode;                      /* ジョブカラーモード               *//* M008 */
    int16      hAngle;                             /* イメージの向き                   *//* M008 */
    int16      hOrientation;                       /* ページ毎のオリエンテーション     *//* M008 */
    /* PAR_TBL_COLORBALANCEINFO sColorBalanceInfo; *//* カラーバランス情報          *//* K003 */
    PAR_TBL_RESOLUTION  sCopyResolution;        /* コピー用主／副走査解像度         *//* Added for 300dpi COPY in L5.0 - 20120823 */
    int16      hReserved2[2];                      /* Reserved                         *//* K003 *//* reduce 4 bytes to insert sCopyResolution above. */
    PAR_TBL_RGBBALANCEINFO   sRGBBalanceInfo;   /* RGBバランス情報                  *//* M008 */
    int16      hOriginalType;                      /* 原稿タイプ                       *//* M011 */
    int16      hOneTouchMode;                      /* ワンタッチモード情報             *//* M011 */
    int16      hCenterCorner;                      /* 印刷基準                         *//* M011 */
    int16      hPaperType;                         /* 厚紙種別                         *//* M011 */
    int16      hPDL;                               /* ページ記述言語                   *//* M011 */
    int16      hPrintScreen;                       /* ハーフトーンスクリーン           *//* M011 */
    int16      hTonerSave;                         /* トナーセーブ                     *//* M011 */
    int16      hSmoothing;                         /* スムージング情報                 *//* M011 */
    int16      hValidity;                          /* ファイル化頁設定                 *//* M011 */
    int16      hScanMethod;                        /* 原稿入力方法                     *//* M012 */
    FL_PAGE_THUM_INFO    sPageThumInfo;         /* サムネイル情報                   *//* K001 */
    PAR_TBL_ALLCOLORINFO sAllColorInfo;         /* カラーバランス情報(高/中/低濃度) *//* K001 */
    int16      hMonoColor;                         /* モノカラー選択色                 *//* K001 */
    int16      hSharpness;                         /* シャープネス情報                 *//* K001 */
    int16      hImageQType;                        /* 画質設定                         *//* K001 */
    int16      hExtraImageQType;                   /* extra image quality type (add member variable) - weiss_feature crs (0.01) - 2-1-4-14.     Vermilion - 20111226 */
    int16      hDFScanNoiseReduction;              /* DF Scan Noise Reduction Setting for R-C00173-3  - 20140404 */
    int16      hAutoTrapping;                      /* Auto Trapping         - 20150317 */
    int16      hReserved[4];                       /* Reserved                         *//* K001 */ /* (reduce 2 bytes to insert hAutoTrapping above.) - 20150317 */
    int16      hContainedPage;                     /* 1ページに含むマルチページ数      *//* Add  EX-Mash/BP 1st */
    int16      hMixImg;                            /* 合成画像のカラー *//* MB001 Start */
    int16      hMixTransparent;                    /* 合成画像の透過率(置き換え/透かし(淡)/透かし(中)/透かし(濃)/地紋合成) */
    int16      hMixFlg;                            /* 合成OFF/ON */
    int16      hSharpnessFlg;                      /* シャープネス ON/OFF */
    int16      hSmartCMMFlg;                       /* smartCMM ON/OFF */
    int16      hNegaposiReverse;                   /* ネガポジ反転 */
    int16      hDensityType;                       /* 濃度(Auto/Manual) */
    int16      hDensityVal;                        /* 濃度値 */
    int16      hBackground;                        /* 下地処理 */
    int16      hEditMode;                          /* 編集モード */
    int16      hOriginalSize;                      /* 原稿サイズ */
    int16      hAlignmentAddInfo;                  /* アライメント付加位置情報 *//* MB001  End */

  } FL_PAGE_COM_ATR;

  /********************************************/
  /* 頁入力情報                               */
  /********************************************/
  typedef struct FL_PAGE_IN_ATR {
    int16      hPaperLength;                   /* 受信副走査サイズコード                       */
    int16      hDualFlag;                      /* 受信並行印刷情報                             */
    uint32     liDataSize;                     /* 画像データサイズ(基本FAXの場合のみ)          */
    int16      hSubPgNo;                       /* 次分割頁の有無(長尺時の分割で有効) USR/LOCAL */
                                            /*      無し：FL_PAGE_NEXT_NONEXIST             */
                                            /*      有り：FL_PAGE_NEXT_EXIST                */
    int16      hDetectedSize;                  /* 原稿サイズ検知結果          2000.11.20 ADD   */
    int16      hRTIPageNum;                    /* Input/Received page number. Added for RTI of page selection printing from FaxRx Preview. EBX_RCR_235 - 20170915 */
    int16      hReserved2[1];                  /* Reserved                                     */

  }   FL_PAGE_IN_ATR;

  /************************************************************/
  /* 頁出力情報                                               */
  /************************************************************/
  typedef struct FL_PAGE_OUT_ATR {
    int16      hCopies;                        /* 印刷部数（置数）                         */
    PAR_TBL_RESOLUTION  sPrnResolution;     /* 印刷用解像度                             */
    int16      hPaperSize;                     /* 用紙サイズコード                         */
    int16      hMainMagnification;             /* 主走査出力変倍率％(自動変倍時：縮小率)   */
    int16      hSubMagnification;              /* 副走査出力変倍率％(自動変倍時：縮小率)   */
    int16      hCassette;                      /* 給紙元:給紙元コード（ＡＤＤを除く）      */
    int16      hSFBPaperSize;                  /* 手差用紙サイズ 紙サイズコード            */
    int16      hWhitePaperFlag;                /* 白紙フラグ [8.00]                        */
/*  int16      hSingleSideFlag;              *//* 片面フラグ [8.00] Rioβ4から未使用       */
/*  int16      hReserved2;                   *//* reserved (Rioβ4 hInsReverseに使用) R004 */
    int16      hInsReverse;                    /* 反転フラグ                          R005 */
    int16      hMoff;                          /* 画像シフトオフセット値：主               */
    int16      hSoff;                          /* 画像シフトオフセット値：副               */
    int16      hTabPaperFlag;                  /* タブ紙ページであることを示す        M018 */
    int16      hTabMoff;                       /* 主走査画像シフト幅（0.01mm unit）   M018 */
    int16      hTabSoff;                       /* 副走査画像シフト幅（0.01mm unit）   M018 */
    int16      hTabWidth;                      /* タブ幅（0.1mm unit）                M018 */
    int16      hPrnDuplex;                     /* 片両混在印刷   Rioβ4から使用       R001 */
    int16      hMirror;                        /* 鏡像                                R002 */
    int16      hInsPaperSize;                  /*                                     R003 */
    int16      hInsPaperType;                  /*                                     R003 */
    int16      hSpFeed;                        /* プリンタ用カスタムサイズ：送り(1mm unit) K002 */
    int16      hSpWidth;                       /* プリンタ用カスタムサイズ：幅(1mm unit)   K002 */
    int16      hForceFrontSide;                /* 強制おもて面印刷フラグ                   K004 */
/*  int16      hReserved[4];                 *//* reserved                            R003 *//* K001 */
/*  int16      hReserved[11];                *//* UserTrace用Reserve                  K001 *//* K004 */
    int16      hActMoff;                       /* MoffのActual *//* MB002 */
    int16      hActSoff;                       /* SoffのActual *//* MB002 */
    int8       aTSINo[21];                     /* FAX TSI No.          Add  EX-Mash/BP 1st */
    int16      hExpandPrnArea;                 /* 印刷領域拡張 *//* Add for Expanding Printable Area in L6.0 -20150309 */
    int16      hCenteringCopy;                 /* CenteringCopy in L6.01 -20160531 */
    int16      hReserved[6];                   /* UserTrace用Reserve *//* MB002 *//* reduce 2 bytes to insert hCenteringCopy above. - 20160531 */
/*  int16      hReserved[10];                *//* UserTrace用Reserve                  K004 */

  } FL_PAGE_OUT_ATR;

  /********************************************/
  /* 頁ステータス情報                         */
  /*  flPageAtrGet()で使用                    */
  /********************************************/
  typedef struct FL_PAGE_STATUS {
    uint32     liPgDataSize;                   /* 画像データサイズ                 */
    int16      hPgModeFlg;                     /* 画像モード(メモリフル頁/通常頁などを示す)*/
    int8       aPgStr[5];                      /* ファイル名拡張子（頁番号文字列） */
    int16      hThumFile;                      /* サムネイルファイル有無 */
    uint32     liThumDataKSize;                /* サムネイル画像データサイズ(1プレーン時のサイズ or ブラック) *//* K001 */
    uint32     liThumDataCSize;                /* サムネイル画像データサイズ(シアン)   *//* K001 */
    uint32     liThumDataMSize;                /* サムネイル画像データサイズ(マゼンダ) *//* K001 */
    uint32     liThumDataYSize;                /* サムネイル画像データサイズ(イエロー) *//* K001 */

  } FL_PAGE_STATUS;

#endif // __CI_SYSTEMDATAFILE_PAGE_H__
