#include<iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

bool GetBoxList(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxList boxlist;
    if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
    
    CString boxnumber;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());
    }
    return true;
}


bool test_BoxDocument()
{
	DEBUGL4("Entering Test BoxDocument Interaface Test cases\n");
	unsigned int passcount=0;
	Status ret;
	DocStatus state;

	DEBUGL4("Starting Test case -1.1 -Box Document Acquire\n");
	BoxDocumentRef boxdoc;		
	boxdoc = BoxDocument::Acquire();
	if(boxdoc == static_cast<void *> (NULL)) {
	    DEBUGL1("Test Case - 1.1 -- BoxDocument::Acquire() failed\n");
	    return false;
	}
	else
	{
		DEBUGL6("Test Case - 1.1 -- BoxDocument::Acquire() Success\n");
		passcount++;
	}

	// For Test case - 1.2 Create a Box and Folder
	CString BoxBasePath = "EFilingBoxes";	
	CString BoxNumber="000";
	CString FolderName="chandra";
	CString DocumentName="TestCD";
	DocumentRef doc=NULL;	
	
	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_FAILED)
	{
		DEBUGL4("Test case -1.2 -Create Document  Failed\n");	
		passcount--;
	}
	else
	{
		DEBUGL4("Test case -1.2 -Create Document Success\n");	
		passcount++;		
	}

	// For Test case - 1.3  Box and Folder does not exist
	BoxNumber="999";
	FolderName="chandra";
	DocumentName="TestCD";
	doc=NULL;	
	
	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_OK)
	{
		DEBUGL4("Test case -1.3 -Create Document  Failed\n");	
		passcount--;
	}
	else
	{
		DEBUGL4("Test case -1.3 -Create Document Success\n");	
		passcount++;		
	}

	// For Test case - 1.4 Box and Folder are empty
	BoxNumber="";
	FolderName="";
	DocumentName="TestCD";
	doc=NULL;	
	
	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_OK)
	{
		DEBUGL4("Test case -1.4 -Create Document  Failed\n");	
		passcount--;
	}
	else
	{
		DEBUGL4("Test case -1.4 -Create Document Success\n");	
		passcount++;		
	}

	// For Test case - 1.5 Document already exists 
	BoxNumber="000";
	FolderName="chandra";
	DocumentName="TestCD";
	doc=NULL;	
	
	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_FAILED)
	{
		DEBUGL4("Test case -1.5 -Create Document  Failed\n");	
		passcount--;
	}
	else
	{
		DEBUGL4("Test case -1.5 -Create Document Success\n");	
		passcount++;		
	}

	// For Test case - 1.6 get status of the created Document 
	if(doc)
	{
		if(doc->GetStatus(state)==STATUS_OK)
		{
			if(state == 0)
			{
				DEBUGL6("Test case -1.6 - Document Status Success\n");
				passcount++;
			}
			else{
				DEBUGL6("Test case -1.6 - Document Status Failed -- State is not READY\n");
				passcount--;
			}				
		}
		else
		{
				DEBUGL6("Test case -1.6 - Document Status Failed\n");
				passcount--;
		}
	}

	// For Test case - 1.7  Max Document creation Test
	// Already 2 created check for 999/997 only
	passcount--;	
#if 0	
	BoxNumber="000";
	FolderName="Chandra";
	char buff[5];
	memset(buff,'\0',6);
	for(int i=2;i<=1001;i++)
	{
		sprintf(buff,"%d",i);
		DocumentName=buff;
		ret = boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName);
		if((ret == STATUS_FAILED)||(doc == static_cast <void*>(NULL)))
		{
				DEBUGL6("Test case -1.7 -Maxt Document test Failed\n");
				passcount--;
		}
	}
	if(ret == STATUS_OK)
	{
		DEBUGL6("Test case -1.7 -Maxt Document test success\n");
		passcount++;
	}
#endif
	// For Test case - 1.8  
	if(1)
	{
		DEBUGL6("Test case -1.8 -BoxDoc interface test Pending\n");
		passcount++;
	}
	
	// For Test case - 1.9
	BoxNumber="000";
	FolderName="Chandra";
	DocumentName="";
	doc=NULL;	

	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_OK)
	{
		DEBUGL6("Test case -1.9 -BoxDoc interface test Failed\n");
		passcount--;
	}
	else
	{
		DEBUGL6("Test case -1.9 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.10
	passcount--;
#if 0
	BoxNumber="000";
	FolderName="Chandra";
	DocumentName="Mohan";
	doc=NULL;	

	if(boxdoc->CreateDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName)==STATUS_OK)
	{
		DEBUGL6("Test case -1.10 -BoxDoc interface test Failed\n");
		passcount--;
	}
	else
	{
		DEBUGL6("Test case -1.10 -BoxDoc interface test Success\n");
		passcount++;		
	}
#endif

	//TC_BoxDoc1.11 - get document instance
	doc =NULL;
	BoxNumber = "000";
	FolderName="chandra";
	DocumentName="TestCD";
	ret = boxdoc->GetDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName);
	if((ret == STATUS_FAILED)||(doc == static_cast <void*>(NULL)))
	{
			DEBUGL6("Test case -1.11 -BoxDoc interface test Failed\n");
			passcount--;
	}
	else
	{
		DEBUGL6("Test case -1.11 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	//TC_BoxDoc1.11 - get document instance
	doc =NULL;
	BoxNumber = "000";
	FolderName = "Chandra";
	DocumentName="junkDoc";
	ret = boxdoc->GetDocument(doc, BoxBasePath, BoxNumber, FolderName, DocumentName);
	if((ret == STATUS_FAILED)||(doc == static_cast <void*>(NULL)))
	{
			DEBUGL6("Test case -1.12 -BoxDoc interface test Success\n");
			passcount++;
	}
	else
	{
		DEBUGL6("Test case -1.12 -BoxDoc interface test Failed\n");
		passcount--;		
	}

	// For Test case - 1.13
	if(1)
	{
		DEBUGL6("Test case -1.13 -BoxDoc interface test Pending\n");
		passcount++;
	}

	// For Test case - 1.14 -- create box instance
	CString name("TestBox");
	BoxRef box;
	if(boxdoc->CreateBox(box, BoxBasePath, name) != STATUS_OK) {
		DEBUGL6("Test case -1.14 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.14 -BoxDoc interface test Success\n");
		passcount++;		
	}

	// For Test case - 1.15 -- create box instance wrong basepath
	CString boxBasePath("/jill/");
	box=NULL;
	if(boxdoc->CreateBox(box,boxBasePath, name) == STATUS_OK) {
		DEBUGL6("Test case -1.15 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.15 -BoxDoc interface test Success\n");
		passcount++;		
	}

	// For Test case - 1.16 -- create box instance wrong basepath
	boxBasePath="";
	box=NULL;	
	if(boxdoc->CreateBox(box,boxBasePath, name) == STATUS_OK) {
		DEBUGL6("Test case -1.16 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.16 -BoxDoc interface test Success\n");
		passcount++;		
	}

	// For Test case - 1.17 -- create box already exists
	box=NULL;	
	if(boxdoc->CreateBox(box,BoxBasePath, name) == STATUS_OK) {
		DEBUGL6("Test case -1.17 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.17 -BoxDoc interface test Success\n");
		passcount++;		
	}

	// For Test case - 1.18
	if(1)
	{
		DEBUGL6("Test case -1.18 -BoxDoc interface test Pending\n");
		passcount++;
	}

	// For Test case - 1.19
	CString boxnumber = "Boxdoesnotexist";
	box=NULL;
	if(boxdoc->GetBox(box, BoxBasePath, boxnumber) == STATUS_OK) {
		DEBUGL6("Test case -1.19 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.19 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.20
	boxnumber = "TestBox";
	box=NULL;
	if(boxdoc->GetBox(box, BoxBasePath, boxnumber) != STATUS_OK) {
		DEBUGL6("Test case -1.20 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.20 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.21
	if(GetBoxList(BoxBasePath) != true) {
		DEBUGL6("Test case -1.21 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.22 -BoxDoc interface test Success\n");
		passcount++;		
	}

	// For Test case - 1.22
	//TC_BoxDoc1.22 - Delete document
	BoxNumber="000";
	FolderName="chandra";
	DocumentName = "TestCD";
	ret = boxdoc->DeleteDocument(BoxBasePath, BoxNumber, FolderName, DocumentName) ;	
	if(ret == STATUS_FAILED)
	{
		DEBUGL6("Test case -1.22 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.22 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.23
	BoxNumber = "TestBox";
	ret = boxdoc->DeleteBox(BoxBasePath, BoxNumber);
	if(ret == STATUS_FAILED)
	{
		DEBUGL6("Test case -1.23 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.23 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.24
	//TC_BoxDoc1.24 - Delete document
	BoxNumber="000";
	FolderName="chandra";
	DocumentName = "TestCD";
	ret = boxdoc->DeleteDocument(BoxBasePath, BoxNumber, FolderName, DocumentName) ;	
	if(ret == STATUS_OK)
	{
		DEBUGL6("Test case -1.24 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.24 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	// For Test case - 1.25
	BoxNumber = "TestBox";
	ret = boxdoc->DeleteBox(BoxBasePath, BoxNumber);
	if(ret == STATUS_OK)
	{
		DEBUGL6("Test case -1.25 -BoxDoc interface test Failed\n");
		passcount--;		
	}
	else
	{
		DEBUGL6("Test case -1.25 -BoxDoc interface test Success\n");
		passcount++;		
	}
	
	int val = 25-passcount;
	DEBUGL6("TESTCASES PASSED --%d\n TESTCASES FAILED --%d\n",passcount,val);

	DEBUGL4("Exiting Test BoxDocument Interaface Test cases\n");
	return true;
}
bool test_Box()
{
	DEBUGL4("Entering  Box Interaface Test cases\n");
	
	DEBUGL4("Exiting  Box Interaface Test cases\n");
	return true;
}

bool test_Folder()
{
	DEBUGL4("Entering  Box Interaface Test cases\n");
	
	DEBUGL4("Exiting  Box Interaface Test cases\n");
	return true;
}
bool test_Document()
{
	DEBUGL4("Entering  Box Interaface Test cases\n");
	
	DEBUGL4("Exiting  Box Interaface Test cases\n");
	return true;
}
bool test_Page()
{
	DEBUGL4("Entering  Box Interaface Test cases\n");
	
	DEBUGL4("Exiting  Box Interaface Test cases\n");
	return true;
}

bool test_miscelleneous()
{
	DEBUGL4("Entering  Box Interaface Test cases\n");
	
	DEBUGL4("Exiting  Box Interaface Test cases\n");
	return true;
}




bool utr_testcases() 
{
    CString boxbasepath = "EFilingBoxes";
    bool result;
    while(1) {
        int i = 0;
        cout << "Current path is " << boxbasepath <<  endl;
        cout << "1. BoxDocument interface Tests" << endl;
        cout << "2. Box interface Tests" << endl;
        cout << "3. Folder interface Tests" << endl;
        cout << "4. Document interface Tests" << endl;
        cout << "5. Page interface Tests" << endl;
        cout << "6. Misclleneous Test" << endl;
        cout << "0. exit" << endl;
        cin >> i;
        result = false;
        switch(i) {
        case 0: return true;
        case 1: result = test_BoxDocument(); break;
        case 2: result = test_Box(); break;
        case 3: result = test_Folder(); break;
        case 4: result = test_Document(); break;
        case 5: result = test_Page(); break;
        case 6: result = test_miscelleneous(); break;
        }
        cout << "result = " << result << endl;
    }
    return true;
}
