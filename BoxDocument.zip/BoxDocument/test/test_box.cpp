#include<iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>
#include <CI/OperatingEnvironment/cuuid.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

BoxRef GetBox(CString boxbasepath, CString boxnumber) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }

    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";
    // get box instance
    BoxRef box;
    if(boxdoc->GetBox(box, boxbasepath, boxnumber,password) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBox() is failed\n");
        return NULL;
    }
	 
	    return box;
}

bool test_CreateFolder(CString boxbasepath, CString boxnumber) {
    
		
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
	
    CString name;
    cout << "Enter Folder Name (n for empty): " << endl;
    cin >> name;
	if(name == "n")
		name = "";
	
	FolderRef folder; 
    if(box->CreateFolder(folder,name) != STATUS_OK) {
        DEBUGL1("Box::CreateFolder() is failed\n");
        return false;
    }
    DEBUGL6("Folder %s is created\n", name.c_str());
    return true;
}


bool test_DeleteFolder(CString boxbasepath, CString boxnumber) {
    
		
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
	
    CString name;
    cout << "Enter Folder Name (n for empty): " << endl;
    cin >> name;
	if(name == "n")
		name = "";
	
    if(box->DeleteFolder(name) != STATUS_OK) {
        DEBUGL1("Box::DeleteFolder() is failed\n");
        return false;
    }
    DEBUGL6("Folder %s is deleted\n", name.c_str());
    return true;
}
	
bool test_GetFolderList(CString boxbasepath, CString boxnumber) {
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
    
    FolderList list;
    if(box->GetFolderList(list) != STATUS_OK) {
        DEBUGL1("Box::GetFolderList() is failed\n");
        return false;
    }
    CString name;
    for(FolderList::iterator it = list.begin(); it != list.end(); it++) {
        (*it)->GetName(name);
        DEBUGL6("Folder Name - %s\n", name.c_str());
    }
    return true;
}

extern bool test_folder(CString, CString, CString&);
bool test_GetFolder(CString boxbasepath, CString boxnumber) {
    CString name;
    cout << "Enter Folder Name (n for empty): " << endl;
    cin >> name;
	if(name == "n")
		name = "";
	
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }
    
    // get box instance
    BoxRef box;
    if(boxdoc->GetBox(box, boxbasepath, boxnumber) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBox() is failed\n");
        return NULL;
    }
    
    // get folder instance
    FolderRef folder;
    if(box->GetFolder(folder, name) != STATUS_OK) {
        DEBUGL1("Box::GetFolder() is failed\n");
        return NULL;
    }
	
    return test_folder(boxbasepath, boxnumber, name);
}

bool test_GetDocumentList(CString boxbasepath, CString boxnumber) {
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
    
    // get document list
    DocumentList doclist;
    if(box->GetDocumentList(doclist) != STATUS_OK) {
        DEBUGL1("Box::GetDocumentList() is failed\n");
        return false;
    }
    CString name;
    for(DocumentList::iterator it = doclist.begin(); it != doclist.end(); it++) {
        (*it)->GetName(name);
        DEBUGL6("Document Name - %s\n", name.c_str());
    }
    return true;
}
bool test_GetDocumentListToDelete(CString boxbasepath) {
   BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

    CString num;
    cout << "Enter Box number : " << endl;
    cin >> num;

    CString phoneNumber = "";
    //cout << "Enter phone number (only for polling boxes else leave it empty by entering n): " << endl;
    //cin >> phoneNumber;
    //if(phoneNumber=="n")
    //  phoneNumber="";

    CString password = "";         
    //cout << "Enter Box Password : 'n' for empty" << endl;
    //cin >> password;
    //if(password=="n")         
    //  password="";

    CString access = "2";
   // cout << "Select Access Context Type:\n1.LOCAL_READ\n2.LOCAL_WRITE\n3.REMOTE_READ\n4.REMOTE_WRITE\n " << endl;
   // cin >> access;
   AccessContext context = LOCAL_READ;
   if(access=="1")
      context=LOCAL_READ;
   else if(access=="2")
      context=LOCAL_WRITE;
   else if(access=="3")
      context=REMOTE_READ;
   else if(access=="4")
      context=REMOTE_WRITE;

    // get box instance
    BoxRef box;
    if(boxdoc->GetMailBox(box,boxbasepath, num,context,password, phoneNumber) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetMailBox() is failed\n");
        return false;
    }
   DocumentList doclist;
   if(box->GetDocumentListToDelete(doclist) != STATUS_OK) {
      DEBUGL1("Box::GetDocumentListToDelete() failed..!\n");
      return false;
   }
   CString name("");
   for(DocumentList::iterator it = doclist.begin();it != doclist.end(); it++) {
      (*it)->GetName(name);
      DEBUGL6("Document name = %s\n",name.c_str());
      if(box->DeleteDocument(name) != STATUS_OK) {
         DEBUGL6("Box::test_GetDocumentListToDelete()::DeleteDocument() failed\n");
         return false;
      }
   }
   DEBUGL1("Box::test_GetDocumentListToDelete() is has deleted all documents successfully\n");
   return true;
}

extern bool test_document(CString, CString, CString, CString&);
bool test_GetDocument(CString boxbasepath, CString boxnumber) {
    CString name;
    cout << "Enter Document Name (n for empty): " << endl;
    cin >> name;
	if(name == "n")
		name = "";

    BoxDocumentRef boxdoc;
	CUUIDRef uid = new CUUID();	  
	CString sessionID= uid->toString();

    boxdoc = BoxDocument::Acquire(sessionID);
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }

	BoxRef box;
	if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

	DocumentRef doc;
    if(box->GetDocument(doc, name) != STATUS_OK) {
        DEBUGL1("Box::GetDocument() is failed\n");
        return false;
    }
    
    return test_document(boxbasepath, boxnumber, "", name);
}

bool test_RenameBox(CString boxbasepath, CString boxnumber) {
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
    
    CString new_name;
    cin.ignore(); //To ignore the '\n' or ENTER
    cout << "Enter new Box name" << endl;
    getline(cin, new_name); //To allow names with spaces till '\n'
    if(box->SetName(new_name) != STATUS_OK) {
        DEBUGL1("Box::SetName() is failed\n");
        return false;
    }
    return true;
}

bool test_GetWebDAVProperty(CString boxbasepath, CString boxnumber) {
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
    CString key, value;
    char* keylist[15] = {"documentType", "boxName", "isPasswordProtected", "password", "preservationPeriodFlag", "documentPreserveDays", "notificationEmailSetting", "notifyBeforeDeletionOfDocument", "notifyOnError", "notifyOnJobCompletion", "notificationEmailAddress", "creationDate", "lastModifiedDate", "lastAccessDate", "lastBackupDate"};
    for(int i = 0; i < 15; i++) {
        key = keylist[i];
        box->GetWebDAVProperty(key, value);
        DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    }
    return true;
}

bool test_SetWebDAVProperty(CString boxbasepath, CString boxnumber) {
    BoxRef box = GetBox(boxbasepath, boxnumber);
    if(!box) {
        return false;
    }
    CString key, value;
    cout << "Enter Box property (KEY)" << endl;
    cin >> key;
    cout << "Enter Box property (VALUE)" << endl;
    cin >> value;
    if(box->SetWebDAVProperty(key, value) != STATUS_OK) {
        DEBUGL1("Box::SetWebDAVProperty() is failed\n");
        return false;
    }
    return true;
}

bool test_UndoEditDocument(CString boxbasepath,CString name)
{
	CString docname,res;
    	std::vector<CString> doclist;
	BoxRef box = GetBox(boxbasepath, name);
	if(!box) {
		cout << "Could not obtain the Box ref"<< endl;		
		return false;
	}
	
	cout << "Enter document Name for which operation need to be undone" << endl;
	cin >> docname;
	doclist.push_back(docname);
	
	cout << "Do you want to Enter More documents: <Enter y(yes) n(no)> " << endl;
	cin >> res;
	while((res.compare("y")==0))
	{
		cout << "Enter document Name for which operation need to be undone" << endl;
		cin >> docname;
		doclist.push_back(docname);
		cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
		cin >> res;
		break;
	}

	if(box->UndoEditDocument(doclist))
	{
		cout <<"UndoEditDocument failed"<< endl;		
		return false;
	}
	else 
		cout <<"UndoEditDocument Sucessful"<< endl;	
	
	return true;
}

bool test_IsPasswordProtected(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }

		if(box->IsPasswordProtected())
		{	
			DEBUGL6("IsPasswordProtected - true\n");
			return true;
		}	
		else  
		{	
			DEBUGL6("IsPasswordProtected - false\n");
			return false;
		}	
		
}

bool test_GetDocumentPreserveDays(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }

		CString days;
		if(box->GetDocumentPreserveDays(days)!=STATUS_OK)
		{	
			DEBUGL1("GetDocumentPreserveDays Failed\n");
			return false;
		}	
		else  
			DEBUGL6("GetDocumentPreserveDays Success - days<%s>\n",days.c_str());		
		
		return true;	
}

bool test_GetLastModifiedDate(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }

		CString date;
		if(box->GetLastModifiedDate(date)!=STATUS_OK)
		{	
			DEBUGL1("GetLastModifiedDate Failed\n");
			return false;			
		}	
		else  
			DEBUGL6("GetLastModifiedDate Success - date<%s>\n",date.c_str());			
		
		return true;		
}

bool test_ChangePassword(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }

		CString boxpassword;
		cout << "Enter new Box Password: 'n' for Empty\n" << endl;
		cin >> boxpassword;
		if(boxpassword=="n")
			boxpassword="";
		 
		if(box->ChangePassword(boxpassword)!=STATUS_OK)
		{
			DEBUGL1("ChangePassword failed\n");
			return false;
		}
		
		return true;	
}

bool test_Unlock(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }
		 
		if(box->Unlock()!=STATUS_OK)
		{
			DEBUGL1("Unlock failed\n");
			return false;
		}
		
		return true;	
}

bool test_GetLastBackupDate(CString boxbasepath, CString boxnumber) 
{
		CString date;
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }		 
		if(box->GetLastBackupDate(date)!=STATUS_OK)
		{
			DEBUGL1("GetLastBackupDate failed\n");
			return false;
		}		
		DEBUGL6("Last backup date = %s\n",date.c_str());
		BoxList boxlist;
		cout << "\nWith GetBoxList\n";

		BoxDocumentRef boxdoc;
		boxdoc = BoxDocument::Acquire();
		if(boxdoc == static_cast<void *> (NULL)) {
		    DEBUGL1("BoxDocument::Acquire() is failed\n");
		    return false;
		}

		if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxList() is failed\n");
		    return false;
		}
		
		for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
			(*it)->GetLastBackupDate(date);
			DEBUGL6("Last backup date - %s\n", date.c_str());
		}
		
		return true;	
}
bool test_SetLastBackupDate(CString boxbasepath, CString boxnumber) 
{
		CString date = "12122010";
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }		 
		if(box->SetLastBackupDate(date)!=STATUS_OK)
		{
			DEBUGL1("GetLastBackupDate failed\n");
			return false;
		}		
		int i;
		scanf("%d",&i);
		cout << "\nWith GetBoxList\n";
		BoxList boxlist;

		BoxDocumentRef boxdoc;
		boxdoc = BoxDocument::Acquire();
		if(boxdoc == static_cast<void *> (NULL)) {
		    DEBUGL1("BoxDocument::Acquire() is failed\n");
		    return false;
		}

		if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxList() is failed\n");
		    return false;
		}
		
		for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
			(*it)->SetLastBackupDate(date);
		}
		
		return true;	
}
bool test_GetPassword(CString boxbasepath, CString boxnumber) 
{
	    BoxRef box = GetBox(boxbasepath, boxnumber);
	    if(!box) {
	        return false;
	    }
		 CString password;
		if(box->GetPassword(password)!=STATUS_OK)
		{
			DEBUGL1("Getpassword failed\n");
			return false;
		}
		DEBUGL8("Password = (%s)\n", password.c_str());
		return true;	
}

bool test_box(CString boxbasepath, CString boxnumber) {
    bool result;
    while(1) {
		int i = 0;
		cout << "Box: /" << boxbasepath << "/" << boxnumber << endl;
		cout << "1. Create Folder" << endl;
		cout << "2. Get Folder List" << endl;
		cout << "3. Get Folder" << endl;
		cout << "4. Get Document List" << endl;
		cout << "5. Get Document" << endl;
		cout << "6. Delete folder" << endl;		
		cout << "7. Rename Box" << endl;
		cout << "8. Get WebDAV property" << endl;
		cout << "9. Set WebDAV property" << endl;
		cout << "10. Is Box Password Protected" << endl;
		cout << "11. Get Document Preserve Days" << endl;
		cout << "12. Get LastModified Date" << endl;		  
		cout << "13. Change Password" << endl;		  
		cout << "14. Unlock Box" << endl;
		cout << "15. UndoEditDocument functionality" << endl;		
		cout << "16. Get LastBackup Date" << endl;		  
		cout << "17. Set LastBackup Date" << endl;		  
		cout << "18. Get password" << endl;		  
		
		cout << "0. exit" << endl;
		cin >> i;
		result = false;
        switch(i) {
        case 0: return true;
        case 1: result = test_CreateFolder(boxbasepath, boxnumber); break;
        case 2: result = test_GetFolderList(boxbasepath, boxnumber); break;
        case 3: result = test_GetFolder(boxbasepath, boxnumber); break;
        case 4: result = test_GetDocumentList(boxbasepath, boxnumber); break;
        case 5: result = test_GetDocument(boxbasepath, boxnumber); break;
        case 6: result = test_DeleteFolder(boxbasepath, boxnumber); break;		
        case 7: result = test_RenameBox(boxbasepath, boxnumber); break;
        case 8: result = test_GetWebDAVProperty(boxbasepath, boxnumber); break;
        case 9: result = test_SetWebDAVProperty(boxbasepath, boxnumber); break;
        case 10: result = test_IsPasswordProtected(boxbasepath, boxnumber); break;
        case 11: result = test_GetDocumentPreserveDays(boxbasepath, boxnumber); break;
        case 12: result = test_GetLastModifiedDate(boxbasepath, boxnumber); break;		  
        case 13: result = test_ChangePassword(boxbasepath, boxnumber); break;		  
        case 14: result = test_Unlock(boxbasepath, boxnumber); break;		  		  
        case 15: result = test_UndoEditDocument(boxbasepath, boxnumber); break;		  	
        case 16: result = test_GetLastBackupDate(boxbasepath, boxnumber); break;		  	
        case 17: result = test_SetLastBackupDate(boxbasepath, boxnumber); break;		  	
        case 18: result = test_GetPassword(boxbasepath, boxnumber); break;		  	
        }
        cout << "result = " << result << endl;
    }
    return true;
}

bool test_CreateBox(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }
    
    // create box instance
    CString name;
    cout << "Enter Box number : " << endl;
    cin >> name;

    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";
	 
    BoxRef box;
    if(boxdoc->CreateBox(box, boxbasepath, name,password) != STATUS_OK) {
        DEBUGL1("BoxDocument::CreateBox() is failed\n");
        return true;
    }
    DEBUGL6("Box %s is created\n", name.c_str());
    return true;
}

bool test_GetBoxList(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxList boxlist;
	DEBUGL6("Date before GetBoxList \n");		
    if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	DEBUGL6("Date before GetBoxList \n");	
    
    CString boxnumber, name, presflag, docpresdays, creationdate, lastmodifieddate;
	bool ispassprotected;
	uint64 boxsize;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());		
		(*it)->GetName(name);
        DEBUGL6("BOX Name - %s\n", name.c_str());		
        DEBUGL6("BOX is passwordprotected - %d\n",  (*it)->IsPasswordProtected());		
		(*it)->GetPreservationPeriodFlag(presflag);
        DEBUGL6("BOX preservation flag - %s\n", presflag.c_str());		
		(*it)->GetDocumentPreserveDays(docpresdays);
        DEBUGL6("BOX preservation days - %s\n", docpresdays.c_str());		
		(*it)->GetCreationDate(creationdate);
        DEBUGL6("BOX creation date - %s\n", creationdate.c_str());		
		(*it)->GetLastModifiedDate(lastmodifieddate);
        DEBUGL6("BOX last modified date - %s\n", lastmodifieddate.c_str());		
		(*it)->GetSize(boxsize);
        DEBUGL6("BOX size - %u\n", boxsize);		

    }
	
    return true;
}
bool test_GetBoxListforAl(CString boxbasepath){
    DEBUGL4("test_GetBoxListforAl::Enter..\n");
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

    BoxList boxlist;
    //DEBUGL6("Date before GetBoxList \n");
    if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
    DEBUGL6("Date before GetBoxList \n");

    CString boxnumber, name, presflag, docpresdays, creationdate, lastmodifieddate;
    bool ispassprotected;
    uint64 boxsize;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++){
        (*it)->GetNumber(boxnumber);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());
        (*it)->GetName(name);
        DEBUGL6("BOX Name - %s\n", name.c_str());
        DEBUGL6("BOX is passwordprotected - %d\n",  (*it)->IsPasswordProtected());
        (*it)->GetPreservationPeriodFlag(presflag);
        DEBUGL6("BOX preservation flag - %s\n", presflag.c_str());
        (*it)->GetDocumentPreserveDays(docpresdays);
        DEBUGL6("BOX preservation days - %s\n", docpresdays.c_str());
        (*it)->GetCreationDate(creationdate);
        DEBUGL6("BOX creation date - %s\n", creationdate.c_str());
        (*it)->GetLastModifiedDate(lastmodifieddate);
        DEBUGL6("BOX last modified date - %s\n", lastmodifieddate.c_str());
        (*it)->GetSize(boxsize);
        DEBUGL6("BOX size - %u\n", boxsize);
    }
    for(BoxList::iterator bit = boxlist.begin(); bit != boxlist.end(); bit++){
            DocumentList doclist;
            if((*bit)->GetViewDocumentList(doclist) != STATUS_OK)
            {
                DEBUGL1("test_GetBoxListforAl::GetViewDocumentList() failed..\n");
                return false;
            }
            CString docname, jobtypeval, creationdate, lastmodifieddate, thumbpath, cutdoc;
            DocStatus st;
            JobTypeColorSet jcset;
            PaperSizeMap papermap;
            int totalpages;
            uint64 docsize;
            for(DocumentList::iterator docit = doclist.begin(); docit != doclist.end(); docit++)
            {
                (*docit)->GetName(docname);
                DEBUGL6("Document name = (%s)\n", docname.c_str());
                (*docit)->GetWebDAVProperty("jobType",jobtypeval);
                DEBUGL6("Document job type = (%s)\n", jobtypeval.c_str());
                (*docit)->GetWebDAVProperty("creationDate",creationdate);
                DEBUGL6("Document creation date = (%s)\n", creationdate.c_str());
                (*docit)->GetWebDAVProperty("lastModifiedDate",lastmodifieddate);
                DEBUGL6("Document last modified date = (%s)\n", lastmodifieddate.c_str());
                (*docit)->GetWebDAVProperty("cutDocument",cutdoc);
                DEBUGL6("Document cut document flag = (%s)\n", cutdoc.c_str());
                (*docit)->GetTotalPage(totalpages);
                DEBUGL6("Document total pages = (%d)\n", totalpages);
                (*docit)->GetTotalSize(docsize);
                DEBUGL6("Document total size = (%u)\n",docsize);
                (*docit)->GetThumbnailImage(thumbpath);
                DEBUGL6("Document path = (%s)\n", thumbpath.c_str());
                (*docit)->GetStatus(st);
                DEBUGL6("Document status = (%d)\n", st);
                if((*docit)->GetJobTypeColorSet(jcset) != STATUS_OK)
                    DEBUGL1("Failed to get jobtypecolormap\n");
                if((*docit)->GetPaperSizeMap(papermap) != STATUS_OK)
                    DEBUGL1("Failed to get papersizemap\n");

                PageList pagelist;
                if((*docit)->GetViewPageList(pagelist)!= STATUS_OK)
                {
                    DEBUGL1("BoxDocument::Failed to get the page list \n");
                    return false;
                }
                CString jobtype, creationdate, lastmodifieddate, cutpage, tpath, papersize;
                int hres, vres, width, height;
                uint64 filesize;
                ColorMode colormode;
                for(PageList::iterator pageit = pagelist.begin(); pageit != pagelist.end(); pageit++)
                {
                    (*pageit)->GetWebDAVProperty("jobType", jobtype);
                    DEBUGL6("Page job type = (%s)\n", jobtype.c_str());
                    (*pageit)->GetWebDAVProperty("creationDate", creationdate);
                    DEBUGL6("Page creation date = (%s)\n", creationdate.c_str());
                    (*pageit)->GetWebDAVProperty("lastModifiedDate", lastmodifieddate);
                    DEBUGL6("Page last modified date = (%s)\n", lastmodifieddate.c_str());
                    (*pageit)->GetWebDAVProperty("cutPage", cutpage);
                    DEBUGL6("Page cut page flag = (%s)\n", cutpage.c_str());
                    (*pageit)->GetPaperSize(papersize);
                    DEBUGL6("Page papersize = (%d)\n", papersize.c_str());
                    (*pageit)->GetResolution(hres, vres);
                    DEBUGL6("Page hres = (%d) vres = (%d)\n", hres, vres);
                    (*pageit)->GetFileSize(filesize);
                    DEBUGL6("Page file size = (%u)\n", filesize);
                    (*pageit)->GetThumbnailImage(tpath);
                    DEBUGL6("Page thumbnail path = (%s)\n", tpath.c_str());
                    (*pageit)->GetColorMode(colormode);
                    DEBUGL6("Page color mode = (%d)\n", colormode);
                    (*pageit)->GetImageSize(width, height);
                    DEBUGL6("Page image width = (%d) height = (%d)\n", width, height);
                }
            }
    }    
    DEBUGL4("test_GetBoxListforAl::Exit..\n");
    return true;
}

    
bool test_GetViewDocumentList(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxRef boxobj;
	//DEBUGL6("Date before GetBoxList \n");		
	DocumentList documentlist;
    if(boxdoc->GetBox(boxobj, boxbasepath, "00000", "") != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	if(boxobj->GetViewDocumentList(documentlist) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	CString docname, jobtypeval, creationdate, lastmodifieddate, thumbpath, cutdoc;
	DocStatus st;
	JobTypeColorSet jcset;
	PaperSizeMap papermap;
	int totalpages;
	uint64 docsize;
    for(DocumentList::iterator docit = documentlist.begin(); docit != documentlist.end(); docit++) 
	{
		(*docit)->GetName(docname);
        DEBUGL6("Document name = (%s)\n", docname.c_str());
		(*docit)->GetWebDAVProperty("jobType",jobtypeval);
        DEBUGL6("Document job type = (%s)\n", jobtypeval.c_str());
		(*docit)->GetWebDAVProperty("creationDate",creationdate);
        DEBUGL6("Document creation date = (%s)\n", creationdate.c_str());
		(*docit)->GetWebDAVProperty("lastModifiedDate",lastmodifieddate);
        DEBUGL6("Document last modified date = (%s)\n", lastmodifieddate.c_str());
		(*docit)->GetWebDAVProperty("cutDocument",cutdoc);
        DEBUGL6("Document cut document flag = (%s)\n", cutdoc.c_str());
		(*docit)->GetTotalPage(totalpages);
        DEBUGL6("Document total pages = (%d)\n", totalpages);
		(*docit)->GetTotalSize(docsize);
        DEBUGL6("Document total size = (%u)\n",docsize);
		(*docit)->GetThumbnailImage(thumbpath);
        DEBUGL6("Document path = (%s)\n", thumbpath.c_str());
		(*docit)->GetStatus(st);
        DEBUGL6("Document status = (%d)\n", st);
		if((*docit)->GetJobTypeColorSet(jcset) != STATUS_OK)
			DEBUGL1("Failed to get jobtypecolormap\n");
        //DEBUGL6("Document name = (%d)\n", jcset[]);
		if((*docit)->GetPaperSizeMap(papermap) != STATUS_OK)
			DEBUGL1("Failed to get papersizemap\n");
        //DEBUGL6("Document name = (%d)\n", papermap[]);
	}
	//DEBUGL6("Date before GetBoxList \n");	
#if 0    
    CString boxnumber, name, presflag, docpresdays, creationdate, lastmodifieddate;
	bool ispassprotected;
	uint64 boxsize;
	DocumentList documentlist;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());		
		(*it)->GetName(name);
        DEBUGL6("BOX Name - %s\n", name.c_str());		
        DEBUGL6("BOX is passwordprotected - %d\n",  (*it)->IsPasswordProtected());		
		(*it)->GetPreservationPeriodFlag(presflag);
        DEBUGL6("BOX preservation flag - %s\n", presflag.c_str());		
		(*it)->GetDocumentPreserveDays(docpresdays);
        DEBUGL6("BOX preservation days - %s\n", docpresdays.c_str());		
		(*it)->GetCreationDate(creationdate);
        DEBUGL6("BOX creation date - %s\n", creationdate.c_str());		
		(*it)->GetLastModifiedDate(lastmodifieddate);
        DEBUGL6("BOX last modified date - %s\n", lastmodifieddate.c_str());		
		(*it)->GetSize(boxsize);
        DEBUGL6("BOX last modified date - %u\n", boxsize);		
		(*it)->GetViewDocumentList(documentlist);
    	for(DocumentList::iterator docit = documentlist.begin(); docit != documentlist.end(); docit++) {
			(*docit)->	
		}
        DEBUGL6("BOX last modified date - %u\n", boxsize);		

    }
#endif	
    return true;
}
bool test_GetViewPageList(CString boxbasepath)
{
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxRef boxobj;
	//DEBUGL6("Date before GetBoxList \n");		
	DocumentRef document;
    if(boxdoc->GetBox(boxobj, boxbasepath, "00000", "") != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	if(boxobj->GetDocument(document, "DOC110929") != STATUS_OK)
	{
        DEBUGL1("BoxDocument::Failed to get the document\n");
        return false;
	}
	PageList pagelist;
	if(document->GetViewPageList(pagelist)!= STATUS_OK)
	{
        DEBUGL1("BoxDocument::Failed to get the page list \n");
        return false;
	}
	CString jobtype, creationdate, lastmodifieddate, cutpage, tpath, papersize;
	int hres, vres, width, height; 
	uint64 filesize;
	ColorMode colormode;
    for(PageList::iterator pageit = pagelist.begin(); pageit != pagelist.end(); pageit++) 
	{
		(*pageit)->GetWebDAVProperty("jobType", jobtype);
        DEBUGL6("Page job type = (%s)\n", jobtype.c_str());
		(*pageit)->GetWebDAVProperty("creationDate", creationdate);
        DEBUGL6("Page creation date = (%s)\n", creationdate.c_str());
		(*pageit)->GetWebDAVProperty("lastModifiedDate", lastmodifieddate);
        DEBUGL6("Page last modified date = (%s)\n", lastmodifieddate.c_str());
		(*pageit)->GetWebDAVProperty("cutPage", cutpage);
        DEBUGL6("Page cut page flag = (%s)\n", cutpage.c_str());
		(*pageit)->GetPaperSize(papersize);
        DEBUGL6("Page papersize = (%d)\n", papersize.c_str());
		(*pageit)->GetResolution(hres, vres);
        DEBUGL6("Page hres = (%d) vres = (%d)\n", hres, vres);
		(*pageit)->GetFileSize(filesize);
        DEBUGL6("Page file size = (%u)\n", filesize);
		(*pageit)->GetThumbnailImage(tpath);
        DEBUGL6("Page thumbnail path = (%s)\n", tpath.c_str());
		(*pageit)->GetColorMode(colormode);
        DEBUGL6("Page color mode = (%d)\n", colormode);
		(*pageit)->GetImageSize(width, height);
        DEBUGL6("Page image width = (%d) height = (%d)\n", width, height);
	
	}
	return true;
}

bool test_GetMIBBoxList(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxList boxlist;
	int totalBoxes; 
	DEBUGL6("Date before GetBoxList \n");	
    if(boxdoc->GetBoxList(boxlist, totalBoxes, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	DEBUGL6("Date before GetBoxList \n");
	
    
    CString boxnumber, boxname;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
	(*it)->GetName(boxname);	
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());
        DEBUGL6("BOX Name - %s\n", boxname.c_str());		
    }
        DEBUGL6("Total number of boxes - %d\n", totalBoxes);		

    return true;
}


bool test_GetBoxListWithRange(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	int from;
	cout << "Enter range from (0 to 65535) : ";	
	cin >> from;

	int to;
	cout <<"Enter range to(0 to 65535) : ";
	cin >>to;
	
    BoxList boxlist;
    if(boxdoc->GetBoxList(boxlist, boxbasepath,from, to) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
	
    
    CString boxnumber;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());
    }
    return true;
}


bool test_GetBox(CString boxbasepath) {
    CString name;
    cout << "Enter Box number : " << endl;
    cin >> name;
	
    BoxRef box = GetBox(boxbasepath, name);
    if(!box) {
        return false;
    }

    return test_box(boxbasepath, name);
}
bool test_DeleteBox(CString boxbasepath) {
    CString name;
    cout << "Enter Box number : " << endl;
    cin >> name;
	
    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";
	
    BoxDocumentRef boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

	if(boxdoc->DeleteBox(boxbasepath,name,password) != STATUS_OK)
	{
        	DEBUGL1("BoxDocument::DeleteBox failed\n");
		return false;
	}
	return true;
}

bool test_ChangeBasePath(CString &boxbasepath) {
    CString new_name;
    cout << "Enter new path : " << endl;
    cin >> new_name;
    boxbasepath = new_name;
    return true;
}
bool test_CopyDocument(CString boxbasepath)
{
    CString srcBox,dstBox, Document;
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter src Box Number: " << endl;
    cin >> srcBox;

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Document Number: " << endl;
    cin >> Document;

    ret = boxdoc->GetBox(box,boxbasepath,srcBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->CopyDocument(Document);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

    DEBUGL6("BoxDocument::Copy Document PASSED\n");

    ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Paste Document failed\n");
        return false;
    }

	DEBUGL6("BoxDocument::Paste Document PASSED\n");

   return true;
}

bool test_CutDocument(CString boxbasepath)
{
    CString srcBox,dstBox, Document;
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter src Box Number: " << endl;
    cin >> srcBox;

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

    cout << "Enter Document Number: " << endl;
    cin >> Document;

    ret = boxdoc->GetBox(box,boxbasepath,srcBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->CutDocument(Document);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Cut Document failed\n");
        return false;
    }

    ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Cut Document failed\n");
        return false;
    }

   return true;
}

bool test_CopyVector(CString boxbasepath)
{
    std::vector<CString> m_doclist;
    CString srcBox,dstBox;

    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter src Box Number: " << endl;
    cin >> srcBox;

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

 	CString Document,res;
	cout << "Enter Document Number: " << endl;
	cin >> Document;
	m_doclist.push_back(Document);
	
	cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
	cin >> res;
	while((res.compare("y")==0))
	{
		cout << "Enter Document Number: " << endl;
		cin >> Document;
		m_doclist.push_back(Document);
		cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
		cin >> res;
		break;
	}
   

    ret = boxdoc->GetBox(box,boxbasepath,srcBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->CopyDocument(m_doclist);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

    ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   return true;
}

bool test_CutVector(CString boxbasepath)
{
    std::vector<CString> m_doclist;
    CString srcBox,dstBox;

    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter src Box Number: " << endl;
    cin >> srcBox;

    cout << "Enter Dst Box Number: " << endl;
    cin >> dstBox;

 	CString Document,res;
	cout << "Enter Document Number: " << endl;
	cin >> Document;
	m_doclist.push_back(Document);
	
	cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
	cin >> res;
	while((res.compare("y")==0))
	{
		cout << "Enter Document Number: " << endl;
		cin >> Document;
		m_doclist.push_back(Document);
		cout << "Do you want to Enter More: <Enter y(yes) n(no)> " << endl;
		cin >> res;
		break;
	}
   

    ret = boxdoc->GetBox(box,boxbasepath,srcBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->CutDocument(m_doclist);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

    ret = boxdoc->GetBox(box,boxbasepath,dstBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

   return true;
}
bool test_ClipboardOpeartions(CString boxbasepath)
{
    int i;
    bool result;
    boxbasepath =  boxbasepath;

    cout << "1. Copy Document sequence" << endl;
    cout << "2. Cut Document sequence" << endl;
    cout << "3. Copy more than 1 Document seq" << endl;
    cout << "4. Cut more than 1 Document seq" << endl;
    cout << "0. exit" << endl;
    cin >> i;
    result = false;
    switch(i) {
        case 0: return true;
        case 1: result = test_CopyDocument(boxbasepath); break;
        case 2: result = test_CutDocument(boxbasepath); break;
        case 3: result = test_CopyVector(boxbasepath); break;
        case 4: result = test_CutVector(boxbasepath); break;
        }
        cout << "result = " << result << endl;
    return result;
}

bool test_CreateDocument(CString boxbasepath)
{
CString BoxNumber,FolderName,DocumentName;
BoxDocumentRef boxdoc=NULL;
BoxRef box=NULL;
DocumentRef doc=NULL;

boxdoc = BoxDocument::Acquire();
if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
}
cout<<"Enter BoxNumber"<<endl;
cin>>BoxNumber;
cout<<"Enter DocumentName"<<endl;
cin>>DocumentName;
FolderName="";

if(!boxdoc->BoxExist(boxbasepath,BoxNumber))
{
    CString boxpassword;
    cout<<"\nEnter the box password:\nEnter 'n' for no password\n";
    cin>>boxpassword;
    if(boxpassword=="N")
		boxpassword="";
	 
	if(boxdoc->CreateBox(box,boxbasepath,BoxNumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::CreateBox() failed\n");
		return false;
	}
}
else
{
	if(boxdoc->GetBox(box,boxbasepath,BoxNumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}
}


// 3.1: Create New Document in box
for(int i = 0; i < 10;i++)
{
if(box->CreateDocument(doc,DocumentName) != STATUS_OK) {
    DEBUGL1("Box::CreateDocument() is failed\n");
    return false;	
}
}
return true;
}


bool test_CutPage(CString boxbasepath)
{

    CString newBox="2",newFolder="1",newDocument="1";
		DocumentRef doc1;
	Status ret;
	BoxRef box;

	BoxDocumentRef boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }


    ret = boxdoc->GetBox(box,boxbasepath,newBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

	if(boxdoc->GetBox(box,boxbasepath,newBox)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

	if(!newFolder.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,newFolder)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc1, newDocument) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc1, newDocument) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}

    DEBUGL6("Document:: Editing called\n");

    if(doc1->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
	int i;

	DEBUGL6("Document:: Edit succesfull\n");

	scanf("%d",&i);

   if(doc1->CutPage(2) != STATUS_OK) {
        DEBUGL1("Document::CutPage() is failed\n");
        return false;
    }
	
	DEBUGL6("Document:: CutPage succesfull\n");
	scanf("%d",&i);

	newBox="3";
	box=NULL;
   ret = boxdoc->GetBox(box,boxbasepath,newBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->PasteDocument();
    if(ret == STATUS_FAILED ){
        DEBUGL1("BoxDocument::Paste Document failed\n");
        return false;
    }

 if(doc1->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

DEBUGL6("Document:: Paste document succesfull\n");
return true;
}


bool test_PastePage(CString boxbasepath)
{
    CString srcBox,dstBox, Document;
    Status ret;

    BoxDocumentRef boxdoc=NULL;
    BoxRef box=NULL;
    DocumentRef doc=NULL;

    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    cout << "Enter src Box Number: " << endl;
    cin >> srcBox;

    cout << "Enter Document Number: " << endl;
    cin >> Document;

    int newpage;
    CString newBox,newFolder,newDocument;

    cout << "Enter the BoxName where it has to be pasted" << endl;
    cin >> newBox;

    cout << "Enter the FolderName where it has to be pasted" << endl;
    cin >> newFolder;

    cout << "Enter the DocumentName where it has to be pasted" << endl;
    cin >> newDocument;

    cout << "Enter the Page Number" << endl;
    cin >> newpage;
	 

    ret = boxdoc->GetBox(box,boxbasepath,srcBox);
    if(box == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::GetBox failed\n");
        return false;
    }

    ret = box->CutDocument(Document);
    if(ret == STATUS_FAILED ) {
        DEBUGL1("BoxDocument::Copy Document failed\n");
        return false;
    }

	int i;
	DEBUGL6("Document:: Cut Document succesfull\n");
	scanf("%d",&i);

	if(boxdoc->GetBox(box,boxbasepath,newBox)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}
	doc=NULL;
	if(!newFolder.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,newFolder)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc, newDocument) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc, newDocument) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
	scanf("%d",&i);

   if(doc->PastePage(newpage) != STATUS_OK) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Paste succesfull\n");
	scanf("%d",&i);

	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Save succesfull\n");


   return true;
}


bool test_WEP(CString boxbasepath)
{
    dom::NodeRef WEP;
    
    //Create a HierarchicalDBRef object
    ci::hierarchicaldb::HierarchicalDBRef phdb = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
    //Have a string for the Documet name.
    CString sDoc = "tempdoc1";
    dom::DocumentRef pDoc;
	CString domFileName = "options.xml";
	DEBUGL6("test_WEP: domFileName = %s\n",domFileName.c_str());	
	if(phdb->CreateTempDocumentFromFile(pDoc,domFileName) != STATUS_OK)
	{
		DEBUGL1("test_WEP: Unable to open the $EB2/bin/%s\n",domFileName.c_str());
		return STATUS_FAILED;
	}

	WEP = pDoc->getDocumentElement();
	if(!WEP)
	{
		DEBUGL1("test_WEP: Invalide ref\n");
		return false;
	}
		
    CString newBox,newFolder,newDocument;

    cout << "Enter the BoxName where it has to be created" << endl;
    cin >> newBox;

	BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

    BoxRef box;
    if(boxdoc->GetBox(box, boxbasepath, newBox) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBox() is failed\n");
        return false;
    }
    // 6.3: Put WEP DOM object
    if(box->SetWEPDocument(WEP) != STATUS_OK) {
        DEBUGL1("Document::SetWEPDocument() is failed\n");
        return false;
    }
	else
        DEBUGL6("\nDocument::SetWEPDocument() SUCCESS\n");
	int i;
	scanf("%d",&i);
    
	//Get WEP 
	CString documentID;
	if(box->GetWEPDocument(documentID)!=STATUS_OK)
		return STATUS_FAILED;
	cout << "\nDocument ID is "<<documentID<<endl;
	return true;
}


bool test_GetSize(CString boxbasepath)
{
   CString name;
    cout << "Enter Box Name : " << endl;
    cin >> name;
    BoxRef box = GetBox(boxbasepath, name);
    if(!box) {
        return false;
    }
	 uint64 size = 0;
    if(box->GetSize(size) != STATUS_OK) {
        DEBUGL1("Box::GetSize() is failed\n");
        return true;
    }
    DEBUGL6("Box::GetSize() size is %lld",size);
	
	return true;
}

bool test_Extract(CString boxbasepath)
{
   CString name,docname;
   Ref<ci::boxdocument::Extractor> extractor = NULL;
   CString extractFilePath = "";
   CString zipFilename;
	Extractor::ExtractStatus status;
	int progress;
   
    cout << "Enter Box Name: " << endl;
    cin >> name;
    BoxRef box = GetBox(boxbasepath, name);
    if(!box) {
	 cout << "Could not obtain the Box ref"<< endl;		
        return false;
    }
    cout << "Enter zip file path to be extracted: " << endl;
    cin >> docname;

    cout << "Enter Box Name to extact to" << endl;
    cin >> zipFilename;
    extractFilePath =zipFilename;
	
    if(box->ExtractArchive(extractor,docname,extractFilePath) != STATUS_OK) {
        DEBUGL1("Box::ExtractArchive() is failed\n");
        return false;
    }
    if(!extractor)
    {
        DEBUGL1("Box::ExtractArchive() is failed\n");
        return false;
    }
    else
    {
      DEBUGL1("Box::ExtractArchive() Successful ----- Reading status and progress\n");	
		for(int temp = 0; temp<10;temp++)
		{
			if(extractor->GetStatus(status)!= STATUS_OK)
			{
			 	DEBUGL1("extractor::GetStatus() is failed\n");
			       return false;
			}
			if(extractor->GetProgress(progress)!= STATUS_OK)
			{
			 	DEBUGL1("extractor::GetProgress() is failed\n");
			       return false;
			}
				DEBUGL1("test_Extract:: STATUS --- %d  and  PROGRESS ---- %d\n",status,progress);
			sleep(1);
		}
    }	
	return true;
}

bool test_DeleteAll(CString boxbasepath)
{
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    Status st = boxdoc->DeleteAll(boxbasepath);
    if( st != STATUS_OK) {
	 if(st==STATUS_NOTREADY)	
        DEBUGL1("BoxDocument::DeleteAll() failed as document is not ready state\n");	 	
	 else	
        DEBUGL1("BoxDocument::DeleteAll() is failed\n");
	 
        return false;
    }
       DEBUGL1("BoxDocument::DeleteAll() Successful\n");	
	return true;
}

bool test_ClearClipboard()
{
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    if(boxdoc->ClearClipBoard() != STATUS_OK) {
        DEBUGL1("BoxDocument::ClearClipboard() is failed\n");
        return false;
    }
       DEBUGL1("BoxDocument::ClearClipboard() Successful\n");	
	return true;
}
bool test_Archive(CString boxbasepath)
{
	CString name,docname;
	std::vector<CString> doclist;
	Ref<ci::boxdocument::Archiver> archiver = NULL;
	CString zipFilePath = "/storage/box/";
	CString zipFilename;
	CString response;
	
	cout << "Enter Box Name: " << endl;
	cin >> name;
	BoxRef box = GetBox(boxbasepath, name);
	if(!box) 
	{
		cout << "test_Archive::Could not obtain the Box ref"<< endl;		
		return false;
	}

	while(1)
	{
		cout << "test_Archive::Enter document Name to be archived: " << endl;
		cin >> docname;
		doclist.push_back(docname);
		cout << "Do you want to continue and more doument name for Zipping --- Enter 'y' for yes and 'n' for No:" << endl;
		cin >> response;
		if((response.compare("y")==0)||(response.compare("Y")==0)||(response.compare("yes")==0)||(response.compare("YES")==0))
			continue;
		else
			break;
	}

	cout << "Enter zipfile Name" << endl;
	cin >> zipFilename;
	zipFilePath +=zipFilename;
	Status status = box->CreateArchive(archiver,zipFilePath,doclist);
	if(STATUS_OK != status)
	{
		switch(status)
		{
			case ::STATUS_DISK_FULL:
				DEBUGL1("Archive::Archiving failed due to lack of storage space\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_REPOSITORY_FULL);
				break;							
			case STATUS_ARCHIVE_SIZE_ERROR :
				DEBUGL1("Archive::Archiving failed because the archive size is more than 2GB\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_ARCHIVE_SIZE_ERROR);
				break;						
			default:
				DEBUGL1("Archive::Archiving failed\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_FAILED);					
		}
	}					
	int progress = 0;
	ci::boxdocument::Archiver::ArchiveStatus efilingArchiveStatus;
				
	do
	{					
		if(archiver->GetProgress(progress) != STATUS_OK)
		{
			DEBUGL1("Archive::Archiving failed\n");
			return false;
			//throw CeFilingException(status, SC_STATUS_INTERNAL_ERROR);
		}					
		DEBUGL6("Archive::Progress of Archiving = %d\n",progress);
		if(archiver->GetStatus(efilingArchiveStatus) != STATUS_OK)
		{
			DEBUGL1("Archive::Archiving failed\n");
			return false;
			//throw CeFilingException(status, SC_STATUS_INTERNAL_ERROR);
		}					
		switch(efilingArchiveStatus)
		{
				case Archiver::READY : break;
				case Archiver::ARCHIVING : break;
				case Archiver::CREATED	:  break;
			case Archiver::CANCELED : 
				DEBUGL1("Archive::Archiving cancelled\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_FAILED);
				//throw CeFilingException(status, SC_STATUS_ARCHIVE_CANCELED);
				break;
			case Archiver::DELETED :
				DEBUGL1("Archive::Archiving deleted\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_FAILED);
				break;
			case Archiver::DISK_FULL :
				DEBUGL1("Archive::Archiving failed due to lack of storage space\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_REPOSITORY_FULL);
				break;
			case Archiver::ARCHIVE_SIZE_ERROR:
				DEBUGL1("Archive::Execute::Archiving failed\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_ARCHIVE_SIZE_ERROR);
				break;
			default :
				DEBUGL1("Archive::Archiving failed\n");
				return false;
				//throw CeFilingException(status, SC_STATUS_INTERNAL_ERROR);
		}														
	}while(progress != 100 && efilingArchiveStatus != Archiver::CREATED);	
	
    return true;
}

bool test_Archive_Status_and_Progress(CString boxbasepath)
{
	CString name,docname;
	std::vector<CString> doclist;
	Ref<ci::boxdocument::Archiver> archiver = NULL;
	CString zipFilePath = "/storage/box/";
	CString zipFilename;
	CString response;
	Archiver::ArchiveStatus status;
	int progress;
	
	cout << "Enter Box Name: " << endl;
	cin >> name;
	BoxRef box = GetBox(boxbasepath, name);
	if(!box) 
	{
		cout << "Could not obtain the Box ref"<< endl;		
		return false;
	}

	while(1)
	{
		cout << "Enter document Name to be archived: " << endl;
		cin >> docname;
		doclist.push_back(docname);
		cout << "Do you want to continue and more doument name for Zipping --- Enter 'y' for yes and 'n' for No:" << endl;
		cin >> response;
		if((response.compare("y")==0)||(response.compare("Y")==0)||(response.compare("yes")==0)||(response.compare("YES")==0))
			continue;
		else
			break;
	}

	cout << "Enter zipfile Name" << endl;
	cin >> zipFilename;
	zipFilePath +=zipFilename;
	
	if(box->CreateArchive(archiver,zipFilePath,doclist) != STATUS_OK) 
	{
	    DEBUGL1("Box::CreateArchive() is failed\n");
	    return false;
	}		

	if(!archiver)	
	{
	    DEBUGL1("Box::CreateArchive() is failed\n");
	    return false;
	}
	else
	{
	       DEBUGL1("Box::CreateArchive() Successful ----- Reading status and progress\n");	
		for(int temp = 0; temp<10;temp++)
		{
			if(archiver->GetStatus(status)!= STATUS_OK)
			{
			 	DEBUGL1("archiver::GetStatus() is failed\n");
			       return false;
			}
			if(archiver->GetProgress(progress)!= STATUS_OK)
			{
			 	DEBUGL1("archiver::GetProgress() is failed\n");
			       return false;
			}
				DEBUGL1("test_Archive_Status_and_Progress:: STATUS --- %d  and  PROGRESS ---- %d\n",status,progress);
			sleep(1);
		}
	}
	return true;
}

bool test_GetBoxListFunc(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    BoxList boxlist;
    if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
    
    CString boxnumber;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) 
	{
		(*it)->GetNumber(boxnumber);
		DEBUGL6("test_GetBoxListFunc: BOX Number - %s\n", boxnumber.c_str());
		
		DocumentList list; 	  
		if((*it)->GetDocumentList(list)!=STATUS_OK)
			DEBUGL1("GetDocumentList Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: GetDocumentList Success\n");
		
		CString foldername="Fold";
		if((*it)->CreateFolder(foldername)!=STATUS_OK)
			DEBUGL1("CreateFolder Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: CreateFolder Success\n");

		CString docname="Doc";
		if((*it)->CopyDocument(docname)!=STATUS_OK)
			DEBUGL1("CopyDocument Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: CopyDocument Success\n");		

		CString days;
		if((*it)->GetDocumentPreserveDays(days)!=STATUS_OK)
			DEBUGL1("GetDocumentPreserveDays Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: GetDocumentPreserveDays Success - days<%s>\n",days.c_str());		
		
		CString date;
		if((*it)->GetLastModifiedDate(date)!=STATUS_OK)
			DEBUGL1("GetLastModifiedDate Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: GetLastModifiedDate Success - date<%s>\n",date.c_str());		
		
		uint64 size;
		if((*it)->GetSize(size)!=STATUS_OK)
			DEBUGL1("GetSize Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: GetSize Success - size<%llu>\n",size);

		CString name;
		if((*it)->GetName(name)!=STATUS_OK)
			DEBUGL1("GetName Failed\n");
		else  
			DEBUGL6("test_GetBoxListFunc: GetName Success - name<%s>\n",name.c_str());
			
		if((*it)->IsPasswordProtected())
			DEBUGL6("IsPasswordProtected - true\n");
		else  
			DEBUGL6("test_GetBoxListFunc: IsPasswordProtected - false\n");

		DEBUGL6("BoxDocument::Getting/Setting mail box properties\n");	 
		CString boxType;
		if((*it)->GetBoxType(boxType) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument::BoxType - <%s>\n",boxType.c_str());	 
		
		CString userName="hello";
		if((*it)->SetUserName(userName) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		userName="";	
		if((*it)->GetUserName(userName) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument::userName - <%s>\n",userName.c_str());	 
		
		CString comment="notme";	
		if((*it)->SetComment(comment) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		comment="";
		if((*it)->GetComment(comment) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument::comment - <%s>\n",comment.c_str());	 			

		if((*it)->IsLocked())
			DEBUGL6("IsLocked - true\n");
		else  
			DEBUGL6("IsLocked - false\n");
		
		CString creationdate="";
		if((*it)->GetCreationDate(creationdate) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument:: creationdate - (%s)\n", creationdate.c_str());
		
		CString emailId="";
		if((*it)->GetNotificationEmailId(emailId) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument:: email id - (%s)\n", emailId.c_str());

		uint numDoc=0;
		if((*it)->GetDocumentCount(numDoc) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument:: number of document in a box - (%u)\n", numDoc);

		uint numFolder=0;
		if((*it)->GetFolderCount(numFolder) != STATUS_OK) {
		    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
		    return false;
		}
		DEBUGL6("test_GetBoxListFunc: BoxDocument:: number of folder in a box - (%u)\n", numFolder);

    }
    return true;
}

bool test_GetMailBox(CString boxbasepath)
{
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }    
	 
    CString num;
    cout << "Enter Box number : " << endl;
    cin >> num;

    CString phoneNumber;
    cout << "Enter phone number (only for polling boxes else leave it empty by entering n): " << endl;
    cin >> phoneNumber;
    if(phoneNumber=="n")
	 	phoneNumber="";

    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";

    CString access;
    cout << "Select Access Context Type:\n1.LOCAL_READ\n2.LOCAL_WRITE\n3.REMOTE_READ\n4.REMOTE_WRITE\n " << endl;
    cin >> access;
	AccessContext context = LOCAL_READ;
	if(access=="1")
		context=LOCAL_READ;
	else if(access=="2")
		context=LOCAL_WRITE;
	else if(access=="3")
		context=REMOTE_READ;
	else if(access=="4")
		context=REMOTE_WRITE;

    CString adminEnable("");
    cout << "Enter 1.Allow admin password for GetMailBox\n2.Disallow admin password for GetMailBox\n " << endl;
    cin >> adminEnable;
    
    BoxRef box;
    if(adminEnable == "1")
    {
        // get box instance
        if(boxdoc->GetMailBox(box,boxbasepath, num,context,password, phoneNumber) != STATUS_OK) {
            DEBUGL1("BoxDocument::GetMailBox() is failed\n");
            return false;
        }
    }
    else if(adminEnable == "2")
    {
        // get box instance
        Status retStatus = boxdoc->GetMailBox(box,boxbasepath, num,context,password, phoneNumber, false);
        if(retStatus != STATUS_OK)
        {
            DEBUGL1("BoxDocument::GetMailBox() failed\n");
            if(retStatus == STATUS_AUTHENTICATIONFAILS)
                DEBUGL1("BoxDocument::GetMailBox() failed because authentication failed. Passing admin password to print confidential box is disallowed\n"); 
            return false;
        }
    }
    DEBUGL6("BoxDocument::GetMailBox() OK\n");	 

	DEBUGL6("BoxDocument::Getting/Setting mail box properties\n");	 
	CString boxType;
	if(box->GetBoxType(boxType) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	DEBUGL6("BoxDocument::BoxType - <%s>\n",boxType.c_str());	 
	
	CString userName="hello";
	if(box->SetUserName(userName) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	userName="";	
	if(box->GetUserName(userName) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	DEBUGL6("BoxDocument::userName - <%s>\n",userName.c_str());	 
	
	CString comment="notme";	
	if(box->SetComment(comment) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	comment="";
	if(box->GetComment(comment) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	DEBUGL6("BoxDocument::comment - <%s>\n",comment.c_str());	 
  	 password="";
	if(box->GetPassword(password) != STATUS_OK) {
	    DEBUGL1("BoxDocument::GetBoxType() is failed\n");
	    return false;
	}
	DEBUGL6("BoxDocument::password - <%s>\n",password.c_str());
    return box;	 
}

bool test_CreateMailBox(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }
    
    // create box instance
    CString name;
    cout << "Enter Box number : " << endl;
    cin >> name;

    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";
	 
    BoxRef box;
    if(boxdoc->CreateBox(box, boxbasepath, name,password) != STATUS_OK) {
        DEBUGL1("BoxDocument::CreateBox() is failed\n");
        return true;
    }
    DEBUGL6("Box %s is created\n", name.c_str());

    CString value;
    cout << "Enter Box property (Confidential, BulletinBoard, Relay)" << endl;
    cin >> value;
    if(box->SetWebDAVProperty("documentType", value) != STATUS_OK) {
        DEBUGL1("Box::SetWebDAVProperty() is failed\n");
        return false;
    }

    CString phoneNumber;
    cout << "Enter Box property phone number (only for pollingboxes else leave it empty by entering  n) : " << endl;
    cin >> phoneNumber;
    if(phoneNumber != "n")
    {
      if(box->SetWebDAVProperty("phoneNumber", phoneNumber) != STATUS_OK) {
         DEBUGL1("Box::SetWebDAVProperty() is failed\n");
         return false;
      }
   }
   return true;
}

bool test_DeleteMailBox(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }
    
    CString name;
    cout << "Enter Box number : " << endl;
    cin >> name;

    CString password;
    cout << "Enter Box Password : 'n' for empty" << endl;
    cin >> password;
    if(password=="n")
	 	password="";

   CString access;
   cout << "Select Access Context Type:\n1.LOCAL_READ\n2.LOCAL_WRITE\n3.REMOTE_READ\n4.REMOTE_WRITE\n " << endl;
   cin >> access;
	AccessContext context = LOCAL_READ;
	if(access=="1")
		context=LOCAL_READ;
	else if(access=="2")
		context=LOCAL_WRITE;
	else if(access=="3")
		context=REMOTE_READ;
	else if(access=="4")
		context=REMOTE_WRITE;

	 if(boxdoc->DeleteMailBox(boxbasepath,name,context,password)!=STATUS_OK)
    {
     DEBUGL1("BoxDocument::DeleteMailBox is failed\n");
     return false; 
    }   
  return true; 
}

bool test_GetStatus(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    BoxDocStatus st = boxdoc->GetStatus(boxbasepath);
    if(st == INITIALIZING) 
	 	DEBUGL6("BoxDocument::GetStatus() returned INITIALIZING\n");	 
    else if(st == INITIALIZED) 
	 	DEBUGL6("BoxDocument::GetStatus() returned INITIALIZED\n");	 
    else if(st == UNINITIALIZED) 
	 	DEBUGL6("BoxDocument::GetStatus() returned UNINITIALIZED\n");	 
    else if(st == DELETING_ALL) 
	 	DEBUGL6("BoxDocument::GetStatus() returned DELETING_ALL\n");	 
    else
	 {	
	 	DEBUGL1("BoxDocument::GetStatus() Failed\n");	 
		return false;	
	} 
	return true;
}	

bool test_UnlockWoPassword(CString boxbasepath) 
{

    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return true;
    }

    CString boxnumber;
    cout << "Enter Box number : " << endl;
    cin >> boxnumber;
		 
    BoxList boxlist;
    if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }

    CString num;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) 
	{
		(*it)->GetNumber(num);
		DEBUGL6("BOX Number - %s\n", num.c_str());
		if(num==boxnumber)
		{	
			if((*it)->Unlock()!=STATUS_OK)
			{
				DEBUGL1("Unlock failed\n");
				return false;
			}
		}
	}			 		
		return true;	
}

bool test_UnlockAllBoxes(CString boxbasepath) 
{
	 // Acquire an BoxDocument instance
	Ref<BoxDocument> boxdoc = BoxDocument::Acquire();
	if(boxdoc->UnlockAllBoxes() != STATUS_OK)
		DEBUGL1("unlock all boxes failed\n");
	else
		DEBUGL6("unlock of all boxes successful\n");
	return true;
}	
bool test_GetDocumentPropertyList(CString boxbasepath) 
{
 // Acquire an BoxDocument instance
Ref<BoxDocument> boxdoc = BoxDocument::Acquire();

// Get the list of boxes in the box base path
Status status;
BoxList boxlist;
status = boxdoc->GetBoxList(boxlist, boxbasepath);

CString boxnumber;
cout << "Enter Box number : " << endl;
cin >> boxnumber;

// Pick up a box in the list
BoxList::iterator it = find_if(boxlist.begin(), boxlist.end(), BoxFinder(boxnumber));
Ref<Box> box;
if(it != boxlist.end()) {
    box = *it;
} else {
	DEBUGL1("Finding Box failed\n");
	return false;
}

// Get FCODE properties
CString dst, dsttype, cid;
box->GetRelayReportDestination(dst);
box->GetRelayReportDestinationType(dsttype);
box->GetRelayReportContactId(cid);

cout << "Box FCODE properties:" << endl<<"Destination - "<<dst<<endl<<"DestinationType - "<<dsttype<<endl<<"ContactId - "<<cid<<endl;

// Get the list of document properties in the box
DocumentPropertiesList docproplist;
status = box->GetDocumentPropertiesList(docproplist);

CString docname;
cout << "Enter Document Name : " << endl;
cin >> docname;

// Pick up a document in the list
DocumentPropertiesList::iterator dit = find_if(docproplist.begin(), docproplist.end(), DocFinder(docname));
Ref<DocumentProperties> docprop;
if(dit != docproplist.end()) {
    docprop = *dit;
} else {
	DEBUGL1("Finding Doc failed\n");
	return false;
}

CString name, from, reception_time, reception_num, from_string, from_stringfn, from_stringln;
int total_page;
docprop->GetName(name);
docprop->GetTotalPage(total_page);
docprop->GetFromProperty(from);
docprop->GetReceptionTime(reception_time);
docprop->GetReceptionNumber(reception_num);
docprop->GetFromString(from_string);
docprop->GetFromStringFirstName(from_stringfn);
docprop->GetFromStringLastName(from_stringln);

CString faxstatus, pollingTransmission;
docprop->GetStatusOfReceivedData(faxstatus);
cout<<"StatusOfReceivedData = " << faxstatus << endl;

docprop->GetStatusOfHardCopy(faxstatus);
cout<<"StatusOfHardCopy = " << faxstatus << endl;

docprop->GetStatusOfRelayReport(faxstatus);
cout<<"StatusOfRelayReport = " << faxstatus << endl;

docprop->GetStatusOfPollingTransmission(pollingTransmission);
cout<<"statusOfPollingTransmission = "<<pollingTransmission<<endl;

faxstatus = "RECEIVE_DATA";
docprop->SetStatusOfReceivedData(faxstatus);

faxstatus = "HARD_COPY";
docprop->SetStatusOfHardCopy(faxstatus);

faxstatus = "RELAY_REPORT";
docprop->SetStatusOfRelayReport(faxstatus);

pollingTransmission = "Polling_Transmission";
docprop->SetStatusOfPollingTransmission(pollingTransmission);

docprop->GetStatusOfReceivedData(faxstatus);
cout<<"StatusOfReceivedData after updation = " << faxstatus << endl;

docprop->GetStatusOfHardCopy(faxstatus);
cout<<"StatusOfHardCopy after updation  = " << faxstatus << endl;

docprop->GetStatusOfRelayReport(faxstatus);
cout<<"StatusOfRelayReport after updation  = " << faxstatus << endl;

docprop->GetStatusOfPollingTransmission(pollingTransmission);
cout<<"statusOfPollingTransmission after updating = "<<pollingTransmission<<endl;

cout<<"Document properties:" << endl;
cout<<"Name - "<<name<<endl;
cout<<"TotalPage - "<<total_page<<endl;
cout<<"FromProperty - "<<from<<endl;
cout<<"ReceptionTime - "<<reception_time<<endl;
cout<<"ReceptionNumber- "<<reception_num<<endl;
cout<<"fromString - "<<from_string<<endl;
cout<<"fromStringFirstName - "<<from_stringfn<<endl;
cout<<"fromStringLastName - "<<from_stringln<<endl;

return true;	
}	
bool test_Initialize()
{
    // get the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) 
    {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    if((boxdoc->Initialize())!=STATUS_OK)
    {
	DEBUGL1("BoxDocument:: Initialize() failed\n ");
	return false;
    }	
    DEBUGL6("\nInitialize succesfull");
    return true;
}

bool test_Cleanup()
{
    // get the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) 
    {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    if((boxdoc->Cleanup())!=STATUS_OK)
    {
	DEBUGL1("BoxDocument:: Cleanup() failed \n");
	return false;
    }	
    DEBUGL6("Cleanup succesfull\n");
    return true;
}

bool test_BoxExist(CString boxbasepath)
{
    // get the instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) 
    {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

	CString number;
	cout << "Enter box number : ";
	cin >> number;
	
    if((boxdoc->BoxExist(boxbasepath, number))!=true)
    {
	DEBUGL1("BoxDocument:: test_BoxExist() failed \n");
	return false;
    }	
    DEBUGL6("Box exst\n");
    return true;
}

bool test_IsBoxUsed(CString boxbasepath) 
{
	 // Acquire an BoxDocument instance
	Ref<BoxDocument> boxdoc = BoxDocument::Acquire();
	if(boxdoc->isUsed(boxbasepath))
		DEBUGL1("Yes box is used\n");
	else
		DEBUGL2("No box is not used\n");
	return true;
}

bool test_GetMAILBoxList(CString boxbasepath) {
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }

    BoxList boxlist;
   int totalBoxes;
   DEBUGL6("Date before GetBoxList \n");
    if(boxdoc->GetMailBoxList(boxlist, totalBoxes, boxbasepath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
   DEBUGL6("Date before GetBoxList \n");

    CString boxnumber,boxname,comment,username,boxtype,documentID;
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(boxnumber);
   (*it)->GetName(boxname);
   (*it)->GetComment(comment);
   (*it)->GetUserName(username);
   (*it)->GetBoxType(boxtype);
   (*it)->GetWEPDocument(documentID);
        DEBUGL6("BOX Number - %s\n", boxnumber.c_str());
        DEBUGL6("BOX Name - %s\n", boxname.c_str());
        DEBUGL6("Comment - %s\n", comment.c_str());
        DEBUGL6("UserName - %s\n", username.c_str());
        DEBUGL6("Box Type - %s\n", boxtype.c_str());
        DEBUGL6("Document_ID - %s\n", documentID.c_str());
    }
        DEBUGL6("Total number of boxes - %d\n", totalBoxes);

    return true;
}

bool test_accessorsRequirement(CString boxbasepath)
{
   BoxDocumentRef boxdoc = BoxDocument::Acquire();
   if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
   CString boxnumber("");
   RFFileNameFormat filefmt;
   RFDateFormat datefmt;
   RFPageNumberFormat pgfmt;
   RFSubID subid;
   CString comment("");
   if(boxbasepath != "ITUTBoxes")
   {
      BoxList boxlist;
      DEBUGL6("test_accessorsRequirement::Getting the list of Boxes..\n");
      if(boxdoc->GetBoxList(boxlist, boxbasepath) != STATUS_OK) {
         DEBUGL1("BoxDocument::GetBoxList() is failed\n");
         return false;
      }
      DEBUGL6("test_accessorsRequirement::Calling setters for each box and then call getters..\n");
      for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
         (*it)->GetNumber(boxnumber);
         (*it)->SetFileNameFormat((RFFileNameFormat)7);
         (*it)->SetDateFormat((RFDateFormat)6);
         (*it)->SetPageNumberFormat((RFPageNumberFormat)6);
         (*it)->SetSubID((RFSubID)6);
         (*it)->SetRFComment("attachment");
         DEBUGL2("test_accessorsRequirement::Calling getters for Box Number <%s>..\n",boxnumber.c_str());
         (*it)->GetFileNameFormat(filefmt);
         (*it)->GetDateFormat(datefmt);
         (*it)->GetPageNumberFormat(pgfmt);
         (*it)->GetSubID(subid);
         (*it)->GetRFComment(comment);
         DEBUGL8("test_accessorsRequirement::filenameformat = <%d>\n",(int)filefmt);
         DEBUGL8("test_accessorsRequirement::dateformat = <%d>\n",(int)datefmt);
         DEBUGL8("test_accessorsRequirement::pagenumberformat = <%d>\n",(int)pgfmt);
         DEBUGL8("test_accessorsRequirement::subid = <%d>\n",(int)subid);
         DEBUGL8("test_accessorsRequirement::rfcomment = <%s>",comment.c_str());
         boxnumber = comment = "";
         filefmt = (RFFileNameFormat)0;
         datefmt = (RFDateFormat)0;
         pgfmt = (RFPageNumberFormat)0; 
         subid = (RFSubID)0;
      }
   }
   else
   {
      BoxList boxlist;
      int total = 0;
      DEBUGL6("test_accessorsRequirement::Getting the list of Boxes..\n");
      if(boxdoc->GetMailBoxList(boxlist, total, boxbasepath) != STATUS_OK) {
         DEBUGL1("BoxDocument::GetBoxList() is failed\n");
         return false;
      }
      DEBUGL6("test_accessorsRequirement::Calling setters and getters for each box..\n");
      for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
         (*it)->GetNumber(boxnumber);
         (*it)->SetFileNameFormat((RFFileNameFormat)7);
         (*it)->SetDateFormat((RFDateFormat)6);
         (*it)->SetPageNumberFormat((RFPageNumberFormat)6);
         (*it)->SetSubID((RFSubID)6);
         (*it)->SetRFComment("attachment");
         DEBUGL2("test_accessorsRequirement::Calling getters for Box Number <%s>..\n",boxnumber.c_str());
         (*it)->GetFileNameFormat(filefmt);
         (*it)->GetDateFormat(datefmt);
         (*it)->GetPageNumberFormat(pgfmt);
         (*it)->GetSubID(subid);
         (*it)->GetRFComment(comment);
         DEBUGL8("test_accessorsRequirement::filenameformat = <%d>\n",(int)filefmt);
         DEBUGL8("test_accessorsRequirement::dateformat = <%d>\n",(int)datefmt);
         DEBUGL8("test_accessorsRequirement::pagenumberformat = <%d>\n",(int)pgfmt);
         DEBUGL8("test_accessorsRequirement::subid = <%d>\n",(int)subid);
         DEBUGL8("test_accessorsRequirement::rfcomment = <%s>",comment.c_str());
         boxnumber = comment = "";
         filefmt = (RFFileNameFormat)0;
         datefmt = (RFDateFormat)0;
         pgfmt = (RFPageNumberFormat)0;
         subid = (RFSubID)0;
      }
   }
   return true;
}


bool test_boxbase() {
    CString boxbasepath = "EFilingBoxes";
    bool result;
    while(1) {
		int i = 0;
		cout << "Current path is " << boxbasepath <<  endl;
		cout << "1. Create Box" << endl;
		cout << "2. Get Box List" << endl;
		cout << "3. Get Box List with range" << endl;
		cout << "4. Get Box" << endl;
		cout << "5. Delete Box" << endl;		
		cout << "6. Change Base Path" << endl;
		cout << "7. Initilize Box" << endl;	
		cout << "8. Cleanup Box" << endl;	
		cout << "9. Box exit?" << endl;			
		cout << "10. ClipBoard Operations" << endl;
		cout << "11. Create Document" << endl;
		cout << "12. Cut Page - Paste Document" << endl;
		cout << "13. Cut Document - Paste Page " << endl;		  
		cout << "14. SET WEP DOC for Box" << endl;		  
		cout << "15. GetSize for Box" << endl;		  
		cout << "16. Test Archive functionality" << endl;		  
		cout << "17. Test Extract functionality" << endl;		  
		cout << "18. Archive functionality--- to show Status and Progress" << endl;		  		
		cout << "19 GetBoxList and Functions" << endl;
		cout << "20 Clear Clipboard functionality" << endl;	
		cout << "21 Delete All functionality" << endl;
		cout << "22. Get MailBox" << endl;		
		cout << "23. Create MailBox" << endl;				
		cout << "24. Delete MailBox" << endl;				
		cout << "25. GetStatus of BoxDocument" << endl;				
		cout << "26. Unlock Box without password" << endl;				
		cout << "27. Get Document property list" << endl;	
		cout << "28. UnlockAllBoxes" << endl;								
		cout << "29. Is box used" << endl;
		cout << "30. Get BoxList for MIB" << endl;
		cout << "31. Get Mailbox list for MIB" << endl;				
		cout << "32. Get DocumentListToDelete" << endl;				
		cout << "33. Test Accessors" << endl;
		cout << "34. Test View Document List" << endl;
		cout << "35. Test View Document List" << endl;
		cout << "36. Test GetList for AL req" << endl;
      cout << "0. exit" << endl;
		cin >> i;
		result = false;
        switch(i) {
	        case 0: return true;
	        case 1: result = test_CreateBox(boxbasepath); break;
	        case 2: result = test_GetBoxList(boxbasepath); break;
	        case 3: result = test_GetBoxListWithRange(boxbasepath); break;		
	        case 4: result = test_GetBox(boxbasepath); break;
	        case 5: result = test_DeleteBox(boxbasepath); break;
	        case 6: result = test_ChangeBasePath(boxbasepath); break;
	        case 7: result = test_Initialize(); break;		
	        case 8: result = test_Cleanup(); break;				
	        case 9: result = test_BoxExist(boxbasepath); break;				
	        case 10: result = test_ClipboardOpeartions(boxbasepath); break;
	        case 11: result = test_CreateDocument(boxbasepath); break;
	        case 12: result = test_CutPage(boxbasepath); break;
	        case 13: result = test_PastePage(boxbasepath); break;		  
	        case 14: result = test_WEP(boxbasepath); break;		  
	        case 15: result = test_GetSize(boxbasepath); break;		  
	        case 16: result = test_Archive(boxbasepath); break;		
	        case 17: result = test_Extract(boxbasepath); break;
	        case 18: result = test_Archive_Status_and_Progress(boxbasepath); break;		
	        case 19: result = test_GetBoxListFunc(boxbasepath); break;
	        case 20: result = test_ClearClipboard(); break;				
	        case 21: result = test_DeleteAll(boxbasepath); break;				
	        case 22: result = test_GetMailBox(boxbasepath); break;						  
	        case 23: result = test_CreateMailBox(boxbasepath); break;		  
	        case 24: result = test_DeleteMailBox(boxbasepath); break;		  
	        case 25: result = test_GetStatus(boxbasepath); break;		  		  
	        case 26: result = test_UnlockWoPassword(boxbasepath); break;
	        case 27: result = test_GetDocumentPropertyList(boxbasepath); break;
	        case 28: result = test_UnlockAllBoxes(boxbasepath); break;		  
	        case 29: result = test_IsBoxUsed(boxbasepath); break;
	        case 30: result = test_GetMIBBoxList(boxbasepath); break;						
	        case 31: result = test_GetMAILBoxList(boxbasepath); break;						
           case 32: result = test_GetDocumentListToDelete(boxbasepath); break;
           case 33: result = test_accessorsRequirement(boxbasepath); break;
           case 34: result = test_GetViewDocumentList(boxbasepath); break;
           case 35: result = test_GetViewPageList(boxbasepath); break;
           case 36: result = test_GetBoxListforAl(boxbasepath); break;
         }
        cout << "result = " << result << endl;
    }
    return true;
}
