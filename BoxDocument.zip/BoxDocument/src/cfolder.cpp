/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cfolder.cpp
 Revision: com_t#5
 File Spec: EBX:MA6036.A-DEV_SRC;com_t#5
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:44:25

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#5 (APPROVED)
     Created:  09-JAN-2009 21:44:25      CHANDRAMOHAN.PUJARI
       Added code Edit Progress related API's
     Updated:  09-JAN-2009 21:44:25      CHANDRAMOHAN.PUJARI
       Added code Edit Progress related API's
     Updated:  09-JAN-2009 21:44:25      CHANDRAMOHAN.PUJARI
       Added code Edit Progress related API's
     Updated:  09-JAN-2009 21:44:25      CHANDRAMOHAN.PUJARI
       Item revision com_t#5 created from revision com_t#4 with status
       $TO_BE_DEFINED
   
   Revision com_t#4 (APPROVED)
     Updated:  19-DEC-2008 21:33:39      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing and indented
       the code
     Created:  19-DEC-2008 21:33:36      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing and indented
       the code
     Updated:  19-DEC-2008 21:33:36      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing and indented
       the code
     Updated:  19-DEC-2008 21:33:32      CHANDRAMOHAN.PUJARI
       Item revision com_t#4 created from revision com_t#3 with status
       $TO_BE_DEFINED
   
   Revision com_t#3 (APPROVED)
     Created:  08-DEC-2008 21:02:57      CHANDRAMOHAN.PUJARI
       Added Code for BoxUsuage,Error Codes,LastAccessdate and modified
       date
     Updated:  08-DEC-2008 21:02:57      CHANDRAMOHAN.PUJARI
       Added Code for BoxUsuage,Error Codes,LastAccessdate and modified
       date
     Updated:  08-DEC-2008 21:02:57      CHANDRAMOHAN.PUJARI
       Added Code for BoxUsuage,Error Codes,LastAccessdate and modified
       date
     Updated:  08-DEC-2008 21:02:57      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
   
   Revision com_t#2 (APPROVED)
     Created:  17-NOV-2008 22:00:40      CHANDRAMOHAN.PUJARI
       Changed CutDocument-CutPage flag to cutDocument-cutPage and
       Added Implementation for new Interface API s of Folder Class
     Updated:  17-NOV-2008 22:00:40      CHANDRAMOHAN.PUJARI
       Changed CutDocument-CutPage flag to cutDocument-cutPage and
       Added Implementation for new Interface API s of Folder Class
     Updated:  17-NOV-2008 22:00:40      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
     Updated:  17-NOV-2008 22:00:40      CHANDRAMOHAN.PUJARI
       Changed CutDocument-CutPage flag to cutDocument-cutPage and
       Added Implementation for new Interface API s of Folder Class
   
   Revision com_t#1 (APPROVED)
     Created:  03-NOV-2008 19:13:09      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:13:09      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:13:09      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:13:07      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:58      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:34      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:13      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:17      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:39      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:07:49      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:34:10      13848
       Initial revision
========================== End of Source Header =============================*/

#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/DocumentStore/documentstore.h>
#include "CI/OperatingEnvironment/cexception.h"
#include "cboxdocument.h"
#include "proputils.h"
#include "cdocument.h"
#include "cfolder.h"
#include "cpage.h"
#include <iomanip>
#include <sstream>
#include <cerrno>
#include<iostream>

#define MAXLINESIZE 250

//using namespace ci::DocumentStore;
using namespace ci::hierarchicaldb;
using namespace dom;
using namespace std;
namespace ci 
{
    namespace boxdocument 
    {
        typedef std::map<CString, CString> pair;
        //Define the declared static data member
        std::vector<CString> CFolder::m_CutVecofDocs;
        //bool CFolder::m_CutFlag;

        std::vector<CString> CFolder::m_CopyVecofDocs;
		std::vector<CString> CFolder::m_PastedVecofDocs;
        //bool CFolder::m_CopyFlag;

        //bool CFolder::m_PasteFlag;

        CString CFolder::m_DelDoc="";
        //bool CFolder::m_DelDocFlag;
	pthread_mutex_t gfolder_mutex_initializer = PTHREAD_MUTEX_INITIALIZER;

        CFolder::CFolder(CString sessionID, CString boxbasepath, CString boxnumber, CString foldername) : 
            m_BoxBasePath(boxbasepath), 
            m_BoxNumber(boxnumber),
            m_FolderName(foldername),
            m_sessionID(sessionID)
        {
            if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCFolder::CFolder: Failed to increment the count\n ");

            typedef std::map<CString, CString> pair;
            m_WebDAVProperties.insert(pair::value_type("folderName", foldername));
            CString local = Utility::GetUnixTime();    
            m_WebDAVProperties.insert(pair::value_type("creationDate", local));
            m_WebDAVProperties.insert(pair::value_type("lastAccessDate", local));	
            m_WebDAVProperties.insert(pair::value_type("lastModifiedDate", local));
			m_returnpastedocname = "";
        }

        CFolder::~CFolder() 
        {
            // release member variables
            if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCFolder::~CFolder: Failed to decrement the count\n ");
        }

		
        Status CFolder::GetDocument(DocumentRef &doc, CString documentname) 
        {
            return Utility::GetDocument(m_sessionID, doc,m_BoxBasePath,m_BoxNumber,m_FolderName,documentname);
        }

        Status CFolder::GetDocumentList(DocumentList &list) 
        {
            return GetDocumentList(list, 0, 65535);
        }

        Status CFolder::GetDocumentList(DocumentList &list, unsigned int from, unsigned int size) 
        {
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CFolder::::GetDocumentList::Getting collection list is failed");
                return STATUS_FAILED;
            }

            CString documentname,documentPath;
            CString stsfile;
            DocumentRef pDocRef = NULL;
            Status ret;
            std::map<CString, CString>::iterator propIterator;
            std::map<CString, CString> WebDAVpropertyMap;					

            for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
            {
                documentname = vec[i];
                documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname);
                stsfile = documentPath + "/.document";

                WebDAVpropertyMap.insert(pair::value_type("documentName", ""));
                WebDAVpropertyMap.insert(pair::value_type("jobType", ""));
                WebDAVpropertyMap.insert(pair::value_type("mixpaperSize", ""));  // TBD
                WebDAVpropertyMap.insert(pair::value_type("mixresolution", "")); // TBD
                WebDAVpropertyMap.insert(pair::value_type("mixcolorMono", ""));  // TBD
                WebDAVpropertyMap.insert(pair::value_type("totalSize", ""));
                WebDAVpropertyMap.insert(pair::value_type("totalPages", ""));
                WebDAVpropertyMap.insert(pair::value_type("creationDate", ""));
                WebDAVpropertyMap.insert(pair::value_type("lastModifiedDate", ""));			
                WebDAVpropertyMap.insert(pair::value_type("lastAccessDate", ""));	 	 						
                WebDAVpropertyMap.insert(pair::value_type("lastArchiveDate", ""));
                WebDAVpropertyMap.insert(pair::value_type("from", ""));    
                WebDAVpropertyMap.insert(pair::value_type("receptionTime",""));
                WebDAVpropertyMap.insert(pair::value_type("receptionNumber",""));
                WebDAVpropertyMap.insert(pair::value_type("cutDocument",""));

                if(Utility::ResourceExist(stsfile) ==true)
                {
                    DEBUGL8("CFolder::::GetDocumentList:document Name = %s\n",documentname.c_str());
                    //Read the properties from the xml file and update the same to local map of document class.
                    Utility::GetAllProperties(documentPath,"documentproperties.xml",WebDAVpropertyMap);
                    WebDAVpropertyMap["documentName"]=  documentname;
                }
                else
                {
                    DEBUGL8("CFolder::::GetDocumentList:Folder found hence skipping\n");
                    continue;
                }
                // GetDocument
                pDocRef = NULL;
                try 
                {
                    pDocRef = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,m_FolderName,documentname);
                    if(!pDocRef)
                    {
                        DEBUGL1("CFolder::GetDocumentList: doc object is null\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::::GetDocumentList::Loading Box is failed\n");
                        continue;
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CFolder::::GetDocumentList: Caught exception (%s)\n",e.what());
                    pDocRef = NULL;
                    return STATUS_FAILED;
                }
                list.push_back(pDocRef);								
            }
            return STATUS_OK;
        }
        Status CFolder::GetDocumentListToDelete(DocumentList &list) 
        {
           //Now get the list of the documents inside the boxpath and then check the status of the documents.
           std::vector<CString> vec;
           std::vector<CString>::iterator dIt;
           CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
           //Now get the list of files present under the boxbasepath.
           if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
           {
              DEBUGL1("CBoxDocument::DeleteBoxList::Getting collection list is failed");
              return STATUS_FAILED;
           }
           CString documentname,documentPath;
           CString stsfile;
           DocumentRef pDocRef = NULL;
           Status ret;
           std::map<CString, CString>::iterator propIterator;
           std::map<CString, CString> WebDAVpropertyMap;
           typedef std::map<CString, CString> property_pair;
           int from = 0, size = 65535;
           for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
           {
              documentname = vec[i];
              documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname);
              stsfile = documentPath + "/.document";

              WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("mixpaperSize", ""));  // TBD
              WebDAVpropertyMap.insert(property_pair::value_type("mixresolution", "")); // TBD
              WebDAVpropertyMap.insert(property_pair::value_type("mixcolorMono", ""));  // TBD
              WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
              WebDAVpropertyMap.insert(property_pair::value_type("lastAccessDate", ""));	 	 						
              WebDAVpropertyMap.insert(property_pair::value_type("lastArchiveDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("from", ""));    
              WebDAVpropertyMap.insert(property_pair::value_type("receptionTime",""));
              WebDAVpropertyMap.insert(property_pair::value_type("receptionNumber",""));
              WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));

              if(Utility::ResourceExist(stsfile) ==true)
              {
                 DEBUGL8("CBox::GetDocumentList:document Name = %s\n",documentname.c_str());
                 //Read the properties from the xml file and update the same to local map of document class.
                 Utility::GetAllProperties(documentPath,"documentproperties.xml",WebDAVpropertyMap);
                 WebDAVpropertyMap["documentName"]=  documentname;
              }
              else
              {
                 DEBUGL8("CBox::GetDocumentList:Folder found hence skipping\n");
                 continue;
              }
              // GetDocument
              pDocRef = NULL;
              try 
              {
                 pDocRef = new CViewDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,m_FolderName,documentname);
                 if(!pDocRef)
                 {
                    DEBUGL8("CBox::GetDocumentList: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 ret = dynamic_cast<CViewDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CBox::GetDocumentList::Loading Box is failed\n");
                    continue;
                 }
              }  
              catch(exception &e)
              {
                 DEBUGL1("CFolder::::GetDocumentList: Caught exception (%s)\n",e.what());
                 pDocRef = NULL;
                 return STATUS_FAILED;
              }
              list.push_back(pDocRef);								
           }
           return STATUS_OK;
        }
        Status CFolder::GetViewDocumentList(DocumentList &list) 
        {
            return GetViewDocumentList(list, 0, 65535);
        }

        Status CFolder::GetViewDocumentList(DocumentList &list,unsigned int from, unsigned int size) 
        {
           DEBUGL4("CFolder::GetViewDocumentList: Enter\n");
           //Now get the list of the documents inside the boxpath and then check the status of the documents.
           std::vector<CString> vec;
           std::vector<CString>::iterator dIt;
           CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
           //Now get the list of files present under the boxbasepath.
           if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
           {
              DEBUGL1("CFolder::GetViewDocumentList::Getting collection list is failed");
              return STATUS_FAILED;
           }
           CString documentname,documentPath;
           CString stsfile;
           DocumentRef pDocRef = NULL;
           Status ret;
           std::map<CString, CString>::iterator propIterator;
           std::map<CString, CString> WebDAVpropertyMap;
           typedef std::map<CString, CString> property_pair;
           //int from = 0, size = 65535;
		   CString stringArray[9] = {"documentName", "jobType", "totalSize", "totalPages", "creationDate", 
										"lastModifiedDate", "cutDocument", "jobTypeColorMap", "paperSizeMap"};
           for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
           {
              documentname = vec[i];
              documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname);
              stsfile = documentPath + "/.document";

              WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
              WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobTypeColorMap","")); 
              WebDAVpropertyMap.insert(property_pair::value_type("paperSizeMap",""));

              if(Utility::ResourceExist(stsfile) ==true)
              {
                 DEBUGL8("CFolder::GetViewDocumentList:document Name = %s\n",documentname.c_str());
                 //Read the properties from the xml file and update the same to local map of document class.
                 Utility::GetPropertyMaps(documentPath,"documentproperties.xml",WebDAVpropertyMap,stringArray, 9);
                 WebDAVpropertyMap["documentName"]=  documentname;
              }
              else
              {
                 DEBUGL8("CFolder::GetViewDocumentList:Folder found hence skipping\n");
                 continue;
              }
              // GetDocument
              pDocRef = NULL;
              try 
              {
                 pDocRef = new CViewDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,m_FolderName,documentname);
                 if(!pDocRef)
                 {
                    DEBUGL8("CFolder::GetViewDocumentList: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 ret = dynamic_cast<CViewDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CFolder::GetViewDocumentList::Loading Box is failed\n");
                    continue;
                 }
              }  
              catch(exception &e)
              {
                 DEBUGL1("CFolder::GetViewDocumentList: Caught exception (%s)\n",e.what());
                 pDocRef = NULL;
                 return STATUS_FAILED;
              }
              list.push_back(pDocRef);								
           }
           DEBUGL4("CFolder::GetViewDocumentList: Exit\n");			
           return STATUS_OK;
        }

        Status CFolder::CreateFolder(CString foldername) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::CreateFolder(FolderRef& folder, CString foldername) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::GetFolder(FolderRef& folder, CString foldername) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::GetFolderList(FolderList &list) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::GetFolderList(FolderList &list,unsigned int from, unsigned int size) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::DeleteFolder(CString foldername) 
        {
            return STATUS_FAILED;
        }

        Status CFolder::SetWebDAVProperty(CString key, CString value) 
        {
            std::map<CString, CString> PropertyMap;
            CString xmlfile("folderproperties.xml");
            CString modifiedtime = Utility::GetUnixTime();
            m_WebDAVProperties[key] = value;
            PropertyMap.insert(pair::value_type(key.c_str(), value.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));	
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            return st;
        }

        Status CFolder::GetWebDAVProperty(CString key, CString &value) 
        {
            value = m_WebDAVProperties[key];
            return STATUS_OK;
        }

        Status CFolder::SetName(CString name) 
        {
            if(Utility::ResourceExist( m_BoxBasePath, m_BoxNumber, name)) 
            {
                DEBUGL1("CFolder::SetName:: %s is already used\n", name.c_str());
                return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
            }

            std::map<CString, CString> PropertyMap;
            CString xmlfile("folderproperties.xml");
            CString modifiedtime = Utility::GetUnixTime();

            PropertyMap.insert(pair::value_type("folderName", name));
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));	
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
            CString newpath = m_BoxBasePath+ "/" + m_BoxNumber + "/" + name;
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            if(ci::operatingenvironment::Folder::MoveDir(path, newpath)!=STATUS_OK)
                return STATUS_FAILED;

            m_FolderName = name;
            return st;
        }

        Status CFolder::GetName(CString &name) 
        {
            name = m_FolderName;
            return STATUS_OK;
        }

       	Status CFolder::CutDocument(CString docname) 
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CutDocument(documents));
        }

        Status CFolder::CutDocument(std::vector<CString> documents) 
        {
            DEBUGL4("CFolder::CutDocument: Enter\n");
            std::vector<CString>::iterator iter;
            std::vector<CString> vec;
            std::map<CString, CString> PropertyMap;
            CString xmlfile("documentproperties.xml");
            Status rst;
            Status sdf;
            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CFolder::CutDocument::Getting collection list failed");
                return STATUS_FAILED;
            }

            //Delete Clipboard documents,if any
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

				DEBUGL8("CFolder::CutDocument: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());
                //Check if the clipborad document is of the same user
                CString sid;		
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
                {
                    DEBUGL1("CFolder::CutDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }		
                DEBUGL8("CFolder::CutDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());
                if(sid!=m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CFolder::DeleteFolder::Deleting %s Document Failed\n",resourceKey.c_str());
                    return STATUS_FAILED;
                }
            }

            //Refresh all the documents in the Folder
            DocumentList docList;
            DocumentList::iterator doc;	
            if(GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CFolder::CutDocument::Getting document list is failed\n");
                return STATUS_FAILED;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {
                    CString docName;
                    (*doc)->GetName(docName);
                    if(UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CFolder::CutDocument:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        return STATUS_FAILED;			
                    }
                }
            }

            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CFolder::CutDocument:Document <%s>\n",(*iter).c_str());		
                if(((*iter).empty()))
                {
                    DEBUGL1("CFolder::CutDocument: Document name empty\n");
                    return STATUS_FAILED;
                }			

                //Obtain the document
                DocumentRef doc;
                GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CFolder::CutDocument: Given Document name does not exist\n");
                    return STATUS_RESOURCENOTFOUND;
                }

                notEditDocuments.push_back(*iter);
                //Original doc path 
                CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,(*iter)) + "/";

                // check current status
                DocStatus st;
                doc->GetStatus(st);
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CFolder::CutDocument: Document is being used by another user<status: %d>\n", st);
                    return STATUS_USER_USING;
                }
                if(st != READY) 
                {
                    DEBUGL1("CFolder::CopyDocument: Document is NOT in READY/EDITING state\n");
                    if(UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CopyDocument:UndoEditDocument for Failed\n");
                        return STATUS_FAILED;			
                    }
                    return STATUS_USER_EDITING;
                }

                //Check for the user
                CString orgUserID;
                if(Utility::GetProperty(from,"documentproperties.xml","sessionID",orgUserID)!=STATUS_OK)		
                {
                    DEBUGL1("CFolder::CutDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }
                if((!(orgUserID.empty()))&&(m_sessionID != orgUserID))
                {
                    DEBUGL1("CFolder::CutDocument: Document being used by other user\n");
                    return STATUS_FAILED;
                }

		PropertyMap.clear();
                if(orgUserID.empty())
                {
                    //update the sessionID 
                    PropertyMap.insert(pair::value_type("sessionID",m_sessionID.c_str()));
                 }
                
                
                    //update the sessionID and cutDocument flag 
                    PropertyMap.insert(pair::value_type("cutDocument","true"));
                    sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)	
                    {	
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::CutDocument:SetProperty for SessionID failed because Disk is Full\n");
                            return  STATUS_DISK_FULL;
                        }
                        DEBUGL1("CFolder::CutDocument:SetProperty for SessionID Failed\n");
                        return STATUS_FAILED;
                    }	
                

                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CFolder::CutDocument: GetProperty of WorkspaceDocName failed\n");
                    return STATUS_FAILED;
                }

                //Clipboard doc path
                Status rst;
                //CString newDocName=m_sessionID+"_"+m_BoxNumber+"_"+(*iter);
                //CString to = CLIPBOARD_PATH + newDocName + "/";
                CString newDocName = m_sessionID + "_" + WorkspaceDocName;
				ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> ClipboardpathPtr = NULL;
				CString to =CLIPBOARD_PATH + newDocName;
	            Status ds= ci::operatingenvironment::Folder::CreateFolder(ClipboardpathPtr,to.c_str());
				if(!ClipboardpathPtr)
				{
					DEBUGL1("CFolder::CreateFolder::ClipboardpathPtr is NULL\n");	
				}
				if(ds != STATUS_OK)
				{
					rst = Utility::RemoveResource(to);
					if(rst != STATUS_OK)
						DEBUGL2("CFolder::CreateFolder: Failed to remove half created folder\n");

					DEBUGL1("CFolder::CreateFolder::Creation of %s Failed\n", to.c_str());
					return ds;	
				}
				to = to + "/";
				CString fromdocxml = from + "/documentproperties.xml";
				CString fromdocdom = from + "/documentproperties_dom";
				Status retsts = ci::operatingenvironment::File::CopyFile(fromdocxml,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CFolder::CutDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CFolder::CutDocument: Failed to remove half created folder\n");			

                    return retsts;
                }
		retsts = ci::operatingenvironment::File::CopyFile(fromdocdom,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CFolder::CutDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CFolder::CutDocument: Failed to remove half created folder\n");			

                    return retsts;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                PropertyMap.clear();
                CString docxmlfile("documentproperties.xml");
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName.c_str()));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                sdf = Utility::SetProperties(to,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	   
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CFolder::CutDocument: Failed to remove half created folder\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::CutDocument:SetProperty for SessionID failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::CutDocument:SetProperty for SessionID Failed\n");

                    return STATUS_FAILED;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();
                try 
                {
                    PageRef page;					
                    if(doc->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::CutDocument: Getting page %d failed\n", strpageno.c_str());
                        rst = Utility::RemoveResource(resourceKey);

                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::CutDocument: Failed to remove half created folder\n");			

                        return STATUS_FAILED;
                    }	

                    if(!page)
                    {
                        DEBUGL1("CFolder::CutDocument: page object is null\n");
                        return STATUS_FAILED;
                    }
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                    CString pagePath=from+"Image/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));			
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);		
                    pagePath=from+"Subsampling/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                    pagePath=from+"Thumbnail/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CFolder::CutDocument: exception caught (%s)\n", e.what());
                    return STATUS_FAILED;
                }
                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CFolder::CutDocument: Failed to remove half created folder\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::CutDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::CutDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent Failed\n");

                    return STATUS_FAILED;
                }	

            }

            DEBUGL4("CFolder::CutDocument:Exit\n");
            return STATUS_OK;
        }


        Status CFolder::CopyDocument(CString docname) 
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CopyDocument(documents));
        }

        Status CFolder::CopyDocument(std::vector<CString> documents) 
        {

            DEBUGL4("CFolder::CopyDocument: Enter\n");
            std::vector<CString>::iterator iter;
            std::vector<CString> vec;
            CString xmlfile("documentproperties.xml");
            Status rst;
            Status sdf;
            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CFolder::CopyDocument: Getting collection list failed");
                return STATUS_FAILED;
            }

            //Delete Clipboard documents,if any
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

		DEBUGL8("CFolder::CopyDocument: vector<%s>, fullDocName<%s> \n",vec[i].c_str(),fulldocumentname.c_str());
                //Check if the clipborad document is of the same user
                CString sid;		
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
                {
                    DEBUGL1("CFolder::CopyDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }		
                DEBUGL8("CFolder::CopyDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());
                if(sid!=m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CFolder::CopyDocument::Deleting %s Document Failed\n",resourceKey.c_str());
                    return STATUS_FAILED;
                }
            }


            //Refresh all the documents in the Folder
            DocumentList docList;
            DocumentList::iterator doc;	
            if(GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CFolder::CopyDocument::Getting document list is failed\n");
                return STATUS_FAILED;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                //To fix FR_5285, added check to verify if the document is in editing then should not
                //reset session id and cutdocument flag. 
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {	
                    CString docName;
                    (*doc)->GetName(docName);
                    if(UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CFolder::CopyDocument:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        return STATUS_FAILED;
                    }
                }
            }

            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CFolder::CopyDocument:Document <%s>\n",(*iter).c_str());		
                if(((*iter).empty()))
                {
                    DEBUGL1("CFolder::CopyDocument: Document name empty");
                    return STATUS_FAILED;
                }			

                //Obtain the original document
                DocumentRef doc;
                GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CFolder::CopyDocument: Given Document name does not exist\n");
                    return STATUS_RESOURCENOTFOUND;
                }			

                notEditDocuments.push_back(*iter);


                // check current status
                DocStatus st;
                doc->GetStatus(st);
                //if(!(st== READY || st==USING || st==EDITING)) 
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CBox::CopyDocument: document is being used <%d>. return STATUS_USER_USING\n", st);
                    return STATUS_USER_USING;
                }
                if(!(st== READY || st==EDITING)) 			
                {
                    DEBUGL1("CFolder::CopyDocument: Document is NOT in READY/EDITING state\n");
                    if(UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CopyDocument:UndoEditDocument for Failed\n");
                        return STATUS_FAILED;			
                    }

                    return STATUS_FAILED;
                }
                if(st == EDITING)
                {
                    DEBUGL1("CFolder::CopyDocument: document is in editing state\n");
                    return STATUS_USER_EDITING;
                }
                //Original doc path 
                CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,(*iter)) + "/";

                //Set the session-ID on the orignal document
                std::map<CString,CString> PropertyMap;
                PropertyMap.clear();
                //update the sessionID and cutDocument flag 
                PropertyMap.insert(pair::value_type("sessionID",m_sessionID.c_str()));
                PropertyMap.insert(pair::value_type("cutDocument","false"));
                sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::CopyDocument:SetProperty for SessionID failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::CopyDocument:SetProperty for SessionID Failed\n");
                    return STATUS_FAILED;
                }			

                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CFolder::CopyDocument: GetProperty of WorkspaceDocName failed\n");
                    return STATUS_FAILED;
                }

                //Clipboard doc path
                //CString newDocName=m_sessionID+"_"+m_BoxNumber+"_"+m_FolderName+"_"+(*iter)+"/";
                //CString to =CLIPBOARD_PATH + newDocName;
                CString newDocName = m_sessionID + "_" + WorkspaceDocName;
                CString to =CLIPBOARD_PATH + newDocName;
                Status retsts = ci::operatingenvironment::Folder::CopyDir(from,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CFolder::CopyDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CFolder::CopyDocument: Failed to remove half created folder\n");			

                    return retsts;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                CString docxmlfile("documentproperties.xml");
                PropertyMap.clear();
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",m_FolderName));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                sdf = Utility::SetProperties(to,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL2("CFolder::CopyDocument: Failed to remove half created folder\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::CopyDocument:SetProperty for SessionID failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::CopyDocument:SetProperty for SessionID Failed\n");

                    return STATUS_FAILED;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();
                try 
                {
                    PageRef page;					
                    if(doc->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::CopyDocument: Getting page %d failed\n", strpageno.c_str());
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::CopyDocument: Failed to remove half created folder\n");			
                        return STATUS_FAILED;
                    }	

                    if(!page)
                    {
                        DEBUGL1("CFolder::CopyDocument: page object is null\n");
                        return STATUS_FAILED;
                    }
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                    CString pagePath=from+"Image/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));			
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);		
                    pagePath=from+"Subsampling/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                    pagePath=from+"Thumbnail/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CFolder::CopyDocument: exception caught (%s)\n", e.what());
                    return STATUS_FAILED;
                }
                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL2("CFolder::CopyDocument: Failed to remove half created folder\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::CopyDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::CopyDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent Failed\n");

                    return STATUS_FAILED;
                }	

            }

            DEBUGL4("CFolder::CopyDocument: Exit\n");	
            return STATUS_OK;
        }

		Status CFolder::PasteDocument() 
		{
			DEBUGL4("CFolder::PasteDocument: Enter\n");
			std::vector<CString> vec;
			Status sdf;
			CString xmlfile("documentproperties.xml");
			int err =pthread_mutex_lock(&gfolder_mutex_initializer);
			if (err != 0)
				DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
	   		m_PastedVecofDocs.clear();
			err =pthread_mutex_unlock(&gfolder_mutex_initializer);
			if (err != 0)
				DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
			//Get the List of Documents in Clipboard
			if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
			{
				DEBUGL1("CFolder::PasteDocument: Getting collection list failed");
				return STATUS_FAILED;
			}

			for(unsigned int i = 0;i < vec.size(); i++) 
			{
				//Get the document name
				CString fulldocumentname = vec[i];		
				CString documentname;		
				CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
				if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					return STATUS_FAILED;
				}				
				DEBUGL8("CFolder::PasteDocument: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

				//Check for limit
				unsigned int  count=0;
				Utility::GetDocumentCount(m_BoxBasePath, m_BoxNumber,m_FolderName,count);
				 
	     			//check limit for pagelogbox = PAGELOGBOX_DOC_LIMIT ; other boxes limit = DOC_LIMIT
	     	                if((m_BoxBasePath != "/storage/box/PageLogBoxes" && count >= CBoxDocument::DOC_LIMIT) || (count >= CBoxDocument::PAGELOGBOX_DOC_LIMIT) )
				{
					DEBUGL1("CFolder::PasteDocument: The number of documents reach limit\n");
					std::vector<CString> vecDoc;
					vecDoc.clear();

					//Get the List of Documents in Clipboard
					if(Utility::GetCollectionList(vecDoc,CLIPBOARD_PATH)!=STATUS_OK) 
					{
						DEBUGL1("CFolder::PasteDocument: Getting collection list failed");
						return STATUS_FAILED;
					}

					for(unsigned int i = 0;i < vecDoc.size(); i++) 
					{
						//Get the document name
						CString fulldocumentname = vecDoc[i];		
						CString documentname;		
						CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
							return STATUS_FAILED;
						}				
						DEBUGL8("CFolder::PasteDocument: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  
						CString from = CLIPBOARD_PATH + fulldocumentname+"/";
						CString path=Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName)+"/";
						CString newpath = path + documentname + "/";
						//Read the properties of the original box and see if the document is cut from the same box
						CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
						if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
							return STATUS_FAILED;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
							return STATUS_FAILED;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
							return STATUS_FAILED;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
							return STATUS_FAILED;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
							return STATUS_FAILED;
						}


						CString orgPath;
						if(srcFolderName.empty())
							orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
						else
							orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

						DEBUGL8("CFolder::PasteDocument: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
						//Reset the properties on the Original document			
						std::map<CString,CString> PropertyMap;

						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						//PropertyMap.insert(pair::value_type("sessionID",""));
						PropertyMap.insert(pair::value_type("cutDocument",""));
						sdf = Utility::SetProperties(orgPath,xmlfile,PropertyMap);
						if(sdf != STATUS_OK)	
						{	
							Status rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");
							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

								return STATUS_DISK_FULL;
							}
							DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID Failed\n");

							return STATUS_FAILED;
						}					
					}		
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}

				//Check if the clipbaord document is of the same user
				CString sid;
				if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					return STATUS_FAILED;
				}				

				DEBUGL8("CFolder::PasteDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());

				if(sid!=m_sessionID)
				{
					DEBUGL2("CFolder::PasteDocument:Session ID's are different hence continuing\n");
					continue;
				}

				CString from = CLIPBOARD_PATH + fulldocumentname+"/";
				CString path=Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName)+"/";
				CString newpath = path + documentname + "/";
				//Read the properties of the original box and see if the document is cut from the same box
				CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
				if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
				{
					DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
					return STATUS_FAILED;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
				{
					DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
					return STATUS_FAILED;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
				{
					DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
					return STATUS_FAILED;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
				{
					DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
					return STATUS_FAILED;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
				{
					DEBUGL1("CFolder::PasteDocument: Getproperty failded\n");			
					return STATUS_FAILED;
				}


				CString orgPath;
				if(srcFolderName.empty())
					orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
				else
					orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

				DEBUGL8("CFolder::PasteDocument: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
				DEBUGL8("CFolder::PasteDocument: cutDocumentFlag = (%s)\n",cutDocumentFlag.c_str());
				bool bSamePath = false;

				CString truncdocname = "";
				Status ret;
				//In case of cut document and paste in different box
				//check if same resource exist and if exist increment document name
				CString NewWorkspaceDocName("");
				if(orgPath.compare(newpath) && (cutDocumentFlag == "true"))
				{
					if(documentname.length()>64)
					{
						DEBUGL8("CFolder::PasteDocument:calling TruncateDocumentName during CUT operation as document name is more than 64 characters\n");
						ret = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
						if(ret != STATUS_OK )
							DEBUGL1("CFolder::PasteDocument:TruncateDocumentName has not returned STATUS_OK\n");
						documentname = truncdocname;
						newpath = path + documentname;
					}		

					if(Utility::ResourceExist(newpath))
					{
						DEBUGL8("CFolder::PasteDocument:Document with the same document name is already existing\n");
						ret = Utility::LimitTo64Characters(documentname,newpath,path);
						if(ret != STATUS_OK)
							DEBUGL1("CFolder::PasteDocument:LimitTo64Characters has not returned STATUS_OK\n");
					}
					if(m_returnpastedocname)
					{
						err =pthread_mutex_lock(&gfolder_mutex_initializer);
						if (err != 0)
							DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
						m_PastedVecofDocs.push_back(documentname.c_str());
						err =pthread_mutex_unlock(&gfolder_mutex_initializer);
						if (err != 0)
							DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
					}
				}
				//In case of copy operation, if same document exist increment document name
				else if(cutDocumentFlag == "false" || cutDocumentFlag == "")
				{
					DEBUGL8("CFolder::PasteDocument: Its a copy operation\n");
					if(documentname.length()>64)
					{
						DEBUGL8("CFolder::PasteDocument:calling TruncateDocumentName when COPY operation is done\n");
						ret = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
						 if(ret != STATUS_OK )
                            DEBUGL1("CFolder::PasteDocument:TruncateDocumentName has not returned STATUS_OK\n");
						documentname = truncdocname;
						newpath = path + documentname;
					}

					if(Utility::ResourceExist(newpath))
					{
						DEBUGL8("CFolder::PasteDocument:Document with the same document name is already existing\n");
						ret = Utility::LimitTo64Characters(documentname,newpath,path);
						if(ret != STATUS_OK)
                            DEBUGL1("CFolder::PasteDocument:LimitTo64Characters has not returned STATUS_OK\n");
					}
					NewWorkspaceDocName = CUUID().toString();
					if(m_returnpastedocname)
					{
						err =pthread_mutex_lock(&gfolder_mutex_initializer);
						if (err != 0)
							DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
						m_PastedVecofDocs.push_back(documentname.c_str());
						err =pthread_mutex_unlock(&gfolder_mutex_initializer);
						if (err != 0)
							DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");

					}
				}

				Status retStatus;
				Status rst;
				//In case of cut operation and boxbasepaht are same
				//remove the original document and paste the updated document
				if(cutDocumentFlag == "true")
				{
					CString to = newpath;
					if(!orgPath.compare(newpath) )
					{
						bSamePath = true;
					}
					CString pasteboxpath,pasteboxnumber,pasteboxfolder,pasteboxdocument;
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxBasePath",pasteboxpath)!=STATUS_OK)		
					{
						DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
						return STATUS_FAILED;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxNumber",pasteboxnumber)!=STATUS_OK)		
					{
						DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
						return STATUS_FAILED;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcFolderName",pasteboxfolder)!=STATUS_OK)		
					{
						DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
						return STATUS_FAILED;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcDocumentName",pasteboxdocument)!=STATUS_OK)		
					{
						DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
						return STATUS_FAILED;
					}					
					CString orgDocumentPath = Utility::GetResourcePath(pasteboxpath,pasteboxnumber,pasteboxfolder,pasteboxdocument) + "/";		

					DEBUGL8("CFolder::PasteDocument:pasteboxpath (%s) pasteboxnumber (%s) pastefoldername (%s) to (%s)\n",pasteboxpath.c_str(), pasteboxnumber.c_str(),pasteboxfolder.c_str(),to.c_str()); 

					DEBUGL8("CFolder::PasteDocument:orgDocumentPath (%s)\n",orgDocumentPath.c_str()); 
					if(bSamePath == false){
						retStatus = ci::operatingenvironment::Folder::CopyDir(orgDocumentPath,to);
						if(retStatus !=STATUS_OK)
						{
							rst = Utility::RemoveResource(to);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return retStatus;
						}
					}	
					Status retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties.xml",to);
					if (retsts !=STATUS_OK)	
					{
						Status rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

						DEBUGL1("CFolder::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						return retsts;
					}
					retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties_dom",to);
					if (retsts !=STATUS_OK)	
					{
						Status rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

						DEBUGL1("CFolder::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						return retsts;
					}

					if(bSamePath)
					{
						if(m_returnpastedocname)
						{
							err =pthread_mutex_lock(&gfolder_mutex_initializer);
							if (err != 0)
								DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
							m_PastedVecofDocs.push_back(documentname.c_str());
							err =pthread_mutex_unlock(&gfolder_mutex_initializer);
							if (err != 0)
								DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
						}
					}

				}
				//In case of copy operation copy the dir to original document
				else
				{
					CString to = newpath;
					retStatus = ci::operatingenvironment::Folder::CopyDir(from,to);
					if(retStatus !=STATUS_OK)
					{
						rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");
						DEBUGL1("CFolder::PasteDocument: Copying document to ClipBoard failed\n");
						return retStatus;				

					}

					NewWorkspaceDocName = CUUID().toString();
				}

				//Original Document Path
				CString orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName;
				resourceKey = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname) + "/";		
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname,"","srcBoxBasePath",orgBoxBasePath)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

					return STATUS_FAILED;
				}				
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname,"","srcBoxNumber",orgBoxNumber)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

					return STATUS_FAILED;
				}				
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname,"","srcFolderName",orgFolderName)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

					return STATUS_FAILED;
				}				
				if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname,"","srcDocumentName",orgDocumentName)!=STATUS_OK)		
				{
					DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

					return STATUS_FAILED;
				}				

				//Obtain the Clipboard document
				DocumentRef clipDoc;
				CString clipPath = CLIPBOARD_PATH;
				if(Utility::GetDocument(m_sessionID, clipDoc,clipPath,"","",fulldocumentname)==STATUS_OK)
				{
					try
					{
						//Getting document properties from original document
						DEBUGL8("CFolder::PasteDocument:Getting Properties\n");		
						std::map<CString,CString> webDAVProperties;
						if(!clipDoc)
						{
							DEBUGL1("CFolder::PasteDocument: doc object is null\n");
							return STATUS_FAILED;
						}
						Status ret = dynamic_cast<CDocument*>(clipDoc.operator->())->GetProperties(webDAVProperties);
						if(ret != STATUS_OK) 
						{
							DEBUGL1("CFolder::PasteDocument:GetProperties of OrgDoc failed\n");
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return ret;
						}		
						std::map<CString,CString>::iterator mapIter;
						for(mapIter=webDAVProperties.begin();mapIter!=webDAVProperties.end();mapIter++)
						{
							DEBUGL8("CFolder::PasteDocument: Key<%s> and Value<%s>\n",(mapIter->first).c_str(),(mapIter->second).c_str());
						}

						//Setting document properties on current document
						DocumentRef curDoc;		
						curDoc = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,m_FolderName, documentname);

						if(!curDoc)
						{
							DEBUGL1("CFolder::PasteDocument: doc object is null\n");
							return STATUS_FAILED;
						}
						//To fix STFR_11907
						//Not required anymore because the aim is to write the attributes
						//of the copied document to the documentproperties.xml of the pasted
						//document
						//Set WorkspaceDocName property
						CString key = "WorkspaceDocName";
						if(cutDocumentFlag != "true")
							webDAVProperties[key] = NewWorkspaceDocName;
						//Re-setting the cut flag  
						webDAVProperties["cutDocument"] = "";                 

						//Setting the new document name
						webDAVProperties["documentName"] = documentname;

						//Setting the creation date and the modified date
						CString creatTime = Utility::GetUnixTime();
						webDAVProperties["creationDate"] = creatTime;
						webDAVProperties["lastModifiedDate"] = creatTime;

						//Write the attributes of the copied/cut document to the paste document
						ret = dynamic_cast<CDocument*>(curDoc.operator->())->SetProperties(webDAVProperties);
						if(ret != STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument:SetProperties of CurDoc failed\n");
							curDoc = NULL; // release
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return ret;
						}

						//Check for the CutDocument property and delete the original document
						DocumentRef orgDoc;
						if(Utility::GetDocument(m_sessionID, orgDoc,orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)!=STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument: Obtaining Original Document failed\n");
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return STATUS_FAILED;
						}

						CString flag;
						CString dpath =Utility::GetResourcePath(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)+"/";
						std::map<CString,CString> PropertyMap;
						if(proputils::GetProperty(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName,"","cutDocument",flag)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::PasteDocument:GetProperty Failed\n");
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return STATUS_FAILED;
						}

						if(flag=="true")
						{	
							if(!orgDoc)
							{
								DEBUGL1("CFolder::PasteDocument: doc object is null\n");
								return STATUS_FAILED;
							}
							// Start to Delete
							if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
							{
								DEBUGL1("CFolder::PasteDocument: Deleting document failed\n");
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

								return STATUS_FAILED;
							}
						}	
						else
						{
							//Reset the properties on the Original document			
							PropertyMap.clear();
							//update the sessionID and cutDocument flag 
							PropertyMap.insert(pair::value_type("sessionID",""));
							PropertyMap.insert(pair::value_type("cutDocument",""));
							sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap);
							if(sdf != STATUS_OK)	
							{	
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");
								if(sdf == STATUS_DISK_FULL)
								{
									DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

									return STATUS_DISK_FULL;
								}
								DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID Failed\n");

								return STATUS_FAILED;
							}					
						}

						if(flag=="true")
						{	
							//Clear the ClipBoard
							if((ci::operatingenvironment::Folder::Remove(from,true) != STATUS_OK))
							{
								DEBUGL1("CFolder::CopyDocument::Deleting %s Document Failed\n",from.c_str());
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

								return STATUS_FAILED;
							}
						}

						//Remove the properties
						path= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname)+"/";
						//Reset the properties on the Original document
						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						PropertyMap.insert(pair::value_type("sessionID",""));
						PropertyMap.insert(pair::value_type("cutDocument",""));
						sdf = Utility::SetProperties(path,xmlfile,PropertyMap);
						if(sdf!=STATUS_OK)	
						{	
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");
							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

								return STATUS_DISK_FULL;
							}
							DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID Failed\n");

							return STATUS_FAILED;
						}

						//Remove the properties
						path= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname)+"/";

						//Reset the properties on the Original document
						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						PropertyMap.insert(pair::value_type("sessionID",""));
						PropertyMap.insert(pair::value_type("cutDocument",""));
              					PropertyMap.insert(pair::value_type("srcFolderName",""));
						PropertyMap.insert(pair::value_type("srcBoxNumber",""));
						PropertyMap.insert(pair::value_type("srcBoxBasePath",""));
						PropertyMap.insert(pair::value_type("srcDocumentName",""));
						PropertyMap.insert(pair::value_type("IsImagedataPresent",""));
						PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent",""));
						PropertyMap.insert(pair::value_type("IsThumbnaildataPresent",""));
						sdf = Utility::SetProperties(path,xmlfile,PropertyMap);
						if(sdf!=STATUS_OK)	
						{	
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");
							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CFolder::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

								return STATUS_DISK_FULL;
							} 
							DEBUGL1("CFolder::PasteDocument:SetProperty  Failed\n");

							return STATUS_FAILED;
						}

						if(dynamic_cast<CDocument*>(curDoc.operator->())->InitializeStatus()!=STATUS_OK)
						{
							DEBUGL1("CFolder::PasteDocument:Initializing Status Failed\n");
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::PasteDocument: Failed to remove half created folder\n");

							return STATUS_FAILED;
						}		
					}
					catch(exception &e)
					{
						DEBUGL1("CFolder::PasteDocument: caught exception (%s)\n",e.what());
						return STATUS_FAILED;
					}
				}
			}
			DEBUGL4("CFolder::PasteDocument: Exit\n");
			return STATUS_OK;
		}

		Status CFolder::PasteDocument(std::vector<CString> &documentnames)
		{
			Status st;
			documentnames.clear();
			DEBUGL4("CFolder::PasteDocument: Enter\n");
			m_returnpastedocname = true;
			if((st = PasteDocument())!= STATUS_OK)
			{
				DEBUGL4("CFolder::PasteDocument with document names: Failed\n");
				m_returnpastedocname = false;
				return st;
			}
			std::vector<CString>::iterator it;
			DEBUGL8("CFolder::PasteDocument m_PastedVecofDocs - size() = [%d]\n",m_PastedVecofDocs.size());
			it = documentnames.begin();
			int err =pthread_mutex_lock(&gfolder_mutex_initializer);
			if (err != 0)
				DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
			documentnames.insert(it, m_PastedVecofDocs.begin(), m_PastedVecofDocs.end());
			err =pthread_mutex_unlock(&gfolder_mutex_initializer);
			if (err != 0)
				DEBUGL2("CFolder::PasteDocument:: pthread_mutex_lock failed\n ");
			if(documentnames.empty())
				DEBUGL1("CFolder::PasteDocument: No entry found for document names in vector documentnames\n");
			m_returnpastedocname = false;
			DEBUGL4("CFolder::PasteDocument: Exit\n");
			return STATUS_OK;
		}

        Status CFolder::LoadProperties() 
        {
            std::map<CString, CString>::iterator it = m_WebDAVProperties.begin();
            // clear the current values in m_WebDavProperties
            for(;it != m_WebDAVProperties.end(); it++) 
                it->second = "";

            if(proputils::GetAllFolderProperties(m_BoxBasePath,m_BoxNumber,m_FolderName,m_WebDAVProperties)!=STATUS_OK)
            {
                DEBUGL1("CFolder::LoadProperties::Loading properties is failed\n");
                return STATUS_FAILED;
            }

            m_FolderName= m_WebDAVProperties["folderName"]; 
            return STATUS_OK;	
        }

        Status CFolder::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) 
        {
            m_WebDAVProperties = WebDAVpropertyMap;
            return STATUS_OK;	
        }


        Status CFolder::SaveProperties() 
        {
            Status st = proputils::SetFolderProperties(m_BoxBasePath,m_BoxNumber,m_FolderName,m_WebDAVProperties);
            if(st != STATUS_OK)
            {
                DEBUGL1("CFolder::SaveProperties::setting properties to dom failed\n");
                return st;
            }
            return STATUS_OK;
        }

        Status CFolder::GetSize(uint64 &size)
        {
            //uint64 val;
            size=0;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName) + "/";
            if(Utility::ResourceSize(m_sessionID, m_BoxBasePath,m_BoxNumber,m_FolderName,"","",size)!=STATUS_OK)		
            {
                DEBUGL1("CFolder::GetSizeResourceSize Failed\n");
                return STATUS_FAILED;
            }								
            DEBUGL8("CFolder::GetSize:: Full Size of Folder is %lld\n", size);
            //size = atoi(val.c_str());

#if 0
            CString val;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber, m_FolderName) + "/";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,"","","totalBoxSize",val)!=STATUS_OK)		
            {
                DEBUGL1("CFolder::GetSize:GetProperty Failed\n");
                return STATUS_FAILED;
            }								
            size = atoi(val.c_str());
            DEBUGL8("CFolder::GetSize - Size of <%s> is %llu\n",m_FolderName.c_str(),size);
#endif
            return STATUS_OK;
        }
        /**
         * create archive
         * @param[out] archiver - created Archiver object.
         * @param[in] target - archive file path / file name
         * @param[in] documentname - document name to be archived
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CreateArchive(ArchiverRef &archiver, CString target, CString documentname)
        {
            std::vector<CString> documentlist;
            documentlist.clear();
            documentlist.push_back(documentname);
            return (CreateArchive(archiver,target,documentlist));
        }

        /**
         * create archive
         * @param[out] archiver - created Archiver object.
         * @param[in] target - archive file path / file name
         * @param[in] documentlist - list of document name to be archived
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CreateArchive(ArchiverRef &archiver, CString target, std::vector<CString> documentlist)
        {
            DEBUGL4("CFolder::CreateArchive::Createarchive Enter\n");
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,"")+"/";
            CString archivedocpath("");
            std::vector<CString>::iterator it;
            DocumentRef docRef;
            DocStatus docSts;
            Status pRet;
            std::vector<CString> documentpaths;


            //Validate the input Parameters.
            if(target.compare("")==0)
            {
                DEBUGL1("CFolder::CreateArchive::target Name is empty\n");
                return STATUS_FAILED;
            }

            for(it=documentlist.begin();it !=documentlist.end();it++)
            {
                docRef=NULL;
                archivedocpath=path+(*it);
                DEBUGL8("CFolder::CreateArchive::archive Document path =%s\n",path.c_str());

                if(!(Utility::ResourceExist(archivedocpath)))
                {
                    DEBUGL1("CFolder::CreateArchive::DocumentName %s does not exist \n",it->c_str());
                    return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
                }
                //Read the status of the Document. if its not READY/USING then return failed.
                pRet=GetDocument(docRef,(*it));
                if((pRet !=STATUS_OK)||(docRef == static_cast<void*>(NULL)))
                {
                    DEBUGL1("CFolder::CreateArchive::Could not Obtain DocRef. GetDocument Failed\n");
                    return pRet;
                }
                if(docRef->GetStatus(docSts) != STATUS_OK) 
                {
                    DEBUGL1("CFolder::CreateArchive::Getting document status is failed for document %s\n",it->c_str());
                    return STATUS_FAILED;
                }
                // if NOT (READY or USING)
                if(!((docSts == READY) || (docSts == USING))) //RESERVING is not used for Archiving(EFilingBoxes).
                {
                    DEBUGL1("CFolder::CreateArchive::Document Status is not READY or USING\n");
                    return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
                }
				Status stat = docRef->Use();
                if(stat != STATUS_OK) 
				{
					if(stat == STATUS_DISK_FULL) {
						DEBUGL1("CFolder::CreateArchive::Changing document status to USING failed for document (%s) due to DISK FULL\n",it->c_str());
						return stat;
					} else {
						DEBUGL1("CFolder::CreateArchive::Changing document status to USING failed for document %s\n",it->c_str());
						return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
					}
				}		
            }
            //Create a vector of document paths and document list so as to send it to Archive class
            documentpaths.clear();
            documentpaths.push_back(m_BoxBasePath);
            documentpaths.push_back(m_BoxNumber);
            documentpaths.push_back(m_FolderName);
            Ref<CArchiver> carchiver;

            //Now create a Archiver Object and set the required parameters.
            carchiver = new CArchiver(m_sessionID, target,documentpaths,documentlist);
            if(!carchiver)
            {
                DEBUGL1("CFolder::CreateArchive::Creating archive object Failed\n");
                return STATUS_FAILED;
            }
            //create a Thread and start the actual Operation
            pRet = carchiver->CreateArchiveThread();
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CFolder::CreateArchive::Could not Create a Thread\n");
                return pRet;
            }

            archiver=carchiver;

            DEBUGL4("CFolder::CreateArchive::Createarchive Exit\n");
            return STATUS_OK;
        }

        /**
         * extract archive
         * @param[out] extractor - created Extractor object
         * @param[in] archiverpath - path of the archive to be extracted
         * @param[in] extractorpath - path to which the archived files needs to extracted  
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::ExtractArchive(ExtractorRef &extractor,CString archiverpath,CString extractorpath)
        {
            Status pRet;
            std::vector<CString> documentpaths;
            DocumentRef docRef=NULL;

            DEBUGL4("CFolder::ExtractArchive: Enter\n");
            //Validate the input Parameters.
            if((extractorpath.compare("")==0) ||(archiverpath.compare("")==0))
            {
                DEBUGL1("CFolder::ExtractArchive::archiverpath or  extractorpath's are empty\n");
                return STATUS_FAILED;
            }

            //Create a vector of document paths and document list so as to send it to Archive class
            documentpaths.clear();
            documentpaths.push_back(m_BoxBasePath);
            documentpaths.push_back(m_BoxNumber);
            documentpaths.push_back(m_FolderName);
            Ref<CExtractor> cextractor;

            //Now create a Archiver Object and set the required parameters.
            extractorpath = BOXPATH + extractorpath;	
            cextractor = new CExtractor(m_sessionID, archiverpath,documentpaths,extractorpath);
            if(!cextractor)
            {
                DEBUGL1("CFolder::ExtractArchive::Creating extractor object Failed\n");
                return STATUS_FAILED;
            }

            //create a Thread and start the actual Operation
            pRet = cextractor->CreateExtractThread();
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CFolder::ExtractArchive::Could not Create a Thread\n");
                return pRet;
            }

            extractor=cextractor;
            DEBUGL4("CFolder::ExtractArchive: Exit\n");
            return STATUS_OK;
        }

        /**
         * Delete Archive 
         * @param[in] archivepath - path of the archive file that needs to be deleted
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         */
        Status CFolder::DeleteArchive(CString archivepath)
        {
            DEBUGL4("CFolder::DeleteArchive:Enter - DeletePath<%s>\n",archivepath.c_str());
            //Now delete the Box
            if((ci::operatingenvironment::File::DeleteFile(archivepath) != STATUS_OK))
            {
                DEBUGL1("CFolder::DeleteArchive::Deleting %s Document Failed\n",archivepath.c_str());
                return STATUS_FAILED;
            }
            DEBUGL4("CFolder::DeleteArchive: Exit\n");	
            return STATUS_OK;
        }

       	/**
         * cut the documents faster
         * if document status is NOT READY, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] docname - source document name
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CutDocument(ProgressRef& progress, CString docname)
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CutDocument(progress, documents));
        }

        /**
         * cut the documents faster
         * if document status is NOT READY, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] documents - source document names
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CutDocument(ProgressRef& progress, std::vector<CString> documents)
        {
            DEBUGL4("CFolder::CutDocument-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString cutProgShmName = "foldCut_" + CUUID().toString(); 
            m_CutErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(cutProgShmName,m_CutErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".cutDiskFullFold_", ".cutResourceNotFound_");
            if(!m_cprogress)
            {
                DEBUGL1("CFolder::CutDocument-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_CutProgShmName = cutProgShmName;

            //Create shared memory to store progress of cut operation
            m_prgShmid = SharedMemory::Create(cutProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false); 
            if(!m_prgShmid)
            {
                DEBUGL1("CFolder::CutDocument:: Failed to create shared memory..\n");
                return STATUS_FAILED;
            }
            //Create an instance of the invoking Object
            //CFolder cutFolderObj = (CFolder)*this;			
            pRetValue = CreateCutThread(this,documents);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1("CFolder::CutDocument-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }
        /**
         * copy the documents to clipboard
         * if document status is NOT READY or USING 
         *    or RESERVING or EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] docname - source document name
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CopyDocument(ProgressRef& progress, CString docname)
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CopyDocument(progress,documents));
        }

        /**
         * copy the documents to clipboard
         * if document status is NOT READY or USING 
         *    or RESERVING or EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] documents - source document names
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CFolder::CopyDocument(ProgressRef& progress, std::vector<CString> documents)
        {
            DEBUGL4("CFolder::CopyDocument-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString copyProgShmName = CUUID().toString(); 
            m_CopyErrfile = "foldCopy" + CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(copyProgShmName,m_CopyErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".copyDiskFullFold_", ".copyResourceNotFound_");
            if(!m_cprogress)
            {
                DEBUGL1("CFolder::CopyDocument-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_CopyProgShmName = copyProgShmName;

            //Create shared memory to store progress of copy operation
            m_prgShmid = SharedMemory::Create(copyProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
            if(!m_prgShmid)
            {
                DEBUGL1("CFolder::CopyDocument-- Unable to create shared memory..\n");
                return STATUS_FAILED;
            }
            //Create an instance of the invoking Object
            //CFolder copyFolderObj = (CFolder)*this;			
            pRetValue = CreateCopyThread(this,documents);
            if(pRetValue != STATUS_OK)
            {
                DEBUGL1("CFolder::CopyDocument-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;}

            /**
             * paste the document from clipboard
             * @param[out] progress - user can get operation progress from this.
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure,
             *         STATUS_DISK_FULL if there is not enough space on the disk.
             */
            Status CFolder::PasteDocument(ProgressRef& progress)
            {
                DEBUGL4("CFolder::PasteDocument-- Entered for Progress \n ");

                Status pRetValue = STATUS_OK;
                //Generate a name for creating Shared memory
                CString pasteProgShmName = "foldPaste" + CUUID().toString(); 
                m_PasteErrfile = CUUID().toString(); 

                //Create an instance of CProgress
                m_cprogress = new CProgress(pasteProgShmName,m_PasteErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".pasteDiskFullFold_");
                if(!m_cprogress)
                {
                    DEBUGL1("CFolder::PasteDocument-- Creating an instance of Progress failed \n");
                    return STATUS_FAILED;
                }
                m_PasteProgShmName = pasteProgShmName;
    
                //Create shared memory to store the progress of paste operation
                m_prgShmid = SharedMemory::Create(pasteProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
                if(!m_prgShmid)
                {
                    DEBUGL1("CFolder::PasteDocument-- Unable to create shared memory to store progress..\n");
                    return STATUS_FAILED;
                }
                //Create an instance of the invoking Object
                //CFolder pasteFolderObj = (CFolder)*this;			
                pRetValue = CreatePasteThread(this);
                if(pRetValue!=STATUS_OK)
                {
                    DEBUGL1("CFolder::PasteDocument-- Creating Paste thread Failed \n");
                    return pRetValue;
                }

                progress = m_cprogress;
                return STATUS_OK;
            }

            Status CFolder::CreateCutThread(CFolder* cutFolderObj, std::vector<CString> documents)
            {
                Status pRetVal;
                m_ThreadID = NULL;
                //unique name given for locking the resource
                CString lockpath="lockingcutfolderthread";
                GlobalMutexRef threadMutex = NULL;

                // enter critical section
                pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1("CFolder::CreateCutThread-- User has Locked the resource please retry...\n ");
                    return STATUS_FAILED;		
                }
                //Push the vector of pages into its respective static variable
                std::vector<CString>::iterator it;
                for(it = documents.begin();it!=documents.end();it++)
                    m_CutVecofDocs.push_back(*it);

                //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
                //m_CutFlag = FLAG_SET;
				pRetVal = CreateThread(StartCutThread,reinterpret_cast<void*>(cutFolderObj),m_ThreadID);

                if(pRetVal !=STATUS_OK)
                    DEBUGL1("CFolder::CreateCutThread::Could not Create a Thread\n");
                else
                    DEBUGL8("CFolder::CreateCutThread:: Creation of thread Initiated\n");
               //exit critical section
                pRetVal = Utility::LeaveCriticalSection(threadMutex);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1("CFolder::CreateCutThread()--Releasing the Locked Resource Failed\n ");
                    return STATUS_FAILED;		
                }
                return pRetVal;
            }


         	void* CFolder::StartCutThread(void *arg)
			{
                DEBUGL4("CFolder::StartCutThread-- Started \n");
                Status rst;
                Status sdf;
                //Copy the passed instance of the invoking object into a local variable 
                CFolder* folderobj = (CFolder*)arg;
                //unique name given for locking the resource
                CString threadlockpath ="lockingstartCutFolderthread";
               //Copy the pages from static variable to a local variable
                std::vector<CString>::iterator itr;
                std::vector<CString> documents;
				for(itr=m_CutVecofDocs.begin();itr!=m_CutVecofDocs.end();itr++)
					documents.push_back(*itr);	

				m_CutVecofDocs.clear();

				//Create Shared memory used for writing the updted progress in it
				void *pCutMapAddr;
                //cutshmPid = SharedMemory::Create(folderobj.m_CutProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!folderobj->m_prgShmid)
				{
					DEBUGL1("CFolder::StartCutThread: -- Failed to Create Shared Memory for Cut Progress Name \n ");
					folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
					//m_CutFlag = FLAG_RESET;
                        		folderobj->m_prgShmid = NULL;
					return NULL;
				}
				else
				{
					int iShmPidSize = folderobj->m_prgShmid->getSize();
					//Map the Created Segment to another address
					folderobj->m_prgShmid->Map(pCutMapAddr);
					if(pCutMapAddr!=NULL)
					{
						memset(pCutMapAddr,0,iShmPidSize);
					}
					else
					{
						DEBUGL1("CFolder::StartCutThread: -- Mapping Failed for Cut Progress Name\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
						//m_CutFlag = FLAG_RESET;
                        			folderobj->m_prgShmid = NULL;
						return NULL;
					}
				}


				//set the initial value of Cut Document progress as 1% . The Start Cut 
				//thread will update it as and when the operation progresses
				*((int*)pCutMapAddr) = 1;

				std::vector<CString>::iterator iter;
				std::vector<CString> vec;

				//Get the List of Documents in Clipboard
				if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
				{
					DEBUGL1("CFolder::StartCutThread: Getting collection list failed");
					folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        		folderobj->m_prgShmid = NULL;
					return NULL;
				}
				//Delete Clipboard documents,if any
				for(unsigned int i = 0;i < vec.size(); i++) 
				{
					CString fulldocumentname = vec[i];
					CString documentname;
					CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

	     	 			DEBUGL8("CFolder::StartCutThread: vector<%s>, fullDocName<%s> \n",vec[i].c_str(),fulldocumentname.c_str());
					//Check if the clipborad document is of the same user
					CString sid;
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
					{	
						DEBUGL1("CFolder::StartCutThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        			folderobj->m_prgShmid = NULL;
						return NULL;
					}		
					DEBUGL8("CFolder::StartCutThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),folderobj->m_sessionID.c_str());
					if(sid!=folderobj->m_sessionID)
						continue;

					//Now delete the Box
					if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
					{
						DEBUGL1("CFolder::StartCutThread:: DeleteResource <%s> is failed\n", resourceKey.c_str());
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        			folderobj->m_prgShmid = NULL;
						return NULL;
					}
				}

                //Refresh all the documents in the Folder
				DocumentList docList;
				DocumentList::iterator doc;	
				if(folderobj->GetDocumentList(docList) != STATUS_OK) 
				{
					DEBUGL1("CFolder::StartCutThread::Getting document list is failed\n");
					folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        		folderobj->m_prgShmid = NULL;
					return NULL;
				}
				for(doc=docList.begin();doc!=docList.end();doc++)
				{
                    CString docName;
                    DocStatus st;
                    (*doc)->GetStatus(st);
                    if(st != EDITING)
                    {
						(*doc)->GetName(docName);
						if(folderobj->UndoEditDocument(docName)!=STATUS_OK)
						{
							DEBUGL1("CFolder::StartCutThread:UndoEditDocument for <%s> Failed\n",docName.c_str());
							folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        				folderobj->m_prgShmid = NULL;
							return NULL;
						}
					}
				}

				//Progress initialization
				int curProg =0;
				int count =1;
				uint totalCnt = documents.size();
				std::map<CString,CString> PropertyMap;
				CString xmlfile("documentproperties.xml");
				std::vector<CString> notEditDocuments;
				for(iter=documents.begin();iter!=documents.end();iter++)
				{
					DEBUGL8("CFolder::StartCutThread:Document <%s>\n",(*iter).c_str());		
					if(((*iter).empty()))
					{
						DEBUGL1("CFolder::StartCutThread: Document name empty\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        			folderobj->m_prgShmid = NULL;
						return NULL;
					}			
					//Original doc path 
					CString from = Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,(*iter)) + "/";
					CString cutpath = Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName) + "/";

					//Obtain the document
					DocumentRef doc;
					folderobj->GetDocument(doc,(*iter));
					if(!(doc))
					{
                        			DEBUGL1("CFolder::StartCutThread: Given Document name does not exist\n");
			                        folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
                        			if(Utility::CreateUniqueFile(cutpath, ".cutResourceNotFound_" + folderobj->m_sessionID) != STATUS_OK)
		                                DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					notEditDocuments.push_back(*iter);
					// check current status
					DocStatus st;
					doc->GetStatus(st);
					if(st == USING || st == RESERVING)
					{
						DEBUGL1("CFolder::StartCutThread:Document is being used by another user <status: %d>\n", st);
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(st != READY) 
					{
						DEBUGL1("CFolder::StartCutThread: Document is NOT in READY state\n");
						if(folderobj->UndoEditDocument(notEditDocuments)!=STATUS_OK)
						{
							DEBUGL1("CFolder::StartCutThread:UndoEditDocument for Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        	folderobj->m_prgShmid = NULL;
							return NULL;
						}		

						if(Utility::CreateUniqueFile(cutpath, ".copypage2ndsession_" + folderobj->m_sessionID) != STATUS_OK)
							DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");

						folderobj->m_prgShmid = NULL;
						return NULL;
					}
					//Check for the user
					CString orgUserID;
					if(Utility::GetProperty(from,"documentproperties.xml","sessionID",orgUserID)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartCutThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if((!(orgUserID.empty()))&&(folderobj->m_sessionID != orgUserID))
					{
						DEBUGL1("CFolder::StartCutThread:org SessionID not same as Current Session ID\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}

					if(orgUserID.empty())
					{
						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						PropertyMap.insert(pair::value_type("sessionID",folderobj->m_sessionID.c_str()));
						PropertyMap.insert(pair::value_type("cutDocument","true"));
						sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
						if(sdf != STATUS_OK)	
						{	
							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CFolder::StartCutThread:SetProperty failed because Disk is Full\n");
								DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                                if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");

								rst = folderobj->m_prgShmid->Destroy();
								if(rst!=STATUS_OK)
								{
									DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
								}
								folderobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CFolder::StartCutThread:SetProperty for SessionID Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);

			                        	folderobj->m_prgShmid = NULL;
							return NULL;
						}	
					}
					else
					{	
						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						PropertyMap.insert(pair::value_type("cutDocument","true"));
						sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
						if(sdf != STATUS_OK)
						{
							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CFolder::StartCutThread:SetProperty failed because Disk is Full\n");
								DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                                if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");
								rst = folderobj->m_prgShmid->Destroy();
								if(rst!=STATUS_OK)
								{
									DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
								}
								folderobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CFolder::StartCutThread: Document being used by other user\n");
							folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        	folderobj->m_prgShmid = NULL;
							return NULL;
						}
					}		
					/*Read the UUID from documentproperties.xml*/
					CString WorkspaceDocName("");
					if(proputils::GetProperty(folderobj->m_BoxBasePath, folderobj->m_BoxNumber,folderobj->m_FolderName, (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartCutThread: GetProperty of WorkspaceDocName failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}

					//Clipboard doc path
					//CString newDocName=boxobj.m_sessionID+"_"+boxobj.m_BoxNumber+"_"+(*iter);
					//CString to =CLIPBOARD_PATH + newDocName + "/";
					CString newDocName = folderobj->m_sessionID + "_" + WorkspaceDocName;
					ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> ClipboardpathPtr = NULL;
					CString to =CLIPBOARD_PATH + newDocName;
					Status ds= ci::operatingenvironment::Folder::CreateFolder(ClipboardpathPtr,to.c_str());
					if(!ClipboardpathPtr)
					{
						DEBUGL1("CFolder::CreateFolder::ClipboardpathPtr is NULL\n");	
					}
					if(ds != STATUS_OK)
					{
						rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL2("CFolder::CreateFolder: Failed to remove half created folder\n");
						DEBUGL1("CFolder::CreateFolder::Creation of %s Failed\n", to.c_str());
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
						folderobj->m_prgShmid = NULL;
						return NULL;


					}
					to = to + "/";
					CString fromdocxml = from + "/documentproperties.xml";
					CString fromdocdom = from + "/documentproperties_dom";
					Status retsts = ci::operatingenvironment::File::CopyFile(fromdocxml,to);
					if (retsts !=STATUS_OK)	
					{	
						rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");
                        if(retsts==STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::StartCutThread: Copying document returned STATUS DISK FULL\n");
                            DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                            if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");
							rst = folderobj->m_prgShmid->Destroy();
							if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						DEBUGL1("CFolder::StartCutThread: Copying document to ClipBoard failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
						folderobj->m_prgShmid = NULL;
						return NULL;
					}

					retsts = ci::operatingenvironment::File::CopyFile(fromdocdom,to);
					if (retsts !=STATUS_OK)	
					{	
						rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");
						if(retsts==STATUS_DISK_FULL)
						{
							DEBUGL1("CFolder::StartCutThread: Copying document returned STATUS DISK FULL\n");
							DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
							if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");
							rst = folderobj->m_prgShmid->Destroy();
							if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						DEBUGL1("CFolder::StartCutThread: Copying document to ClipBoard failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
						folderobj->m_prgShmid = NULL;
						return NULL;
					}
					//Set the properties
					CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
					PropertyMap.clear();
					CString docxmlfile("documentproperties.xml");		
					//update the other properties 
					PropertyMap.insert(pair::value_type("srcBoxBasePath",folderobj->m_BoxBasePath.c_str()));
					PropertyMap.insert(pair::value_type("srcBoxNumber",folderobj->m_BoxNumber.c_str()));
					PropertyMap.insert(pair::value_type("srcFolderName",folderobj->m_FolderName.c_str()));
					PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
					sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
					if(sdf != STATUS_OK)
					{	
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");

						if(sdf == STATUS_DISK_FULL)
						{
							DEBUGL1("CFolder::StartCutThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                            if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");

							rst = folderobj->m_prgShmid->Destroy();
							if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						DEBUGL1("CFolder::StartCutThread: Setting properties on document failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}	

					//Set Page Properties
					CString strpageno;
					std::ostringstream str;
					// convert int page no to str page no
					str << std::setfill('0') << std::setw(3) << 1;
					strpageno= str.str();

					PageRef page;					
					if(doc->GetPage(1, page) != STATUS_OK) 
					{
						DEBUGL1("CFolder::StartCutThread: Getting page %d failed\n", strpageno.c_str());
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");			
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}	
                    try
                    {
                        PropertyMap.clear();
						if(!page)
						{
							DEBUGL1("CFolder::StartCutThread: page object is null\n");
							folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");			

			                        	folderobj->m_prgShmid = NULL;
							return NULL;          
						}
						CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
						CString pagePath=from+"Image/"+strpageno+ext;
						if(Utility::ResourceExist(pagePath))
						{
							PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));
						}
						ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
						pagePath=from+"Subsampling/"+strpageno+ext;
						if(Utility::ResourceExist(pagePath))
						{
							PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));
						}
						ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
						pagePath=from+"Thumbnail/"+strpageno+ext;
						if(Utility::ResourceExist(pagePath))
						{
							PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
						}
					}
					catch(exception &e)
					{
                        DEBUGL1("CFolder::StartCutThread: exception caught (%s)\n",e.what());
							rst=folderobj->m_prgShmid->Destroy();
							if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
					if(sdf != STATUS_OK)			
					{
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartCutThread: Failed to remove half created folder\n");

						if(sdf == STATUS_DISK_FULL)
						{
							DEBUGL1("CFolder::StartCutThread:SetProperty failed because Disk is Full\n");
							DEBUGL8("CFolder::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                            if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CFolder::StartCutThread: Unable to create the file\n");

							
							rst=folderobj->m_prgShmid->Destroy();
							if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						DEBUGL1("CFolder::StartCutThread:SetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_CutErrfile,folderobj->m_prgShmid);

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}

					//Progress updation
					curProg = (int)((((float)count++)/((float)totalCnt))*100);
					if(curProg != 100)
					{
						*((int*)pCutMapAddr) = curProg;				
						DEBUGL8("CFolder::StartCutThread::Current Progress<%d>\n",curProg);
					}
				}
				*((int*)pCutMapAddr) = PROGRESS_COMPLETED;				

				rst=folderobj->m_prgShmid->Destroy();
				if(rst!=STATUS_OK)
				{
					DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
				}
				folderobj->m_prgShmid = NULL;
               DEBUGL4("CFolder::StartCutThread:Exit\n");
                return NULL;
            }

	         Status CFolder::CreateCopyThread(CFolder* copyFolderObj, std::vector<CString> documents)
			{
				Status pRetVal;
				m_ThreadID = NULL;
				//unique name given for locking the resource
				CString lockpath="lockingcopyfolderthread";
				GlobalMutexRef threadMutex = NULL;
				// enter critical section
				pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
				if(pRetVal !=STATUS_OK)
				{
					DEBUGL1("CFolder::CreateCopyThread-- User has Locked the resource please retry...\n ");
					return STATUS_FAILED;		
				}
				//Push the vector of pages into its respective static variable
				std::vector<CString>::iterator it;
				for(it = documents.begin();it!=documents.end();it++)
					m_CopyVecofDocs.push_back(*it);

				//Flag set to 1 untill the inputs are copied into local variables in the Started Thread
				//m_CopyFlag = FLAG_SET;

				pRetVal = CreateThread(StartCopyThread,reinterpret_cast<void*>(copyFolderObj),m_ThreadID);
				if(pRetVal !=STATUS_OK)
					DEBUGL1("CFolder::CreateCopyThread::Could not Create a Thread\n");
				else
					DEBUGL8("CFolder::CreateCopyThread:: Creation of thread Initiated\n");
				pRetVal = Utility::LeaveCriticalSection(threadMutex);
				if(pRetVal !=STATUS_OK)
				{
					DEBUGL1("CFolder::CreateCopyThread()--Releasing the Locked Resource Failed\n ");
					return STATUS_FAILED;		
				}
				return pRetVal;
			}

            void* CFolder::StartCopyThread(void *arg)
            {

                DEBUGL4("CFolder::StartCopyThread-- Started \n");
                Status rst;
                Status sdf;
                //Copy the passed instance of the invoking object into a local variable 
                CFolder* folderobj = (CFolder*)arg;
                //unique name given for locking the resource
                CString threadlockpath ="lockingstartCopyFolderthread";
               //Copy the pages from static variable to a local variable
                std::vector<CString>::iterator itr;
                std::vector<CString> documents;
                for(itr=m_CopyVecofDocs.begin();itr!=m_CopyVecofDocs.end();itr++)
                    documents.push_back(*itr);	

                m_CopyVecofDocs.clear();

                //Create Shared memory used for writing the updted progress in it
                void *pCopyMapAddr;
                //copyshmPid = SharedMemory::Create(folderobj.m_CopyProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
                if(!folderobj->m_prgShmid)
                {
                    DEBUGL1("CFolder::StartCopyThread: -- Failed to Create Shared Memory for Cut Progress Name \n ");
                    folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                    //m_CopyFlag = FLAG_RESET;
                    return NULL;
                }
                else
                {
                    int iShmPidSize = folderobj->m_prgShmid->getSize();
                    //Map the Created Segment to another address
                    folderobj->m_prgShmid->Map(pCopyMapAddr);
                    if(pCopyMapAddr!=NULL)
                    {
                        memset(pCopyMapAddr,0,iShmPidSize);
                    }
                    else
                    {
                        DEBUGL1("CFolder::StartCopyThread: -- Mapping Failed for Cut Progress Name\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        //m_CopyFlag = FLAG_RESET;
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }
                }

               //set the initial value of Cut Document progress as 1% . The Start Cut 
                //thread will update it as and when the operation progresses
                *((int*)pCopyMapAddr) = 1;

                std::vector<CString>::iterator iter;
                std::vector<CString> vec;

                //Get the List of Documents in Clipboard
                if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
                {
                    DEBUGL1("CFolder::StartCopyThread: Getting collection list failed");
                    folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                    folderobj->m_prgShmid = NULL;
                    return NULL;
                }
                //Delete Clipboard documents,if any
                for(unsigned int i = 0;i < vec.size(); i++) 
                {
                    CString fulldocumentname = vec[i];
                    CString documentname;		
                    CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

		    DEBUGL8("CFolder::StartCopyThread: vector<%s>, fullDocName<%s> \n",vec[i].c_str(),fulldocumentname.c_str());
                    //Check if the clipborad document is of the same user
                    CString sid;		
                    if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
                    {
                        DEBUGL1("CFolder::StartCopyThread:GetProperty Failed\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL8("CFolder::StartCopyThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),folderobj->m_sessionID.c_str());


                    if(sid!=folderobj->m_sessionID)
                        continue;

                    if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                    {
                        DEBUGL1("CFolder::StartCopyThread:: DeleteResource <%s> is failed\n", resourceKey.c_str());
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }
                }

                //Refresh all the documents in the Folder
                DocumentList docList;
                DocumentList::iterator doc;	
                if(folderobj->GetDocumentList(docList) != STATUS_OK) 
                {
                    DEBUGL1("CFolder::StartCopyThread::Getting document list is failed\n");
                    folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                    folderobj->m_prgShmid = NULL;
                    return NULL;
                }
                for(doc=docList.begin();doc!=docList.end();doc++)
                {
                    //To fix FR_5285, added check to verify if the document is in editing then should not
                    //reset session id and cutdocument flag. 
                    // check current status
                    DocStatus st;
                    (*doc)->GetStatus(st);
                    if(!(st==EDITING)) 
                    {		
                        CString docName;
                        (*doc)->GetName(docName);
                        if(folderobj->UndoEditDocument(docName)!=STATUS_OK)
                        {
                            DEBUGL1("CFolder::StartCopyThread:UndoEditDocument for <%s> Failed\n",docName.c_str());
                            folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                            folderobj->m_prgShmid = NULL;
                            return NULL;
                        }
                    }
                }

                //Progress initialization
                int curProg =0;
                int count =1;
                uint totalCnt = documents.size();

                for(iter=documents.begin();iter!=documents.end();iter++)
                {
                    DEBUGL8("CFolder::StartCopyThread:Document <%s>\n",(*iter).c_str());		
                    if(((*iter).empty()))
                    {
                        DEBUGL1("CFolder::StartCopyThread: Document name empty");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }			
                    //Original doc path 
                    CString from = Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,(*iter)) + "/";
                    CString copypath = Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName) + "/";

                    //Obtain the original document
                    DocumentRef doc;
                    folderobj->GetDocument(doc,(*iter));
                    if(!(doc))
                    {
                        DEBUGL1("CFolder::StartCopyThread: Given Document name does not exist\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);

                        if(Utility::CreateUniqueFile(copypath, ".copyResourceNotFound_" + folderobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");

                        folderobj->m_prgShmid = NULL;

                        return NULL;
                    }			

                    // check current status
                    DocStatus st;
                    doc->GetStatus(st);
                    //if(!(st== READY || st==USING || st==EDITING)) 
                    if(st == USING || st == RESERVING)
                    {
                        DEBUGL1("CFolder::StartCopyThread: Document is in USING state <status: %d>\n", st);
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;			
                    }
                    if(!(st== READY || st==EDITING)) 
                    {
                        DEBUGL1("CFolder::StartCopyThread: Document is NOT in READY/EDITING state\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    if(st == EDITING)
                    {
                         if(Utility::CreateUniqueFile(copypath, ".copypage2ndsession_" + folderobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");
                        folderobj->m_prgShmid = NULL;
                        
                        return NULL;
                    }

                    //Set the session-ID on the orignal document
                    std::map<CString,CString> PropertyMap;
                    CString xmlfile("documentproperties.xml");
                    PropertyMap.clear();
                    //update the sessionID and cutDocument flag on the original document
                    PropertyMap.insert(pair::value_type("sessionID",folderobj->m_sessionID.c_str()));
                    PropertyMap.insert(pair::value_type("cutDocument","false"));
                    sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)		
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::StartCopyThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CFolder::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                            if(Utility::CreateUniqueFile(copypath, ".copyDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");
			    rst=folderobj->m_prgShmid->Destroy();
		       	    if(rst!=STATUS_OK)
	  		    {
				DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
			    }
                            folderobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CFolder::StartCopyThread:SetProperty Failed\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }

                    /*Read the UUID from documentproperties.xml*/
                    CString WorkspaceDocName("");
                    if(proputils::GetProperty(folderobj->m_BoxBasePath, folderobj->m_BoxNumber, folderobj->m_FolderName, (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                    {
                        DEBUGL1("CFolder::StartCopyThread: GetProperty of WorkspaceDocName failed\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }

                    //Clipboard doc path
                    //CString newDocName=folderobj.m_sessionID+"_"+folderobj.m_BoxNumber+"_"+folderobj.m_FolderName+"_"+(*iter)+"/";
                    //CString to = CLIPBOARD_PATH + newDocName;
                    CString newDocName = folderobj->m_sessionID + "_" + WorkspaceDocName;
                    CString to = CLIPBOARD_PATH + newDocName + "/";
                    Status retsts = ci::operatingenvironment::Folder::CopyDir(from,to);
                    if (retsts !=STATUS_OK)	
                    {
                        rst = Utility::RemoveResource(to);
                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::StartCopyThread: Failed to remove half created folder\n");

                        if(retsts==STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::StartCopyThread: Copying document to ClipBoard failed\n");
                            DEBUGL8("CFolder::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                            if(Utility::CreateUniqueFile(copypath, ".copyDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");

			    rst=folderobj->m_prgShmid->Destroy();
		       	    if(rst!=STATUS_OK)
	  		    {
				DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
			    }
                            folderobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CFolder::StartCopyThread: Copying document returned STATUS DISK FULL\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }

                    //Set the properties
                    CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                    PropertyMap.clear();
                    CString docxmlfile("documentproperties.xml");
                    //update the other properties 
                    PropertyMap.insert(pair::value_type("srcBoxBasePath",folderobj->m_BoxBasePath.c_str()));
                    PropertyMap.insert(pair::value_type("srcBoxNumber",folderobj->m_BoxNumber.c_str()));
                    PropertyMap.insert(pair::value_type("srcFolderName",folderobj->m_FolderName));
                    PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                    sdf = Utility::SetProperties(to,docxmlfile,PropertyMap);
                    if(sdf != STATUS_OK)	
                    {	
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::StartCopyThread: Failed to remove half created folder\n");
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::StartCopyThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CFolder::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                            if(Utility::CreateUniqueFile(copypath, ".copyDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");

			    rst=folderobj->m_prgShmid->Destroy();
		       	    if(rst!=STATUS_OK)
	  		    {
				DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
			    }
                            folderobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CFolder::CopyDocument:SetProperty for SessionID Failed\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);

                        folderobj->m_prgShmid = NULL;

                        return NULL;
                    }	

                    //Set Page Properties
                    CString strpageno;
                    std::ostringstream str;
                    // convert int page no to str page no
                    str << std::setfill('0') << std::setw(3) << 1;
                    strpageno= str.str();

                    PageRef page;					
                    if(doc->GetPage(1, page) != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::StartCopyThread: Getting page %d failed\n", strpageno.c_str());
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::StartCopyThread: Failed to remove half created folder\n");
                        folderobj->m_prgShmid = NULL;

                        return NULL;
                    }	
                    try
                    {
                        PropertyMap.clear();
                        if(!page)
                        {
                            DEBUGL1("CFolder::StartCopyThread: page object is null\n");
                            folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);
                            rst = Utility::RemoveResource(resourceKey);
                            if(rst != STATUS_OK)
                                DEBUGL1("CFolder::StartCopyThread: Failed to remove half created folder\n");
                            folderobj->m_prgShmid = NULL;

                            return NULL;          
                        }
                        CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                        CString pagePath=from+"Image/"+strpageno+ext;
                        if(Utility::ResourceExist(pagePath))
                        {
                            PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));		
                        }
                        ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                        pagePath=from+"Subsampling/"+strpageno+ext;
                        if(Utility::ResourceExist(pagePath))
                        {
                            PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));		
                        }
                        ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                        pagePath=from+"Thumbnail/"+strpageno+ext;
                        if(Utility::ResourceExist(pagePath))
                        {
                            PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
                        }
                    }
                    catch(exception &e)
                    {
                        DEBUGL1("CFolder::StartCopyThread: exception caught (%s)\n", e.what());
			    rst=folderobj->m_prgShmid->Destroy();
		       	    if(rst!=STATUS_OK)
	  		    {
				DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
			    }
                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                    if(sdf != STATUS_OK)			
                    {
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CFolder::StartCopyThread: Failed to remove half created folder\n");
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CFolder::StartCopyThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CFolder::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                            if(Utility::CreateUniqueFile(copypath, ".copyDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CFolder::StartCopyThread: Unable to create the file\n");

			    rst=folderobj->m_prgShmid->Destroy();
		       	    if(rst!=STATUS_OK)
	  		    {
				DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
			    }
                            folderobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CFolder::StartCopyThread:SetProperty Failed\n");
                        folderobj->ErrorFileCreation(folderobj->m_CopyErrfile,folderobj->m_prgShmid);


                        folderobj->m_prgShmid = NULL;
                        return NULL;
                    }


                    //Progress updation
                    curProg = (int)((((float)count++)/((float)totalCnt))*100);
                    if(curProg !=100)
		    {
		    	*((int*)pCopyMapAddr) = curProg;				
                    	DEBUGL8("CFolder::StartCopyThread::Current Progress<%d>\n",curProg);
		    }

                }
                *((int*)pCopyMapAddr) = PROGRESS_COMPLETED;				
		rst=folderobj->m_prgShmid->Destroy();
          	if(rst!=STATUS_OK)
	  	{
			DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
		}
                folderobj->m_prgShmid = NULL;

                DEBUGL4("CFolder::StartCopyThread: Exit\n");	
                return NULL;
            }

            Status CFolder::CreatePasteThread(CFolder* pasteFolderObj)
            {
                Status pRetVal;
                m_ThreadID = NULL;
                //unique name given for locking the resource
                CString lockpath="lockingpastefolderthread";
                GlobalMutexRef threadMutex = NULL;
                // enter critical section
                pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1("CFolder::CreatePasteThread-- User has Locked the resource please retry...\n ");
                    return STATUS_FAILED;		
                }

                //Flag set to 1 untill the inputs are copied into local variables in the Started Thread
                //m_PasteFlag = FLAG_SET;

                pRetVal = CreateThread(StartPasteThread,reinterpret_cast<void*>(pasteFolderObj),m_ThreadID);
                if(pRetVal !=STATUS_OK)
                    DEBUGL1("CFolder::CreatePasteThread::Could not Create a Thread\n");
                else
                    DEBUGL8("CFolder::CreatePasteThread:: Creation of thread Initiated\n");
               pRetVal = Utility::LeaveCriticalSection(threadMutex);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1("CFolder::CreatePasteThread()--Releasing the Locked Resource Failed\n ");
                    return STATUS_FAILED;		
                }
                return pRetVal;
            }

            void* CFolder::StartPasteThread(void *arg)
			{
				DEBUGL4("CFolder::StartPasteThread-- Started \n");
				Status sdf;
				Status rst;
				//Copy the passed instance of the invoking object into a local variable 
				CFolder* folderobj = (CFolder*)arg;
				CString xmlfile("documentproperties.xml");
				//unique name given for locking the resource
				CString threadlockpath ="lockingstartPasteFolderthread";
				//Create Shared memory used for writing the updted progress in it
				void *pPasteMapAddr;
				//pasteshmPid = SharedMemory::Create(folderobj.m_PasteProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!folderobj->m_prgShmid)
				{
					DEBUGL1("CFolder::StartPasteThread: -- Failed to Create Shared Memory for Paste Progress Name \n ");
					folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
					//m_PasteFlag= FLAG_RESET;
					return NULL;
				}
				else
				{
					int iShmPidSize = folderobj->m_prgShmid->getSize();
					//Map the Created Segment to another address
					folderobj->m_prgShmid->Map(pPasteMapAddr);
					if(pPasteMapAddr!=NULL)
					{
						memset(pPasteMapAddr,0,iShmPidSize);
					}
					else
					{
						DEBUGL1("CFolder::StartPasteThread: -- Mapping Failed for Paste Progress Name\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
						//m_PasteFlag= FLAG_RESET;
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
				}

				//set the initial value of Paste Document progress as 1% . The Start Paste 
				//thread will update it as and when the operation progresses
				*((int*)pPasteMapAddr) = 1;


				DEBUGL4("CFolder::StartPasteThread: Enter\n");
				std::vector<CString> vec;

				//Get the List of Documents in Clipboard
				if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
				{
					DEBUGL1("CFolder::StartPasteThread: Getting collection list failed");
					folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                folderobj->m_prgShmid = NULL;
					return NULL;
				}

				//Progress initialization
				int curProg =0;
				int count =1;
				uint totalCnt = vec.size();
				std::map<CString,CString> PropertyMap;

				for(unsigned int i = 0;i < vec.size(); i++) 
				{
					CString fulldocumentname = vec[i];
					CString documentname;		
					CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

					if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}

					DEBUGL8("CFolder::StartPasteThread: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

					//Check for limit
					DocumentList docList;
					folderobj->GetDocumentList(docList);
					if(folderobj->m_BoxBasePath != "/storage/box/ITUTBoxes" && docList.size() >= CBoxDocument::DOC_LIMIT) 
					{
						DEBUGL1("CFolder::StartPasteThread: The number of documents reach limit\n");
						//Get the List of Documents in Clipboard
						std::vector<CString> vecDoc;
						if(Utility::GetCollectionList(vecDoc,CLIPBOARD_PATH)!=STATUS_OK) 
						{
							DEBUGL1("CFolder::StartPasteThread: Getting collection list failed");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        	folderobj->m_prgShmid = NULL;
							return NULL;
						}

						for(unsigned int i = 0;i < vecDoc.size(); i++) 
						{
							CString fulldocumentname = vecDoc[i];
							CString documentname;		
							CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

							if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}

							DEBUGL8("CFolder::StartPasteThread: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  
							CString from = CLIPBOARD_PATH + fulldocumentname+"/";
							CString path=Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName)+"/";
							CString newpath = path + documentname + "/";
							CString pastepath = path;

							//Read the properties of the original box and see if the document is cut from the same box
							CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
							if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}
							if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}
							if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}
							if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}
							if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}


							CString orgPath;
							if(srcFolderName.empty())
								orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
							else
								orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

							DEBUGL8("CFolder::StartPasteThread: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
							//Reset the properties on the Original document			
							PropertyMap.clear();
							//update the sessionID and cutDocument flag 
							//PropertyMap.insert(pair::value_type("sessionID",""));
							PropertyMap.insert(pair::value_type("cutDocument",""));
							sdf = Utility::SetProperties(orgPath,xmlfile,PropertyMap);
							if(sdf != STATUS_OK)	
							{
								Status rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
								if(sdf == STATUS_DISK_FULL)
								{
									DEBUGL1("CFolder::StartPasteThread:SetProperty failed because Disk is Full\n");
									DEBUGL8("CFolder::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
										DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");

			    						rst=folderobj->m_prgShmid->Destroy();
		       	 						if(rst!=STATUS_OK)
						  			{
										DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
									}
									folderobj->m_prgShmid = NULL;
									return NULL;
								}
								DEBUGL1("CFolder::StartPasteThread:SetProperty Failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}
						}

						//return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;

					}

					//Check if the clipborad document is of the same user
					CString sid;
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					DEBUGL8("CFolder::StartPasteThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),folderobj->m_sessionID.c_str());

					if(sid!=folderobj->m_sessionID)
					{
						DEBUGL2("CFolder::StartPasteThread:Session ID's are different hence continuing\n");
						continue;
					}

					CString from = CLIPBOARD_PATH + fulldocumentname+"/";
					CString path=Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName)+"/";
					CString newpath = path + documentname + "/";
					CString pastepath = path;

					//Read the properties of the original box and see if the document is cut from the same box
					CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
					if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread: Getproperty failded\n");			
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}


					CString orgPath;
					if(srcFolderName.empty())
						orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
					else
						orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

					DEBUGL8("CFolder::StartPasteThread: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
					DEBUGL8("CFolder::StartPasteThread: cutDocumentFlag = (%s)\n",cutDocumentFlag.c_str());
					bool bSamePath = false;
					CString truncdocname = "";
					Status ret;
					//In case of cut document and paste in different box
					//check if same resource exist and if exist increment document name
					CString NewWorkspaceDocName("");
					if(orgPath.compare(newpath) && (cutDocumentFlag == "true"))
					{
							if(documentname.length()>64)
							{
								DEBUGL8("CFolder::StartPasteThread:calling TruncateDocumentName()\n");
								ret = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
								if(ret != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread:calling TruncateDocumentName() has not returned STATUS_OK\n");
								documentname = truncdocname;
								newpath = path + documentname;
							}		
							if(Utility::ResourceExist(newpath))
							{
								DEBUGL8("CFolder::StartPasteThread:Document with same document name is already existing\n");
								ret = Utility::LimitTo64Characters(documentname,newpath,path);
								if(ret != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread:LimitTo64Characters has not returned STATUS_OK\n");
							}
					}
					//In case of copy operation, if same document exist increment document name
					else if(cutDocumentFlag == "false" || cutDocumentFlag == "")
					{
						if(documentname.length()>64)
						{
							DEBUGL8("CFolder::StartPasteThread:calling TruncateDocumentName()\n");
							ret = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
						if(ret != STATUS_OK)
                                    DEBUGL1("CFolder::StartPasteThread:calling TruncateDocumentName() has not returned STATUS_OK\n");

							documentname = truncdocname;
							newpath = path + documentname;
						}
						if(Utility::ResourceExist(newpath))
						{
							DEBUGL8("CFolder::StartPasteThread:Document with the same document name is already existing\n");
							ret = Utility::LimitTo64Characters(documentname,newpath,path);
							if(ret != STATUS_OK)
                                    DEBUGL1("CFolder::StartPasteThread:LimitTo64Characters has not returned STATUS_OK\n");
						}
						NewWorkspaceDocName = CUUID().toString();
					}

					Status retStatus;
					Status rst;
					//In case of cut operation and boxbasepaht are same
					//remove the original document and paste the updated document
					if(cutDocumentFlag == "true")
					{
						CString to = newpath;
						if(!orgPath.compare(newpath) )
						{
							bSamePath = true;
						}

						CString pasteboxpath,pasteboxnumber,pasteboxfolder,pasteboxdocument;
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxBasePath",pasteboxpath)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxNumber",pasteboxnumber)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcFolderName",pasteboxfolder)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcDocumentName",pasteboxdocument)!=STATUS_OK)		
						{
							DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
							folderobj->m_prgShmid = NULL;
							return NULL;
						}
						CString orgDocumentPath = Utility::GetResourcePath(pasteboxpath,pasteboxnumber,pasteboxfolder,pasteboxdocument) + "/";		

						DEBUGL8("CFolder::StartPasteThread:pasteboxpath (%s) pasteboxnumber (%s) pastefoldername (%s) to (%s)\n",pasteboxpath.c_str(), pasteboxnumber.c_str(),pasteboxfolder.c_str(),to.c_str()); 

						DEBUGL8("CFolder::StartPasteThread:orgDocumentPath (%s)\n",orgDocumentPath.c_str()); 

						if(bSamePath == false){
							retStatus = ci::operatingenvironment::Folder::CopyDir(orgDocumentPath,to);
							if(retStatus !=STATUS_OK)
							{
								rst = Utility::RemoveResource(to);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

								if(retStatus == STATUS_DISK_FULL)
								{
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
										DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");
			    						rst=folderobj->m_prgShmid->Destroy();
		       	 						if(rst!=STATUS_OK)
						  			{
										DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
									}
									folderobj->m_prgShmid = NULL;
									return NULL;
								}
								DEBUGL1("CFolder::StartPasteThread: Copying document to ClipBoard failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								folderobj->m_prgShmid = NULL;
								return NULL;				
							}
						}
						Status retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties.xml",to);
						if(retsts != STATUS_OK){
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

							if(retsts == STATUS_DISK_FULL)
							{
								if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");
			    						rst=folderobj->m_prgShmid->Destroy();
		       	 						if(rst!=STATUS_OK)
						  			{
										DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
									}
								folderobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CFolder::StartPasteThread: Copying document to ClipBoard failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							folderobj->m_prgShmid = NULL;
							return NULL;	
						}
						retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties_dom",to);
						if(retsts != STATUS_OK){
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

							if(retsts == STATUS_DISK_FULL)
							{
								if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");
			    					rst=folderobj->m_prgShmid->Destroy();
		       	 					if(rst!=STATUS_OK)
						  		{
									DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
								}
								folderobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CFolder::StartPasteThread: Copying document to ClipBoard failed\n");
			                        	folderobj->m_prgShmid = NULL;
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
							return NULL;	
						}
					}
					//In case of copy operation copy the dir to original document
					else
					{
						CString to = newpath;
						retStatus = ci::operatingenvironment::Folder::CopyDir(from,to);
						if(retStatus !=STATUS_OK)
						{
							rst = Utility::RemoveResource(to);
							if(rst != STATUS_OK)
								DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

							if(retStatus == STATUS_DISK_FULL)
							{
								if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");

			    					rst=folderobj->m_prgShmid->Destroy();
		       	 					if(rst!=STATUS_OK)
						  		{
									DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
								}
								folderobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CFolder::StartPasteThread: Copying document to ClipBoard failed\n");
							folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
			                        	folderobj->m_prgShmid = NULL;
							return NULL;				
						}
						NewWorkspaceDocName = CUUID().toString();
					}

					//Original Document Path
					CString orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName;
					resourceKey = Utility::GetResourcePath(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,documentname) + "/";
					if(proputils::GetProperty(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,documentname,"","srcBoxBasePath",orgBoxBasePath)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(proputils::GetProperty(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,documentname,"","srcBoxNumber",orgBoxNumber)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(proputils::GetProperty(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,documentname,"","srcFolderName",orgFolderName)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        folderobj->m_prgShmid = NULL;
						return NULL;
					}
					if(proputils::GetProperty(folderobj->m_BoxBasePath,folderobj->m_BoxNumber,folderobj->m_FolderName,documentname,"","srcDocumentName",orgDocumentName)!=STATUS_OK)
					{
						DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
						folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
			                        folderobj->m_prgShmid = NULL;

						return NULL;
					}

					//Obtain the Clipboard document
					DocumentRef clipDoc;
					CString clipPath = CLIPBOARD_PATH;
					if(Utility::GetDocument(folderobj->m_sessionID, clipDoc,clipPath,"","",fulldocumentname)==STATUS_OK)
					{
						try
						{		
							//Getting document properties from original document
							DEBUGL8("CFolder::StartPasteThread:Getting Properties\n");		
							std::map<CString,CString> webDAVProperties;
							if(!clipDoc)
							{
								DEBUGL1("CFolder::StartPasteThread: doc object is null\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;            
							}
							Status ret = dynamic_cast<CDocument*>(clipDoc.operator->())->GetProperties(webDAVProperties);
							if(ret != STATUS_OK) 
							{
								DEBUGL1("CFolder::StartPasteThread:GetProperties of OrgDoc failed\n");
								//return ret;
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;

							}		
							std::map<CString,CString>::iterator mapIter;
							for(mapIter=webDAVProperties.begin();mapIter!=webDAVProperties.end();mapIter++)
							{
								DEBUGL8("CFolder::StartPasteThread: Key<%s> and Value<%s>\n",(mapIter->first).c_str(),(mapIter->second).c_str());
							}

							//Setting document properties on current document
							DocumentRef curDoc;		
							curDoc = new CDocument(folderobj->m_sessionID, folderobj->m_BoxBasePath, folderobj->m_BoxNumber,folderobj->m_FolderName, documentname);

							// Save WebDAV properties
							if(!curDoc)
							{
								DEBUGL1("CFolder::StartPasteThread: doc object is null\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;          
							}

							//Not required anymore because the aim is to write the attributes of the
							//copied/cut  document to documentproperties.xml of paste document
							//Setting WorkspaceDocName property
							CString key = "WorkspaceDocName";
							if(cutDocumentFlag != "true")
								webDAVProperties[key] = NewWorkspaceDocName;
							//Re-setting the cut flag 
							webDAVProperties["cutDocument"] = "";

							//Setting the new document name
							webDAVProperties["documentName"] = documentname;

							//Setting the creation date and the modified date
							CString creatTime = Utility::GetUnixTime();
							webDAVProperties["creationDate"] = creatTime;
							webDAVProperties["lastModifiedDate"] = creatTime;

							//Writing the attributes of the cut/copied document to the paste document
							ret = dynamic_cast<CDocument*>(curDoc.operator->())->SetProperties(webDAVProperties);
							if(ret != STATUS_OK)
							{
								if(ret == STATUS_DISK_FULL)
								{
									DEBUGL1("CFolder::StartPasteThread:SetProperties of CurDoc failed because Disk is Full\n");
									curDoc = NULL; // release
									DEBUGL8("CFolder::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
										DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");
									rst = Utility::RemoveResource(resourceKey);
									if(rst != STATUS_OK)
										DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
			    						rst=folderobj->m_prgShmid->Destroy();
		       	 						if(rst!=STATUS_OK)
						  			{
										DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
									}
									folderobj->m_prgShmid = NULL;
									return NULL;
								}
								DEBUGL1("CFolder::StartPasteThread:SetProperties of CurDoc failed\n");
								curDoc = NULL; // release
								//return ret;
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}


							//Check for the CutDocument property and delete the original document
							DocumentRef orgDoc;
							if(Utility::GetDocument(folderobj->m_sessionID, orgDoc,orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread: Obtaining Original Document failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}

							CString flag;
							CString dpath =Utility::GetResourcePath(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)+"/";
							if(proputils::GetProperty(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName,"","cutDocument",flag)!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread:GetProperty Failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}

							if(flag=="true")
							{	
								if(!orgDoc)
								{
									DEBUGL1("CFolder::StartPasteThread: doc object is null\n");
									folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
									rst = Utility::RemoveResource(resourceKey);
									if(rst != STATUS_OK)
										DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        			folderobj->m_prgShmid = NULL;
									return NULL;         
								}
								// Start to Delete
								if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
								{
									DEBUGL1("CFolder::StartPasteThread: Deleting document failed\n");
									folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
									rst = Utility::RemoveResource(resourceKey);
									if(rst != STATUS_OK)
										DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        			folderobj->m_prgShmid = NULL;
									return NULL;
								}
							}	
							else
							{
								//Reset the properties on the Original document			
								PropertyMap.clear();
								//update the sessionID and cutDocument flag 
								PropertyMap.insert(pair::value_type("sessionID",""));
								PropertyMap.insert(pair::value_type("cutDocument",""));
								sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap);
								if(sdf != STATUS_OK)	
								{
									rst = Utility::RemoveResource(resourceKey);
									if(rst != STATUS_OK)
										DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
									if(sdf == STATUS_DISK_FULL)
									{
										DEBUGL1("CFolder::StartPasteThread:SetProperty failed because Disk is Full\n");
										DEBUGL8("CFolder::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
										if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
											DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");

			    							rst=folderobj->m_prgShmid->Destroy();
		       	 							if(rst!=STATUS_OK)
						  				{
											DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
										}
										folderobj->m_prgShmid = NULL;
										return NULL;
									}
									DEBUGL1("CFolder::StartPasteThread:SetProperty Failed\n");
									folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);

			                        			folderobj->m_prgShmid = NULL;

									return NULL;
								}
							}

							if(flag=="true")
							{	
								//Clear the ClipBoard
								if((ci::operatingenvironment::Folder::Remove(from,true) != STATUS_OK))
								{
									DEBUGL1("CFolder::StartPasteThread: DeleteResource %s is failed\n", from.c_str());
									folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
									rst = Utility::RemoveResource(resourceKey);
									if(rst != STATUS_OK)
										DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        			folderobj->m_prgShmid = NULL;
									return NULL;
								}	
							}

							//Reset the properties on the Original document
							PropertyMap.clear();

							//CString docxmlfile("documentproperties.xml");
							PropertyMap.insert(pair::value_type("srcBoxNumber",""));
							PropertyMap.insert(pair::value_type("srcBoxBasePath",""));
							PropertyMap.insert(pair::value_type("srcDocumentName",""));
							PropertyMap.insert(pair::value_type("IsImagedataPresent",""));
							PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent",""));
							PropertyMap.insert(pair::value_type("IsThumbnaildataPresent",""));
							//update the sessionID and cutDocument flag 
							PropertyMap.insert(pair::value_type("sessionID",""));
							PropertyMap.insert(pair::value_type("cutDocument",""));

							sdf = Utility::SetProperties((path + documentname + "/"),xmlfile,PropertyMap);
							if(sdf != STATUS_OK)	
							{	
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");
								if(sdf == STATUS_DISK_FULL)
								{
									DEBUGL1("CFolder::StartPasteThread:SetProperty failed because Disk is Full\n");
									DEBUGL8("CFolder::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
									if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullFold_" + folderobj->m_sessionID) != STATUS_OK)
										DEBUGL2(" CFolder::StartPasteThread: Unable to create the file\n");

			    						rst=folderobj->m_prgShmid->Destroy();
		       	 						if(rst!=STATUS_OK)
						  			{
										DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
									}
									folderobj->m_prgShmid = NULL;
									return NULL;
								}
								DEBUGL1("CFolder::StartPasteThread:SetProperty Failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);

			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}							

							if(dynamic_cast<CDocument*>(curDoc.operator->())->InitializeStatus()!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartPasteThread:Initializing Status Failed\n");
								folderobj->ErrorFileCreation(folderobj->m_PasteErrfile,folderobj->m_prgShmid);
								rst = Utility::RemoveResource(resourceKey);
								if(rst != STATUS_OK)
									DEBUGL1("CFolder::StartPasteThread: Failed to remove half created folder\n");

			                        		folderobj->m_prgShmid = NULL;
								return NULL;
							}		

							//Progress updation
							curProg = (int)((((float)count++)/((float)totalCnt))*100);
							if(curProg != 100)
							{
								*((int*)pPasteMapAddr) = curProg;				
								DEBUGL8("CFolder::StartPasteThread::Current Progress<%d>\n",curProg);
							}
						}
						catch(exception &e)
						{
							DEBUGL1("CFolder::StartPasteThread: caught exception (%s)\n", e.what());
			    				rst=folderobj->m_prgShmid->Destroy();
		       	 				if(rst!=STATUS_OK)
							{
								DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
							}
			                        	folderobj->m_prgShmid = NULL;
							return NULL;
						}

					}
				}
				*((int*)pPasteMapAddr) = PROGRESS_COMPLETED;				
			    	rst=folderobj->m_prgShmid->Destroy();
		       		if(rst!=STATUS_OK)
				{
					DEBUGL1("CFolder::StartCutThread:: Failed to destroy shared memory\n");
				}
				folderobj->m_prgShmid = NULL;
				DEBUGL4("CFolder::StartPasteThread: Exit\n");
				return NULL;
			}

            Status CFolder::CreateThread(ThreadFun funcName,ThreadArg funcArgument,Ref<Thread> threadID)
            {
                if(!(threadID = Thread::Create(funcName)))
                {
                    DEBUGL1("CFolder::CreateThread: --Unable to create the thread\n");
                    return STATUS_FAILED;
                }
                else
		{
			m_ThreadID = threadID;
			DEBUGL8("CFolder::CreateThread: -Thread created successfully\n");

			if(threadID->Start(funcArgument)!=STATUS_OK)
			{
				DEBUGL1("CFolder::CreateThread: -Unable to start the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL8("CFolder::CreateThread: -Thread started successfully\n");
			if(threadID->Detach()!=STATUS_OK)
			{
				DEBUGL1("CFolder::CreateThread: -Unable to detach the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL8("CFolder::CreateThread: -Thread detached successfully\n");
		}

                return STATUS_OK;
            }
            void CFolder::ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid)
            {
                DEBUGL1("CFolder::ErrorFileCreation: Entered \n");
                Status retStatus;
				CString sCurrDirPath = Utility::GetTmpPath();
                FilePtr fPtr = NULL;
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> binFolder = NULL;

                //Create a file indicating the Status to be not Status Ok
                binFolder= ci::operatingenvironment::Folder::Bind(sCurrDirPath);
                if(!binFolder)
                    DEBUGL2("CFolder::ErrorFileCreation::Folder Binding Failed\n");
                fPtr = File::CreateFile(filename,binFolder,"w");
                if(fPtr)
                    DEBUGL8("CFolder::ErrorFileCreation::File Created Successfully\n");

                if(shmpid) {
                    retStatus = shmpid->Destroy();
                    if(retStatus!=STATUS_OK)
                        DEBUGL2("CFolder::ErrorFileCreation: Failed to Destroy Shared Segment Cut Prog Name \n");
                }
            }

            /**
             * create document instance on the container
             * the name of document is least number of non-exist documents. 
             * @param[out] doc - instance of Document class 
             * @param[in/out] documentname - on input, it is document name expected by 
             *                                users. on output, it's created document 
             *                                name. if document has the same name
             *                                exists, suffix will be added.
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure,
             *         STATUS_DISK_FULL if there is not enough space on the disk.
             *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the resource limit is reached
             */
			Status CFolder::CreateDocument(DocumentRef& doc, CString &documentname)
			{
				Status rst;
				Status sdf;
				doc = NULL;
				DEBUGL4("CFolder::CreateDocument::Enter - documentname<%s>\n",documentname.c_str());		
				// confirm documentname is NOT empty
				if(documentname == "") 
				{
					DEBUGL1("CFolder::CreateDocument::Document name is empty\n");
					return STATUS_FAILED;
				}

				bool bHasAvailableSize = false;
				Status ret = Utility::IsStorageFull(bHasAvailableSize);
				if(ret != STATUS_OK)
				{
					DEBUGL1("CFolder::CreateDocument:: IsStorageFull() API failed for /storage \n");
					return STATUS_FAILED;
				}
				else
				{
					if(!bHasAvailableSize)
					{
						DEBUGL1("CFolder::CreateDocument:: /storage is near full return STATUS_DISK_FULL\n");
						return STATUS_DISK_FULL;
					}
				}
				// RAII to enter Critical Section
				// confirm documentname folder exists
				CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName) + "/";
				CString uniqFileName;
				if(Utility::GetUniqueFile(path,uniqFileName) != STATUS_OK)
				{
					DEBUGL1("proputils::CreateFile:: GetUniqueFile failed\n");
					return STATUS_FAILED;		
				}
				CriticalSectionRef cs = new CriticalSection(uniqFileName);

				std::vector<CString> docVec;
				if(Utility::GetCollectionList(docVec,path)!=STATUS_OK) 
				{
					DEBUGL1("CFolder::CreateDocument::GetCollectionList failed\n");
					return STATUS_FAILED;
				}

				int docCount = docVec.size();			

				if((m_BoxBasePath == "/storage/box/PageLogBoxes")&&( docCount >= CBoxDocument::PAGELOGBOX_DOC_LIMIT))
                {
                    DEBUGL1("CFolder::CreateDocument:: The number of documents reached max limit is reached for pagelogboxes\n");
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
		}
				if ((m_BoxBasePath == "/storage/box/FaxRxPreviewBoxes") && (docCount >= CBoxDocument::FAXRXPREVIEWBOX_DOC_LIMIT))
				{
					DEBUGL1("CBox::CreateDocument:: The number of documents reached max limit for %s\n",m_BoxBasePath.c_str());
					return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
				}
                if((m_BoxBasePath != "/storage/box/ITUTBoxes") &&(m_BoxBasePath != "/storage/box/PageLogBoxes") && (m_BoxBasePath != "/storage/box/FaxRxPreviewBoxes")&&( docCount >= CBoxDocument::DOC_LIMIT))
                {
                    DEBUGL1("CFolder::CreateDocument:: The number of documents reached max limit for %s\n",m_BoxBasePath.c_str());
                    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
                }

                CString newpath = path + documentname + "/";
                if(Utility::ResourceExist(newpath)) 
                {
                    // if the document name already exists get the next available document Number
                    uint docnum = 1;
                    std::ostringstream strm;
                    // if documentname folder exist, add suffix to path
                    while(true) 
                    {
                        strm.str("");
                        strm << std::setfill('0') << std::setw(3) << docnum;
                        newpath = path + documentname + "-" + strm.str() + "/";
                        if(!Utility::ResourceExist(newpath)) 
                        {
                            documentname = documentname + "-" + strm.str();
                            break;
                        }
                        docnum++;
                    }
                }
				try
				{
					doc = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,m_FolderName, documentname);
					if(!doc)
					{
						DEBUGL1("CFolder::CreateDocument: doc object is null\n");
						return STATUS_FAILED;
					}
					// create document folders and status file
					ret = dynamic_cast<CDocument*>(doc.operator->())->Initialize();
					if(ret != STATUS_OK) 
					{
						DEBUGL1("CFolder::CreateDocument::Document initialization is failed\n");
						doc = NULL; // release
						rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::CreateDocument: Failed to remove half created document\n");
						return ret;
					}
					dom::DocumentRef domDocRef;
					ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
					pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
					if (!pHDB)
					{
						DEBUGL1("CFolder::CreateDocument: Failed to Acquire HierarchicalDB\n");
						return STATUS_FAILED;
					}

					//Create documentproperties_dom from bin path
					Status ds = pHDB->CreateDocumentFromFile(path+"/"+documentname, "documentproperties_dom", domDocRef, Utility::GetEB2ROOTPath() + "/bin/documentproperties.xml");
					if(ds != STATUS_OK)
					{
						DEBUGL1("CFolder::CreateDocument::Creation of %s Failed\n", path.c_str());
						rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
						if(rst != STATUS_OK)
							DEBUGL1("CFolder::CreateDocument: Failed to remove half created document\n");

						return ds;
					}

					// Save WebDAV properties
					ret = dynamic_cast<CDocument*>(doc.operator->())->SaveProperties();
					if(ret != STATUS_OK) 
					{
						DEBUGL1("CFolder::CreateDocument::SaveProperties failed\n");
						doc = NULL; // release
						rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
						if(rst != STATUS_OK)
							DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created document\n");
						return ret;
					}
				}
				catch(exception &e)
				{
					DEBUGL1("CBoxDocument::CreateBox: caught exception (%s)\n", e.what());
					return STATUS_FAILED;
				}
				CString xmlfile("documentproperties.xml");
				std::map<CString,CString > PropertyMap;
				PropertyMap.clear();
				PropertyMap.insert(pair::value_type("totalDocSize", "0"));
				sdf = Utility::SetProperties(newpath, xmlfile,PropertyMap);
				if(sdf != STATUS_OK)
				{
					if(sdf == STATUS_DISK_FULL)
					{
						DEBUGL1("CFolder::CreateDocument::SetProperty failed because Disk is Full\n");
						doc = NULL; // release
						rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
						if(rst != STATUS_OK)
							DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created document\n");
						return STATUS_DISK_FULL;
					}
					DEBUGL1("CFolder::CreateDocument::SetProperty Failed\n");
					doc = NULL; // release		
					rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
					if(rst != STATUS_OK)
						DEBUGL1("CBoxDocument::CreateBox: Failed to remove half created document\n");

					return STATUS_FAILED;
				}
				/*Generate UUID and save it in documentproperties.xml.This UUID can be used as the name of the Document in Workspace or Clipboard.*/
				CString WorkspaceDocName = CUUID().toString();
				sdf = proputils::SetProperty(m_BoxBasePath, m_BoxNumber, m_FolderName, documentname, "", "WorkspaceDocName", WorkspaceDocName);
				if(sdf != STATUS_OK)
				{
					rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName + "/" + documentname);
					if(rst != STATUS_OK)
						DEBUGL1("CFolder::CreateDocument: Failed to remove half created document\n");

					doc = NULL; //release
					if(sdf == STATUS_DISK_FULL)
					{
						DEBUGL1("CFolder::CreateDocument : Failed to set the property because disk is full\n");
						return STATUS_DISK_FULL;
					}
					DEBUGL1("CFolder::CreateDocument : Failed to set the property\n");
					return STATUS_FAILED;
				}


				DEBUGL4("CFolder::CreateDocument::Exit\n");		
				return STATUS_OK;
			}

            /**
             * delete document
             * document status will be changed to DELETING. after that, document will
             * be deleted. 
             * if document status is NOT READY or EDITING, it will fail.
             * @param[in] documentname - serial number from "00000".
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure.
             */
            Status CFolder::DeleteDocument(CString documentname)
            {
                DEBUGL8("CFolder::DeleteDocument::Enter\n");
                
                CString Path = m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName + "/" + documentname + "/";
                if(!Utility::ResourceExist(Path))
                {
                    DEBUGL2("CFolder::DeleteDocument::Document<%s> not found\n",documentname.c_str());
                    return STATUS_RESOURCENOTFOUND;
                }

                // Check Document Status
                DocStatus st;
                if(Utility::GetStatus(m_BoxBasePath, m_BoxNumber, m_FolderName, documentname, st)!=STATUS_OK)
                {
                    DEBUGL1("CFolder::Delete : Failed to get document status\n");
                    return STATUS_FAILED;							
                }
                

                CString session;
                if(Utility::GetProperty(m_BoxBasePath  + "/" + m_BoxNumber + "/" + m_FolderName + "/" + documentname, "documentproperties.xml", "sessionID", session)!=STATUS_OK)
                {
                    DEBUGL1("CFolder::DeleteDocument: Obtaining session id failed\n");
                    //Check if save is in progress.. if so return STATUS_USER_USING
                    CString savefilenam = "";
                    if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber  + "/" + m_FolderName, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                        DEBUGL2("CFolder::DeleteDocument: Unable to get the file\n");

                    DEBUGL8("CFolder::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                    if(!savefilenam.empty())
                    {
                        DEBUGL1("CFolder::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                        return STATUS_USER_USING;
                    } 
                    return STATUS_FAILED;
                }
                DEBUGL8("CBox::DeleteDocument:: document sessionid (%s) current session id (%s)\n", session.c_str(), m_sessionID.c_str());			

                //If document sessionid and current session id are same then allow editing document to delete.
                //If both are in different, then dont allow editing document to delete
                if(session == m_sessionID)
                {
                    // if NOT (READY or EDITING or CREATING)
                    if(!((st == READY) || (st == EDITING) || (st == CREATING))) 
                    {
                        DEBUGL1("CFolder::DeleteDocument::Document Status is not READY, EDITING\n");
                        return STATUS_FAILED;
                    }
                } 
                else if(session != m_sessionID) 
                {
                    // if NOT (READY)
                    if(!(st == READY))
                    {
                        DEBUGL1("CFolder::DeleteDocument::Document Status is not READY\n");
                        if(st == EDITING)				
                            return STATUS_USER_EDITING;
                        else if(st == USING || st == RESERVING)
                            return STATUS_USER_USING;
                        else 
                            return STATUS_FAILED;
                    }	

                    else
                    {
                        CString savefilenam = "";
                        if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                            DEBUGL2("CFolder::DeleteDocument: Unable to get the file\n");

                        DEBUGL8("CFolder::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());

                        if(!savefilenam.empty())
                        {
                            DEBUGL1("CFolder::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                            return STATUS_USER_USING;
                        }
                    }
                }

                Status ds;
                if(st!=DELETING)
                {	
                    if(Utility::ChangeStatus(m_BoxBasePath, m_BoxNumber, m_FolderName, documentname, DELETING) != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::Delete : Failed to change document status to DELETING\n");
                        return STATUS_FAILED;
                    }
                }	

                CString path = Utility::GetResourcePath(m_BoxBasePath, 
                        m_BoxNumber,
                        m_FolderName,
                        documentname) + "/";
                uint64 tempsize = 0;
                CString val;
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,m_FolderName,documentname,"","totalDocSize", val)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                    return STATUS_FAILED;
                }
                tempsize = val.length()? atoi(val.c_str()): 0;

                //*******************fix for dtfr-8232*********************************
                //Create unique file to indicate name of document that is being deleted.
                //This unique file is checked for each time boxdocument is initialized.
                //If the unique file is present then the partially deleted document(document 
                //that was being deleted before machine was turned off) is deleted.
		CString uniqueFileId = ".delete_" + documentname + "_";
                if(Utility::CreateUniqueFile(m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName + "/", &uniqueFileId) != STATUS_OK)  //fix for EBX_DTFR_17238
                    DEBUGL2("CFolder::Delete: Unable to create the unique file\n");

                // delete whole folder
                ds = ci::operatingenvironment::Folder::Remove(path.c_str(),true);
                if(ds != STATUS_OK) {
                    DEBUGL1("CDocument::Delete : DeleteResource %s is failed\n", path.c_str());
                    return ds;
                }
		if(ds==STATUS_OK)
                {
			// When CreateUniqueFile is called(Line No: 4079) , "uniqueFileId" is updated with the absolute path of the document that has to be deleted 
			// Deletion of UniqueFile is called immediately after Folder::Remove so as to ensure that Unique file is deleted even incase of abrupt shutdown
			if((ci::operatingenvironment::File::DeleteFile(uniqueFileId))!=STATUS_OK)
				DEBUGL2("CFolder::Delete: Unable to delete the %s unique file\n",uniqueFileId.c_str());
                }
                uint64 size;
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", val) != STATUS_OK)
                {
                    DEBUGL1("CDocument::Delete : Failed to get the property\n");
                    return STATUS_FAILED;							
                }
                size = val.length()? atoi(val.c_str()): 0;
                size -= tempsize;
                std::ostringstream boxsize;
                boxsize << size;

                Status sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", boxsize.str());
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::Delete : Failed to set the property because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::Delete : Failed to set the property\n");								
                    return STATUS_FAILED;							
                }
                DEBUGL4("CFolder::DeleteDocument::Exit\n");		
                return STATUS_OK;
            }


            /**
             * delete document
             * document status will be changed to DELETING. after that, document will
             * be deleted. 
             * if document status is NOT READY or EDITING, it will fail.
             * @param[out] progress - user can get operation progress from this.
             * @param[in] documentname - serial number from "00000".
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure.
             */
            Status CFolder::DeleteDocument(ProgressRef& progress,CString documentname)
            {
                DEBUGL4(" CFolder::DeleteDocument()-- Entered Progress Updation \n ");

                Status pRetValue = STATUS_OK;
                //Generate a name for creating Shared memory
                CString deletedocProgShmName = CUUID().toString(); 
                m_DeleteDocErrfile = CUUID().toString();
                // Check Document Status
                DocStatus st;
                if(Utility::GetStatus(m_BoxBasePath, m_BoxNumber, m_FolderName, documentname, st)!=STATUS_OK)
                {
                    DEBUGL1("CFolder::Delete : Failed to get document status\n");
                    return STATUS_FAILED;							
                }
                CString session;
                if(Utility::GetProperty(m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName + "/" + documentname, "documentproperties.xml", "sessionID", session)!=STATUS_OK)
                {
                    DEBUGL1("CFolder::DeleteDocument: Obtaining session id failed\n");
                    //Check if save is in progress.. if so return STATUS_USER_USING
                    CString savefilenam = "";
                    if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber  + "/" + m_FolderName, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                        DEBUGL2("CFolder::DeleteDocument: Unable to get the file\n");

                    DEBUGL8("CFolder::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                    if(!savefilenam.empty())
                    {
                        DEBUGL1("CFolder::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                        return STATUS_USER_USING;
                    } 
                    return STATUS_FAILED;
                }
                DEBUGL8("CFolder::DeleteDocument:: document sessionid (%s) current session id (%s)\n", session.c_str(), m_sessionID.c_str());			

                //If document sessionid and current session id are same then allow editing document to delete.
                //If both are in different, then dont allow editing document to delete
                if(session == m_sessionID)
                {
                    // if NOT (READY or EDITING)
                    if(!((st == READY) || (st == EDITING))) 
                    {
                        DEBUGL1("CFolder::DeleteDocument::Document Status is not READY, EDITING\n");
                        return STATUS_FAILED;
                    }
                } 
                else if(session != m_sessionID) 
                {
                    // if NOT (READY)
                    if(!(st == READY)) 
                    {
                        DEBUGL1("CFolder::DeleteDocument::Document Status is not READY\n");
                        if(st == EDITING)				
                            return STATUS_USER_EDITING;
                        else if(st == USING || st == RESERVING)
                            return STATUS_USER_USING;
                        else 
                            return STATUS_FAILED;
                    }
                    else
                    {
                        CString savefilenam = "";
                        if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber + "/" + m_FolderName, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                            DEBUGL2("CFolder::DeleteDocument: Unable to get the file\n");

                        DEBUGL8("CFolder::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());

                        if(!savefilenam.empty())
                        {
                            DEBUGL1("CFolder::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                            return STATUS_USER_USING;
                        }
                    }
                }
                if(st!=DELETING)
                {	
                    if(Utility::ChangeStatus(m_BoxBasePath, m_BoxNumber, m_FolderName, documentname, DELETING) != STATUS_OK) 
                    {
                        DEBUGL1("CFolder::Delete : Failed to change document status to DELETING\n");
                        return STATUS_FAILED;
                    }
                }	

                //Create an instance of CProgress	
                m_cprogress = new CProgress(deletedocProgShmName,m_DeleteDocErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,m_FolderName,".deleteDiskFullFold_");
                if(!m_cprogress)
                {
                    DEBUGL1(" CFolder::DeleteDocument()-- Creating an instance of Progress failed \n");
                    return STATUS_FAILED;
                }
                m_DelDocProgShmName = deletedocProgShmName;
                //Create shared memory to store the progress of delete operation
                m_prgShmid = SharedMemory::Create(deletedocProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false); 
                //Create an instance of the invoking Object
                //CFolder deldocObj = (CFolder)*this;			
                pRetValue = CreateDeleteDocumentThread(this,documentname);
                if(pRetValue!=STATUS_OK)
                {
                    DEBUGL1(" CFolder::DeleteDocument()-- Creating Cut thread Failed \n");
                    return pRetValue;
                }

                progress = m_cprogress;
                return STATUS_OK;
            }

            Status CFolder::CreateDeleteDocumentThread(CFolder* docelemObj, CString documentname )
            {
                Status pRetVal;
                m_ThreadID = NULL;
                //unique name given for locking the resource
                CString lockpath="lockingBoxDocumentDeleteDocthread";

                // enter critical section
                GlobalMutexRef threadMutex = NULL;	
                pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1(" CFolder::CreateDeleteDocumentThread()-- User has Locked the resource please retry...\n ");
                    return STATUS_FAILED;

                }
                //Copy the input parameter into their respective static variable
                m_DelDoc= documentname;
                //Flag set to 1 untill the inputs are copied into local variables in the Started Thread		
                //m_DelDocFlag = FLAG_SET;
                pRetVal = CreateThread(StartDeleteDocumentThread,reinterpret_cast<void*>(docelemObj),m_ThreadID);

                if(pRetVal !=STATUS_OK)
                    DEBUGL1(" CFolder::CreateDeleteDocumentThread()-- Could not Create a Thread\n");
                else
                    DEBUGL8(" CFolder::CreateDeleteDocumentThread()-- Creation of thread Initiated\n");
               //exit criticalsection
                pRetVal = Utility::LeaveCriticalSection(threadMutex);
                if(pRetVal !=STATUS_OK)
                {
                    DEBUGL1(" CFolder::CreateDeleteDocumentThread()--Releasing the Locked Resource Failed\n ");
                    return STATUS_FAILED;		
                }
                return pRetVal;
            }

            void* CFolder::StartDeleteDocumentThread(void *arg)
            {
                DEBUGL4(" CFolder::StartDeleteDocumentThread()-- Started \n");
                Status sdf;
                //unique name given for locking the resource
                CString threadlockpath ="lockingBoxDocStartDeleteDocThread";
                //Copy the passed instance of the invoking object into a local variable 
                CFolder* deldocObj = ((CFolder*)arg);
               //Copy the inputs from static variable into a local variable 
                CString documentname = m_DelDoc;
                //Create Shared memory used for writing the updated progress in it
                void *pDeleteDocumentMapAddr;
                //deleteDocshmPid = SharedMemory::Create(deldocObj.m_DelDocProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
                if(!deldocObj->m_prgShmid)
                {
                    DEBUGL1(" CFolder::StartDeleteDocumentThread()  -- Failed to Create Shared Memory for Delete Document Progress Name \n ");
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                    //m_DelDocFlag = FLAG_RESET;
                    return NULL;
                }
                else
                {
                    int iShmPidSize = deldocObj->m_prgShmid->getSize();
                    //Map the Created Segment to another address
                    deldocObj->m_prgShmid->Map(pDeleteDocumentMapAddr);
                    if(pDeleteDocumentMapAddr!=NULL)
                    {
                        memset(pDeleteDocumentMapAddr,0,iShmPidSize);
                    }
                    else
                    {
                        DEBUGL1(" CFolder::StartDeleteDocumentThread() -- Mapping Failed for Delete Document Progress Name\n");
                        deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                        //m_DelDocFlag = FLAG_RESET;
                        return NULL;
                    }
                }
               //set the initial value of DeleteDocument progress as 1% . The Start DeleteDocument 
                //thread will update it as and when the operation progresses 
                *((int*)pDeleteDocumentMapAddr) = 1;	


                // Start to Delete
                int count=1;
                int numRes = 1;
                CString path = Utility::GetResourcePath(deldocObj->m_BoxBasePath, 
                        deldocObj->m_BoxNumber,
                        deldocObj->m_FolderName,
                        documentname) + "/";
                CString deletepath = Utility::GetResourcePath(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber, deldocObj->m_FolderName) + "/";
                uint64 tempsize = 0;
                //CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"",documentname) + "/";
                CString val;
                if(proputils::GetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,deldocObj->m_FolderName,documentname,"","totalDocSize", val)!=STATUS_OK)
                {
                    DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                    //Create a file indicating the Status to be not Status Ok			
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                    return NULL;
                }
                tempsize = val.length()? atoi(val.c_str()): 0;
                //Create unique file to indicate name of document that is being deleted.This unique file is checked for each time boxdocument is initialized.If the unique file is present then the partially deleted document(document that was being deleted before machine was turned off) is deleted.
                /***************************************************fix for dtfr-8232**************************************************/
		CString uniqueFileId = ".delete_" + documentname + "_";
                if(Utility::CreateUniqueFile(deldocObj->m_BoxBasePath + "/" + deldocObj->m_BoxNumber + "/" + deldocObj->m_FolderName + "/", &uniqueFileId) != STATUS_OK)  //fix for EBX_DTFR_17238
                    DEBUGL2("CFolder::StartDeleteDocumentThread: Unable to create the unique file\n");

                // delete whole folder
                Status ds = ci::operatingenvironment::Folder::Remove(path.c_str(),true);
                if(ds != STATUS_OK) {
                    DEBUGL1("CDocument::Delete : DeleteResource %s is failed\n", path.c_str());
                    //Create a file indicating the Status to be not Status Ok			
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		

                    return NULL;
                }
		if(ds == STATUS_OK)
		{
			// When CreateUniqueFile is called(Line No: 4337) , "uniqueFileId" is updated with the absolute path of the document that has to be deleted 
			// Deletion of UniqueFile is called immediately after Folder::Remove so as to ensure that Unique file is deleted even incase of abrupt shutdown
			if((ci::operatingenvironment::File::DeleteFile(uniqueFileId))!=STATUS_OK)
				DEBUGL2("CFolder::Delete: Unable to delete the %s unique file\n",uniqueFileId.c_str());
		}


                uint64 size;
                //propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
                if(proputils::GetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,"","","","totalBoxSize", val) != STATUS_OK)
                {
                    DEBUGL1("CDocument::Delete : Failed to get the property\n");
                    //Create a file indicating the Status to be not Status Ok			
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);				
                    return NULL;							
                }
                size = val.length()? atoi(val.c_str()): 0;
                size -= tempsize;
                std::ostringstream boxsize;
                boxsize << size;

                sdf = proputils::SetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,"","","","totalBoxSize", boxsize.str());
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::Delete : Failed to set the property because Disk is Full\n");
                        DEBUGL8("CFolder::Delete : savepath = (%s)\n", deletepath.c_str());
                        if(Utility::CreateUniqueFile(deletepath, ".deleteDiskFullFold_" + deldocObj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CFolder::StartDeleteDocumentThread: Unable to create the file\n");
                        deldocObj->m_prgShmid = NULL;
                        return NULL;

                    }
                    DEBUGL1("CDocument::Delete : Failed to set the property\n");
                    //Create a file indicating the Status to be not Status Ok			
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);				
                    return NULL;							
                }

                //Update Progress
                int curProg = (int)((((float)count++)/((float)numRes))*100);
                *((int*)pDeleteDocumentMapAddr) = PROGRESS_COMPLETED;				//end of the DeleteDocument Thread..It has to be 100%
                deldocObj->m_prgShmid = NULL;
                DEBUGL8("CFolder::StartDeleteDocumentThread::Current Progress<%d>\n",curProg);

                DEBUGL4("\n CFolder::StartDeleteDocumentThread: Exit\n");	
                return NULL;
            }

            /**
             * Undo the cut/copy document operation
             * @param[in] docname - source document name
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure,
             */
            Status CFolder::UndoEditDocument(CString docname)
            {
                DEBUGL8("CFolder::UndoEditDocument: Enter and Document Name is <%s>\n",docname.c_str());
                CString xmlfile = "documentproperties.xml";
                std::map<CString, CString> PropertyMap;
                PropertyMap.insert(pair::value_type("sessionID",""));
                PropertyMap.insert(pair::value_type("cutDocument",""));	
                //Get the resource path.
                CString dpath =Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,m_FolderName,docname)+"/";	
                //clear the flags that are set during cut or Copy document operation
                Status sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap);
                if(sdf!=STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CFolder::UndoEditDocument:SetProperties failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CFolder::UndoEditDocument:SetProperties Failed\n");
                    return STATUS_FAILED;
                }
                return STATUS_OK;
            }

            /**
             * Undo the cut/copy document operation
             * @param[in] documents - source document names     
             * @return STATUS_OK on success,
             *         STATUS_FAILED on failure,
             */
            Status CFolder::UndoEditDocument(std::vector<CString> documents)
            {
                CString dpath;
                CString docname;
                std::vector<CString>::iterator iter;
                //clear the flags that are set during cut or Copy document operation
                for(iter=documents.begin();iter!=documents.end();iter++)
                {
                    docname = (*iter);
                    if(UndoEditDocument(docname)!=STATUS_OK)
                    {
                        DEBUGL1("CFolder::UndoEditDocument:Failed for Document <%s>\n",docname.c_str());
                        return STATUS_FAILED;
                    }
                    else
                        DEBUGL8("CFolder::UndoEditDocument:Document <%s> properties Reset sucessfully\n",docname.c_str());

                } 
                return STATUS_OK;
            }

            Status CFolder::GetDocumentPropertiesList(DocumentPropertiesList &list)
            {
                return STATUS_OK;
            }

            Status CFolder::GetDocumentPropertiesList(DocumentPropertiesList &list, 
                    unsigned int from, unsigned int size)
            {
                DEBUGL4("CViewBox::GetDocumentPropertiesList::Enter\n");

                std::vector<CString> vec;
                CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber,m_FolderName) + "/";
                if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
                {
                    DEBUGL1("CViewBox::GetDocumentPropertiesList::Getting collection list is failed");
                    return STATUS_FAILED;
                }
                list.clear();
                try
                {
                    for(unsigned int i = from, cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++) 
                    {
                        CString docName = vec[i];
                        // GetDocument
                        DocumentPropertiesRef document = NULL;
                        document = new CDocumentProperties(m_BoxBasePath, m_BoxNumber,m_FolderName,docName);
                        DocStatus st;
                        if(!document)
                        {
                            DEBUGL1("CFolder::GetDocumentPropertiesList: doc object is null\n");
                            return STATUS_FAILED;
                        }
                        Status ret = dynamic_cast<CDocumentProperties*>(document.operator->())->GetStatus(st);
                        if( ret != STATUS_OK || st == DELETING) 
                        {
                            DEBUGL2("CViewBox::GetDocumentPropertiesList::Getting document status failed or document is deleting\n");
                            continue;
                        }
                        list.push_back(document);								
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CViewBox::GetDocumentPropertiesList: caught exception (%s)\n", e.what());
                    return STATUS_FAILED;
                }

                DEBUGL4("CViewBox::GetDocumentPropertiesList::Exit\n");		
                return STATUS_OK;	
            }

    }; // namespace boxdocument
}; // namespace ci

