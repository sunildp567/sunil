/*======================================================================*
 *  (C)Copyright TOSHIBA TEC Corporation 2006. All rights reserved.
 *----------------------------------------------------------------------*/
#ifndef  __VXW_TYPES2_H__
#define  __VXW_TYPES2_H__

/*======================================================================*
 *  Types
 *----------------------------------------------------------------------*/
typedef int               I32;        /* 32bit */
typedef unsigned int      W32;        /* 32bit */
typedef unsigned int      UI32;       /* 32bit */
typedef unsigned int      UW32;       /* 32bit */
typedef char              B;          /* 8bit  */
typedef short int         HI;         /* 16bit */
typedef short             H16;        /* half word (16bit) */
typedef unsigned char     UB;         /* unsigned char */
typedef unsigned short    UH16;       /* unsigned short */

typedef float           F32;        /*　浮動小数点数（32bit） */
typedef double          D64;        /*　浮動小数点数（64bit） */


/* -------------------------------------------------------------------- */

#endif	/* __VXW_TYPES2_H__ */





