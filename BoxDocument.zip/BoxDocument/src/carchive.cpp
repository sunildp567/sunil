/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: carchive.cpp
 Revision: com_t#1
 File Spec: EBX:TA8447.A-DEV_SRC;com_t#1
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:55:24

  Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#1 (APPROVED)
     Created:  09-JAN-2009 21:55:24      CHANDRAMOHAN.PUJARI
       Intial Version
========================== End of Source Header =============================*/
#include <vector>
#include <algorithm>
#include <utility>
#include <status.h>
#include <CI/SystemInformation/systeminformation.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/Codecs/zip.h>
#include "carchive.h"
#include "cdocument.h"
#include "cpage.h"
#include <iomanip>
#include <sstream>
#include "proputils.h"

using namespace ci::boxdocument;
using namespace ci::hierarchicaldb;
using namespace ci::operatingenvironment;
using namespace ci::codecs;
#define EFBPASS "EFB@arc_ext#pass18"
#define LENOVO_EQUIPMENT_BRAND "Lenovo Digital MFC"
#define OKI_EQUIPMENT_BRAND "OKI MFP Series"

using namespace std;

namespace ci {
namespace boxdocument {

	bool CArchiver::m_ArchiveFlag;
	/* Param c'tor */
	CArchiver::CArchiver(CString sessionID, CString archivedpath,std::vector<CString>documentpaths, std::vector<CString> documentlist)
	{
		//Initialise variables
		m_sessionID = sessionID;
		m_ArchivePath = archivedpath;
		m_Documentpaths=documentpaths;
		m_Documentlist=documentlist;
		m_ArchiveStatus=READY;
		m_ArchiveProgress = 0;
		std::vector<CString>::iterator it;
		it=m_Documentpaths.begin();
		m_BoxBasePath = (*it);
		it = it + 1;
		m_BoxNumber = (*it);
		it = it + 1;
		m_FolderName= (*it);	
		m_pProgressShmName = "";
		m_pStatusShmName = "";
		m_ThreadId = NULL;
	}

    /* Destructor */
    CArchiver::~CArchiver() 
    {
      if(m_pStatusShmName.size()) 
      {
         ArchiveStatus sts;
         GetStatus(sts);
         DEBUGL6("CArchiver::~Carchiver::Status is %d\n",sts);
      }
      if(m_pProgressShmName.size())
      {
         int progress;
         GetProgress(progress);
         DEBUGL6("CArchiver::~Carchiver::Progress is %d\n",progress);
      }
    }
    
    /**
     * get archiving status
     * @param[out] status - archiving status
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CArchiver::GetStatus(ArchiveStatus &status)
	{
		void *pMapAddr;

		//Update to previous Status value
		status = m_ArchiveStatus;	
		
		// Bind to shared mem
		CString pShmName = m_pStatusShmName;
		DEBUGL8("CArchiver::GetStatus::Shared memory name is %s\n",pShmName.c_str());
		Ref<SharedMemory> bBindshmName = SharedMemory::Bind(pShmName.c_str());
		if(!bBindshmName)
		{
         switch(m_ArchiveStatus) {
            case Archiver::READY:
            case Archiver::ARCHIVING: 
                     break;
            default:
               return STATUS_OK;
         }
         DEBUGL1("CArchiver::GetStatus::Binding to Shared memory Failed, Current Status <%d>\n",status);
			return STATUS_FAILED;					
		}
		bBindshmName->Acquire();

		bBindshmName->Map(pMapAddr);
		if(pMapAddr==NULL)
		{
			DEBUGL1("CArchiver::GetStatus::Mapping Failed - Current Status is %d\n",status);
         bBindshmName = NULL;
			return STATUS_FAILED;
		}
		status= *((ArchiveStatus*)pMapAddr);
		m_ArchiveStatus = status;
      bBindshmName->Unmap(pMapAddr);
      bBindshmName->Release();
		DEBUGL6("CArchiver::GetStatus::Status is - %d\n",status);

		switch (m_ArchiveStatus){
			case Archiver::CREATED: 
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::CREATED\n");			
				bBindshmName->Destroy();
				return STATUS_OK;									
			case Archiver::CANCELED:
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::CANCELED\n");			
				bBindshmName->Destroy();
				return STATUS_OK;									
			case Archiver::CANCEL_INITIATED:
				//As the archiving is in progress so during cancel process we are returning as archiving [Archiver::ARCHIVING]
				status=Archiver::ARCHIVING;
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::CANCEL_INITIATED\n");			
				bBindshmName = NULL;
				return STATUS_OK;								
			case Archiver::READY:	
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::READY\n");			
        			bBindshmName = NULL;
				return STATUS_OK;									
			case Archiver::ARCHIVING:
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::ARCHIVING\n");			
         			bBindshmName = NULL;
				return STATUS_OK;									
			case Archiver::ERROR:
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::ERROR\n");			
				bBindshmName->Destroy();
				return STATUS_OK;									
			case Archiver::DISK_FULL:
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::DISK_FULL\n");			
				bBindshmName->Destroy();
				return STATUS_OK;									
			case Archiver::ARCHIVE_SIZE_ERROR:
				DEBUGL1("CArchiver::GetStatus:: Set Archiver::ARCHIVE_SIZE_ERROR\n");			
				bBindshmName->Destroy();
				return STATUS_OK;									
			default: //do nothing
		}	
      		bBindshmName = NULL;
		return STATUS_OK;
	}
    
    /**
     * get archiving progress
     * @param[out] progress - archiving progress [0-100] %
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CArchiver::GetProgress(int &progress)
	{
		void *pMapAddr;

		//Update to previous progress value
		progress = m_ArchiveProgress;

		// Bind to shared mem
		CString pShmName = m_pProgressShmName;
		DEBUGL8("CArchiver::GetProgress::Shared memory name is %s\n",pShmName.c_str());
		Ref<SharedMemory> bBindshmName = SharedMemory::Bind(pShmName.c_str());
		if(!bBindshmName)
		{
	      		if(PROGRESS_COMPLETED == m_ArchiveProgress) return STATUS_OK; //on 100% sharedmemory was deleted. so don't bind again. Just keep returning 100%..
				DEBUGL1("CArchiver::GetProgress::Binding to Shared memory Failed, Current Progress <%d>\n",progress);				
			return STATUS_FAILED;					
		}
      
	        bBindshmName->Acquire();
		bBindshmName->Map(pMapAddr);
		if(pMapAddr==NULL)
		{
			DEBUGL1("CArchiver::GetProgress::Mapping Failed\n");
         		bBindshmName = NULL;
			return STATUS_FAILED;
		}
		progress = *((int*)pMapAddr);
		m_ArchiveProgress = progress;
      		bBindshmName->Unmap(pMapAddr);
      		bBindshmName->Release();
		DEBUGL6("CArchiver::GetProgress::progress - %d\n",progress);
      		if(PROGRESS_COMPLETED == progress || m_ArchiveStatus == Archiver::CANCELED) {
         		DEBUGL6("CArchiver::GetProgress: Progress is 100%. Destroying Progress SharedMemory %s\n", pShmName.c_str());
         		bBindshmName -> Destroy();
      		}
		bBindshmName = NULL;
      		DEBUGL8("CArchiver::GetProgress::progress - %d\n",progress);
		return STATUS_OK;
	}

    
    /**
     * get a path of created archive
     * @param[out] path - archive path
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CArchiver::GetPath(CString &path)
	{
		path = m_ArchivePath;
		return STATUS_OK;
	}
    
    /**
     * cancel to archive
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CArchiver::Cancel()
	{
		DEBUGL4("CArchiver::Cancel::Enter\n");
	
		DEBUGL8("CArchiver::Cancel::Clean up process initiated\n");
		CArchiver *carchiverobj = this;

		std::vector<CString>::iterator docIter;
		std::vector<CString> documentlist = carchiverobj->m_Documentlist;
		std::vector<CString> documentpaths = carchiverobj->m_Documentpaths;
		CString boxbasepath = carchiverobj->m_BoxBasePath;
		CString boxNumber = carchiverobj->m_BoxNumber;
		CString folderName = carchiverobj->m_FolderName;	
      		DocumentRef doc;
      		Status ret;
		int cancelThreadRetryCnt = 10000;

		//Initialize the pStatusShmid
		//If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetStaus() API 
		bool bCreated;
		Ref<SharedMemory> pStatusShmid = SharedMemory::Bind(m_pStatusShmName.c_str(), SHM_CREATE_IF_BIND_FAILS|SHM_NO_AUTO_DESTROY, bCreated, UUID_CONTENT_LENGTH);
		if(!pStatusShmid)
		{
			DEBUGL1("CArchiver::Cancel: Failed to Create Status Shared Memory\n ");
			return STATUS_FAILED;
		}
		void *pStatusMapAddr;
		int iStatusShmPidSize = pStatusShmid->getSize();
		pStatusShmid->Map(pStatusMapAddr);
		if(pStatusMapAddr!=NULL)
			memset(pStatusMapAddr,'\0',iStatusShmPidSize);
		else if(pStatusMapAddr == NULL)
		{
			DEBUGL1("CArchiver::Cancel:Shared memory Mapping Failed\n");
			return STATUS_FAILED;
		}
		pStatusShmid->Acquire();
		//Update the status to CANCEL_INITIATED
		*((ArchiveStatus*)pStatusMapAddr) = Archiver::CANCEL_INITIATED;
		DEBUGL1("CArchiver::Cancel: CANCEL_INITIATED is set for Archiver thread to cancel archiving\n");
		pStatusShmid->Release();
		// Clean-up will be done by RevertStatus() in StartArchive()
		//CleanUp of temporary files
		//changed $EB2/tmp path to "/work/ci/tmp/"
		CString tmppath = Utility::GetCITmpPath();
		CString basefolder =  "/storage/box/";
		CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
	   	/*	
		if((folderName).empty())
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
		else
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;
      		*/
		
		//Delete the tmp file containing the size information
		CString tmpFileName = tmppath+"_fileSize";		
		//changed the $EB2/tmp path to "/work/ci/tmp/"
		if(File::DeleteFile(Utility::GetCITmpPath()+tmpFileName)!=STATUS_OK)
				DEBUGL2("CArchiver::Cancel - Could not delete the %s file :: Delete Manually\n",tmpFileName.c_str());

		//Delete the temporary folder holding the archive.xml and document zip's
		CString folderPath = tmppath + "_Zip";	
		if((ci::operatingenvironment::Folder::Remove(folderPath,true))!=STATUS_OK)
			DEBUGL2("CArchiver::Cancel - Could not delete the %s folder :: Delete Manually\n",folderPath.c_str());

		//Check if the status is updated to CANCELED from Archiving thread
		DEBUGL8("CArchiver::Cancel: Archiving status=%d\n",*((ArchiveStatus*)pStatusMapAddr));
		for (int i =0; i < cancelThreadRetryCnt; i++)	{	
			if (*((ArchiveStatus*)pStatusMapAddr) == Archiver::CANCELED || *((ArchiveStatus*)pStatusMapAddr) == Archiver::ERROR || *((ArchiveStatus*)pStatusMapAddr) == Archiver::DISK_FULL || *((ArchiveStatus*)pStatusMapAddr) == Archiver::ARCHIVE_SIZE_ERROR)	{
				DEBUGL1("CArchiver::Cancel: CANCELED is set by archiving thread hence clean up process is started\n");
				break;
			}
			usleep(100000);
		}
		pStatusShmid->Acquire();
		*((ArchiveStatus*)pStatusMapAddr) = Archiver::CANCELED;
		pStatusShmid->Release();
		pStatusShmid->Unmap(pStatusMapAddr);
		pStatusShmid->Destroy();
		pStatusShmid = NULL;		
		
		DEBUGL4("CArchiver::Cancel::Exit\n");		
		return STATUS_OK;
	}
    
    /**
     * delete created archive
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    	Status CArchiver::Delete()
	{
		//To be deprecated
		return STATUS_OK;
	}


	/**	
	*	Function: CreateThread
	* 	Description:
	*		This function creates a thread and that does the archiving job
	*   	@return: Status
	*/		
	Status CArchiver::CreateArchiveThread()
	{
		DEBUGL4("CArchiver::CreateArchiveThread::Enter\n");
	
		Status pRet;
		m_ThreadId = NULL;
		CString lockpath="lockingArchiveThread";
		GlobalMutexRef threadMutex = NULL;

		// enter critical section
		pRet = Utility::EnterCriticalSection(threadMutex, lockpath);
		if(pRet !=STATUS_OK)
		{
			DEBUGL1("\n CArchiver::CreateArchiveThread::User has Locked the resource please retry...\n ");
			return pRet;			
		}
		
		m_pProgressShmName = CUUID().toString();
		m_pStatusShmName = CUUID().toString();

		//Flag set to 1 untill the inputs are copied into local variables in the Started Thread
		m_ArchiveFlag = FLAG_SET;

		CArchiver *m_ArchiverObj = this;
		pRet=CreateThread(StartArchive,reinterpret_cast<void*>(m_ArchiverObj),m_ThreadId);
		if(pRet !=STATUS_OK)
		{
			DEBUGL1("CBox::CreateArchive::Could not Create a Thread\n");
			Utility::LeaveCriticalSection(threadMutex);
			return pRet;
		}
		else
			DEBUGL8("CArchiver::CreateArchiveThread:: Creation of thread Initiated\n");
		
		//Once local variable copied Flag is set to 0 and loop ends		
		while(1)
		{	
			if(m_ArchiveFlag == FLAG_RESET)
			{
				DEBUGL8("CDocument::CreateArchiveThread: -- Flag is Reset <%d> \n",m_ArchiveFlag);	
				break;
			}
			DEBUGL8("CDocument::CreateArchiveThread: -- Flag not reset \n");				
		}

		//exit criticalsection
		pRet = Utility::LeaveCriticalSection(threadMutex);
		if(pRet !=STATUS_OK)
		{
			DEBUGL1("CArchiver::CreateArchiveThread::Releasing the Locked Resource Failed\n ");
			return pRet;			
		}

		DEBUGL4("CArchiver::CreateArchiveThread::Exit\n");
		return pRet;
	}



	/**	
	*	Function: CreateThread
	* 	Description:
	*		This function creates a thread and returns the thread id
	* 	Arguments:
	*		@param1: the function name with which thread is to be created
	*		@param2: the argument to be passed to the function
	*		@param3: the thread id that is returned after the creation of the thread
	* 	Return Values:
	*   	@return: Status
	*/	
	Status CArchiver::CreateThread(ThreadFunction functionName,ThreadArgument functionArgument, Ref<Thread> & threadId)
	{
		DEBUGL4("CArchiver::CreateThread::Enter\n");

		if(!(threadId = Thread::Create(functionName)))
		{
			DEBUGL1("CArchiver::CreateThread::Unable to create the thread\n");
			return STATUS_FAILED;
		}
		else
		{
			m_ThreadId = threadId;
			DEBUGL8("CArchiver::CreateThread::Thread created successfully\n");
			if(threadId->Start(functionArgument)!=STATUS_OK)
			{
				DEBUGL1("CArchiver::CreateThread::Unable to start the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL5("CArchiver::CreateThread::Thread started successfully\n");
			if(threadId->Detach()!=STATUS_OK)
			{
				DEBUGL1("CArchiver::CreateThread: -Unable to detach the Thread!!!\n");
				return STATUS_FAILED;
			}
			else
				DEBUGL8("CArchiver::CreateThread: -Thread detached successfully\n");
		}
				
		DEBUGL4("CArchiver::CreateThread::Exit\n");		
		return STATUS_OK;
	}

	/**
	* StartArchive -Archives the given document list used as a thread routine
	* @param[in] arg - arguments if any
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*         STATUS_DISK_FULL on disk Full.	
	*/
	void* CArchiver::StartArchive(void *arg)
	{
		DEBUGL4("CArchiver::StartArchive::Enter\n");
		Status ret;
		CArchiver *carchiverobj = ((CArchiver*)arg);
		void *pMapAddr;
		void *pStatusMapAddr;

		CString pShmName = carchiverobj->m_pProgressShmName;
		CString pStatusShmName = carchiverobj->m_pStatusShmName;

		DEBUGL8("CArchiver::StartArchive::Progress shared memory name is %s\n",pShmName.c_str());
		//Create the shared memory for progress operation
		//If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetProgress() API		
		Ref<SharedMemory> pProgressShmid = SharedMemory::Create(pShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
		if(!pProgressShmid)
		{
			DEBUGL1("CArchiver::StartArchive: Failed to Create Shared Memory for Progress operation\n ");
         		carchiverobj->RevertStatus(carchiverobj);
         		m_ArchiveFlag = FLAG_RESET;
			return NULL;
		}

		int iShmPidSize = pProgressShmid->getSize();
		pProgressShmid->Map(pMapAddr);
		if(pMapAddr!=NULL)
			memset(pMapAddr,'\0',iShmPidSize);
		else
		{
			DEBUGL1("CArchiver::StartArchive::Shared memory Mapping Failed\n");
         		carchiverobj->RevertStatus(carchiverobj);
         		pProgressShmid -> Destroy();
         		m_ArchiveFlag = FLAG_RESET;
			return NULL;
		}
		DEBUGL8("CArchiver::StartArchive::Status shared memory name is %s \n",pStatusShmName.c_str());
		//Now create Shared memory for Status operation.
		//If object goes out of scope also, shared memory will not be destroyed. It is destroyed in GetStatus() API		
		bool bCreated;
		Ref<SharedMemory> pStatusShmid = SharedMemory::Bind(pStatusShmName.c_str(), SHM_CREATE_IF_BIND_FAILS|SHM_NO_AUTO_DESTROY, bCreated, UUID_CONTENT_LENGTH);
		if(!pStatusShmid)
		{
			DEBUGL1("CArchiver::StartArchive: Failed to Create Shared Memory for Status Operation\n ");
         		carchiverobj->RevertStatus(carchiverobj);
         		pProgressShmid -> Destroy();
         		m_ArchiveFlag = FLAG_RESET;
			return NULL;
		}
		int iStatusShmSize = pStatusShmid->getSize();
		pStatusShmid->Map(pStatusMapAddr);
		if(pStatusMapAddr!=NULL)
			memset(pStatusMapAddr,'\0',iStatusShmSize);
		else
		{
			DEBUGL1("CArchiver::StartArchive::Shared memory Mapping Failed\n");
         		carchiverobj->RevertStatus(carchiverobj);
         		pProgressShmid -> Destroy();
         		pStatusShmid -> Destroy();
         		m_ArchiveFlag = FLAG_RESET;
			return NULL;
		}
		/* Fix for EBX_STFR_18418. Only after both Status & Progress Shared Memory is created reset the flag 
		   So that CreateArchive() will return to the User after both the SharedMemory's are created*/
		m_ArchiveFlag = FLAG_RESET; 
      
      		pStatusShmid->Acquire();
		if (*((ArchiveStatus*)pStatusMapAddr)== Archiver::CANCEL_INITIATED){
			carchiverobj->RevertStatus(carchiverobj);
			*((ArchiveStatus*)pStatusMapAddr)= Archiver::CANCELED;
			DEBUGL2("CArchiver::StartArchive: Found CANCEL_INITIATED so marked CANCELED and exiting archive thread\n");
			pStatusShmid->Release();
			return NULL;
		}
		//Set Archive status to Archiving.
		*((ArchiveStatus*)pStatusMapAddr)= Archiver::ARCHIVING;
      pStatusShmid->Release();
      
		//set the initial value of archive progress as 1%.The thread will update it as and when files are zippied
		*((int*)pMapAddr)=1;

		//Estimate the progress.Get the total size of the documents to be archived
		uint64 size=0;
		std::vector<CString>::iterator docIter;
		std::vector<CString> documentlist = carchiverobj->m_Documentlist;
		std::vector<CString> documentpaths = carchiverobj->m_Documentpaths;
		CString boxbasepath = carchiverobj->m_BoxBasePath;
		CString boxNumber = carchiverobj->m_BoxNumber;
		CString folderName = carchiverobj->m_FolderName;
		DocumentRef doc;
		CString value("");
		uint64 tmpvalue = 0;
		int curProgress = 10;
		*((int*)pMapAddr)=curProgress;
		//Download the documents
		//changed the tmp path from $EB2/tmp to "/work/ci/tmp"
		CString tmppath = Utility::GetCITmpPath(); 
		CString basefolder =  "/storage/box/";
		CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
		CString dPath("");
		int numberOfDocs = documentlist.size();
		int count =1;
      CString path("");
      /*
		if(folderName.empty())
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
		else
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;
		*/
      tmppath += "ArchiveDocument_" + carchiverobj->m_sessionID;
       /******************************Fix for STFR-5241*****************************/
      for(docIter=documentlist.begin();docIter!=documentlist.end();docIter++)
      {
         DEBUGL8("CArchiver::StartArchive - Iterator String val<%s>, Status = %d\n",docIter->c_str(), *((ArchiveStatus*)pStatusMapAddr));
		if (*((ArchiveStatus*)pStatusMapAddr)== Archiver::CANCEL_INITIATED)		{
			carchiverobj->RevertStatus(carchiverobj);
      			pStatusShmid->Acquire();
			*((ArchiveStatus*)pStatusMapAddr)= Archiver::CANCELED;
      			pStatusShmid->Release();
			DEBUGL2("CArchiver::StartArchive: Found CANCEL_INITIATED so marked CANCELED and exiting archive thread\n");
			return NULL;
		}
               if(proputils::GetProperty(boxbasepath,boxNumber,folderName,(*docIter),"","totalSize", value)!=STATUS_OK)
               {
                  DEBUGL1("CArchiver::StartArchive - GetProperty of totalDocSize Failed\n");
                     *((ArchiveStatus*)pStatusMapAddr)=Archiver::ERROR;
                     carchiverobj->RevertStatus(carchiverobj);
                     return NULL;
               }
         std::istringstream totalDocSizeStr(value);
             totalDocSizeStr >> tmpvalue;
               size = size + tmpvalue;
               DEBUGL8("CArchiver::StartArchive - Size of the document %s is %llu\n",(*docIter).c_str(),tmpvalue);
      }
      DEBUGL8("CArchiver::StartArchive - Size of the documents to be archived is %llu\n",size);
      //Limit check here
      const uint64 SIZE_LIMIT = 2147483648UL;
      if(size>=SIZE_LIMIT)
      {
         carchiverobj->RevertStatus(carchiverobj);
         DEBUGL1("CArchiver::StartArchive - Exceeded archive size limit of 2GB\n");
         *((ArchiveStatus*)pStatusMapAddr)=Archiver::ARCHIVE_SIZE_ERROR;
         return NULL;
      }
		std::vector<CString> pTmpvec;
                ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
		CString docPath,imagPath;
		for(docIter=documentlist.begin();docIter!=documentlist.end();docIter++,count++)
		{	
			DEBUGL8("CArchiver::StartArchive - Iterator String val<%s>\n",docIter->c_str());
			#if 0
         if(proputils::GetProperty(boxbasepath,boxNumber,folderName,(*docIter),"","totalDocSize", value)!=STATUS_OK)
			{
				DEBUGL1("CArchiver::StartArchive - GetProperty of totalDocSize Failed\n");					
				*((ArchiveStatus*)pStatusMapAddr)=Archiver::ERROR;
            carchiverobj->RevertStatus(carchiverobj);
            pProgressShmid -> Destroy();
            pStatusShmid = NULL;
				return NULL;
			}
			std::istringstream totalDocSizeStr(value);
			totalDocSizeStr >> tmpvalue;
			size = size + tmpvalue;
			DEBUGL8("CArchiver::StartArchive - Size of the document %s is %llu\n",(*docIter).c_str(),tmpvalue);
			#endif   
		if (*((ArchiveStatus*)pStatusMapAddr)== Archiver::CANCEL_INITIATED)		{
			carchiverobj->RevertStatus(carchiverobj);
      			pStatusShmid->Acquire();
			*((ArchiveStatus*)pStatusMapAddr)= Archiver::CANCELED;
      			pStatusShmid->Release();
			DEBUGL2("CArchiver::StartArchive: Found CANCEL_INITIATED so marked CANCELED and exiting archive thread\n");
			return NULL;
		}
			dPath = tmppath+"_";
			dPath+="Document";
			std::ostringstream oss;
			oss << count;			
			dPath+=oss.str();
			DEBUGL8("CArchiver::StartArchive - Download Path <%s>\n",dPath.c_str());			

			//Copy all Documents to Temp Path.
			path = Utility::GetResourcePath(boxbasepath,boxNumber,folderName,(*docIter));	
			CString tPath = path+"/";
         		dPath +="/"; 
			DEBUGL8("CArchiver::StartArchive path (%s) dPath (%s)\n",tPath.c_str(),dPath.c_str());
			
			ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> tmpFolder=NULL;
			if((ret= ci::operatingenvironment::Folder::CreateFolder(tmpFolder,dPath))!= STATUS_OK)
			{
				DEBUGL1("CArchiver::StartArchive:: Failed to CreateFolder\n");				
            carchiverobj->RevertStatus(carchiverobj);
				if(ret == STATUS_DISK_FULL)
				{
					DEBUGL1("CArchiver::StartArchive:: Cannot create directory, disk is full\n");				
					*((ArchiveStatus*)pStatusMapAddr)=Archiver::DISK_FULL;
				}
				else
					*((ArchiveStatus*)pStatusMapAddr)=Archiver::ERROR;
            //revert the status of the document to using.
            pProgressShmid -> Destroy();
            pStatusShmid = NULL;
				return NULL;
			}
			DEBUGL8("********* CArchiver::StartArchive - Copying ****************\n");
			if((ret = ci::operatingenvironment::Folder::CopyDir(tPath,dPath))!= STATUS_OK)
			{
				DEBUGL1("CArchiver::StartArchive:: Failed to CopyDir\n");				
            carchiverobj->RevertStatus(carchiverobj);
				if(ret == STATUS_DISK_FULL)
				{
					DEBUGL1("CArchiver::StartArchive:: Cannot create directory, disk is full\n");
					*((ArchiveStatus*)pStatusMapAddr)=Archiver::DISK_FULL;
				}
				else 
            {
					*((ArchiveStatus*)pStatusMapAddr)=Archiver::ERROR;
				}
            pProgressShmid -> Destroy();
            pStatusShmid = NULL;
				return NULL;
			}

		//Added code to delete dom files  and lock files in all Documents..
			docPath = dPath + (*docIter) + "/";	
			DEBUGL4("CArchiver::StartArchive::<%s> Folder docPath\n",docPath.c_str());
			FolderPtr = ci::operatingenvironment::Folder::Bind(docPath);
			if(!FolderPtr)
			{
				DEBUGL1("CArchiver::StartArchive::<%s> Folder Binding Failed\n",docPath.c_str());
				return NULL;
			}
			if(FolderPtr->GetFiles(pTmpvec, "_systemfilelock") != STATUS_OK)
			{
				DEBUGL1("CArchiver::StartArchive::Getting Files inside Folder Failed\n");
				return NULL;
			}
			pTmpvec.push_back("documentproperties_dom");
				
			std::vector<CString>::iterator pIt;
			for(pIt = pTmpvec.begin(); pIt != pTmpvec.end(); pIt++)
			{
				DEBUGL8("CArchiver::StartArchive::Files is %s\n",(*pIt).c_str());	
				if((ret = ci::operatingenvironment::File::Exists(docPath + (*pIt))) == STATUS_OK)
				{
					if((ret = ci::operatingenvironment::File::DeleteFile(docPath + (*pIt))) != STATUS_OK)
					{
						DEBUGL1("CArchiver::StartArchive::Getting Files inside <%s> Folder Failed\n",(dPath + (*pIt)).c_str());
						return NULL;
					} 
				}
			}
			pTmpvec.clear();	
		        imagPath = docPath + "/Image" + "/";
			DEBUGL4("CArchiver::StartArchive::<%s> Folder imagePath\n",imagPath.c_str());

                	ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> FolderPtr = NULL;
			FolderPtr = ci::operatingenvironment::Folder::Bind(imagPath);
			if(!FolderPtr)
			{
				DEBUGL1("CArchiver::StartArchive::<%s> Folder Binding Failed\n",imagPath.c_str());
				return NULL;
			}
			if(FolderPtr->GetFiles(pTmpvec, "_dom") != STATUS_OK)
			{
				DEBUGL1("CArchiver::StartArchive::Getting Files inside Folder Failed\n");
				return NULL;
			}
			for(pIt = pTmpvec.begin(); pIt != pTmpvec.end(); pIt++)
			{
				if((ret = ci::operatingenvironment::File::Exists(imagPath + (*pIt))) == STATUS_OK)
				{
					if((ret = ci::operatingenvironment::File::DeleteFile(imagPath + (*pIt))) != STATUS_OK)
					{
						DEBUGL1("CArchiver::StartArchive::Getting Files inside <%s> Folder Failed\n",(imagPath + (*pIt)).c_str());
						return NULL;
					} 
				}
			}
		        pTmpvec.clear();			
			curProgress=(int)((((count)/numberOfDocs)*55) + 10);
			if(curProgress < PROGRESS_COMPLETED)
			{	
				DEBUGL8("CArchiver::StartArchive - Current progress <%d>\n",curProgress);
				*((int*)pMapAddr)=curProgress;
			}			
		}
      #if 0
		DEBUGL8("CArchiver::StartArchive - Size of the documents to be archived is %llu\n",size);
		//Limit Check here
		const uint64 SIZE_LIMIT = 2147483648UL;
		if(size>=SIZE_LIMIT)
		{
         carchiverobj->RevertStatus(carchiverobj);
			DEBUGL1("CArchiver::StartArchive - Exceeded the archive size limit of 2GB\n");
			*((ArchiveStatus*)pStatusMapAddr)=Archiver::ARCHIVE_SIZE_ERROR;
         pProgressShmid -> Destroy();
         pStatusShmid = NULL;
			return NULL;
		}
	   #endif
		//Zip the documents
		ret = carchiverobj->ZipDocument((carchiverobj),tmppath, pMapAddr);
		if(ret!=STATUS_OK)
		{
         carchiverobj->RevertStatus(carchiverobj);
			DEBUGL1("CArchiver::StartArchive - ZipDocument Failed\n");
			if(ret == ::STATUS_DISK_FULL)
				*((ArchiveStatus*)pStatusMapAddr)=Archiver::DISK_FULL;
			else
				*((ArchiveStatus*)pStatusMapAddr)=Archiver::ERROR;
         pProgressShmid -> Destroy();
         pStatusShmid = NULL;
			return NULL;
		}

		*((int*)pMapAddr) = 97;
		int currprogress = 97;		
		//Now change the status of all documents to READY
		int numofDocs = documentlist.size();
		count = 1;
		for(docIter=documentlist.begin();docIter !=documentlist.end();docIter++, count++)
		{
			CString pDocpath = Utility::GetResourcePath(boxbasepath,boxNumber,folderName,(*docIter))+"/";	
			DEBUGL8("CArchiver::StartArchive:: stsfile path (%s), Status=%d\n",pDocpath.c_str(), *((ArchiveStatus*)pStatusMapAddr));
			if (*((ArchiveStatus*)pStatusMapAddr)== Archiver::CANCEL_INITIATED)		{
				carchiverobj->RevertStatus(carchiverobj);
      				pStatusShmid->Acquire();
				*((ArchiveStatus*)pStatusMapAddr)= Archiver::CANCELED;
      				pStatusShmid->Release();
				DEBUGL2("CArchiver::StartArchive: Found CANCEL_INITIATED so marked CANCELED and exiting archive thread\n");
				return NULL;
			}
			//delete the status file and create ready.sts
			if(ci::operatingenvironment::File::Exists(pDocpath+"using.sts"))
			{
				ci::operatingenvironment::File::DeleteFile(pDocpath+"using.sts");
			}
			else if(ci::operatingenvironment::File::Exists(pDocpath + "reserving.sts"))
			{
				ci::operatingenvironment::File::DeleteFile(pDocpath + "reserving.sts");
			}

			CString statuspath = "'" +  pDocpath + "ready.sts'";
			CString createstatusfile = "touch " + statuspath;
			int r;
			ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
			sysinfo->RunCmd(createstatusfile, r);
			DEBUGL8("CArchiver::StartArchive:: - Status file created\n");

			//Update the archive date
			std::map<CString, CString > PropertyMap;
			PropertyMap.clear();
			PropertyMap.insert(make_pair("lastArchiveDate", (Utility::GetUnixTime()).c_str()));
			proputils::SetDocumentProperties(boxbasepath,boxNumber,folderName,(*docIter),PropertyMap);			
			//int currprogress = (5 * count/numofDocs) + 95;
			currprogress = (int)((float)((((float)count)/((float)numofDocs))*5) + 97);
			if(currprogress < PROGRESS_COMPLETED)
			{	
				DEBUGL8("CArchiver::StartArchive - Current progress <%d>\n",currprogress);
				*((int*)pMapAddr)=currprogress;
			}						
		}	
		
		if (*((ArchiveStatus*)pStatusMapAddr)== Archiver::CANCEL_INITIATED)		{
			carchiverobj->RevertStatus(carchiverobj);
      			pStatusShmid->Acquire();
			*((ArchiveStatus*)pStatusMapAddr)= Archiver::CANCELED;
      			pStatusShmid->Release();
			DEBUGL2("CArchiver::StartArchive: Found CANCEL_INITIATED so marked CANCELED and exiting archive thread\n");
			return NULL;
		}
      pProgressShmid->Acquire();
		*((int*)pMapAddr)=PROGRESS_COMPLETED;
      pProgressShmid->Release();
		DEBUGL6("CArchiver::StartArchive - Current progress <100>, Status=%d\n", *((ArchiveStatus*)pStatusMapAddr));
		pStatusShmid->Acquire();
      *((ArchiveStatus*)pStatusMapAddr)=Archiver::CREATED;
      pStatusShmid->Unmap(pStatusMapAddr);
      pStatusShmid->Release();
      pProgressShmid = NULL;
      pStatusShmid = NULL;

		DEBUGL4("CArchiver::StartArchive::Exit\n");	
		return NULL;
	}

	/**
	 * Download the documents from the given list to a local temporary path. The downloaded documents can then be zipped.
	 * @param[in] tmppath - the local path where the documents will be downloaded to
	 * @param[in] totalSize - the estimated total size of the documents to be downloaded
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status CArchiver::DownloadDocument(CArchiver *carchiverobj,CString tmppath,uint64 totalSize,void *pMapAddr)
	{
		DEBUGL4("CArchiver::DownloadDocument::Enter\n");
		DEBUGL4("CArchiver::DownloadDocument::Exit\n");		
		return STATUS_OK;	
	}
   Status CArchiver::RevertStatus(CArchiver *carchiverobj)
   {
		DEBUGL4("CArchiver::RevertStatus::Enter\n");	
		std::vector<CString>::iterator docIter;
		std::vector<CString> documentlist = carchiverobj->m_Documentlist;
		std::vector<CString> documentpaths = carchiverobj->m_Documentpaths;
		CString boxbasepath = carchiverobj->m_BoxBasePath;
		CString boxNumber = carchiverobj->m_BoxNumber;
		CString folderName = carchiverobj->m_FolderName;	
		CString tmppath = Utility::GetCITmpPath(); 
		CString basefolder =  "/storage/box/";
		CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
      
      /*
 		if(folderName.empty())
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber;
		else
			tmppath+="ArchiveDocument_" + carchiverobj->m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName;
      */
      tmppath += "ArchiveDocument_" + carchiverobj->m_sessionID;
      int count=1; 
     	//Now change the status of all documents to READY
		for(docIter=documentlist.begin();docIter !=documentlist.end();docIter++,count++)
		{
			CString pDocpath = Utility::GetResourcePath(boxbasepath,boxNumber,folderName,(*docIter))+"/";	
			DEBUGL8("CArchiver::RevertStatus:: stsfile path (%s)\n",pDocpath.c_str());
			//delete the status file and create ready.sts
			if(ci::operatingenvironment::File::Exists(pDocpath+"using.sts"))
			{
				ci::operatingenvironment::File::DeleteFile(pDocpath+"using.sts");
			}
			else if(ci::operatingenvironment::File::Exists(pDocpath + "reserving.sts"))
			{
				ci::operatingenvironment::File::DeleteFile(pDocpath + "reserving.sts");
			}

			CString statuspath = "'" + pDocpath + "ready.sts'";
			CString createstatusfile = "touch " + statuspath;
			int r;
			ci::systeminformation::SystemInformationRef sysinfo = ci::systeminformation::SystemInformation::Acquire();
			sysinfo->RunCmd(createstatusfile, r);
			DEBUGL8("CArchiver::RevertStatus:: Status file created\n");

			//Update the archive date
			std::map<CString, CString > PropertyMap;
			PropertyMap.insert(make_pair("lastArchiveDate", (Utility::GetUnixTime()).c_str()));
			proputils::SetDocumentProperties(boxbasepath,boxNumber,folderName,(*docIter),PropertyMap);			

 			CString dPath = tmppath+"_";
			dPath+="Document";
			std::ostringstream oss;
			oss << count;	
			dPath+=oss.str();
			DEBUGL8("CArchiver::RevertStatus::- Document Path <%s> to be deleted\n",dPath.c_str());
			//Delete the temporary folder holding the documents
			if((ci::operatingenvironment::Folder::Remove(dPath,true))!=STATUS_OK)
				DEBUGL2("CArchiver::RevertStatus:: Could not delete the %s folder :: Delete Manually\n",dPath.c_str());			
        
		}	

		DEBUGL4("CArchiver::RevertStatus::Exit\n");	
      return STATUS_OK;
   }
	/**
	 * Zips the documents given to the desired target location
	 * @param[in] tmppath - the local path where the file to be zipped are present	 
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status CArchiver::ZipDocument(CArchiver *carchiverobj, CString tmppath, void *pMapAddr)
	{
		DEBUGL4("CArchiver::ZipDocument::Enter\n");	
		std::vector<CString> documentlist = carchiverobj->m_Documentlist;
		std::vector<CString> documentpaths = carchiverobj->m_Documentpaths;
		CString boxbasepath = carchiverobj->m_BoxBasePath;
		CString boxNumber = carchiverobj->m_BoxNumber;
		CString folderName = carchiverobj->m_FolderName;		
		Status ret;
		CString folderPath;
		CString basefolder =  "/storage/box/";
		CString strboxbasepath = boxbasepath.substr(basefolder.length(), boxbasepath.length());
		if(pMapAddr==NULL)
		{
			DEBUGL1("CArchiver::ZipDocument::shared memory MAP Address is invalid\n");
			return STATUS_FAILED;
		}
		*((int*)pMapAddr)=65;
		int curProgress = 65;
      
      /*
		if((folderName.empty()))
			folderPath = Utility::GetCITmpPath()+"ArchiveDocument_" + m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_Zip";
		else
			folderPath = Utility::GetCITmpPath()+"ArchiveDocument_" + m_sessionID+"_"+strboxbasepath+"_"+boxNumber+"_"+folderName+"_Zip";	
      */
      folderPath = Utility::GetCITmpPath() + "ArchiveDocument_" + m_sessionID + "_Zip";
		//Create temporary folder to hold the files to be zipped
		ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> tmpFolder;
		Status retStat=STATUS_OK;
		if ((retStat = ci::operatingenvironment::Folder::CreateFolder(tmpFolder, folderPath))!= STATUS_OK)	
		{
			if( retStat == ::STATUS_DISK_FULL)
				DEBUGL1("CArchiver::ZipDocument - Cannot create directory, disk is full\n");
			return retStat;
		}
		
		std::vector<CString>::iterator docIter;
		CString zipFilePath("");
		CString fileName("");
		ZipRef zipRef;
		CString dPath("");
		CString EFBfilePath("");
		int count = 1;
		int numberOfDocs = documentlist.size();	
		DEBUGL8("CArchiver::ZipDocument number of docs = (%d)\n",numberOfDocs);		
		for(docIter=documentlist.begin();docIter!=documentlist.end();docIter++,count++)
		{
			fileName = "Document";
			std::ostringstream oss;
			oss << count;
			fileName += oss.str();
			fileName += ".zip";
			
			//Zip the files of the document
			zipFilePath = folderPath +"/"+ fileName;
			zipRef= Zip::Acquire();
			dPath = tmppath+"_";
			dPath+="Document";
			dPath+=oss.str();

			DEBUGL6("CArchiver::ZipDocument - Download Path <%s>\n",dPath.c_str());		
			ret = zipRef->CreateZip(zipFilePath,dPath,false,EFBPASS,Zip::eNoCompression);
			if(ret!=STATUS_OK)
			{
				DEBUGL1("CArchiver::ZipDocument - Codecs::CreateZip failed\n");
				if((ci::operatingenvironment::Folder::Remove(folderPath,true))!=STATUS_OK)
					DEBUGL2("CArchiver::ZipDocument - Could not delete the %s folder :: Delete Manually\n",folderPath.c_str());
				if((ci::operatingenvironment::Folder::Remove(dPath,true))!=STATUS_OK)
					DEBUGL2("CArchiver::ZipDocument - Could not delete the %s folder :: Delete Manually\n",dPath.c_str());								
				return ret;
			}
			//Delete the folder containing the documents
			if((ci::operatingenvironment::Folder::Remove(dPath,true))!=STATUS_OK)
				DEBUGL2("CArchiver::ZipDocument - Could not delete the %s folder :: Delete Manually\n",dPath.c_str());			
			
			//curProgress=(30 * ((float)count/(float)numberOfDocs)) + 65;
			curProgress= (int)((float)((((float)count)/((float)numberOfDocs))*30) + 65);
			if(curProgress < PROGRESS_COMPLETED)
			{	
				DEBUGL8("CArchiver::ZipDocument - Current progress <%d>\n",curProgress);
				*((int*)pMapAddr)=curProgress;
			}			
		}
		
		//Create the Main zip file containing all the documents along with the archive.xml
		ret = CreateMainZip(carchiverobj,folderPath,documentlist.size());
		if(ret!=STATUS_OK)
		{
			DEBUGL1("CArchiver::ZipDocument - CreateMainZip failed\n");
			if((ci::operatingenvironment::Folder::Remove(folderPath,true))!=STATUS_OK)
				DEBUGL2("CArchiver::ZipDocument - Could not delete the %s folder :: Delete Manually\n",folderPath.c_str());			
			return ret;
		}

		//Delete the temporary folder holding the archive.xml and document ZIP's
		if((ci::operatingenvironment::Folder::Remove(folderPath,true))!=STATUS_OK)
			DEBUGL2("CArchiver::ZipDocument - Could not delete the %s folder :: Delete Manually\n",folderPath.c_str());
		DEBUGL4("CArchiver::ZipDocument::Exit\n");			
		return STATUS_OK;
	}

	/**
	 * Create the main zip file containing the archive.xml file and the document efb's
	 * @param[in] folderPath - the local path that contains all the documents
	 * @param[in] count - number of documents
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status CArchiver::CreateMainZip(CArchiver *carchiverobj,CString folderPath,int count)
	{
		DEBUGL4("CArchiver::CreateMainZip::Enter\n");
		CString archivePath = carchiverobj->m_ArchivePath;
	
		CString zipCommand;				
		time_t rawtime;
		time(&rawtime);
		tm* ptm;
		ptm=localtime(&rawtime);
		
		FilePtr fp;
		Status ret;
		
		ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> tmpFolder =  ci::operatingenvironment::Folder::Bind(folderPath);
		if(!tmpFolder)
		{	
			DEBUGL1("CArchiver::CreateMainZip - Folder Bind failed\n");
			return STATUS_FAILED;
		}	
		else
		{
			ret = ci::operatingenvironment::File::CreateFile(fp,"ARCHIVE.XML",tmpFolder,"wb+");	
			if(ret!=STATUS_OK)
			{
				DEBUGL1("CArchiver::CreateMainZip - File creation failed\n");
				return ret;
			}			
		}				
		
		if(!fp)	
		{
			DEBUGL1("CArchiver::CreateMainZip - Invalid file ptr\n");
			return STATUS_FAILED;
		}
		else
		{
			CString equipmentbrand = Utility::GetEquipmentBrand(); 
			CString EQUIPMENT_BRAND("");


			if(equipmentbrand == "LENOVO")
				EQUIPMENT_BRAND = LENOVO_EQUIPMENT_BRAND;

			else if(equipmentbrand == "OKI")
				EQUIPMENT_BRAND = OKI_EQUIPMENT_BRAND;


			else
				EQUIPMENT_BRAND = PRODUCT_CODE; 
			//Fill the Archive.xml file
			DEBUGL8("CArchiver::CreateMainZip - Archive.xml File\n");
			char * xmlString = new char [1024]; 
			sprintf(xmlString, "<ArchiveInfo><Version>1.0</Version><ArchiveDate>%04d-%02d-%02dT%02d:%02d:%02d</ArchiveDate><MACAddress></MACAddress><NumOfDocs>%d</NumOfDocs><productType>%s</productType></ArchiveInfo>\n",ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday,ptm->tm_hour,ptm->tm_min, ptm->tm_sec,count,EQUIPMENT_BRAND.c_str());
			ret = fp->Write((const void*)xmlString,strlen(xmlString),1);						
			if(ret != STATUS_OK)
			{
					delete[]  xmlString;
					DEBUGL1("CArchiver::CreateMainZip - File write failed\n");
					return ret;
			}
			DEBUGL8("CArchiver::CreateMainZip -File Write done\n");		

			fp->Close();
			DEBUGL8("CArchiver::CreateMainZip -File Close done\n");		

			delete[]  xmlString;
		}

		DEBUGL8("CArchiver::CreateMainZip -Main Zip File\n");
		ZipRef zipRef= Zip::Acquire();
		ret=zipRef->CreateZip(archivePath,folderPath,false,"",Zip::eBestSpeed);
		if(ret!=STATUS_OK)
		{
			DEBUGL1("CArchiver::CreateMainZip - Codecs::CreateZip failed\n");
			return ret;
		}

		DEBUGL4("CArchiver::CreateMainZip::Exit\n");	
		return STATUS_OK;
	}

}; // end of namespace boxdocument
}; // end of namespace ci

