/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cdocument.h
 Revision: com_t#5
 File Spec: EBX:MA6035.A-DEV_SRC;com_t#5
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:42:49

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#5 (APPROVED)
     Created:  09-JAN-2009 21:42:49      CHANDRAMOHAN.PUJARI
       Added functions for Image extension support and Edit Progress
       related API's
     Updated:  09-JAN-2009 21:42:49      CHANDRAMOHAN.PUJARI
       Added functions for Image extension support and Edit Progress
       related API's
     Updated:  09-JAN-2009 21:42:49      CHANDRAMOHAN.PUJARI
       Added functions for Image extension support and Edit Progress
       related API's
     Updated:  09-JAN-2009 21:42:49      CHANDRAMOHAN.PUJARI
       Item revision com_t#5 created from revision com_t#4 with status
       $TO_BE_DEFINED
   
   Revision com_t#4 (APPROVED)
     Created:  19-DEC-2008 21:34:47      CHANDRAMOHAN.PUJARI
       code added for clipboard limitation
     Updated:  19-DEC-2008 21:34:47      CHANDRAMOHAN.PUJARI
       Item revision com_t#4 created from revision com_t#3 with status
       $TO_BE_DEFINED
     Updated:  19-DEC-2008 21:34:47      CHANDRAMOHAN.PUJARI
       code added for clipboard limitation
     Updated:  19-DEC-2008 21:34:47      CHANDRAMOHAN.PUJARI
       code added for clipboard limitation
   
   Revision com_t#3 (APPROVED)
     Updated:  08-DEC-2008 20:37:20      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,Error Codes,LastAccessdate and
       modified date
     Created:  08-DEC-2008 20:37:16      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,Error Codes,LastAccessdate and
       modified date
     Updated:  08-DEC-2008 20:37:16      CHANDRAMOHAN.PUJARI
       Added Code for ScanPreview,Error Codes,LastAccessdate and
       modified date
     Updated:  08-DEC-2008 20:37:16      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
   
   Revision com_t#2 (APPROVED)
     Created:  17-NOV-2008 21:52:30      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s in Document
       class
     Updated:  17-NOV-2008 21:52:30      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s in Document
       class
     Updated:  17-NOV-2008 21:52:30      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
     Updated:  17-NOV-2008 21:52:30      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s in Document
       class
   
   Revision com_t#1 (APPROVED)
     Created:  03-NOV-2008 19:15:54      CHANDRAMOHAN.PUJARI
       Added functions for clipboard functionalities such as copy,cut
       and paste
     Updated:  03-NOV-2008 19:15:54      CHANDRAMOHAN.PUJARI
       Added functions for clipboard functionalities such as copy,cut
       and paste
     Updated:  03-NOV-2008 19:15:54      CHANDRAMOHAN.PUJARI
       Added functions for clipboard functionalities such as copy,cut
       and paste
     Updated:  03-NOV-2008 19:15:54      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:58      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:33      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:13      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:16      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:38      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:07:40      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:34:01      13848
       Initial revision
========================== End of Source Header =============================*/

#ifndef __CI_CDOCUMENT_H__
#define __CI_CDOCUMENT_H__

#include <map>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
//#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/OperatingEnvironment/thread.h>
#include "systemdatafile.h"
#include "cprogress.h"
#include <CI/BoxDocument/progress.h>
#include "CI/OperatingEnvironment/sharedmemory.h"
#include "CI/OperatingEnvironment/cuuid.h"
#include "CI/OperatingEnvironment/file.h"
#include "CI/OperatingEnvironment/folder.h"
#include "BPMash/vxw_types2.h"


using namespace ci::operatingenvironment;

namespace ci {
namespace boxdocument {
namespace statusfilename {
		static const CString CREATING = "creating.sts";
		static const CString READY = "ready.sts";
		static const CString USING = "using.sts";
		static const CString EDITING = "editing.sts";
		static const CString DELETING = "deleting.sts";
		static const CString WAITING = "waiting.sts";
		static const CString RESERVING = "reserving.sts";
};

static const char *const SYSTEMFILE = "00000";
const CString WORKSPACE_PATH = "/imagedata/WorkSpace/";
const CString CLIPBOARD_PATH = "/imagedata/ClipBoard/";
typedef void *ThreadArg;
typedef void *ThreadRtn;
typedef ThreadRtn (*ThreadFun)(ThreadArg);
#define UUID_CONTENT_LENGTH 100

static CString BOX_PRODUCT;
static CString BOX_EB2ROOT;


/**
 *    Launch or Start a new thread for Cut operation
 **/
void* StartCutThread(void *arg);

/**
 *    Launch or Start a new thread for Copy operation
 **/
void* StartCopyThread(void *arg);

/**
 *    Launch or Start a new thread for Save operation
 **/
void* StartSaveThread(void *arg);

/**
 *    Launch or Start a new thread for SaveAs operation
 **/
void* StartSaveAsThread(void* arg);

/**
 *    Launch or Start a new thread for Paste operation
 **/
void* StartPasteThread(void *arg);

/**
 *    Launch or Start a new thread for Faster Paste operation
 **/
void* StartFasterPasteThread(void *arg);
/**
 *    Launch or Start a new thread for Delete operation
 **/
void* StartDeleteThread(void *arg);


class CDocument : public Document
{
private:
	typedef struct SDF_DATA
	{
		CString boxBasePath;
		CString boxNumber;
		CString folderName;
		CString documentName;
		int pageno;
		CString name;
	}SDF_DATA;

	typedef struct blank_page_data
	{
		HI mainScanPixel;
		HI subScanPixel;
		HI mainScanTransferPixel;
		HI subScanTransferPixel;
		HI mainThumbnailScanPixel;
		HI mainThumbnailSubScanPixel;		
		HI hSize;
		HI hImgCoordinate;
		HI hAngle;
		HI hPaperSize;
		HI hOrientation;
		CString fileSize;
	}blank_page_data;
	
	std::map<CString, CString> m_blankFileNames;
	PageRef m_basePageRef;
	PageRef m_blankPageRef;
	int m_jobColorType;
	int m_basePageNumber;
	int m_blankPageNumber;
    
	CString m_blankCopyJpegPath;
   	Ref<CProgress> m_cprogress;

     /**
     * return status file name
     * @param[in] st - document status
     * @return status file name corresponding to document status.
     */
    CString GetStatusFileName(DocStatus st);
    
    
    
    /**
     * Open SystemDataFile at indicated path
     * @param[out] system - Opened SystemDataFile
     * @param[in] path - the path of SystemDataFile
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status OpenSystemDataFile(FL_FILE_MAN_FILE &system, CString path);
    
    /**
     * overwrite image files and system file values
     * param[in] src - source image file path.
     * param[in] dst - destination path
     * param[in] name - file name (without extension)
	  * param[in] ext - extension of the file
     * param[in] pageinfo - 
     * param[in/out] systemfile - system data file to be overwritten
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status OverwriteImage(int pageno, CString src, CString dst, CString name, CString ext, FL_PAGE_MAN_TBL &pageinfo, FL_FILE_MAN_FILE &systemfile);

	/**
 	* This Api is used to put the the system file in the path pointed by m_boxbasepath,m_boxnumber,m_foldername,m_DocumentName 
 	* @return STATUS_OK on success,
 	*          STATUS_FAILED on failure
 	*          STATUS_DISK_FULL if there is not enough space on the partition
 	**/
	Status copySystemFile(FL_FILE_MAN_FILE systemfile, CString pageType);

	/**
     * This API updates the mixed information data obtained from the SDF to the maps. Also checks for any invalid combination
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
	Status UpdateMixedInfoData(PageRef page, bool increment);	 

	/**
     * This API updates the map for different mixed info data.It also sets the mix/Compound type
     * @setreturn STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
   Status UpdateMap(PageRef page, bool increment, std::map<CString,CString> &PropertyMap,CString* key); 
	/**
	 * Initialise the paths to WorkSpace if the document is in editing mode
	 */
	//void WorkSpaceInit();

	/**
	* Revert back paths changed by workSpaceInit
	* */
	//void RevertPaths(CString basepath,CString boxNumber,CString folderName,CString docName);

	
	/**
	* Create a new Thread object with specified functionName and launch it with 
	* specified functionArgument
	*/
   Status CreateThread(ThreadFun functionName,ThreadArg functionArgument,Ref<Thread> threadID);

	void SetAllSize();

	/**
	* Get the blank image.
	* @param[in] page - Instance of the PageRef Class.
	* @param[in] papersize - blank paper size
	* @param[in] pageno - page number to be inserted
	* @param[in] totalPages - total number of pages present in the document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status GetBlankPage(PageRef page, PaperSize papersize, int pageno, int totalPages);

	/**
	* Fill the blank page properties.
	* @param[in] jobType - jobType (SCAN/PRINT/FAX/COPY)
	* @param[in] paperSize - paper size
	* @param[in] basePage - instanf of base page
	* @param[in] blankPage - instant of blank page
	* @param[in] basePageNumber - base page number
	* @param[in] blankPageNumber - blank page number to be inserted
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status FillBlankPageProperties(int jobType, PaperSize papersize, PageRef basePage, 
						PageRef blankPage,  int basePageNumber);
	/**
	* Get the blank page data
	* @param[in] jobColorType - job color type
	* @param[in] paperSize - paper size
	* @param[in] blank_page_data - instance of blank_page_data structure
	* @param[in] resolution - page resolution
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status GetBlankPageData(int jobColorType, PaperSize paperSize, 
									blank_page_data &bpData, CString resolution);

	/**
	* update the blank page data
	* @param[in] blank_page_data - instance of blank_page_data structure
	* @param[in] arrayAddr - pointer to array
	* @param[in] blank_page_data - pointer to thumbnail array
	* @param[in] index - index of the array
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/	
	Status UpdateBlankPageData(blank_page_data &pData, int *arrayAddr, 
										int *thumbnailArrayAddr, int index);
	
   /**
   * update the Orientation for blank page 
   * @param[in] blank_page_data - instance of blank_page_data structure
   * @param[in] arrayAddr - pointer to array
   * @param[in] index - index of the array
   * @return STATUS_OK on success,
   *         STATUS_FAILED on failure
   */         
   Status UpdateOrientation(blank_page_data &pData, int *arrayAddr, int index);
   
   
   /**
	* Fill the blank page properties for image
	* @param[in] paperSize - paper size
	* @param[in] blankSystemFile - blank system file structure to be updated
	* @param[in] basesystemfile - base system file structure to be updated
	* @param[in] bpData - blank page data structure
	* @param[in] horizontalResolution - horizontal resolution
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/		
	Status FillBlankPagePropertiesImage(PaperSize paperSize, 												
												FL_PAGE_MAN_TBL &blankSystemFile,
												FL_FILE_MAN_FILE &basesystemfile,
												blank_page_data bpData, CString horizontalResolution);
	/**
	* Fill the blank page properties for thumbnail
	* @param[in] paperSize - paper size
	* @param[in] blankSystemFile - blank system file structure to be updated
	* @param[in] baseThumbnailSystemfile - base system file structure to be updated
	* @param[in] bpData - blank page data structure
	* @param[in] horizontalResolution - horizontal resolution
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/			
	Status FillBlankPagePropertiesThumbnail(PaperSize paperSize, 													
													FL_PAGE_MAN_TBL &blankSystemFile,
													FL_FILE_MAN_FILE &baseThumbnailSystemfile,
													blank_page_data bpData, CString horizontalResolution);
	/**
	* set the blank file name maps
	* @param[in] : jobType - base page job type
	* @return : None	
	*/		
	void SetBlankFileName(int jobType);
	Status GetPage(int pageno, PageRef &page, FL_FILE_MAN_FILE *sd, FL_FILE_MAN_FILE *sd1, FL_FILE_MAN_FILE *sd2);
	Status OpenSystemDataFile(FL_FILE_MAN_FILE *system, CString path);

    /**
     * slide pages for MovePage method	 
     * @param[in] srcpageno    - The source page number of MovePage
     * @param[in] dstpageno    - The destination page number of MovePage
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SlidePagesForMove(int srcpageNo, int dstpageNo, FL_FILE_MAN_FILE &systemfile, bool subsampling_exists, FL_FILE_MAN_FILE &subsampling, bool thumbnail_exists, FL_FILE_MAN_FILE &thumbnail);
		
    Status UpdateSystemFile(FL_FILE_MAN_FILE &systemfile, CString path);

    bool hasSubsampling(PageRef page);
    bool hasThumbnail(PageRef page);
    
public:

	CString m_sessionID;
	CString m_BoxBasePath;
	CString m_BoxBasePathOrg;
	CString m_BoxNumber;
	CString m_FolderName;
	CString m_DocumentName;
	CString m_JobVal;
	PageList m_PageList; // PageList is loaded when it's used
	std::map<CString, CString> m_WebDAVProperties;
	CString m_WEPDocumentID; // HDB document ID
	bool iSSetsysfileInvoked;
	bool iSDocumentModified;
	FL_FILE_MAN_FILE m_SystemDataFile;
	FL_FILE_MAN_FILE m_SubsamplingSystemDataFile;
	FL_FILE_MAN_FILE m_ThumbnailSystemDataFile;
	int m_TotalPage;
	uint64 m_TotalSize;

	uint64 m_TotalDocSize; //add phani: for GetSize() to avoid downloading the resources for size

	Ref<Thread> m_ThreadID;
	std::vector<int> m_CutVecofPages;
	bool m_CutFlag;
	CString m_CutProgShmName;
	CString m_CutErrfile;

	std::vector<int> m_CopyVecofPages;
	bool m_CopyFlag;
	CString m_CopyProgShmName;
	CString m_CopyErrfile;

	int m_PastePageNo;
	bool m_PasteFlag;
	CString m_PasteProgShmName;
	CString m_PasteErrfile;

	CString m_SaveProgShmName;
	CString m_SaveErrfile;

	CString m_SaveAsNewName;
	CString m_SaveAsResourceBasePath;
	bool m_SaveAsFlag;
	CString m_SaveAsProgShmName;
	CString m_SaveAsErrfile;

	std::vector<int> m_DeleteVecofPages;
	bool m_DeleteFlag;
	CString m_DeleteAsProgShmName;
	CString m_DeleteErrfile;
	bool m_insertblankpage;
	bool m_bLink;

	//Shared memory ref to handle the shm for cut,copy,paste,etc., progress
	Ref<SharedMemory> m_prgShmid;

	std::map<PaperSize,int> m_PaperSizeMap;
	std::map<JobTypeColor,int> m_JobTypeColorMap;
	void ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid);
	void RevertPaths(CString basepath,CString boxNumber,CString folderName,CString docName);
	void WorkSpaceInit();

	/**
	 * slide the page(s) while inserting the page(s) 
	 * @param[in] dstpagenum - destination page postition to be inserted
	 * @param[in] Imgvecsize - number of pages to be inserted
	*/
	 Status SlidePages(int dstpagenum, int Imgvecsize);    
 
	/**
     * constructor
     */
    CDocument(CString sessionID,
              CString boxbasepath, 
              CString boxnumber, 
              CString foldername, 
              CString documentname);
    
    // destructor
    virtual ~CDocument();
    
    //-------------------- document status methods --------------------
    /**
     * get status of the document
     * @param[out] st - current status of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
     Status GetStatus(DocStatus &st) ;

     /**
     * change document status
     *  this function doesn't check valid state transition or not.
     * @param[in] st - change to the status
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
     Status ChangeStatus(DocStatus st);

	/**
	* revert the document status back to CREATING
	* change status from READY to CREATING. if document status is not READY, 
	* it will fal.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	**/
	Status ReCreate(); 

    /**
     * change status after creating the document
     * change document status from CREATING to READY. if document status is 
     * NOT CREATING, it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status EndCreating();
    
    /**
     * change status for using the document
     * change document status from READY or RESERVING to USING. if document status is 
     * NOT COMPLETED, it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status Use();
    
    /**
     * change status after using the document
     * change document status from USING to READY when any document is NOT 
     * using the document. some documents are still using, the document status 
     * is unchanged. if document status is NOT USING, it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status EndUsing();
    
    /**
     * start to edit the document
     * change document status from READY to EDITING. if document status is 
     * NOT READY, it will fail.
     * when this method is called, delta document is created. On saving, 
     * delta documents will be overwritten to original documents. 
     * @param[out] editor - instance of DocumentEditor, or NULL
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status Edit();
    
    /**
     * save the delta document. 
     * change document status from EDITING to READY. if document status is 
     * NOT EDITING, it will fail.
     * when this method is called, unlock delta document. delta documents 
     * will be overwritten to original documents. after that all delta 
     * documents will be deleted. 
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition.
     */
    Status Save();
    
    /**
     * save the edited document with other name
     * change document status from EDITING to READY. if document status is 
     * NOT EDITING, it will fail.
     * when this method is called, unlock delta document. delta documents 
     * will be overwritten to original documents. after that all delta 
     * documents will be deleted. 
     * @param[in] new_name - merged document save as the name
     * @param[in] resourcebasepath - save to the this folder, if it is set.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition.
     */
    Status SaveAs(CString new_name, CString resourcebasepath = "");
    
    /**
     * cancel editing delta document
     * change document status from EDITING to READY. if document status is 
     * NOT EDITING, it will fail.
     * when this method is called, unlock delta document. all delta 
     * documents will be deleted. 
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CancelEdit();

    Status InitializeStatus() ;
    
    //-------------------- end of document status methods --------------------
    
    /**
     * get page instance in the document
     * @param[in] pageno - page number
     * @param[out] page - instance of Page class
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetPage(int pageno, PageRef &page);

   
    /**
     * get new page instance. the new page is added as last page.
     * images of the page is copied when this method is called.
     * @param[in] page - instance of Page class
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition.
     */
    Status AppendPage(PageRef page);
    
    /**
     * insert page to the document
     * @param[in] pageno - new page number of the inserted page 
     *                      document[a1, a2, a3] -- InsertPage(2, b1) ->
     *                      docuemnt[a1, b1, a2, a3])
     * @param[in] page  - a page to be added. If image path as page property 
     *                     is set, the image  will be copied to under the 
     *                     document folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition. 
     */
    Status InsertPage(int pageno, PageRef page);
    
    /**
     * insert pages to the document
     * @param[in] pageno - page number to be inserted
                           (first page number of the inserted page)
     * @param[in] pages  - pages to be added. If an image path is set, 
     *                      the image  will be copied to under the document 
     *                      folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition.
     */
    Status InsertPage(int pageno, PageList pages);
  
	/**
     * insert page faster to the document
     * @param[in] pageno - new page number of the inserted page 
     *                      document[a1, a2, a3] -- InsertPage(2, b1) ->
     *                      docuemnt[a1, b1, a2, a3])
     * @param[in] page  - a page to be added. If image path as page property 
     *                     is set, the image  will be copied to under the 
     *                     document folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition. 
     */
	Status FasterInsertPage(int pageno, PageRef page);

	/**
     * insert pages faster  to the document
     * @param[in] pageno - page number to be inserted
                           (first page number of the inserted page)
     * @param[in] pages  - pages to be added. If an image path is set, 
     *                      the image  will be copied to under the document 
     *                      folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_DISK_FULL if there is not enough space on the partition.
     */
	Status FasterInsertPage(int pageno,  PageList pages);

 
	/**
	* insert blank page to the document
	* the page properties are copied from previous page (if inserting to 
	* first page, the page properties are copied from next one)
	* @param[in] pageno - new page number of the inserted page(see InsertPage)
	* @param[in] size - paper size to be inserted
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status InsertBlankPage(int pageno, PaperSize size);

	/**
	* replace page in the document
	* @param[in] pageno - new page number of the replaced page 
	*                      document[a1, a2, a3] -- InsertPage(2, b1) ->
	*                      docuemnt[a1, b1, a3])
	* @param[in] page  - a page to be added. If image path as page property 
	*                     is set, the image  will be copied to under the 
	*                     document folder.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status ReplacePage(int pageno, PageRef page);
    
	/**
	* replace pages in the document
	* @param[in] pageno - page number to be replaced
	*                     (first page number of the replaced page)
	* @param[in] pages  - pages to be added. If an image path is set, 
	*                      the image  will be copied to under the document 
	*                      folder.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status ReplacePage(int pageno, PageList pages);   
 	
    /**
     * get new page instance. the new page is added as last page.
     * images of the page is linked when this method is called.
     * @param[in] page - instance of Page class
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the disk.
     */
    Status AppendPageByLink(PageRef page);
    
    /**
     * insert page to the document
     * @param[in] pageno - new page number of the inserted page 
     *                      document[a1, a2, a3] -- InsertPage(2, b1) ->
     *                      docuemnt[a1, b1, a2, a3])
     * @param[in] page  - a page to be added. If image path as page property 
     *                     is set, the image  will be linked under the 
     *                     document folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the disk.
     */
    Status InsertPageByLink(int pageno, PageRef page);
    
    /**
     * replace page in the document
     * @param[in] pageno - new page number of the replaced page 
     *                      document[a1, a2, a3] -- InsertPage(2, b1) ->
     *                      docuemnt[a1, b1, a3])
     * @param[in] page  - a page to be added. If image path as page property 
     *                     is set, the image  will be linked under the 
     *                     document folder.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the disk.
     */
    Status ReplacePageByLink(int pageno, PageRef page);
    
    /**
     * get an instance of PageList
     * @param[out] list - list of pages. 
     *                     this list have snapshot of each page instances.
     *                     the snapshot is independent from original pages.
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetPageList(PageList &list);
    
    /**
     * get an instance of PageList
     * @param[out] list - list of pages. 
     *                     this list have snapshot of each page instances.
     *                     the snapshot is independent from original pages.
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @param[in] from - return list from this value.
     * @param[in] size - list size, if "from" + "size" is bigger than the 
     *                    number of all pages, return list size will be smaller
     *                    than "size".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetPageList(PageList &list, 
                                unsigned int from, unsigned int size);
    /**
     * get an instance of PageList. Using these objects user can access the
     * following page properties.
     * jobType
     * paperSize
     * resolution
     * image size
     * size
     * thumbnail
     * colorMode
     * creationDate
     * lastModifiedDate
     * cutPage
     *
     * @param[out] list - list of pages. 
     *                     this list have snapshot of each page instances.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetViewPageList(PageList &list);
    
    /**
     * get an instance of PageList. Using these objects user can access the
     * following page properties.
     * jobType
     * paperSize
     * resolution
     * image size
     * size
     * thumbnail
     * colorMode
     * creationDate
     * lastModifiedDate
     * cutPage
     *
     * @param[out] list - list of pages. 
     *                     this list have snapshot of each page instances.
     * @param[in] from - return list from this value. !! 1-origin !!
     * @param[in] size - list size, if "from" + "size" is bigger than the 
     *                    number of all pages, return list size will be smaller
     *                    than "size".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetViewPageList(PageList &list, 
                                unsigned int from, unsigned int size);
    

    
    //-------------------- System File Operation --------------------
    /**
     * put system file to the document folder
     * @param[in] path - the path of system file
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * 
     *  DEPRICATED
     */
    Status PutSystemFile(CString path){ return STATUS_OK;}
    
    /**
     * set properties from system file on memory
     * some document properties are set as WebDAV properties. Also, some page 
     * properties are set if the main image is copied to the document folder.
     * @param[in] systemfile - a pointer to System File
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWebDAVPropertyFromSystemFile(void* systemfile);
    
    /**
     * get a path of the system file
     * @param[out] path - local path of the system file.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetSystemFile(CString &path);
    
    /**
     * put subsampling system file to the document folder
     * @param[in] path - the path of system file
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * 
     *  DEPRICATED
     */
    Status PutSubSamplingSystemFile(CString path){ return STATUS_OK;}
    
    /**
     * get a path of the subsampling system file
     * @param[out] path - local path of the system file.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetSubsamplingSystemFile(CString &path);
    
    /**
     * put thumbnail system file to the document folder
     * @param[in] path - the path of system file
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * 
     *  DEPRICATED
     */
    Status PutThumbnailSystemFile(CString path){ return STATUS_OK; }
    
    /**
     * get a path of the thumbnail system file
     * @param[out] path - local path of the system file.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetThumbnailSystemFile(CString &path);

    /**
     * get a path of the first thumbnail image
     * @param[out] path - local path of the first thumbnail image.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status  GetTumbnailImage(CString &path);

    
    //-------------------- end of System File Operation --------------------
    
    /**
     * set HDB Document of Workflow Execution Parameter. 
     * @param[in] node - WEP node to save
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWEPDocument(dom::NodeRef node);
    
    /**
     * get WEP Document node from XPath. 
     * @param[out] node - node to be found
     * @param[in] xpath - the XPath to search for
                          if empty string, return root node.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetWEPDocument(dom::NodeRef &node, CString xpath = "");
    
    /**
     * get WEP document ID
     *  BoxDocument create HDB document and return document ID.
     * @param[out] documentID - HDB document ID
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * @note user need to delete this document using document ID.
     */
    Status GetWEPDocument(CString& documentID);
    
    /**
     * set document property
     * @param[in] key - the property name to be set
     * @param[in] value - the property value to be set
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWebDAVProperty(CString key, CString value);

   /**
     * sets WebDAV properties
     * @param[in] WebDAVPropertyMap - Map containing the key & value
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWebDAVProperties(std::map<CString, CString> WebDAVPropertyMap); 

    /**
     * set document property
     * @param[in] key - the property name to be set
     * @param[in] value - the property value to be set
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWebDAVProperty(CString key, int value);
    
    /**
     * get document property
     * @param[in] key - the property name to be set
     * @param[out] value - the property value
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetWebDAVProperty(CString key, CString &value);
    
    /**
     * set a name of the document
     * @param[in] name - a name to be set
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetName(CString name);
    
    /**
     * get a name of the document
     * @param[out] name - a name of the container
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetName(CString &name);

    /**
     * get a set of paper size in Document 
     * @param[out] paperset - a set of paper size in Document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetPaperSizeSet(PaperSizeSet &paperset);
    
    /**
     * get a set of jobType and colorMode combination in Document 
     * @param[out] jcset - a set of jobType and colorMode combination
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetJobTypeColorSet(JobTypeColorSet &jcset);
	 
    
    //-------------------- System File Properties --------------------
    /**
     * get total page of the document
     * @param[out] total - total page of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetTotalPage(int &total);
    
    /**
     * get total size of the document
     * @param[out] total - total size of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetTotalSize(uint64 &total);
    //-------------------- end of System File Properties --------------------
    
    /**
     * cut the page to clipboard
     * if document status is NOT EDITING, it will fail.
     * @param[in] pageno - source page number
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CutPage(int pageno);
    
    /**
     * cut the pages to clipboard
     * if document status is NOT EDITING, it will fail.
     * @param[in] pages - vector of source page numbers
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CutPage(std::vector<int> pages);
    
    /**
     * copy the page to clipboard
     * @param[in] pageno - source page number
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CopyPage(int pageno);
    
    /**
     * copy the pages to clipboard
     * @param[in] pages - vector of source page numbers
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CopyPage(std::vector<int> pages);
    
    /**
     * paste the page(s) from clipboard
     * if document status is NOT EDITING, it will fail.
     * @param[in] pageno - page number to insert
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the partition. 
     */
    Status PastePage(int pageno);

	/**
     * paste the page(s) from clipboard
     * if document status is NOT EDITING, it will fail.
     * @param[in] pageno - page number to insert
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the partition. 
     */
	 Status FasterPastePage(int pageno);

    /**
     * delete page
     * @param[in] pageno - delete page number. after deletion, the pages that 
     *                     have greater page number are off to the front.
     * @param[in] size - delete page size (default = 1)
     * @return STATUS_OK on success,
     *         STATUS_OUT_OF_RANGE if the user specified page doesn't exist
     *         STATUS_FAILED on failure.
     */
    Status DeletePage(int pageno, int delete_size = 1);
    
    /**
     * delete page
     * @param[in] pages - vector of delete page numbers. after deletion, 
     *                     the pages that have greater page numbers are off to
     *                     the front.
     * @return STATUS_OK on success,
     * 	       STATUS_OUT_OF_RANGE if any of the user specified page doesn't exist
     *         STATUS_FAILED on failure.
     */
    Status DeletePage(std::vector<int> pages);
    Status DeletePages(std::vector<int> pages, bool isThumbDataAvail = false, bool isSubsmplDataAvail = false);
    
    // CDocument methods
    /**
     * create document folder and status file
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status Initialize();
    
    /**
     * load properties from WebDAV
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status LoadProperties();

	Status LoadProperties(std::map<CString, CString> WebDAVpropertyMap);

	
    /**
     * save properties to WebDAV
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SaveProperties();
	 
	Status GetProperties(std::map<CString, CString> &WebDAVProperties);

	Status SetProperties(std::map<CString, CString> WebDAVProperties);

	 
    /**
     * delete document folder and status file
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * @NOTE need to enter critical section before calling this method
     */
    Status Delete();

    /**
     * Getnextpage returns next page number as a 5 digit string
     * @return STATUS_OK on success,
     * 
     */
	CString GetNextPage(int pageno);

	/**
	* get full size of the document
	* It includes the size of all files that compose Document.
	* @param[out] total - total size (byte) of the container
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/	 
	Status GetFullSize(uint64 &size);

	/**
	* save the delta document. 
	* change document status from EDITING to READY. if document status is 
	* NOT EDITING, it will fail.
	* when this method is called, unlock delta document. delta documents 
	* will be overwritten to original documents. after that all delta 
	* documents will be deleted. 
	* @param[out] progress - user can get operation progress from this.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status Save(ProgressRef &progress);

	/**
	* save the edited document with other name
	* change document status from EDITING to READY. if document status is 
	* NOT EDITING, it will fail.
	* when this method is called, unlock delta document. delta documents 
	* will be overwritten to original documents. after that all delta 
	* documents will be deleted. 
	* @param[out] progress - user can get operation progress from this.
	* @param[in] new_name - merged document save as the name
	* @param[in] resourcebasepath - save to the this folder, if it is set.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status SaveAs(ProgressRef &progress,CString new_name,CString resourcebasepath = "");



	/**
	* cut the page to clipboard
	* if document status is NOT EDITING, it will fail.
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pageno - source page number
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status CutPage(ProgressRef& progress, int pageno);

	/**
	* cut the pages to clipboard
	* if document status is NOT EDITING, it will fail.
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pages - vector of source page numbers
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status CutPage(ProgressRef& progress, std::vector<int> pages);

	/**
	* copy the page to clipboard
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pageno - source page number
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status CopyPage(ProgressRef& progress, int pageno);

	/**
	* copy the pages to clipboard
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pages - vector of source page numbers
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status CopyPage(ProgressRef& progress, std::vector<int> pages);


	/**
	* paste the page(s) from clipboard
	* if document status is NOT EDITING, it will fail.
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pageno - page number to insert
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status PastePage(ProgressRef& progress, int pageno);

	/**
	* paste the page(s) faster from clipboard
	* if document status is NOT EDITING, it will fail.
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pageno - page number to insert
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure,
	*         STATUS_DISK_FULL if there is not enough space on the disk.
	*/
	Status FasterPastePage(ProgressRef& progress, int pageno);
	
	/**
	* delete page
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pageno - delete page number. after deletion, the pages that 
	*                     have greater page number are off to the front.
	* @param[in] size - delete page size (default = 1)
	* @return STATUS_OK on success,
	*         STATUS_OUT_OF_RANGE if the user specified page doesn't exist
	*         STATUS_FAILED on failure.
	*/
	Status DeletePage(ProgressRef& progress, int pageno,int delete_size = 1);

	/**
	* delete page
	* @param[out] progress - user can get operation progress from this.
	* @param[in] pages - vector of delete page numbers. after deletion, 
	*                     the pages that have greater page numbers are off to
	*                     the front.
	* @return STATUS_OK on success,
	* 	  STATUS_OUT_OF_RANGE if the user specified page doesn't exist
	*         STATUS_FAILED on failure.
	*/
	Status DeletePage(ProgressRef& progress, std::vector<int> pages);

	Status DeleteSinglePage(int pageno);

	
	/**
	* Creating the thread for Cut operation i.e. to cut the page to clipboard
	* if document status is NOT EDITING, it will fail.
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] pages - vector of source page numbers
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateCutThread(CDocument *docObj,std::vector<int> pages);

	/**
	* Creating the thread for Copy operation i.e. to copy the pages to clipboard
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] pages - vector of source page numbers
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateCopyThread(CDocument *docObj,std::vector<int> pages);
	
	/**
	* Creating the thread for Save operation i.e. to Save the Delta Document
	* if document status is NOT EDITING, it will fail.
	* @param[in] docObj - Instance of the CDocument Class.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateSaveThread(CDocument *docObj);

	/**
	* Creating the thread for SaveAs operation i.e. to Save the edited document with other name.
	* if document status is NOT EDITING, it will fail.
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] newname - merged document save as the name.
	* @param[in] resourcebasepath - save to the this folder, if it is set.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateSaveAsThread(CDocument *docObj,CString newname,CString resourcebasepath);	
	
	/**
	* Creating the thread for Paste operation i.e. to paste the page(s) from clipboard.
	* if document status is NOT EDITING, it will fail.
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] pageno - page number to insert
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/

	Status CreatePasteThread(CDocument *docRef,int pageno);

	/**
	* Creating the thread for faster Paste operation i.e. to paste the page(s) from clipboard.
	* if document status is NOT EDITING, it will fail.
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] pageno - page number to insert
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateFasterPasteThread(CDocument *docRef,int pageno);

	/**
	* Creating the thread for Delete operation i.e. to Delete page.
	* @param[in] docObj - Instance of the CDocument Class.
	* @param[in] pages - vector of delete page numbers. after deletion, 
	*                     the pages that have greater page numbers are off to
	*                     the front.
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateDeleteThread(CDocument *docObj,std::vector<int> pages);
	
	/**
	* get a map of paper size in Document 
	* @param[out] papermap - a map of paper size in Document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	Status GetPaperSizeMap(PaperSizeMap &papermap);

	/**
	* get a map of color mode in Document 
	* @param[out] colormap - a map of color mode in Document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	Status GetColorModeMap(ColorModeMap &colormap);

	/**
	* get a map of job type in Document 
	* @param[out] jobmap - a map of job type in Document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	Status GetJobTypeMap(JobTypeMap &jobmap);

	/**
	* get a map of horizontal resolution in Document 
	* @param[out] hrmap - a map of horizontal resolution in Document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	Status GetHorizontalResolutionMap(ResolutionMap &hrmap);


	/**
	* get a map of vertical resolution in Document 
	* @param[out] vrmap - a map of vertical resolution in Document
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	*/
	Status GetVerticalResolutionMap(ResolutionMap &vrmap);

	/**
	 * set input page count of the document
	 * @param[in] count - input page count of the document
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status SetInputPageCount(int count);

	/**
	 * get input page count of the document
	 * @param[out] count - input page count of the document
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status GetInputPageCount(int &count);
	
    /**
     * change status for using the document
     * change document status from READY to RESERVING. if document status is 
     *   NOT READY, it will fail.
     * - when Reserve() is called on RESERVING, it will fail as well.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     */
    Status Reserve();

    /**
     * change status after using the document
     * change document status from RESERVING to READY
     *  & if document status is NOT RESERVING, it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     */
    Status EndReserving();

    Status GetThumbnailImage(CString &path);

    /**
     * moves the page from source to destination during Scan Preview	 
     * @param[in] srcpageno    - The source page number to be moved from  
     * @param[in] dstpageno    - The destination page number to which the source page has to be moved to
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_OUT_OF_RANGE if the user specified srcpage doesn't exist/
     *                             if the user specified dstpageno is out of range
     * Note : MovePage is not supported for XPS & DIB file formats
     */
    Status MovePage(int srcpageNo, int dstpageNo );

    /**
     * get rotation angle of the image file during scan preview
     * @param[in]  pageno - page number of the page that has to be rotated
     * @param[out] rangle  - NOROTATE / ROTATE90 / ROTATE180 / ROTATE270
     * @return STATUS_OK on success
     *         STATUS_FAILED on failure.
     *         STATUS_OUT_OF_RANGE if the user specified page doesn't exist	 
     * Note : GetRotation return zero degrees if rotationAngle property doesn't exist 
     */
    Status GetRotation(int pageNo,RotateAngle &rangle);
    /**
     * Rotates the page by 90 degrees clockwise during Scan preview
     * @param[in]  pageno    - page number of the page that has to be rotated 
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     *         STATUS_OUT_OF_RANGE if the user specified page doesn't exist
     * Note : Only PDF file formats (PDF or Slim PDF or PDF/A or PDF/A-2) are supported for Rotate page
     */

    Status Rotate(int pageNo);

    /**
     *Added to support EBX_RCR_235 FAX Preview
     * set fax preview property for document
	 * default fax preview property is "false" 
     * @param[in] value - the property value
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetFaxPreviewProperty(bool value);
    
    /**
     *Added to support EBX_RCR_235 FAX Preview
     * get fax preview property for document
	 * default fax preview property is "false" 
     * @param[out] value - the property value
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFaxPreviewProperty(bool &value);	
    
    /**
     * get new page instance. 
     * this page is not related with any Document. use Document::AppendPage()
     * after setting page properties.
     * @param[out] page - new instance of Page class
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CreatePage(PageRef &page);

}; // class CDocument
class CViewDocument : public Document
{
   private:
      //Ref<documentstore::Session> m_Session;
      CString m_sessionID;
      CString m_BoxBasePath;
      CString m_BoxBasePathOrg;		
      CString m_BoxNumber;
      CString m_FolderName;
      CString m_DocumentName;
      std::map<CString, CString> m_WebDAVProperties;		
   	uint64 m_TotalSize;
	  uint64 m_TotalDocSize;		
     std::map<PaperSize,int> m_PaperSizeMap;
	  std::map<JobTypeColor,int> m_JobTypeColorMap;
	  void WorkSpaceInit();
	  Status OpenSystemDataFile(FL_FILE_MAN_FILE *system, CString path);
	  void RevertPaths(CString basepath,CString boxNumber,CString folderName,CString docName);
   public:
      Status LoadProperties(std::map<CString, CString> WebDAVpropertyMap);		

      /**
       * constructor
       */
      CViewDocument(CString sessionID,
            CString boxbasepath, 
            CString boxnumber, 
            CString foldername, 
            CString documentname);

      // destructor
      virtual ~CViewDocument();
      Status GetStatus(DocStatus &st);
      Status ReCreate() {return STATUS_FAILED; }
      Status EndCreating() { return STATUS_FAILED; }
      Status Use() { return STATUS_FAILED; }
      Status EndUsing() { return STATUS_FAILED; }
      Status Edit() { return STATUS_FAILED; }
      Status Save() { return STATUS_FAILED; }
      Status Save(ProgressRef &progress) { return STATUS_FAILED; }
      Status SaveAs(CString new_name, CString resourcebasepath = "") { return STATUS_FAILED; }
      Status SaveAs(ProgressRef &progress, 
            CString new_name, 
            CString resourcebasepath = "") { return STATUS_FAILED; }
      Status CancelEdit() { return STATUS_FAILED; }
      Status CreatePage(PageRef &page) { return STATUS_FAILED; }
      Status GetPage(int pageno, PageRef &page, FL_FILE_MAN_FILE *sd, FL_FILE_MAN_FILE *sd1, FL_FILE_MAN_FILE *sd2);
      Status GetPage(int pageno, PageRef &page){return STATUS_FAILED;}
      Status AppendPage(PageRef page) { return STATUS_FAILED; }
      Status InsertPage(int pageno, PageRef page) { return STATUS_FAILED; }
      Status InsertPage(int pageno, PageList pages) { return STATUS_FAILED; }
      Status InsertBlankPage(int pageno, PaperSize size) { return STATUS_FAILED; }
      Status ReplacePage(int pageno, PageRef page) { return STATUS_FAILED; }
      Status ReplacePage(int pageno, PageList pages) { return STATUS_FAILED; }
      Status AppendPageByLink(PageRef page) { return STATUS_FAILED; }
      Status InsertPageByLink(int pageno, PageRef page) { return STATUS_FAILED; }
      Status ReplacePageByLink(int pageno, PageRef page) { return STATUS_FAILED; }
      Status GetPageList(PageList &list) { return STATUS_FAILED; }
      Status GetPageList(PageList &list, 
            unsigned int from, unsigned int size) { return STATUS_FAILED; }
      Status GetViewPageList(PageList &list);
      Status GetViewPageList(PageList &list, 
            unsigned int from, unsigned int size);
      Status PutSystemFile(CString path) { return STATUS_FAILED; }
      Status SetWebDAVPropertyFromSystemFile(void* systemfile) { return STATUS_FAILED; }
      Status GetSystemFile(CString &path) { return STATUS_FAILED; }
      Status PutSubSamplingSystemFile(CString path) { return STATUS_FAILED; }
      Status GetSubsamplingSystemFile(CString &path) { return STATUS_FAILED; }
      Status PutThumbnailSystemFile(CString path) { return STATUS_FAILED; }
      Status GetThumbnailSystemFile(CString &path) { return STATUS_FAILED; }
      Status SetWEPDocument(dom::NodeRef node) { return STATUS_FAILED; }
      Status GetWEPDocument(dom::NodeRef &node, CString xpath = "") { return STATUS_FAILED; }
      Status GetWEPDocument(CString& documentID) { return STATUS_FAILED; }
      Status SetWebDAVProperty(CString key, CString value) { return STATUS_FAILED; }
      Status SetWebDAVProperty(CString key, int value) { return STATUS_FAILED; }
      Status GetWebDAVProperty(CString key, CString &value);
      Status SetName(CString name) { return STATUS_FAILED; }
      Status GetName(CString &name);
      Status GetPaperSizeSet(PaperSizeSet &paperset);
      Status GetJobTypeColorSet(JobTypeColorSet &jcset);
      Status GetTotalPage(int &total);
      Status GetTotalSize(uint64 &total);
      Status CutPage(int pageno) { return STATUS_FAILED; }
      Status CutPage(std::vector<int> pages) { return STATUS_FAILED; }
      Status CutPage(ProgressRef& progress, int pageno) { return STATUS_FAILED; }
      Status CutPage(ProgressRef& progress, std::vector<int> pages) { return STATUS_FAILED; }
      Status CopyPage(int pageno) { return STATUS_FAILED; }
      Status CopyPage(std::vector<int> pages) { return STATUS_FAILED; }
      Status CopyPage(ProgressRef& progress, int pageno) { return STATUS_FAILED; }
      Status CopyPage(ProgressRef& progress, std::vector<int> pages) { return STATUS_FAILED; }
      Status PastePage(int pageno) { return STATUS_FAILED; }
      Status PastePage(ProgressRef& progress, int pageno) { return STATUS_FAILED; }
	  Status FasterPastePage(int pageno) { return STATUS_FAILED; }
      Status FasterPastePage(ProgressRef& progress, int pageno) { return STATUS_FAILED; }
      Status DeletePage(int pageno, int delete_size = 1) { return STATUS_FAILED; }
      Status DeletePage(std::vector<int> pages) { return STATUS_FAILED; }
      Status DeletePage(ProgressRef& progress, 
            int pageno, 
            int delete_size = 1) { return STATUS_FAILED; }
      Status DeletePage(ProgressRef& progress, 
            std::vector<int> pages) { return STATUS_FAILED; }
      Status GetPaperSizeMap(PaperSizeMap &papermap);
      Status GetColorModeMap(ColorModeMap &colormap) { return STATUS_FAILED; }
      Status GetJobTypeMap(JobTypeMap &jobmap) { return STATUS_FAILED; }
      Status GetHorizontalResolutionMap(ResolutionMap &hrmap) { return STATUS_FAILED; }
      Status GetVerticalResolutionMap(ResolutionMap &vrmap) { return STATUS_FAILED; }
      Status SetInputPageCount(int count) { return STATUS_FAILED; }
      Status GetInputPageCount(int &count) { return STATUS_FAILED; }
      Status Reserve() { return STATUS_FAILED; }
      Status EndReserving() { return STATUS_FAILED; }
      Status GetThumbnailImage(CString &path);
      Status MovePage(int srcpageNo, int dstpageNo ) { return STATUS_FAILED;}
      Status GetRotation(int pageNo,RotateAngle &rangle){ return STATUS_FAILED; }
      Status Rotate(int pageNo){ return STATUS_FAILED;}
      Status SetFaxPreviewProperty(bool value){return STATUS_FAILED;}
      Status GetFaxPreviewProperty(bool &value){return STATUS_FAILED;}
};

class CDocumentProperties : public DocumentProperties
{
private:
	//Ref<documentstore::Session> m_Session;
	CString m_SessionID;
    	CString m_BoxBasePath;
    	CString m_BoxNumber;
    	CString m_FolderName;
    	CString m_DocumentName;
    	PageList m_PageList; // PageList is loaded when it's used

public:
    /**
     * constructor
     */
    CDocumentProperties(/*Ref<documentstore::Session> session,*/
              CString boxbasepath, 
              CString boxnumber, 
              CString foldername, 
              CString documentname);
    
    // destructor
    virtual ~CDocumentProperties();
	 
    /**
     * get a name of the document
     * @param[out] name - a name of the container
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetName(CString &name);
    
    /**
     * get total page of the document
     * @param[out] total - total page of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetTotalPage(int &total);
    
    /**
     * get "from" property of the document
     * @param[out] from - "from" property of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFromProperty(CString &from);
    
    /**
     * get reception time of the document
     * @param[out] receptiontime - reception time of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetReceptionTime(CString &receptiontime);
    
    /**
     * get reception number of the document
     * @param[out] receptionnum - reception number of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetReceptionNumber(CString &receptionnum);

    /**
     * get status of the document
     * @param[out] st - current status of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
     Status GetStatus(DocStatus &st);

    /**
     * get fromString of the document
     * @param[out] fromString - fromString of the document
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFromString(CString &fromString);
	
	/**
	 * get fromStringFirstName of the document
	 * @param[out] firstName - firstName of the document
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	 Status GetFromStringFirstName(CString &firstName);

	/**
	 * get fromStringLastName of the document
	 * @param[out] lastName - lastName of the document
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	 Status GetFromStringLastName(CString &lastName);

	/** 
	 * get the status for FAX received data.  
	 * @param[out] receivedData - the status for FAX received data.
	 * @return STATUS_OK on success,
	 *	   STATUS_FAILED on failure.
	 * @NOTE - It is available via GetDocumentList
	 */	     
	 Status GetStatusOfReceivedData(CString &receivedData);
        
    /**
 	 * get the status for hard copy 
 	 * @param[out] hardCopy - the status for hard copy
 	 * @return STATUS_OK on success,
 	 * 	   STATUS_FAILED on failure.
 	 * @NOTE - It is available via GetDocumentList
 	 */
    Status GetStatusOfHardCopy(CString &hardCopy); 

   /**
 	 * get the status for relay report 
 	 * @param[out] relayReport - the status for relay report
 	 * @return STATUS_OK on success,
 	 * 	   STATUS_FAILED on failure.
 	 * @NOTE - It is available via GetDocumentList
 	 */
    Status GetStatusOfRelayReport(CString &relayReport);   
 	  
	/**
 	 * set the status for FAX received data.
 	 * @param[in] receivedData - the status for FAX received data.
 	 * @return STATUS_OK on succcess,
 	 * 	   STATUS_FAILED on failure.
 	 * @NOTE - It is available via GetDocumentList
 	 */
 	 Status SetStatusOfReceivedData(CString receivedData);    
	
	/**
	 * set the status for hard copy.
 	 * @param[in] hardCopy - the status for hard copy.
 	 * @return STATUS_OK on succcess,
 	 * 	   STATUS_FAILED on failure.
 	 * @NOTE - It is available via GetDocumentList
 	 */
    Status SetStatusOfHardCopy(CString hardCopy);

   /** 
 	 * set the status for relay report.
 	 * @param[in] relayReport - the status for relay report.
 	 * @return STATUS_OK on succcess,
 	 * 	   STATUS_FAILED on failure.
 	 * @NOTE - it is available via GetDocumentList
 	 */
 	 Status SetStatusOfRelayReport(CString relayReport);    

   /**
    * get the status for polling transmission
    * @param[out] pollingTransmission - the status for polling transmission
    * @return STATUS_OK on success,
    *         STATUS_FAILED on failure.
    */
   Status GetStatusOfPollingTransmission(CString &pollingTransmission);

   /**
    * set the status for polling transmission
    * @param[in] pollingTransmission - the status for polling transmission
    * @return STATUS_OK on success,
    *         STATUS_FAILED on failure.
    */
   Status SetStatusOfPollingTransmission(CString pollingTransmission);
};
}; // end of namespace boxdocument
}; // end of namespace ci

#endif // __CI_CDOCUMENT_H__
