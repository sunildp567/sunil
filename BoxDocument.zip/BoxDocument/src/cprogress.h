/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cprogress.h
 Revision: com_t#1
 File Spec: EBX:TA8452.A-DEV_SRC;com_t#1
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 22:02:16

  Outline : definition of box operation

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#1 (APPROVED)
     Created:  09-JAN-2009 22:02:16      CHANDRAMOHAN.PUJARI
       Initial Version
========================== End of Source Header =============================*/

#ifndef __CI_CPROGRESS_H__
#define __CI_CPROGRESS_H__

#include <CI/BoxDocument/progress.h>
#include <CI/OperatingEnvironment/ref.h>
#include "CI/OperatingEnvironment/sharedmemory.h"
#include <CI/OperatingEnvironment/cstring.h>

using namespace ci::operatingenvironment;

namespace ci {
namespace boxdocument {

DECL_OBJ_REF(Progress);
#define PROGRESS_COMPLETED 100

/**
 * Progress class provides facilities to get progress.
 */
class CProgress:public Progress
{
	
	//Name of Created Shared Segment
	CString m_ProgShmName;
	CString m_ProgErrName;
	CString m_sessionID;
	CString m_BoxBasePath;
	CString m_BoxNumber;
	CString m_FolderName;
	CString m_DiskFullName;
	CString m_ResourceNotFound;
	CString m_Copypage2ndsession;

public:
    	//Constructor
	CProgress(CString progname,CString errname,CString sesseionID = "",CString BoxBasePath = "",CString BoxNumber = "", CString FolderName = "",CString diskFullFileName = "", CString ResourceNotFoundFileName = "", CString copypage2ndsession = ".copypage2ndsession_");
	/** Virtual destructor */
	virtual ~CProgress();//{ DEBUGL1("CProgress::~CProgress called\n");}
    
    /**
     * get progress
     * when error happen, progress is always 100. And return value is NOT 
     * STATUS_OK. It depends on each operation.
     * @param[out] progress - progress [0-100] %
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
	Status GetProgress(int &progress);

	
};

}; // end of namespace boxdocument
}; // end of namespace ci

#endif // #ifndef __CI_PROGRESS_H__
