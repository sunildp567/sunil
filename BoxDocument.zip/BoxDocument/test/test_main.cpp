#include<iostream>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>

using namespace std;
using namespace ci::softwarediagnostics;

extern bool test_boxbase();
extern bool test_inbox();
extern bool test_boxout();
extern bool test_inboxByLink();

extern bool test_deletedocument();
extern bool test_editdocument();
extern bool utr_testcases();

int main(int argc, char** argv) {
    DiagLogger::PreProcessArgs(argc, argv);
    
    bool result;
    
    while(1) {
        int i = 0;
        cout << "BoxDocument Test Program" <<  endl;
        cout << "1. View Box" << endl;
        cout << "2. Sequence inBox" << endl;
        cout << "3. Sequence inBox by link" << endl;
//        cout << "3. Sequence boxOut" << endl;
        cout << "0. exit" << endl;
        cin >> i;
        result = false;
        switch(i) {
        case 0: return 0;
        case 1: result = test_boxbase(); break;
        case 2: result = test_inbox(); break;
        case 3: result = test_inboxByLink(); break;
		
//        case 3: result = test_boxout(); break;
        }
        cout << "result = " << result << endl;
    }
    return 0;
}
