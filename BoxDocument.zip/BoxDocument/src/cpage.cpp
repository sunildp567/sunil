/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
  ============================== Source Header =================================
Filename: cpage.cpp
Revision: com_t#7
File Spec: EBX:MA6038.A-DEV_SRC;com_t#7
Originator: LOCHANA.LINGEGOWDA
Last Changed: 09-JAN-2009 21:49:39

Outline : 

*/
/*----------------------------------------------------------------------------
  Related Change Documents:
  Not related to any Change Document
  ------------------------------------------------------------------------------
  Related Baselines:
  1:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
  	Creation Date: 13-JAN-2009 19:36:02
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
  
  2:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
  	Creation Date: 13-JAN-2009 18:00:09
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
  
  3:
  	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
  	Creation Date: 13-JAN-2009 15:14:46
  	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
  
  ------------------------------------------------------------------------------
History:
 * Revision com_t#7 (APPROVED)
 *   Created:  09-JAN-2009 21:49:39      CHANDRAMOHAN.PUJARI
 *   Updated:  09-JAN-2009 21:49:39      CHANDRAMOHAN.PUJARI
 *   Updated:  09-JAN-2009 21:49:39      CHANDRAMOHAN.PUJARI
 *   Updated:  09-JAN-2009 21:49:39      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#7 created from revision com_t#6 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#6 (UNIT TESTED)
 *   Created:  23-DEC-2008 22:01:45      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:01:45      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#6 created from revision com_t#5 with status
 *     $TO_BE_DEFINED
 *   Updated:  23-DEC-2008 22:01:45      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 *   Updated:  23-DEC-2008 22:01:45      CHANDRAMOHAN.PUJARI
 *     changes done to support Copy JPEG params issue
 * 
 * Revision com_t#5 (APPROVED)
 *   Created:  19-DEC-2008 21:45:48      CHANDRAMOHAN.PUJARI
 *     support copyJpeg parameter and SetResolution fix
 *   Updated:  19-DEC-2008 21:45:48      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#5 created from revision com_t#4 with status
 *     $TO_BE_DEFINED
 *   Updated:  19-DEC-2008 21:45:48      CHANDRAMOHAN.PUJARI
 *     support copyJpeg parameter and SetResolution fix
 *   Updated:  19-DEC-2008 21:45:48      CHANDRAMOHAN.PUJARI
 *     support copyJpeg parameter and SetResolution fix
 * 
 * Revision com_t#4 (APPROVED)
 *   Created:  08-DEC-2008 21:05:42      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,ColorMode Information,Error Codes
 *   Updated:  08-DEC-2008 21:05:42      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,ColorMode Information,Error Codes
 *   Updated:  08-DEC-2008 21:05:42      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#4 created from revision com_t#3 with status
 *     $TO_BE_DEFINED
 *   Updated:  08-DEC-2008 21:05:42      CHANDRAMOHAN.PUJARI
 *     Added Code for ScanPreview,ColorMode Information,Error Codes
 * 
 * Revision com_t#3 (APPROVED)
 *   Updated:  20-NOV-2008 13:58:40      LOCHANA.LINGEGOWDA
 *     For CP4 - 4th Build
 *   Created:  20-NOV-2008 13:56:35      SACHIDANANDA
 *     GetSubsamplingImage - Fix to return correct ImagePath
 *   Updated:  20-NOV-2008 13:56:35      SACHIDANANDA
 *     GetSubsamplingImage - Fix to return correct ImagePath
 *   Updated:  20-NOV-2008 13:53:10      SACHIDANANDA
 *     Item revision com_t#3 created from revision com_t#2 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#2 (APPROVED)
 *   Updated:  17-NOV-2008 22:03:53      CHANDRAMOHAN.PUJARI
 *     Added Implementation for derived functions of New Interface API
 *     s of Page Class
 *   Created:  17-NOV-2008 22:03:52      CHANDRAMOHAN.PUJARI
 *     Added Implementation for derived functions of New Interface API
 *     s of Page Class
 *   Updated:  17-NOV-2008 22:03:52      CHANDRAMOHAN.PUJARI
 *     Added Implementation for derived functions of New Interface API
 *     s of Page Class
 *   Updated:  17-NOV-2008 22:03:52      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#2 created from revision com_t#1 with status
 *     $TO_BE_DEFINED
 * 
 * Revision com_t#1 (APPROVED)
 *   Created:  03-NOV-2008 19:08:48      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 *   Updated:  03-NOV-2008 19:08:48      CHANDRAMOHAN.PUJARI
 *     Item revision com_t#1 created from revision com_m#1.2 with
 *     status $TO_BE_DEFINED
 *   Updated:  03-NOV-2008 19:08:48      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 *   Updated:  03-NOV-2008 19:08:48      CHANDRAMOHAN.PUJARI
 *     Received updated code from MSM. Checking in on behalf of MSM
 * 
 * Revision com_m#1.2 (APPROVED)
 *   Updated:  01-SEP-2008 17:15:58      13848
 *     Updated attribute(s)
 *   Created:  01-SEP-2008 17:14:34      13848
 *     Update for Ph3.5 1st build
 *   Updated:  01-SEP-2008 17:13:14      13848
 *     Item revision com_m#1.2 created from revision com_m#1.1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1.1 (UNIT TESTED)
 *   Updated:  01-SEP-2008 16:51:17      13848
 *     Updated attribute(s)
 *   Created:  25-AUG-2008 20:11:40      13848
 *     BoxDocument 2nd release
 *   Updated:  25-AUG-2008 20:08:10      13848
 *     Item revision com_m#1.1 created from revision com_m#1 with
 *     status $TO_BE_DEFINED
 * 
 * Revision com_m#1 (UNDER WORK)
 *   Created:  19-AUG-2008 14:34:31      13848
 *     Initial revision
========================== End of Source Header =============================*/
#include <iomanip>
#include <sstream>
#include <cstring>
#include <CI/OperatingEnvironment/file.h>
#include "cpage.h"
#include "proputils.h"

using namespace std;
namespace ci 
{
		namespace boxdocument 
		{
				using namespace papersize;
				
#define COM_IP_NOTHING                                  0
#define COM_IP_MH                                               1
#define COM_IP_MR                                               2
#define COM_IP_MMR                                              3
#define COM_IP_MG3                                              4
#define COM_IP_EXP                                              5
#define COM_IP_JBIG                                     6
#define COM_IP_RECTOR                                   7
#define COM_IP_TIFF                                     8
#define COM_IP_JPEG                                     9
#define COM_IP_PDF                                              10
#define COM_IP_PNG                                              11
#define COM_IP_TJPEG                                    12
#define COM_IP_XPS                                              13
#define COM_IP_DIB                                              14
#define COM_IP_CJPEG_VL                                 15
#define COM_IP_RECTOR_1DS                               16

#define COM_IP_DOC         				 17
#define COM_IP_PPT        				 18
#define COM_IP_XLS         				 19

#define COM_CB_MONO                                     0
#define COM_CB_FULLCOLOR                                2

#define COM_DT_1BIT                                     1
#define COM_DT_4BIT                                     4
#define COM_DT_8BIT                                     8
#define COM_DT_24BIT                                    24

#define COM_YCC_411                                     1
#define COM_YCC_444                                     3
#define COM_YCC_INVALID                                 0

#define COM_IO_PORTRAIT                         0
#define COM_IO_LANDSCAPE                        1

#define COM_RT_NOTHING                          0
#define COM_RT_90                                       1
#define COM_RT_180                                      2
#define COM_RT_270                                      3

				//using namespace ci::DocumentStore;

pthread_mutex_t gpage_mutex_initializer = PTHREAD_MUTEX_INITIALIZER;
std::map<CString,PaperSize> CPage::m_PaperSizeEnumStringMap;
std::map<int,CString> CPage::m_ExtensionTypes;
				// constructor
				CPage::CPage(int pageno, CString documenturi, CString boxbasepath) :
						m_PageNo(pageno),
						m_DocumentURI(documenturi),
						m_ParamFile(NULL),
						m_BoxBasePath(boxbasepath)
				{
						if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
							DEBUGL2("\nCPage::CPage: Failed to increment the count\n ");
	
						memset((FL_PAGE_MAN_TBL *)&(m_PageInformation),'\0',sizeof(FL_PAGE_MAN_TBL));
						memset((FL_PAGE_MAN_TBL *)&(m_SubsamplingPageInformation),'\0',sizeof(FL_PAGE_MAN_TBL));			
						memset((FL_PAGE_MAN_TBL *)&(m_ThumbnailPageInformation),'\0',sizeof(FL_PAGE_MAN_TBL));
						m_ParamFileSize = 0;
						m_VerticalResolution = 0;
						typedef std::map<CString, CString> property_pair;
						m_WebDAVProperties.insert(property_pair::value_type("jobType", ""));
						m_WebDAVProperties.insert(property_pair::value_type("horizontalResolution", ""));
						m_WebDAVProperties.insert(property_pair::value_type("verticalResolution", ""));
						m_WebDAVProperties.insert(property_pair::value_type("imageWidth", ""));
						m_WebDAVProperties.insert(property_pair::value_type("imageHeight", ""));
						m_WebDAVProperties.insert(property_pair::value_type("paperSize", ""));
						m_WebDAVProperties.insert(property_pair::value_type("fileSize", ""));
						m_WebDAVProperties.insert(property_pair::value_type("colorMode", ""));	 
						m_WebDAVProperties.insert(property_pair::value_type("cutPage", ""));	 			

						int mcerr =pthread_mutex_lock(&gpage_mutex_initializer);
   						if (mcerr != 0)
							DEBUGL2("\nCPage::CPage: pthread_mutex_lock failed\n ");
							
						if(m_ExtensionTypes.empty())
						{
						m_ExtensionTypes.insert(make_pair(COM_IP_NOTHING,".raw"));
						m_ExtensionTypes.insert(make_pair(COM_IP_MMR,".mmr"));
						m_ExtensionTypes.insert(make_pair(COM_IP_RECTOR,".rec"));
						m_ExtensionTypes.insert(make_pair(COM_IP_TIFF,".tif"));
						m_ExtensionTypes.insert(make_pair(COM_IP_JPEG,".jpg"));
						m_ExtensionTypes.insert(make_pair(COM_IP_PDF,".pdf"));
						m_ExtensionTypes.insert(make_pair(COM_IP_PNG,".png"));	
						m_ExtensionTypes.insert(make_pair(COM_IP_TJPEG,".tjp"));
						m_ExtensionTypes.insert(make_pair(COM_IP_XPS,".xps"));
						m_ExtensionTypes.insert(make_pair(COM_IP_DIB,".dib"));
						m_ExtensionTypes.insert(make_pair(COM_IP_CJPEG_VL,".cjp"));
						m_ExtensionTypes.insert(make_pair(COM_IP_RECTOR_1DS,".rec"));
						m_ExtensionTypes.insert(make_pair(COM_IP_DOC,".docx"));
						m_ExtensionTypes.insert(make_pair(COM_IP_PPT,".pptx"));
						m_ExtensionTypes.insert(make_pair(COM_IP_XLS,".xlsx"));
						m_ExtensionTypes.insert(make_pair(COM_IP_MH,".mh"));
						}

						if(m_PaperSizeEnumStringMap.empty())
						{
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A1,A1));
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A2,A2));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A3,A3));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A4,A4));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A5,A5));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A6,A6));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A7,A7));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A3Wide,A3_WIDE));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B1,B1));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B2,B2));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B3,B3));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B4,B4));							
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B5,B5));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B6,B6));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B7,B7));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LETTER,LETTER));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEDGER,LEDGER));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEGAL,LEGAL));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_STATEMENT,STATEMENT));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_COMPUTER,COMPUTER));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_FOLIO,FOLIO));		
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13inchLEGAL,LEGAL13));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_8_5SQ,SQUARE8_5));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEDGERWide,LEDGER_WIDE));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13x19inch,RECTANGLE13X19));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_8K,SIZE_8K));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_16K,SIZE_16K));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Postcard,POSTCARD));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_SRA3,SRA3_450));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_320x460mm,SRA3_460));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A1_R,A1_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A2_R,A2_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A3_R,A3_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A4_R,A4_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A5_R,A5_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A6_R,A6_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A7_R,A7_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_A3Wide_R,A3_WIDE_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B1_R,B1_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B2_R,B2_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B3_R,B3_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B4_R,B4_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B5_R,B5_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B6_R,B6_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_B7_R,B7_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LETTER_R,LETTER_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEDGER_R,LEDGER_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEGAL_R,LEGAL_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_STATEMENT_R,STATEMENT_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_COMPUTER_R,COMPUTER_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_FOLIO_R,FOLIO_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13inchLEGAL_R,LEGAL13_R));	

							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13_5Legal,LEGAL135));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13_5Legal_R,LEGAL135_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Executive,EXECTIVE));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Executive_R,EXECTIVE_R));	

							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_LEDGERWide_R,LEDGER_WIDE_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_13x19inch_R,RECTANGLE13X19_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_8K_R,SIZE_8K_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_16K_R,SIZE_16K_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Postcard_R,POSTCARD_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_DOUBLEPOSTCARD,DOUBLEPOSTCARD));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_DOUBLEPOSTCARD_R,DOUBLEPOSTCARD_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_SRA3_R,SRA3_450_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_320x460mm_R,SRA3_460_R));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Undefined,UNDEF_SIZE));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_Custom,SPECIAL_SIZE));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_CustomLongA,SPECIAL_LONG800));	
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_CustomLongB,SPECIAL_LONG1200));		
							m_PaperSizeEnumStringMap.insert(make_pair(PAPER_SIZE_CustomScan,SPECIAL_CUSTOMSCAN));		

						}
						mcerr = pthread_mutex_unlock(&gpage_mutex_initializer);
   						if (mcerr != 0)
							DEBUGL2("\nCPage::CPage: pthread_mutex_unlock failed\n ");
				}

				// destructor
				CPage::~CPage() 
				{
					if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
						DEBUGL2("\nCPage::~CPage: Failed to decrement the count\n ");

					if(m_ParamFile)
						delete []m_ParamFile;
				}

				Status CPage::PutImage(CString path) 
				{
						if(!ci::operatingenvironment::File::Exists(path)) 
						{
								DEBUGL1("CPage::PutImage::Image file is not found - %s\n", path.c_str());
								return STATUS_FAILED;
						}
						m_ImagePath = path;
						DEBUGL8("CPage::PutImage::m_ImagePath is - %s\n", m_ImagePath.c_str());
						return STATUS_OK;
				}

				Status CPage::GetImage(CString &path) 
				{
						path = m_ImagePath;
						return STATUS_OK;
				}

				Status CPage::PutSubsamplingImage(CString path) 
				{
						if(!ci::operatingenvironment::File::Exists(path)) 
						{
								DEBUGL1("CPage::PutSubsamplingImage::Subsampling file is not found - %s\n", path.c_str());
								return STATUS_FAILED;
						}
						m_SubsamplingPath = path;
						DEBUGL8("CPage::PutSubsamplingImage::m_SubsamplingPath is - %s\n", m_SubsamplingPath.c_str());
						return STATUS_OK;
				}

				Status CPage::GetSubsamplingImage(CString &path) 
				{
						path = m_SubsamplingPath;
						return STATUS_OK;
				}

				Status CPage::PutThumbnailImage(CString path) 
				{
						if(!ci::operatingenvironment::File::Exists(path)) 
						{
								DEBUGL1("CPage::PutThumbnailImage::Thumbnail file is not found - %s\n", path.c_str());
								return STATUS_FAILED;
						}
						m_ThumbnailPath = path;
						DEBUGL8("CPage::PutThumbnailImage::m_ThumbnailPath is - %s\n", m_ThumbnailPath.c_str());
						return STATUS_OK;
				}

				Status CPage::GetThumbnailImage(CString &path) 
				{
						path = m_ThumbnailPath;
						return STATUS_OK;
				}

				Status CPage::SetWebDAVProperty(CString key, CString value) 
				{
						typedef std::map<CString, CString> pair;
						std::map<CString, CString> PropertyMap;
						CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(m_PageNo) + ".xml";
						//CString xmlfile("pageproperties.xml");
						CString modifiedtime = Utility::GetUnixTime();
						m_WebDAVProperties[key] = value;
						if(m_DocumentURI.length() != 0)
						{
							PropertyMap.insert(pair::value_type(key.c_str(), value.c_str()));
							CString path = m_DocumentURI + "Image/";
							Status st = Utility::SetProperties(path,xmlfile,PropertyMap);						
							return st;
						}
						else
							return STATUS_OK;
				}


				Status CPage::SetWebDAVProperty(CString key, int value) 
				{
						std::ostringstream oss;
						oss << value;
						return SetWebDAVProperty(key, oss.str());
				}

				Status CPage::GetWebDAVProperty(CString key, CString &value) 
				{
						value = m_WebDAVProperties[key];
						return STATUS_OK;
				}

				Status CPage::SetSystemFile(void* systemfile)
				{
						if(!systemfile)
						{
								DEBUGL1("CPage::SetSystemFile::Invalid system file\n");
								return STATUS_FAILED;
						}
						return(SetWebDAVPropertyFromSystemFile(systemfile));
				}

				Status CPage::SetSubSamplingSystemFile(void* systemfile)
				{
						if(!systemfile)
						{
								DEBUGL1("CPage::SetSubSamplingSystemFile::Invalid system file\n");
								return STATUS_FAILED;
						}

						FL_PAGE_MAN_TBL* fl_page_man_tbl = (FL_PAGE_MAN_TBL*)systemfile;
						m_SubsamplingPageInformation = *fl_page_man_tbl;
						return STATUS_OK;
				}

				Status CPage::SetThumbnailSystemFile(void* systemfile)
				{
						if(!systemfile)
						{
								DEBUGL1("CPage::SetThumbnailSystemFile::Invalid system file\n");
								return STATUS_FAILED;
						}

						FL_PAGE_MAN_TBL* fl_page_man_tbl = (FL_PAGE_MAN_TBL*)systemfile;
						m_ThumbnailPageInformation = *fl_page_man_tbl;
						return STATUS_OK;
				}


				Status CPage::GetResolution(int &horizontal, int &vertical) 
				{
						horizontal = m_HorizontalResolution;
						vertical = m_VerticalResolution;
						return STATUS_OK;
				}

				Status CPage::GetImageSize(int &width, int &height) 
				{
						width = m_ImageWidth;
						height = m_ImageHeight;
						return STATUS_OK;
				}
				
				Status CPage::GetPaperSize(CString &size) 
				{
						size = m_PaperSize;
						return STATUS_OK;
				}
				 
				Status CPage::GetFileSize(uint64 &size) 
				{
						size = m_FileSize;
						return STATUS_OK;
				}

 				Status CPage::SetSubsamplingImage(CString path, CString name)
				{
						m_SubsamplingName = name;
						m_SubsamplingPath = path;
						return STATUS_OK;
				}

            			Status CPage::SetThumbnailImage(CString path, CString name)
				{
						m_ThumbnailName = name;
						m_ThumbnailPath = path;
						return STATUS_OK;
				}

		            Status CPage::SetImage(CString path, CString name)
				{
						m_ImageName = name;
						m_ImagePath = path;
						return STATUS_OK;
				}

				Status CPage::SetProperties(int pageno, CString documenturi)
				{
					if(m_ImagePath.empty()) 
					{
							DEBUGL1("CPage::SetProperties::Image path is not set\n");
							return STATUS_FAILED;
					}
	                  		DEBUGL4("\nCPage::SetProperties Enter\n");
	                  		m_PageNo = pageno;
					
	                  		m_DocumentURI = documenturi;
					CString ImagePath = m_DocumentURI + "Image/";
					//m_ImagePath should be set before calling this funciton
					CString strm = Utility::GetHexadecimalPageNo(pageno);
					CString xmlfile = "pageproperties_" + strm + ".xml";
					Status ds = Utility::SetProperties(ImagePath, xmlfile, m_WebDAVProperties);
	 	                   if(ds!=STATUS_OK)
		                   {
                                 	if(ds == STATUS_DISK_FULL)
                              	{
                                   	 DEBUGL1("CPage::SetProperties::SetProperties to %s is failed because Disk is Full%d\n", m_ImagePath.c_str(), ds);
                                    	return STATUS_DISK_FULL;

                              	}
		                     DEBUGL1("CPage::SetProperties::SetProperties to %s is failed %d\n", m_ImagePath.c_str(), ds);
		                     return STATUS_FAILED;
		                   }
		                   return STATUS_OK;
				}

				Status CPage::AddToDocument(int pageno, CString documenturi, bool link) 
				{
						if(m_ImagePath.empty()) 
						{
								DEBUGL1("CPage::AddToDocument::Image path is not set\n");
								return STATUS_FAILED;
						}
						DEBUGL4("\nCPage::AddToDocument Enter\n");
						m_PageNo = pageno;
						m_DocumentURI = documenturi;

						// copy images to DocumentStore
						m_ImageName = Utility::GetHexadecimalPageNo(m_PageNo);
						CString path = m_DocumentURI + "Image/" + m_ImageName + GetExtension(IMAGEPAGETYPE);
						Status ds;
						if(link)
							ds = ci::operatingenvironment::File::SymbolicLink(m_ImagePath,path);
						else
							ds = ci::operatingenvironment::File::CopyFile(m_ImagePath,path);
						
						if(ds==STATUS_DISK_FULL)
						{
							DEBUGL1("CPage::AddToDocument::PutResource returned DISKFULL Error\n");
							return STATUS_DISK_FULL;
						}
						else if(ds != STATUS_OK) 
						{
							DEBUGL1("CPage::AddToDocument::PutResource %s to %s is failed\n", m_ImagePath.c_str(), path.c_str());
							return STATUS_FAILED;
						}

						CString xmlfilepath = m_DocumentURI + "Image/";
						CString xmlfile = "pageproperties_" + m_ImageName + ".xml";
						// WebDAV properties
						ds = Utility::SetProperties(xmlfilepath, xmlfile, m_WebDAVProperties);
						if(ds != STATUS_OK) 
						{
                        				if(ds == STATUS_DISK_FULL)
                        				{
                              				DEBUGL1("CPage::AddToDocument::SetProperties to %s is failed because Disk is Full %d\n", path.c_str(), ds);
                              				return STATUS_DISK_FULL;
                        				}
							DEBUGL1("CPage::AddToDocument::SetProperties to %s is failed %d\n", path.c_str(), ds);
							return STATUS_FAILED;
						}
						m_ImagePath = Utility::GetResourcePath(path);

						// copy subsampling image to DocumentStore
						if(m_SubsamplingPath != "") 
						{
								m_SubsamplingName = m_ImageName;
								path = m_DocumentURI + "/Subsampling/" + m_SubsamplingName + GetExtension(SUBSAMPLINGPAGETYPE);
								ds = ci::operatingenvironment::File::CopyFile(m_SubsamplingPath,path);
								if(ds==STATUS_DISK_FULL)
								{
										DEBUGL1("CPage::AddToDocument::PutResource returned DISKFULL Error\n");
										return (::STATUS_DISK_FULL);
								}
								else
								{
										if(ds != STATUS_OK) 
										{
												DEBUGL1("CPage::AddToDocument::PutResource %s to %s is failed\n", m_SubsamplingPath.c_str(), path.c_str());
												return STATUS_FAILED;
										}
								}
								m_SubsamplingPath = Utility::GetResourcePath(path);
						}

						// copy thumbnail image to DocumentStore
						if(m_ThumbnailPath != "") 
						{
								//m_ThumbNailName need not have the extension just update it with m_Image name
								m_ThumbnailName = m_ImageName;
								path = m_DocumentURI + "/Thumbnail/" + m_ThumbnailName + GetExtension(THUMBNAILPAGETYPE);
								ds = ci::operatingenvironment::File::CopyFile(m_ThumbnailPath,path);
								if(ds==STATUS_DISK_FULL)
								{
										DEBUGL1("CPage::AddToDocument::PutResource returned DISKFULL Error\n");
										return (::STATUS_DISK_FULL);
								}
								else
								{
										if(ds != STATUS_OK)
										{
												DEBUGL1("CPage::AddToDocument::PutResource %s to %s is failed\n", m_ThumbnailPath.c_str(), path.c_str());
												return STATUS_FAILED;
										}
								}
								m_ThumbnailPath = Utility::GetResourcePath(path);
						}

						//Copy Jpeg parameter file
						if(IsCopyJpegParameterSet()==STATUS_OK)
						{
								Status ret = UploadCopyJpegParameter(m_ImageName,m_DocumentURI);
								if(ret != STATUS_OK)
								{
										DEBUGL1("CPage::AddToDocument - UploadCopyJpegParameter failed\n");
										return ret;
								}
						}
						else
								DEBUGL2("CPage::AddToDocument - CopyJpegParameter not Set Continuing....\n");

						return STATUS_OK;
				}

				CString CPage::GetExtension(int pageType)
				{
					int iExtension;
					if (pageType == IMAGEPAGETYPE)
						iExtension = m_PageInformation.sPageComAtr.hCType	;	
					else if (pageType == SUBSAMPLINGPAGETYPE)
						iExtension = m_SubsamplingPageInformation.sPageComAtr.sPageThumInfo.hCType;
					else if (pageType == THUMBNAILPAGETYPE)
						iExtension = m_ThumbnailPageInformation.sPageComAtr.sPageThumInfo.hCType;

					CString sExt("");					
					int err =pthread_mutex_lock(&gpage_mutex_initializer);
					if (err != 0)
						DEBUGL2("CPage::GetExtension: pthread_mutex_lock failed\n ");

					std::map<int,CString>::iterator iter = m_ExtensionTypes.find(iExtension);
					if(iter != m_ExtensionTypes.end()) 
						sExt = m_ExtensionTypes[iExtension];
					else
						DEBUGL2("CPage::GetExtension - Invalid Extension Type. No extension added to imagename\n");

					err =pthread_mutex_unlock(&gpage_mutex_initializer);
					if (err != 0)
						DEBUGL2("CPage::GetExtension: pthread_mutex_unlock failed\n ");
					DEBUGL8("CPage::GetExtension - Extension is %s for int<%d>\n",sExt.c_str(),iExtension);
					
					return sExt;					
				}

				Status CPage::SetWebDAVPropertyFromSystemFile(void* systemfile) 
				{
						Status ret;
						FL_PAGE_MAN_TBL* fl_page_man_tbl = (FL_PAGE_MAN_TBL*)systemfile;
						m_PageInformation = *fl_page_man_tbl;
						if((ret = SetResolution(m_PageInformation.sPageComAtr.sResolution.hMain, m_PageInformation.sPageComAtr.sResolution.hSub)) != STATUS_OK) 
						{
								DEBUGL8("CPage::SetWebDAVPropertyFromSystemFile - SetResolution Failed\n");
								return ret;
						}
						if((ret = SetImageSize(m_PageInformation.sPageComAtr.hPgMLen,m_PageInformation.sPageComAtr.hPgSLen)) != STATUS_OK) 
						{
								DEBUGL8("CPage::SetWebDAVPropertyFromSystemFile - SetImageSize Failed\n");
								return ret;
						}
						if((ret = SetPaperSize(m_PageInformation.sPageComAtr.hSize)) != STATUS_OK) 
						{
								DEBUGL8("CPage::SetWebDAVPropertyFromSystemFile - SetPaperSize Failed\n");
								return ret;
						}
						if((ret = SetFileSize(m_PageInformation.sPageMan.liPgDataSize)) != STATUS_OK) 
						{
								DEBUGL8("CPage::SetWebDAVPropertyFromSystemFile - SetFileSize Failed\n");
								return ret;
						}
						if((ret = SetColorMode(m_PageInformation.sPageComAtr.sEngColorInf.hColorMode,m_PageInformation.sPageComAtr.sEngColorInf.hDataBit)) != STATUS_OK) 
						{
								DEBUGL8("CPage::SetWebDAVPropertyFromSystemFile - SetColorMode Failed\n");
								return ret;
						}
						return STATUS_OK;
				}


				Status CPage::SetColorMode(int colormode,int databit) 
				{
						if(colormode==COM_CB_FULLCOLOR)
								m_ColorMode= "Color";
						else if((colormode==COM_CB_MONO) && (databit==COM_DT_1BIT))
								m_ColorMode= "Mono";
						else if((colormode==COM_CB_MONO) && (databit==COM_DT_4BIT))
								m_ColorMode= "Gray";												
						else if((colormode==COM_CB_MONO) && (databit==COM_DT_8BIT))
								m_ColorMode= "Gray";
						else if((colormode==COM_CB_MONO) && (databit==COM_DT_24BIT))
								m_ColorMode= "Gray";
						else 
						{
								DEBUGL1("CPage::SetColorMode - Invalid Color Mode\n");
								return STATUS_FAILED;
						}		

						SetWebDAVProperty("colorMode", m_ColorMode);
						DEBUGL8("CPage::SetColorMode - Color Mode: %s\n", m_ColorMode.c_str());

						return STATUS_OK;
				}

				Status CPage::LoadProperties(FL_PAGE_MAN_TBL &systemfile, FL_PAGE_MAN_TBL &subsamplingsystemfile, FL_PAGE_MAN_TBL &thumbnailsystemfile) 
				{

						m_PageInformation = systemfile;
						m_SubsamplingPageInformation = subsamplingsystemfile;
						m_ThumbnailPageInformation = thumbnailsystemfile;

						// get image file name
						m_ImageName = systemfile.sPageMan.aPgStr;
						CString imagepath = m_DocumentURI + "/Image/" + m_ImageName + GetExtension(IMAGEPAGETYPE);

						// get WebDAVProperties
						// when Session::GetProperties() is called, 
						//  all map->second need to be empty string.
						std::map<CString, CString>::iterator it = m_WebDAVProperties.begin();
						for(;it != m_WebDAVProperties.end(); it++) 
						{
								it->second = "";
						}

						CString xmlfilepath = m_DocumentURI + "/Image/";
						CString xmlfile = "pageproperties_" + m_ImageName + ".xml";
						if(Utility::GetAllProperties(xmlfilepath, xmlfile, m_WebDAVProperties)!=STATUS_OK) 
						{
								DEBUGL1("CPage::LoadProperties::getting properties is failed\n");
								return STATUS_FAILED;
						}
						m_ImagePath = Utility::GetResourcePath(imagepath);

						// get subsampling file name
						m_SubsamplingName = subsamplingsystemfile.sPageMan.aPgStr;
						CString subsamplingpath = m_DocumentURI + "/Subsampling/" + m_SubsamplingName + GetExtension(SUBSAMPLINGPAGETYPE);
						if(Utility::ResourceExist(/*m_Session,*/ subsamplingpath)) 
						{
								m_SubsamplingPath = Utility::GetResourcePath(subsamplingpath);
						} 
						else 
						{
								m_SubsamplingPath = "";
						}
						// get thumbnail file name
						//m_ThumbNailName need not have the extension just update it with m_Image name
						m_ThumbnailName = thumbnailsystemfile.sPageMan.aPgStr;
						CString thumbnailpath = m_DocumentURI + "/Thumbnail/" + m_ThumbnailName + GetExtension(THUMBNAILPAGETYPE);
						if(Utility::ResourceExist(thumbnailpath))
						{
								m_ThumbnailPath = Utility::GetResourcePath(thumbnailpath);
						} 
						else 
						{
								DEBUGL2("CPage::LoadProperties::m_ThumbnailPath Resource does not exist..setting m_ThumbnailPath to NULL\n");
								m_ThumbnailPath = "";
						}
						std::istringstream h_resolution(m_WebDAVProperties["horizontalResolution"].c_str());
						h_resolution >> m_HorizontalResolution;
						std::istringstream v_resolution(m_WebDAVProperties["verticalResolution"].c_str());
						v_resolution >> m_VerticalResolution;

						std::istringstream width(m_WebDAVProperties["imageWidth"].c_str()); 
						width >> m_ImageWidth;
						std::istringstream height(m_WebDAVProperties["imageHeight"].c_str());
						height >> m_ImageHeight;
						m_PaperSize = m_WebDAVProperties["paperSize"];
						std::istringstream filesize(m_WebDAVProperties["fileSize"]);
						filesize >> m_FileSize;

						DEBUGL8("CPage::LoadProperties::PaperSize: %s\n",m_PaperSize.c_str());
						int err =pthread_mutex_lock(&gpage_mutex_initializer);
   						if (err != 0)
							DEBUGL2("\nCPage::LoadProperties: pthread_mutex_lock failed\n ");
						m_PaperSizeEnum = m_PaperSizeEnumStringMap[m_PaperSize];

						err =pthread_mutex_unlock(&gpage_mutex_initializer);
   						if (err != 0)
							DEBUGL2("\nCPage::LoadProperties: pthread_mutex_unlock failed\n ");
						DEBUGL8("CPage::LoadProperties::PaperSize Enum: %d\n",m_PaperSizeEnum);
						
						m_ColorMode= m_WebDAVProperties["colorMode"];						
						return STATUS_OK;
				}

				// convert to zero-filling, 5-digit string
				CString CPage::Get5DigitPageNo() 
				{
						std::ostringstream strm;
						strm << std::setfill('0') << std::setw(3) << m_PageNo;
						return strm.str();
				}

				Status CPage::SetResolution(int mainResolution, int subResolution) 
				{
						static const unsigned int resolutionTable[] = {300, 400,  600,   98,   196, 204,   391,    408, 600, 150, 200, 100, 1200,   0,  50, 66,  75};
						static const int tableSize = sizeof(resolutionTable) / sizeof(resolutionTable[0]);

						// set horizontal resolution from table
						if((mainResolution == 0) || (mainResolution > tableSize)) 
						{
								// if out of table, set zero
								m_HorizontalResolution = 0;
						} 
						else 
						{
								m_HorizontalResolution = 
								resolutionTable[mainResolution - 1];
						}

						// set vertical resolution from table
						if((subResolution == 0) || (subResolution > tableSize)) 
						{
								// if out of table, set zero
								m_VerticalResolution = 0;
						} 
						else 
						{

							    m_VerticalResolution = resolutionTable[subResolution - 1];
						}
						SetWebDAVProperty("horizontalResolution", m_HorizontalResolution);
						SetWebDAVProperty("verticalResolution", m_VerticalResolution);
						DEBUGL8("CPage::SetResolution::Resolution: %d x %d\n", m_HorizontalResolution, m_VerticalResolution);
						// return STATUS_FAILED if resolution is zero.
						if((m_HorizontalResolution == 0) || (m_VerticalResolution == 0)) 
						{
								DEBUGL1("CPage::SetResolution::Resolution: %d x %d\n", m_HorizontalResolution, m_VerticalResolution);
								return STATUS_FAILED;
						} 
						return STATUS_OK;
				}

				Status CPage::SetImageSize(int w,int h) 
				{
						m_ImageWidth = w;
						m_ImageHeight = h;
						SetWebDAVProperty("imageWidth", m_ImageWidth);
						SetWebDAVProperty("imageHeight", m_ImageHeight);
						DEBUGL8("CPage::SetImageSize::Pixel: %d x %d\n", m_ImageWidth, m_ImageHeight);
						return STATUS_OK;
				}

				Status CPage::SetPaperSize(int size) 
				{
						m_PaperSize = "";
						m_PaperSizeEnum = (PaperSize)size;

						switch(size)
						{
								case  A1: m_PaperSize = PAPER_SIZE_A1; break;
								case  A2: m_PaperSize = PAPER_SIZE_A2; break;
								case  A3: m_PaperSize = PAPER_SIZE_A3; break;
								case  A4: m_PaperSize = PAPER_SIZE_A4; break;
								case  A5: m_PaperSize = PAPER_SIZE_A5; break;
								case  A6: m_PaperSize = PAPER_SIZE_A6; break;
								case  A7: m_PaperSize = PAPER_SIZE_A7; break;
								case	A3_WIDE: m_PaperSize = PAPER_SIZE_A3Wide; break;
								case B1: m_PaperSize = PAPER_SIZE_B1; break;
								case B2: m_PaperSize = PAPER_SIZE_B2; break;
								case B3: m_PaperSize = PAPER_SIZE_B3; break;
								case B4: m_PaperSize = PAPER_SIZE_B4; break;
								case B5: m_PaperSize = PAPER_SIZE_B5; break;
								case B6: m_PaperSize = PAPER_SIZE_B6; break;
								case B7: m_PaperSize = PAPER_SIZE_B7; break;
								case LETTER: m_PaperSize = PAPER_SIZE_LETTER; break;
								case LEDGER: m_PaperSize = PAPER_SIZE_LEDGER; break;
								case LEGAL: m_PaperSize = PAPER_SIZE_LEGAL; break;
								case STATEMENT: m_PaperSize = PAPER_SIZE_STATEMENT; break;
								case COMPUTER: m_PaperSize = PAPER_SIZE_COMPUTER; break;
								case FOLIO: m_PaperSize = PAPER_SIZE_FOLIO; break;
								case LEGAL13: m_PaperSize = PAPER_SIZE_13inchLEGAL; break;
								case SQUARE8_5: m_PaperSize = PAPER_SIZE_8_5SQ; break;
								case LEDGER_WIDE: m_PaperSize = PAPER_SIZE_LEDGERWide; break;
								case RECTANGLE13X19: m_PaperSize = PAPER_SIZE_13x19inch; break;
								case SIZE_8K: m_PaperSize = PAPER_SIZE_8K; break;
								case SIZE_16K: m_PaperSize = PAPER_SIZE_16K; break;									
							   case POSTCARD: m_PaperSize = PAPER_SIZE_Postcard; break;
								case SRA3_450: m_PaperSize = PAPER_SIZE_SRA3; break;
								case SRA3_460: m_PaperSize = PAPER_SIZE_320x460mm; break;
								case  A1_R: m_PaperSize = PAPER_SIZE_A1_R; break;
								case  A2_R: m_PaperSize = PAPER_SIZE_A2_R; break;
								case  A3_R: m_PaperSize = PAPER_SIZE_A3_R; break;
								case  A4_R: m_PaperSize = PAPER_SIZE_A4_R; break;
								case  A5_R: m_PaperSize = PAPER_SIZE_A5_R; break;
								case  A6_R: m_PaperSize = PAPER_SIZE_A6_R; break;
								case  A7_R: m_PaperSize = PAPER_SIZE_A7_R; break;
								case  A3_WIDE_R: m_PaperSize = PAPER_SIZE_A3Wide_R; break;
								case B1_R: m_PaperSize = PAPER_SIZE_B1_R; break;
								case B2_R: m_PaperSize = PAPER_SIZE_B2_R; break;
								case B3_R: m_PaperSize = PAPER_SIZE_B3_R; break;
								case B4_R: m_PaperSize = PAPER_SIZE_B4_R; break;
								case B5_R: m_PaperSize = PAPER_SIZE_B5_R; break;
								case B6_R: m_PaperSize = PAPER_SIZE_B6_R; break;
								case B7_R: m_PaperSize = PAPER_SIZE_B7_R; break;
								case LETTER_R: m_PaperSize = PAPER_SIZE_LETTER_R; break;
								case LEDGER_R: m_PaperSize = PAPER_SIZE_LEDGER_R; break;
								case LEGAL_R: m_PaperSize = PAPER_SIZE_LEGAL_R; break;
								case STATEMENT_R: m_PaperSize = PAPER_SIZE_STATEMENT_R; break;
								case COMPUTER_R: m_PaperSize = PAPER_SIZE_COMPUTER_R; break;
								case FOLIO_R: m_PaperSize = PAPER_SIZE_FOLIO_R; break;
								case LEGAL13_R: m_PaperSize = PAPER_SIZE_13inchLEGAL_R; break;
								case SQUARE8_5_R: m_PaperSize = PAPER_SIZE_8_5SQ; break;
								case LEDGER_WIDE_R: m_PaperSize = PAPER_SIZE_LEDGERWide_R; break;
								case RECTANGLE13X19_R: m_PaperSize = PAPER_SIZE_13x19inch_R; break;
								case SIZE_8K_R: m_PaperSize = PAPER_SIZE_8K_R; break;
								case SIZE_16K_R: m_PaperSize = PAPER_SIZE_16K_R; break;							
								case LEGAL135_R: m_PaperSize = PAPER_SIZE_13_5Legal_R; break;
								case LEGAL135: m_PaperSize = PAPER_SIZE_13_5Legal; break;	
								case EXECTIVE_R: m_PaperSize = PAPER_SIZE_Executive_R; break;	
								case EXECTIVE: m_PaperSize = PAPER_SIZE_Executive; break;														      
								case POSTCARD_R: m_PaperSize = PAPER_SIZE_Postcard_R; break;
								case DOUBLEPOSTCARD: m_PaperSize = PAPER_SIZE_DOUBLEPOSTCARD; break;
								case DOUBLEPOSTCARD_R: m_PaperSize = PAPER_SIZE_DOUBLEPOSTCARD_R; break;	
								case SRA3_450_R: m_PaperSize = PAPER_SIZE_SRA3_R; break;
								case SRA3_460_R: m_PaperSize = PAPER_SIZE_320x460mm_R; break;								
								case SPECIAL_CUSTOMSCAN:
										 {
											 size_t pos; 
											 pos = m_BoxBasePath.find("TempBoxes");
											 if(pos != string::npos)
											 {
												 m_PaperSize = PAPER_SIZE_CustomScan; 
											 }
											 else
											 {
												 DEBUGL1("CPage::SetPaperSize::FAILED: Sheet size is not defined for other boxes.\n");
												 return STATUS_FAILED;	
											 }
											 break;
										 }
								case UNDEF_SIZE: m_PaperSize = PAPER_SIZE_Undefined; break;
								case SPECIAL_SIZE: m_PaperSize = PAPER_SIZE_Custom; break;
								case SPECIAL_LONG800: m_PaperSize = PAPER_SIZE_CustomLongA; break;
								case SPECIAL_LONG1200: m_PaperSize = PAPER_SIZE_CustomLongB; break;
								default:
										  DEBUGL8("CPage::SetPaperSize::FAILED: Sheet size is not defined\n");
										  return STATUS_FAILED;
						};
						
						SetWebDAVProperty("paperSize", m_PaperSize);
						DEBUGL8("CPage::SetPaperSize::Paper size: %s\n", m_PaperSize.c_str());
						return STATUS_OK;
				}

				Status CPage::SetFileSize(unsigned int size) 
				{
						m_FileSize = size;
						SetWebDAVProperty("fileSize", m_FileSize);
						DEBUGL8("CPage::SetFileSize::File size: %d\n", m_FileSize);
						return STATUS_OK;
				}

				Status CPage::GetSystemFile(FL_PAGE_MAN_TBL &systemfile) 
				{
						systemfile = m_PageInformation;
						return STATUS_OK;
				}

				Status CPage::SetSubsamplingSystemFile(FL_PAGE_MAN_TBL &systemfile) 
				{
						m_SubsamplingPageInformation = systemfile;
						return STATUS_OK;
				}

				Status CPage::GetSubsamplingSystemFile(FL_PAGE_MAN_TBL &systemfile) 
				{
						systemfile = m_SubsamplingPageInformation;
						return STATUS_OK;
				}

				Status CPage::SetThumbnailSystemFile(FL_PAGE_MAN_TBL &systemfile) 
				{
						m_ThumbnailPageInformation = systemfile;
						return STATUS_OK;
				}

				Status CPage::GetThumbnailSystemFile(FL_PAGE_MAN_TBL &systemfile) 
				{
						systemfile = m_ThumbnailPageInformation;
						return STATUS_OK;
				}

				Status CPage::UpdateImageName(FL_PAGE_MAN_TBL &systemfile) 
				{
						std::strncpy(systemfile.sPageMan.aPgStr, m_ImageName.c_str(), 5);
						std::strncpy(m_PageInformation.sPageMan.aPgStr, m_ImageName.c_str(), 5);
						return STATUS_OK;
				}

				Status CPage::UpdateSubsamplingName(FL_PAGE_MAN_TBL &systemfile) 
				{
						std::strncpy(systemfile.sPageMan.aPgStr, m_SubsamplingName.c_str(), 5);
						std::strncpy(m_SubsamplingPageInformation.sPageMan.aPgStr, m_SubsamplingName.c_str(), 5);
						return STATUS_OK;
				}

				Status CPage::UpdateThumbnailName(FL_PAGE_MAN_TBL &systemfile) 
				{
						std::strncpy(systemfile.sPageMan.aPgStr, m_ThumbnailName.c_str(), m_ThumbnailName.length());
						std::strncpy(m_ThumbnailPageInformation.sPageMan.aPgStr, m_ThumbnailName.c_str(),m_ThumbnailName.length() );
						return STATUS_OK;
				}

				Status CPage::SetCopyJpegParameter(void *param, uint32 size)
				{
						if(!param)
						{
								DEBUGL1("CPage::SetCopyJpegParameter - Invalid parameter file\n");
								return STATUS_FAILED;
						}
						m_ParamFile = new char[size];
						memset(m_ParamFile, '\0', size);
						memcpy(m_ParamFile, (char *)param, size);
						m_ParamFileSize = size;
						DEBUGL8("CPage::GetCopyJpegParameter - JPEG parameter size - %u\n",size);
						return STATUS_OK;
				}

				Status CPage::IsCopyJpegParameterSet()
				{
						if(m_ParamFile)
								return STATUS_OK;
						else 
								return STATUS_FAILED;
				}

				Status CPage::GetCopyJpegParameterFilePath(CString &path)
				{
						path.clear();
						CString tmpPath = m_DocumentURI + "/Image/" + m_ImageName+".cjd";

						if(Utility::ResourceExist(tmpPath))
								path = tmpPath;

						DEBUGL8("CPage::GetCopyJpegParameterFilePath - JPEG parameter path - %s\n",path.c_str());
						return STATUS_OK;
				}

				Status CPage::UploadCopyJpegParameter(CString imageName,CString docUri)
				{
						FilePtr m_fp;
						Status m_ret;
						CString copyJpegPath = imageName+ ".cjd";	
						
						CUUIDRef uid = new CUUID();	  
						CString ranId = uid->toString();
						
						CString tmpFileName = "CopyJpegParam_" + ranId + copyJpegPath;
						CString tmpPath = Utility::GetCITmpPath() + tmpFileName ;

						DEBUGL8("CPage::UploadCopyJpegParameter - tmpPath<%s>\n",tmpPath.c_str());

						void *param = m_ParamFile;	
						if(!param)
						{
								DEBUGL1("CPage::UploadCopyJpegParameter - Invalid param file\n");
								return STATUS_FAILED;
						}

						if(File::Exists(tmpPath))
						{
								DEBUGL1("CPage::UploadCopyJpegParameter - File exists. Deleting the file\n");
								// delete file
								File::DeleteFile(tmpPath);		
						}

						ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> tmpFolder=  ci::operatingenvironment::Folder::Bind(Utility::GetCITmpPath());
						if(!tmpFolder)
						{	
								DEBUGL1("CPage::UploadCopyJpegParameter - Folder Bind failed\n");
								return STATUS_FAILED;
						}	
						else
						{
								m_ret = ci::operatingenvironment::File::CreateFile(m_fp,tmpFileName,tmpFolder,"w");	
								if(m_ret!=STATUS_OK)
								{
										DEBUGL1("CPage::UploadCopyJpegParameter - File creation failed\n");
										return m_ret;
								}			
						}					
						DEBUGL8("CPage::UploadCopyJpegParameter -File Creation done\n");	

						if(!m_fp)	
						{
								DEBUGL1("CPage::UploadCopyJpegParameter - Invalid file ptr\n");
								return STATUS_FAILED;
						}
						else
						{
								m_ret = m_fp->Write(param,m_ParamFileSize,1);						
								if(m_ret != STATUS_OK)
								{
										DEBUGL1("CPage::UploadCopyJpegParameter - File write failed\n");
										m_fp->Close();
										return m_ret;
								}
								DEBUGL8("CPage::UploadCopyJpegParameter -File Write done\n");		

								m_fp->Close();
								DEBUGL8("CPage::UploadCopyJpegParameter -File Close done\n");		
						}

						CString imgPath = docUri + "Image/"+copyJpegPath;	
						Status ds = ci::operatingenvironment::File::CopyFile(tmpPath,imgPath);
						if(ds==STATUS_DISK_FULL)
						{
								DEBUGL1("CPage::UploadCopyJpegParameter - PutResource returned DISKFULL Error\n");
								return (::STATUS_DISK_FULL);
						}
						else if(ds != STATUS_OK) 
						{
								DEBUGL1("CPage::UploadCopyJpegParameter - PutResource %s to %s is failed\n",imgPath.c_str(), tmpPath.c_str());
								return STATUS_FAILED;
						}

						// delete file
						File::DeleteFile(tmpPath);		
						return STATUS_OK;

				}

				/**
				 * Get the Page number for given page ref
				 * @return - The Page Number
				 */
				CString CPage::GetPageNo()
				{
					std::ostringstream strm;
					strm << std::setfill('0') << std::setw(3)<<std::hex << m_PageNo;
					DEBUGL8("CPage::GetPageNo - PageNumber is %s\n",strm.str().c_str());					
					return strm.str();
				}

				Status CPage::GetPaperSize(PaperSize &size)
				{
					size = m_PaperSizeEnum;
					return STATUS_OK;				
				}

				Status CPage::GetFileFormat(FileFormat &format)
				{
					return GetFileFormat(format, m_PageInformation.sPageComAtr.hCType,m_PageInformation.sPageComAtr.hYccForm,
												m_PageInformation.sPageComAtr.sEngColorInf.hColorMode,m_PageInformation.sPageComAtr.sEngColorInf.hDataBit);
				}

				Status CPage::GetSubsamplingFileFormat(FileFormat &format)
				{
					return GetFileFormat(format, m_SubsamplingPageInformation.sPageComAtr.sPageThumInfo.hCType,m_SubsamplingPageInformation.sPageComAtr.sPageThumInfo.hYccForm,
												m_SubsamplingPageInformation.sPageComAtr.sPageThumInfo.sColorinf.hColorMode,m_SubsamplingPageInformation.sPageComAtr.sPageThumInfo.sColorinf.hDataBit);
				}

				Status CPage::GetThumbnailFileFormat(FileFormat &format)
				{
					return GetFileFormat(format, m_ThumbnailPageInformation.sPageComAtr.sPageThumInfo.hCType,m_ThumbnailPageInformation.sPageComAtr.sPageThumInfo.hYccForm,
												m_ThumbnailPageInformation.sPageComAtr.sPageThumInfo.sColorinf.hColorMode,m_ThumbnailPageInformation.sPageComAtr.sPageThumInfo.sColorinf.hDataBit);
				}

				Status CPage::GetFileFormat(FileFormat &format,int ctype,int yccform,int colormode,int databit)
				{
					ColorMode color= GRAY;
					if(colormode==COM_CB_FULLCOLOR)
							color= COLOR;
					else if((colormode==COM_CB_MONO) && (databit==COM_DT_1BIT))
							color= MONO;
					else if((colormode==COM_CB_MONO) && (databit==COM_DT_4BIT))
							color= GRAY;												
					else if((colormode==COM_CB_MONO) && (databit==COM_DT_8BIT))
							color= GRAY;
					else if((colormode==COM_CB_MONO) && (databit==COM_DT_24BIT))
							color= GRAY;
					
               DEBUGL8("colormode = %d, databit = %d, ctype = %d, yccform = %d, color = %d\n",
                                    colormode, databit, ctype, yccform, (int)color);

					if((ctype==COM_IP_RECTOR)&&(color==MONO))
						format = FF_RECTOR;
					else if((ctype==COM_IP_JPEG)&&(yccform==COM_YCC_411)&&(color==COLOR))
						format = FF_JPEG411;
					else if((ctype==COM_IP_JPEG)&&(yccform==COM_YCC_444)&&(color==COLOR))
						format = FF_JPEG444;
					else if((ctype==COM_IP_JPEG)&&(yccform==COM_YCC_INVALID)&&(color==GRAY))
						format = FF_JPEG8BITGRAY;
					else if((ctype==COM_IP_MMR)&&(color==MONO))
						format = FF_MMR;
					else if((ctype==COM_IP_MH)&&(color==MONO))
						format = FF_MH;
					else if((ctype==COM_IP_RECTOR)&&(color==GRAY))
						format = FF_TTECJPEGGRAY;
					else if((ctype==COM_IP_RECTOR)&&(color==COLOR))
						format = FF_TTECJPEGCOLOR;					
					else if((ctype==COM_IP_CJPEG_VL)&&(color==GRAY))
						format = FF_COPYJPEGGRAY;
					else if((ctype==COM_IP_CJPEG_VL)&&(color==COLOR))
						format = FF_COPYJPEGCOLOR;
					else if((ctype==COM_IP_DIB))
						format = FF_DIB;
					else if((ctype==COM_IP_TIFF))
						format = FF_TIFF;					
					else if((ctype==COM_IP_XPS))
						format = FF_XPS;
					else if((ctype==COM_IP_PNG))
						format = FF_PNG;
					else if((ctype==COM_IP_PDF))
						format = FF_PDF;					
					else if((ctype==COM_IP_NOTHING))
						format = FF_RAW;
					else if((ctype==COM_IP_DOC))
						format = FF_DOC;
					else if((ctype==COM_IP_PPT))
						format = FF_PPT;					
					else if((ctype==COM_IP_XLS))
						format = FF_XLS;
					else 
					{
						DEBUGL1("CPage::GetFileFormat - Invalid FileFormat\n");
						return STATUS_FAILED;
					}					
					return STATUS_OK;					
				}

				Status CPage::GetAdjustedImageSize(int &width, int &height)
				{
					CString widthVal("");							
					CString path = m_DocumentURI + "/Image/"; 
					CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(m_PageNo) + ".xml";
					if(proputils::GetPageProperty(path, xmlfile, "adjustedImageWidth", widthVal) != STATUS_OK) 
					{
						DEBUGL1("CPage::GetAdjustedImageSize:GetWebDAVProperty of adjustedImageWidth Failed\n");
						return STATUS_FAILED;
					}
					CString heightVal("");
					if(proputils::GetPageProperty(path, xmlfile, "adjustedImageHeight", heightVal)!=STATUS_OK) 
					{
						DEBUGL1("CPage::GetAdjustedImageSize:GetWebDAVProperty of adjustedImageHeight Failed\n");
						return STATUS_FAILED;
					}
					
					std::istringstream iss(widthVal);
					iss >> width;															
					std::istringstream iss1(heightVal);
					iss1 >> height;										
					
					return STATUS_OK;
				}

				Status CPage::GetOrientation(Orientation &orientation)
				{			
					CString orVal("");							
					CString path = m_DocumentURI + "/Image/";
					CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(m_PageNo) + ".xml";					
					if(proputils::GetPageProperty(path, xmlfile, "orientation", orVal)!=STATUS_OK) 
					{
						DEBUGL1("CPage::GetOrientation:GetProperty of orientation Failed\n");
						return STATUS_FAILED;
					}
					std::istringstream iss(orVal);
					int iOrientation;
					iss >> iOrientation;															
					
					if(iOrientation==COM_IO_PORTRAIT)				
						orientation = PORTRAIT;
					else if(iOrientation==COM_IO_LANDSCAPE)				
						orientation = LANDSCAPE;
					else
					{
						DEBUGL1("CPage::GetOrientation:Invalid Orientation\n");
						return STATUS_FAILED;						
					}
					
					return STATUS_OK;				
				}

				Status CPage::GetAngle(Angle &angle)
				{
					CString angleVal("");							
					CString path = m_DocumentURI + "/Image/";
					CString xmlfile = "pageproperties_" + Utility::GetHexadecimalPageNo(m_PageNo) + ".xml";
					if(proputils::GetPageProperty(path.c_str(), xmlfile, "angle", angleVal)!=STATUS_OK) 
					{
						DEBUGL1("CPage::GetAngle:GetProperty of angleVal Failed\n");
						return STATUS_FAILED;
					}
					std::istringstream iss(angleVal);
					int iAngle;
					iss >> iAngle;															
					
					if(iAngle==COM_RT_NOTHING)				
						angle = NOROTATE;
					else if(iAngle==COM_RT_90)				
						angle = ROTATE90;
					else if(iAngle==COM_RT_180)				
						angle = ROTATE180;
					else if(iAngle==COM_RT_270)				
						angle = ROTATE270;					
					else
					{
						DEBUGL1("CPage::GetAngle:Invalid Angle\n");
						return STATUS_FAILED;						
					}
				
					return STATUS_OK;				
				}
				
				Status CPage::GetColorMode(ColorMode &color)
				{
					if(m_ColorMode== "Color")
							color = COLOR;
					else if(m_ColorMode== "Gray")
							color = GRAY;																	
					else if(m_ColorMode== "Mono")
							color = MONO;
					else 
					{
						DEBUGL1("CPage::GetColorMode - Invalid Color Mode\n");
						return STATUS_FAILED;
					}					
					return STATUS_OK;				
				}
				CString CPage::GetPropertyFile()
				{
					DEBUGL8("CPage::GetPropertyFile: Propertyfilename : pageproperties_%s.xml\n", m_ImageName.c_str());
					return ( m_ImageName.size() ? (m_DocumentURI + "/Image/" + "pageproperties_" + m_ImageName + ".xml") : "pageproperties.xml");
	
				}
				CString CPage::GetBlankPropertyFile()
				{
					return m_BlankPropertyFilePath;
	
				}
				
				Status CPage::SetBlankPropertyFile(int pageno,CString path)
				{
					//m_ImagePath should be set before calling this funciton
					CString strm = Utility::GetHexadecimalPageNo(pageno);
					CString Imagepath;
					if(path.empty())
			                          Imagepath = Utility::GetTmpPath();
					else
						Imagepath = path + "/Image/";
					
					CString xmlfile = "pageproperties_" + strm + ".xml";
					m_BlankPropertyFilePath = Imagepath + xmlfile;
					Status ds = ci::operatingenvironment::File::CopyFile("pageproperties.xml",m_BlankPropertyFilePath);
					if((ds==::STATUS_DISK_FULL) || ds != STATUS_OK)
					{
						DEBUGL1("CBoxDocument::CreateBox::Creation of %s Failed\n", m_BlankPropertyFilePath.c_str());
						return ds;
					}
					
					ds = Utility::SetProperties(Imagepath, xmlfile, m_WebDAVProperties);					
	 	                   	if(ds!=STATUS_OK)
		                   	{
                                  		if(ds == STATUS_DISK_FULL)
                              		{
                                 			DEBUGL1("CPage::SetProperties::SetProperties to %s is failed because Disk is Full %d\n", Imagepath.c_str(), ds);
                                 			return STATUS_DISK_FULL;
                              		}
		                     	DEBUGL1("CPage::SetProperties::SetProperties to %s is failed %d\n", Imagepath.c_str(), ds);
		                     	return STATUS_FAILED;
		                   	}
		                     return STATUS_OK;
					
	
				}
				
				

		}; // end of namespace boxdocument
}; // end of namespace ci
