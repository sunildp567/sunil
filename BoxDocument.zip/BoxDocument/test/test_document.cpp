#include<iostream>
#include <map>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>
#include <CI/BoxDocument/progress.h>
#include <CI/OperatingEnvironment/cuuid.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/hierarchicaldb.h>
#include <sys/stat.h>
#include <CI/IndexedDB/Mash/include/comPar.h>
//#include  <DL/include/imStr.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

#define COPY_JPEG 0

bool test_CutPaste(CString boxbasepath, CString boxnumber, CString foldername, CString documentname);
bool test_CopyPaste(CString boxbasepath, CString boxnumber, CString foldername, CString documentname);
bool test_Delete(CString boxbasepath, CString boxnumber, CString foldername, CString documentname);

DocumentRef GetDocument(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    BoxDocumentRef boxdoc;
	CUUIDRef uid = new CUUID();	  
	CString sessionID= uid->toString();

    boxdoc = BoxDocument::Acquire(sessionID);
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return NULL;
    }

	BoxRef box;
	if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
	{
		DEBUGL1("BoxDocument::GetBox() failed\n");
		return false;
	}

    ci::boxdocument::DocumentRef doc;
	if(!foldername.empty())
	{	
		FolderRef folder;
		if(box->GetFolder(folder,foldername)!=STATUS_OK)
		{
			DEBUGL1("Box::GetFolder() failed\n");
			return false;
		}
	    // 6.2: Get document instance
	    if(folder->GetDocument(doc, documentname) != STATUS_OK) {
	        DEBUGL1("Folder::GetDocument() is failed\n");
	        return false;
	    }		
	}	 
	else
	{	
	    // 6.2: Get document instance
	    if(box->GetDocument(doc, documentname) != STATUS_OK) {
	        DEBUGL1("Box::GetDocument() is failed\n");
	        return false;
	    }
	}
    	 
    return doc;
}

bool test_GetStatus(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    DocStatus st;
    if(doc->GetStatus(st) != STATUS_OK) {
        DEBUGL1("Document::GetStatus() is failed\n");
        return false;
    }
    switch(st) {
    case CREATING : DEBUGL6("Status - CREATING\n"); break;
    case READY    : DEBUGL6("Status - READY\n"); break;
    case USING    : DEBUGL6("Status - USING\n"); break;
    case EDITING  : DEBUGL6("Status - EDITING\n"); break;
    case DELETING : DEBUGL6("Status - DELETING\n"); break;
    case WAITING  : DEBUGL6("Status - WAITING\n"); break;
    case RESERVING: DEBUGL6("Status - RESERVING\n");break;
    }
    return true;
}


bool test_EndCreating(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->EndCreating() != STATUS_OK) {
        DEBUGL1("Document::EndCreating() is failed\n");
        return false;
    }
    return true;
}

bool test_Use(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->Use() != STATUS_OK) {
        DEBUGL1("Document::Use() is failed\n");
        return false;
    }
    return true;
}


bool test_EndUsing(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->EndUsing() != STATUS_OK) {
        DEBUGL1("Document::EndUsing() is failed\n");
        return false;
    }
    return true;
}

bool test_Reserve(CString boxbasepath, CString boxnumber, CString foldername, CString documentname){
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->Reserve() != STATUS_OK) {
        DEBUGL1("Document::Reserve() has failed\n");
        return false;
    }
    return true;
}

bool test_EndReserving(CString boxbasepath, CString boxnumber, CString foldername, CString documentname){
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->EndReserving() != STATUS_OK) {
        DEBUGL1("Document::EndReserving() has failed\n");
        return false;
    }
    return true;
}



bool test_Edit(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
    return true;
}

bool test_CancelEdit(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    if(doc->CancelEdit() != STATUS_OK) {
        DEBUGL1("Document::CancelEdit() is failed\n");
        return false;
    }
    return true;
}

bool test_EditandCancelEdit(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }

    DEBUGL1("Document:: Editing called\n");

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

     DEBUGL1("Document::Going to Sleep Check TMP doc exists\n");

     sleep(10);

   if(doc->CancelEdit() != STATUS_OK) {
        DEBUGL1("Document::CancelEdit() is failed\n");
        return false;
    }
return true;

}
bool test_GetPageList(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    PageList list;
    if(doc->GetPageList(list) != STATUS_OK) {
        DEBUGL1("getting page list is failed\n");
        return false;
    }
    for(PageList::iterator it = list.begin(); it != list.end(); it++) {
        CString imagepath;
        if((*it)->GetImage(imagepath) != STATUS_OK) {
            DEBUGL1("Page::GetImage() is failed\n");
            return false;
        }
        DEBUGL6("image path : %s\n", imagepath.c_str());
    }
    return true;
}

extern bool test_page(CString, CString, CString, CString, int);
bool test_GetPage(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    PageList list;
    if(doc->GetPageList(list) != STATUS_OK) {
        DEBUGL1("getting page list is failed\n");
        return false;
    }
    int pageno;
    cout << "Enter Page No.(1 - " << list.size() << ")" << endl;
    cin >> pageno;
    
    return test_page(boxbasepath, boxnumber, foldername, documentname, pageno);
}

bool test_RenameDocument(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    
    CString new_name;
    cout << "Enter new document name" << endl;
    cin >> new_name;
    
    if(doc->SetName(new_name) != STATUS_OK) {
        DEBUGL1("Document::SetName() is failed\n");
        return false;
    }
    doc->GetName(documentname);
    return true;
}

bool test_GetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    CString key, value;
    char* keylist[45] = {"documentName", "jobType", "mixpaperSize", "mixresolution", "mixcolorMono", "totalSize", "totalPages", "creationDate", "lastModifiedDate", "lastAccessDate", "lastArchiveDate", 
		"from", "receptionTime", "receptionNumber", "cutDocument", "paperSizeMap", "jobTypeColorMap", "jobTypeMap", "totalDocSize",
		"docWEPSize", "sessionID", "srcBoxBasePath", "srcBoxNumber", "srcFolderName", "srcDocumentName", "IsImagedataPresent",
		"IsSubsamplingdataPresent", "IsThumbnaildataPresent", "horizontalResolutionMap", "verticalResolutionMap", "colorModeMap", 
		"count", "InputPageCount", "fromString","fromStringFirstName","fromStringLastName", "StatusOfReceivedData", "StatusOfHardCopy",
		"StatusOfRelayReport", "duplex", "paperType", "paperSource", "staple", "holePunch", "faxDuplex"};
    for(int i = 0; i < 45; i++) {
        key = keylist[i];
        doc->GetWebDAVProperty(key, value);
        DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    }
    return true;
}

bool test_SetWebDAVProperty(CString boxbasepath, CString boxnumber, CString foldername, CString documentname) {
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
    CString key, value;
    cout << "Enter Document property (KEY)" << endl;
    cin >> key;
    cout << "Enter Document property (VALUE)" << endl;
    cin >> value;
    if(doc->SetWebDAVProperty(key, value) != STATUS_OK) {
        DEBUGL1("Document::SetWebDAVProperty() is failed\n");
        return false;
    }
    return true;
}
bool test_EditandSave(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }

    DEBUGL1("Document:: Editing called\n");

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

     DEBUGL1("Document::Going to Sleep Check TMP doc exists\n");

     sleep(10);

   if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }
	return true;

}

bool test_EditandSaveAs(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
    CString Newname,newResourceBasepath;
    cout << "Enter New Document Name" << endl;
    cin >> Newname;
    cout << "Enter Document BasePath to where to save in terms of XPATH" << endl;
    cin >> newResourceBasepath;

    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }

    DEBUGL1("Document:: Editing called\n");

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

     DEBUGL1("Document::Going to Sleep Check TMP doc exists\n");

     sleep(10);

   if(doc->SaveAs(Newname,newResourceBasepath) != STATUS_OK) {
        DEBUGL1("Document::SaveAs() is failed\n");
        return false;
    }
	return true;

}
bool test_CopyPage(CString boxbasepath,CString boxnumber,CString foldername,CString documentname,bool isProgress)
{
    int Page,newpage;
    CString newBox,newFolder,newDocument;

    cout << "Enter the page Number" << endl;
    cin >> Page;

    cout << "Enter the BoxName where it has to be pasted" << endl;
    cin >> newBox;

    cout << "Enter the FolderName where it has to be pasted (enter n for empty)" << endl;
    cin >> newFolder;
	if(newFolder == "n")
		newFolder = "";

    cout << "Enter the DocumentName where it has to be pasted" << endl;
    cin >> newDocument;

    cout << "Enter the Page Number" << endl;
    cin >> newpage;

    DocumentRef doc1 = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc1) {
        return false;
    }

    DEBUGL6("Document:: Editing called\n");
    DEBUGL6("Document:: Copying page without editing..\n");

    if(doc1->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Edit succesfull\n");

	int i;
	scanf("%d",&i);
	
	if(isProgress)
	{	
		ProgressRef progress;
		int prog;
		if(doc1->CopyPage(progress,Page) != STATUS_OK)
		{
			DEBUGL1("Document::CopyPage() is failed\n");
			return false;
		}
		do
		{
			if(progress->GetProgress(prog)!=STATUS_OK)
			{
				DEBUGL1("Document::GetProgress() is failed\n");
				return false;				
			}
			DEBUGL6("Document::Progress<%d>\n",prog);			
		}while(prog!=100);
	}	
	else		
	{	
	   if(doc1->CopyPage(Page) != STATUS_OK) {
	        DEBUGL1("Document::CopyPage() is failed\n");
	        return false;
	    }
	}
	DEBUGL6("Document::CopyPagee succesfull\n");
	scanf("%d",&i);
    DocumentRef doc = GetDocument(boxbasepath, newBox,newFolder, newDocument);
    if(!doc) {
        return false;
    }

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull..Pasting the page..\n");
	scanf("%d",&i);

   if(doc->PastePage(newpage) != STATUS_OK) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Paste succesfull\n");
	scanf("%d",&i);

	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

   if(doc1->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }


	DEBUGL6("Document:: Save succesfull\n");

	return true;
}

bool test_CutPage(CString boxbasepath,CString boxnumber,CString foldername,CString documentname,bool isProgress)
{

    int Page,newpage;
    CString newBox,newFolder,newDocument;

    cout << "Enter the page Number" << endl;
    cin >> Page;

    cout << "Enter the BoxName where it has to be pasted" << endl;
    cin >> newBox;

    cout << "Enter the FolderName where it has to be pasted(enter n for empty)" << endl;
    cin >> newFolder;
	if(newFolder == "n")
		newFolder = "";

    cout << "Enter the DocumentName where it has to be pasted" << endl;
    cin >> newDocument;

    cout << "Enter the Page Number" << endl;
    cin >> newpage;

    DocumentRef doc1 = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc1) {
        return false;
    }

    DEBUGL6("Document:: Editing called\n");

    if(doc1->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
	int i;

	DEBUGL6("Document:: Edit succesfull\n");

	scanf("%d",&i);

	if(isProgress)
	{	
		ProgressRef progress;
		int prog;
		if(doc1->CutPage(progress,Page) != STATUS_OK)
		{
			DEBUGL1("Document::CutPage() is failed\n");
			return false;
		}
		do
		{
			if(progress->GetProgress(prog)!=STATUS_OK)
			{
				DEBUGL1("Document::GetProgress() is failed\n");
				return false;				
			}
			DEBUGL6("Document::Progress<%d>\n",prog);			
		}while(prog!=100);
	}	
	else		
	{	
	   if(doc1->CutPage(Page) != STATUS_OK) {
	        DEBUGL1("Document::CutPage() is failed\n");
	        return false;
	    }
	}
	DEBUGL6("Document:: CutPage succesfull\n");
	scanf("%d",&i);
    DocumentRef doc = GetDocument(boxbasepath, newBox,newFolder, newDocument);
    if(!doc) {
        return false;
    }

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
	scanf("%d",&i);

   if(doc->PastePage(newpage) != STATUS_OK) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Paste succesfull\n");
	scanf("%d",&i);

	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

   if(doc1->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }


	DEBUGL6("Document:: Save succesfull\n");

	return true;
}
bool test_DeletePage(CString boxbasepath,CString boxnumber,CString foldername,CString documentname,bool isProgress)
{
    int Page,size;
    cout << "Enter the page Number" << endl;
    cin >> Page;

    cout << "Enter the Number of pages to be deleted" << endl;
    cin >> size;

    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }

    DEBUGL6("Document:: Editing called\n");

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
	if(isProgress)
	{	
		ProgressRef progress;
		int prog;
		if(doc->DeletePage(progress,Page,size) != STATUS_OK)
		{
			DEBUGL1("Document::DeletePage() is failed\n");
			return false;
		}
		do
		{
			if(progress->GetProgress(prog)!=STATUS_OK)
			{
				DEBUGL1("Document::GetProgress() is failed\n");
				return false;				
			}
			DEBUGL6("Document::Progress<%d>\n",prog);			
		}while(prog!=100);
	}	
	else		
	{		 
	   if(doc->DeletePage(Page,size) != STATUS_OK) {
	        DEBUGL1("Document::DeletePage() is failed\n");
	        return false;
	    }
	}
	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
	}
	return true;
}


bool test_CutPages(CString boxbasepath,CString boxnumber,CString foldername,CString documentname,bool isProgress)
{

    int newpage;
    CString newBox,newFolder,newDocument;

    cout << "Pages 1 to 3 will be CUT" << endl;
  	 vector<int> pages;
    pages.push_back(1);
    pages.push_back(2);
    pages.push_back(3);

    cout << "Enter the BoxName where it has to be pasted" << endl;
    cin >> newBox;

    cout << "Enter the FolderName where it has to be pasted" << endl;
    cin >> newFolder;

    cout << "Enter the DocumentName where it has to be pasted" << endl;
    cin >> newDocument;

    cout << "Enter the Page Number" << endl;
    cin >> newpage;

    DocumentRef doc1 = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc1) {
        return false;
    }

    DEBUGL6("Document:: Editing called\n");

    if(doc1->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
	int i;

	DEBUGL6("Document:: Edit succesfull\n");

	scanf("%d",&i);

	if(isProgress)
	{	
		ProgressRef progress;
		int prog;
		if(doc1->CutPage(progress,pages) != STATUS_OK)
		{
			DEBUGL1("Document::CutPage() is failed\n");
			return false;
		}
		do
		{
			if(progress->GetProgress(prog)!=STATUS_OK)
			{
				DEBUGL1("Document::GetProgress() is failed\n");
				return false;				
			}
			DEBUGL6("Document::Progress<%d>\n",prog);			
		}while(prog!=100);
	}	
	else		
	{	
	   if(doc1->CutPage(pages) != STATUS_OK) {
	        DEBUGL1("Document::CutPage() is failed\n");
	        return false;
	    }
	}
	DEBUGL6("Document:: CutPage succesfull\n");
	scanf("%d",&i);
    DocumentRef doc = GetDocument(boxbasepath, newBox,newFolder, newDocument);
    if(!doc) {
        return false;
    }

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
	scanf("%d",&i);

   if(doc->PastePage(newpage) != STATUS_OK) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Paste succesfull\n");
	scanf("%d",&i);

	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

   if(doc1->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }


	DEBUGL6("Document:: Save succesfull\n");

	return true;
}

bool test_CopyPages(CString boxbasepath,CString boxnumber,CString foldername,CString documentname,bool isProgress)
{

    int newpage;
    CString newBox,newFolder,newDocument;

    cout << "Pages 1 to 3 will be COPIED" << endl;
  	 vector<int> pages;
    pages.push_back(1);
    pages.push_back(2);
    pages.push_back(3);

    cout << "Enter the BoxName where it has to be pasted" << endl;
    cin >> newBox;

    cout << "Enter the FolderName where it has to be pasted" << endl;
    cin >> newFolder;

    cout << "Enter the DocumentName where it has to be pasted" << endl;
    cin >> newDocument;

    cout << "Enter the Page Number" << endl;
    cin >> newpage;

    DocumentRef doc1 = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc1) {
        return false;
    }

    DEBUGL6("Document:: Editing called\n");

    if(doc1->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
	int i;

	DEBUGL6("Document:: Edit succesfull\n");

	scanf("%d",&i);

	if(isProgress)
	{	
		ProgressRef progress;
		int prog;
		if(doc1->CopyPage(progress,pages) != STATUS_OK)
		{
			DEBUGL1("Document::CopyPage() is failed\n");
			return false;
		}
		do
		{
			if(progress->GetProgress(prog)!=STATUS_OK)
			{
				DEBUGL1("Document::GetProgress() is failed\n");
				return false;				
			}
			DEBUGL6("Document::Progress<%d>\n",prog);			
		}while(prog!=100);
	}	
	else		
	{	
	   if(doc1->CopyPage(pages) != STATUS_OK) {
	        DEBUGL1("Document::CopyPage() is failed\n");
	        return false;
	    }
	}
	DEBUGL6("Document:: CopyPage succesfull\n");
	scanf("%d",&i);
    DocumentRef doc = GetDocument(boxbasepath, newBox,newFolder, newDocument);
    if(!doc) {
        return false;
    }

    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
	scanf("%d",&i);

   if(doc->PastePage(newpage) != STATUS_OK) {
        DEBUGL1("Document::PastePage() is failed\n");
        return false;
    }

	DEBUGL6("Document:: Paste succesfull\n");
	scanf("%d",&i);

	if(doc->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }

   if(doc1->Save() != STATUS_OK) {
        DEBUGL1("Document::Save() is failed\n");
        return false;
    }


	DEBUGL6("Document:: Save succesfull\n");

	return true;
}

bool test_ReplacePages(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        return false;
    }
	int option;
    cout << "1. Replace page" << endl;	
    cout << "2. Replace page by link" << endl;
	cin >> option;

	if(option == 1)
	{
	    cout << "Pages 1 to 3 will be Replaced with 4 to 6" << endl;

	    PageList list;
	    if(doc->GetPageList(list,4,3) != STATUS_OK) {
	        DEBUGL1("getting page list is failed\n");
	        return false;
	    }


	    DEBUGL6("Document:: Recreate called\n");

	    if(doc->ReCreate() != STATUS_OK) {
	        DEBUGL1("Document::Edit() is failed\n");
	        return false;
	    }
		int i;

		DEBUGL6("Document:: Recreate succesfull\n");

		scanf("%d",&i);

		int pageno=1;
	   if(doc->ReplacePage(pageno,list) != STATUS_OK) {
	        DEBUGL1("Document::ReplacePage() is failed\n");
	        return false;
	    }
		DEBUGL6("Document:: ReaplcePage succesfull\n");
	}
	else
	{
	    cout << "Pages 1 to 3 will be Replaced by link with 4 to 6" << endl;

	    PageList list;
	    if(doc->GetPageList(list,4,3) != STATUS_OK) {
	        DEBUGL1("getting page list is failed\n");
	        return false;
	    }


	    DEBUGL6("Document:: Recreate called\n");

	    if(doc->ReCreate() != STATUS_OK) {
	        DEBUGL1("Document::Edit() is failed\n");
	        return false;
	    }
		int i;

		DEBUGL6("Document:: Recreate succesfull\n");

		scanf("%d",&i);

		int pageno=1;
		PageList::const_iterator    itemIterator;
		PageRef  pageRef;
		for (itemIterator = list.begin(); itemIterator != list.end(); itemIterator++)
		{
			pageRef = *itemIterator;				
		   	if(doc->ReplacePageByLink(pageno,pageRef) != STATUS_OK) {
		      	  	DEBUGL1("Document::ReplacePage() is failed\n");
	      			return false;
	    		}
		}
		DEBUGL6("Document:: ReaplcePage succesfull\n");
		
	}
	return true;
}

bool test_InsertDelete(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
   
    // 3.1: Get Document
    DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
    if(!doc) {
        DEBUGL1("GetDocument() is failed\n");	 	
        return false;
    }
    int total = 1;
    PageRef page;
    for(int i = 0; i < total; i++) {

        // 4: get the instance of new page
        if(doc->GetPage(2,page) != STATUS_OK) {
            DEBUGL1("Document::CreatePage() is failed\n");
            return false;
        }
        
	// 4.2.1
#if 0
        IM_EX_0615_OUT param;
        unsigned short aa =1;
        param.regXSIZE[1] = aa;
        if(page->SetCopyJpegParameter(&param)!=STATUS_OK)
        {
            DEBUGL1("Page::SetCopyJpegParameter failed\n");
            return false;
        }
#endif
	     if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() is failed\n");
        return false;
    }
		 cout << "Document edited\n";
		 scanf("%d",&i);
	int option;
    cout << "1. Insert page" << endl;	
    cout << "2. Insert page by link" << endl;
	cin >> option;
		 
	if(option == 1)
	{
	        // 4.3: add page to Document as last page
	        if(doc->InsertPage(1,page) != STATUS_OK) {
	            DEBUGL1("Document::Insertpage is failed\n");
	            return false;
	        }
	}
	else
	{
	        // 4.3: add page to Document as last page
	        if(doc->InsertPageByLink(1,page) != STATUS_OK) {
	            DEBUGL1("Document::Insertpage is failed\n");
	            return false;
        }
		
	}
	cout << "Insert page  completed\n";
        scanf("%d",&i);
	if(doc->DeletePage(3,1) != STATUS_OK) {
        DEBUGL1("Document::InsertPage() is failed\n");
        return false;
    }
	doc->Save();					


    }
    // 5.1 : Put Document Property
    
    return true;	
}
bool test_insBlankPage(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
	DEBUGL4("test_insBlankPage : Entering insert blank page\n");

	// Get Document
	DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
	if(!doc) {
		DEBUGL1("GetDocument() is failed\n");	 	
	  	return false;
	}
	int pageNum;
	cout << "Enter the page number: "  << endl;
	cin >> pageNum;
	const int NUM_PAPER = 43;
	char *paperSizes[] = {
		"A3", "B4", "A4", "B5", "A5", "A6", "POSTCARD", "LEDGER", "LEGAL", 
		"LETTER", "STATEMENT", "FOLIO", "COMPUTER", "LEGAL13", "A3_WIDE", 
		"SRA3_450", "SRA3_460", "LEDGER_WIDE", "RECTANGLE13X19", 
		"SQUARE8_5", "SIZE_8K", "SIZE_16K", 
		"A3_R", "B4_R", "A4_R", "B5_R", "A5_R", "A6_R", "POSTCARD_R", "LEDGER_R", "LEGAL_R", 
		"LETTER_R", "STATEMENT_R", "FOLIO_R", "COMPUTER_R", "LEGAL13_R", "A3_WIDE_R", 
		"SRA3_450_R", "SRA3_460_R", "LEDGER_WIDE_R", "RECTANGLE13X19_R", 
		"SQUARE8_5_R", "SIZE_8K_R", "SIZE_16K_R" 		
	}; 
	map<CString, PaperSize> paperSizeEnumString;
	paperSizeEnumString["A3"] = ci::boxdocument::A3;
	paperSizeEnumString["B4"] = ci::boxdocument::B4;
	paperSizeEnumString["A4"] = ci::boxdocument::A4;
	paperSizeEnumString["B5"] = ci::boxdocument::B5;
	paperSizeEnumString["A5"] = ci::boxdocument::A5;
	paperSizeEnumString["A6"] = ci::boxdocument::A6;
	paperSizeEnumString["POSTCARD"] = ci::boxdocument::POSTCARD;
	paperSizeEnumString["LEDGER"] = ci::boxdocument::LEDGER;
	paperSizeEnumString["LEGAL"] = ci::boxdocument::LEGAL;
	paperSizeEnumString["LETTER"] = ci::boxdocument::LETTER;
	paperSizeEnumString["STATEMENT"] = ci::boxdocument::STATEMENT;
	paperSizeEnumString["FOLIO"] = ci::boxdocument::FOLIO;
	paperSizeEnumString["COMPUTER"] = ci::boxdocument::COMPUTER;
	paperSizeEnumString["LEGAL13"] = ci::boxdocument::LEGAL13;
	paperSizeEnumString["A3_WIDE"] = ci::boxdocument::A3_WIDE;
	paperSizeEnumString["LEDGER_WIDE"] = ci::boxdocument::LEDGER_WIDE;
	paperSizeEnumString["SRA3_450"] = ci::boxdocument::SRA3_450;
	paperSizeEnumString["SRA3_460"] = ci::boxdocument::SRA3_460;
	paperSizeEnumString["RECTANGLE13X19"] = ci::boxdocument::RECTANGLE13X19;
	paperSizeEnumString["SQUARE8_5"] = ci::boxdocument::SQUARE8_5;
	paperSizeEnumString["SIZE_8K"] = ci::boxdocument::SIZE_8K;
	paperSizeEnumString["SIZE_16K"] = ci::boxdocument::SIZE_16K;
	paperSizeEnumString["A3_R"] = ci::boxdocument::A3_R;
	paperSizeEnumString["B4_R"] = ci::boxdocument::B4_R;
	paperSizeEnumString["A4_R"] = ci::boxdocument::A4_R;
	paperSizeEnumString["B5_R"] = ci::boxdocument::B5_R;
	paperSizeEnumString["A5_R"] = ci::boxdocument::A5_R;
	paperSizeEnumString["A6_R"] = ci::boxdocument::A6_R;
	paperSizeEnumString["POSTCARD_R"] = ci::boxdocument::POSTCARD_R;
	paperSizeEnumString["LEDGER_R"] = ci::boxdocument::LEDGER_R;
	paperSizeEnumString["LEGAL_R"] = ci::boxdocument::LEGAL_R;
	paperSizeEnumString["LETTER_R"] = ci::boxdocument::LETTER_R;
	paperSizeEnumString["STATEMENT_R"] = ci::boxdocument::STATEMENT_R;
	paperSizeEnumString["FOLIO_R"] = ci::boxdocument::STATEMENT_R;
	paperSizeEnumString["COMPUTER_R"] = ci::boxdocument::COMPUTER_R;
	paperSizeEnumString["LEGAL13_R"] = ci::boxdocument::LEGAL13_R;
	paperSizeEnumString["A3_WIDE_R"] = ci::boxdocument::A3_WIDE_R;
	paperSizeEnumString["LEDGER_WIDE_R"] = ci::boxdocument::LEDGER_WIDE_R;
	paperSizeEnumString["SRA3_450_R"] = ci::boxdocument::SRA3_450_R;
	paperSizeEnumString["SRA3_460_R"] = ci::boxdocument::SRA3_460_R;
	paperSizeEnumString["RECTANGLE13X19_R"] = ci::boxdocument::RECTANGLE13X19_R;
	paperSizeEnumString["SQUARE8_5_R"] = ci::boxdocument::SQUARE8_5_R;
	paperSizeEnumString["SIZE_8K_R"] = ci::boxdocument::SIZE_8K_R;
	paperSizeEnumString["SIZE_16K_R"] = ci::boxdocument::SIZE_16K_R;

	CString automate;
	cout << "Automate to insert all the paperSize (y/n): " << endl;
	cin >> automate;
	if(automate == "n")
	{
		cout << "Select the PaperSize from below list" << endl;
		CString paperSize;
		for (int nps = 0; nps < NUM_PAPER; nps++)
			cout << paperSizes[nps] << endl;

		cout << "Enter the paper size (String): " << endl;
		cin >> paperSize;
		doc->Edit();			
		if(doc->InsertBlankPage(pageNum, paperSizeEnumString[paperSize]) != STATUS_OK)
		{
			DEBUGL1("test_insBlankPage : Insert blank page failed\n");
			return false;
		}
		else
		{
			DEBUGL1("test_insBlankPage : Insert blank page success\n");
		}
		doc->Save();
	}
	else if(automate == "y")
	{
		for (int nn = 0; nn < NUM_PAPER; nn++)
		{
			doc->Edit();	
			if(doc->InsertBlankPage(pageNum, paperSizeEnumString[paperSizes[nn]]) != STATUS_OK)
			{
				DEBUGL1("test_insBlankPage : Insert blank page failed\n");
				return false;
			}
			else
			{
				DEBUGL1("test_insBlankPage : Insert blank page success\n");
			}
			doc->Save();					
		}
	}
	else
	{
		cout << "Wrong input" << endl;
		return false;
	}
	DEBUGL4("test_insBlankPage : Exiting insert blank page\n");
	return true;
}
bool test_insBlankPage_loireAlabama(CString boxbasepath,CString boxnumber,CString foldername,CString documentname)
{
   DEBUGL4("test_insBlankPage_loireAlabama : Entering insert blank page for Loire and Alabama\n");

   // Get Document
   DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
   if(!doc) {
      DEBUGL1("GetDocument() has failed\n");
      return false;
   }
   int pageNum;
   cout << "Enter the page number: "  << endl;
   cin >> pageNum;
   const int NUM_PAPER = 34;
   char *paperSizes[] = {
      "A3", "B4", "A4", "B5", "A5", "A6", "POSTCARD", "LEDGER", "LEGAL",
      "LETTER", "STATEMENT", "FOLIO", "COMPUTER", "LEGAL13", /*"A3_WIDE",*/
      /*"SRA3_450", "SRA3_460", "LEDGER_WIDE", "RECTANGLE13X19",*/
      "SQUARE8_5", "SIZE_8K", "SIZE_16K",
      "A3_R", "B4_R", "A4_R", "B5_R", "A5_R", "A6_R", "POSTCARD_R", "LEDGER_R", "LEGAL_R",
      "LETTER_R", "STATEMENT_R", "FOLIO_R", "COMPUTER_R", "LEGAL13_R", /*"A3_WIDE_R",
      "SRA3_450_R", "SRA3_460_R", "LEDGER_WIDE_R", "RECTANGLE13X19_R",*/
      "SQUARE8_5_R", "SIZE_8K_R", "SIZE_16K_R"
   };
   map<CString, PaperSize> paperSizeEnumString;
   paperSizeEnumString["A3"] = ci::boxdocument::A3;
   paperSizeEnumString["B4"] = ci::boxdocument::B4;
   paperSizeEnumString["A4"] = ci::boxdocument::A4;
   paperSizeEnumString["B5"] = ci::boxdocument::B5;
   paperSizeEnumString["A5"] = ci::boxdocument::A5;
   paperSizeEnumString["A6"] = ci::boxdocument::A6;
   paperSizeEnumString["POSTCARD"] = ci::boxdocument::POSTCARD;
   paperSizeEnumString["LEDGER"] = ci::boxdocument::LEDGER;
   paperSizeEnumString["LEGAL"] = ci::boxdocument::LEGAL;
   paperSizeEnumString["LETTER"] = ci::boxdocument::LETTER;
   paperSizeEnumString["STATEMENT"] = ci::boxdocument::STATEMENT;
   paperSizeEnumString["FOLIO"] = ci::boxdocument::FOLIO;
   paperSizeEnumString["COMPUTER"] = ci::boxdocument::COMPUTER;
   paperSizeEnumString["LEGAL13"] = ci::boxdocument::LEGAL13;
   #if 0
   paperSizeEnumString["A3_WIDE"] = ci::boxdocument::A3_WIDE;
   paperSizeEnumString["LEDGER_WIDE"] = ci::boxdocument::LEDGER_WIDE;
   paperSizeEnumString["SRA3_450"] = ci::boxdocument::SRA3_450;
   paperSizeEnumString["SRA3_460"] = ci::boxdocument::SRA3_460;
   paperSizeEnumString["RECTANGLE13X19"] = ci::boxdocument::RECTANGLE13X19;
   #endif
   paperSizeEnumString["SQUARE8_5"] = ci::boxdocument::SQUARE8_5;
   paperSizeEnumString["SIZE_8K"] = ci::boxdocument::SIZE_8K;
   paperSizeEnumString["SIZE_16K"] = ci::boxdocument::SIZE_16K;
   paperSizeEnumString["A3_R"] = ci::boxdocument::A3_R;
   paperSizeEnumString["B4_R"] = ci::boxdocument::B4_R;
   paperSizeEnumString["A4_R"] = ci::boxdocument::A4_R;
   paperSizeEnumString["B5_R"] = ci::boxdocument::B5_R;
   paperSizeEnumString["A5_R"] = ci::boxdocument::A5_R;
   paperSizeEnumString["A6_R"] = ci::boxdocument::A6_R;
   paperSizeEnumString["POSTCARD_R"] = ci::boxdocument::POSTCARD_R;
   paperSizeEnumString["LEDGER_R"] = ci::boxdocument::LEDGER_R;
   paperSizeEnumString["LEGAL_R"] = ci::boxdocument::LEGAL_R;
   paperSizeEnumString["LETTER_R"] = ci::boxdocument::LETTER_R;
   paperSizeEnumString["STATEMENT_R"] = ci::boxdocument::STATEMENT_R;
   paperSizeEnumString["FOLIO_R"] = ci::boxdocument::STATEMENT_R;
   paperSizeEnumString["COMPUTER_R"] = ci::boxdocument::COMPUTER_R;
   paperSizeEnumString["LEGAL13_R"] = ci::boxdocument::LEGAL13_R;
   #if 0
   paperSizeEnumString["A3_WIDE_R"] = ci::boxdocument::A3_WIDE_R;
   paperSizeEnumString["LEDGER_WIDE_R"] = ci::boxdocument::LEDGER_WIDE_R;
   paperSizeEnumString["SRA3_450_R"] = ci::boxdocument::SRA3_450_R;
   paperSizeEnumString["SRA3_460_R"] = ci::boxdocument::SRA3_460_R;
   paperSizeEnumString["RECTANGLE13X19_R"] = ci::boxdocument::RECTANGLE13X19_R;
   #endif
   paperSizeEnumString["SQUARE8_5_R"] = ci::boxdocument::SQUARE8_5_R;
   paperSizeEnumString["SIZE_8K_R"] = ci::boxdocument::SIZE_8K_R;
   paperSizeEnumString["SIZE_16K_R"] = ci::boxdocument::SIZE_16K_R;
   CString automate;
   cout << "Automate to insert all the paperSize for Loire and Alabama (y/n): " << endl;
   cin >> automate;
   if(automate == "n")
   {
      cout << "Select the PaperSize from below list" << endl;
      CString paperSize;
      for (int nps = 0; nps < NUM_PAPER; nps++)
         cout << paperSizes[nps] << endl;

      cout << "Enter the paper size (String): " << endl;
      cin >> paperSize;
      doc->Edit();
      if(doc->InsertBlankPage(pageNum, paperSizeEnumString[paperSize]) != STATUS_OK)
      {
         DEBUGL1("test_insBlankPage_loireAlabama : Insert blank page for Loire and Alabama failed for paperSize\n");
         return false;
      }
      else
      {
         DEBUGL1("test_insBlankPage_loireAlabama : Insert blank page for Loire and Alabama success\n");
      }
      doc->Save();
   }
   else if(automate == "y")
   {
      for (int nn = 0; nn < NUM_PAPER; nn++)
      {
         doc->Edit();
         if(doc->InsertBlankPage(pageNum, paperSizeEnumString[paperSizes[nn]]) != STATUS_OK)
         {
            DEBUGL1("test_insBlankPage_loireAlabama : Insert blank page for Loire and Alabama failesd for paperSize<%s>\n",paperSizes[nn]);
            return false;
         }
         else
         {
            DEBUGL1("test_insBlankPage_loireAlabama : Insert blank page for Loire and Alabama success\n");
         }
         doc->Save();
      }
   }
   else
   {
      cout << "Wrong input" << endl;
      return false;
   }
   DEBUGL4("test_insBlankPage_loireAlabama : Exiting insert blank page for Loire and Alabama\n");
   return true;
}
bool test_GetMap(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname)
{
	// Get Document
	DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
	if(!doc) {
		DEBUGL1("GetDocument() is failed\n");	 	
	  	return false;
	}

	PaperSizeMap pm;
   PaperSizeMap::iterator pit;
	doc->GetPaperSizeMap(pm);

   for(pit = pm.begin();pit!= pm.end(); pit++)
      DEBUGL6("test_GetMap:: PaperSize - %d and Val - %d\n",(*pit).first,(*pit).second);

	ColorModeMap cm;
   ColorModeMap::iterator cit;
	doc->GetColorModeMap(cm);

   for(cit = cm.begin();cit!= cm.end(); cit++)
         DEBUGL6("test_GetMap:: colorMode - %d and Val - %d\n",(*cit).first,(*cit).second);

	JobTypeMap jm;
   JobTypeMap::iterator jit;
	doc->GetJobTypeMap(jm);

   for(jit = jm.begin();jit!= jm.end(); jit++)
         DEBUGL6("test_GetMap:: jobType - %s and Val - %d\n",((*jit).first).c_str(),(*jit).second);

	ResolutionMap rm;
   ResolutionMap::iterator rit;
	doc->GetHorizontalResolutionMap(rm);
   for(rit = rm.begin();rit!= rm.end(); rit++)
      DEBUGL6("test_GetMap:: ResolutionMap(Horizontal)  - %d and Val - %d\n",(*rit).first,(*rit).second);

   rm.clear();
	doc->GetVerticalResolutionMap(rm);
   for(rit = rm.begin();rit!= rm.end(); rit++)
      DEBUGL6("test_GetMap:: ResolutionMap(Horizontal)  - %d and Val - %d\n",(*rit).first,(*rit).second);

   return true;

}
bool test_GetSetPageCount(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname)
{
	// Get Document
	DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
	if(!doc) {
		DEBUGL1("GetDocument() is failed\n");	 	
	  	return false;
	}

	DEBUGL6("Setting page count to 50\n");
	int count = 50;
	if(doc->SetInputPageCount(count)!=STATUS_OK)
	{
		DEBUGL1("setting pagecount failed\n");
		return false;
	}
	int pagecount;
	if(doc->GetInputPageCount(pagecount)!=STATUS_OK)
	{
		DEBUGL1("getting pagecount failed\n");
		return false;
	}
	DEBUGL6("PageCount = %d\n", pagecount);
  	 return true;

}
bool test_GetWEPDocument(CString boxbasepath, CString boxnumber, CString foldername, CString documentname)
{
   DEBUGL4("test_GetWEPDocument Enter\n");
   // Get Document
   DocumentRef doc = GetDocument(boxbasepath, boxnumber, foldername, documentname);
   if(!doc)
   {
      DEBUGL1("GetDocument() is failed\n");
      return false;
   }
   CString docID = "/home/docID";
   DEBUGL6("test_GetWEPDocument: calling getwepdocument\n", docID.c_str());
   if(doc->GetWEPDocument(docID) != STATUS_OK)
   {
      DEBUGL1("Failed to get the wep document\n");
      return false;
   }
   DEBUGL6("test_GetWEPDocument: docID = (%s)\n", docID.c_str());
   DEBUGL4("test_GetWEPDocument Exit\n");
   return true;
}

bool test_Progress(CString boxbasepath, CString boxnumber, CString foldername, CString documentname)
{
	while(true)
	{
		cout << "1. Edit->Cut->Paste->Save" << endl;
		cout << "2. Edit->Copy->Paste->Save" << endl;
		cout << "3. Edit->Delete->Save" << endl;
		cout << "0. Exit" << endl;
		int i;
		cin >> i;
		bool res = false;
		switch(i){
			case 0: return true;
					  break;
			case 1: res = test_CutPaste(boxbasepath, boxnumber, foldername, documentname);
					  break;
			case 2: res = test_CopyPaste(boxbasepath, boxnumber, foldername, documentname);
					  break;
			case 3: res = test_Delete(boxbasepath, boxnumber, foldername, documentname);
		}
		cout << "result = " << res << endl;
	}
}

bool test_Delete(CString boxbasepath, CString boxnumber, CString foldername, CString documentname)
{
	   BoxDocumentRef boxdoc;
   CUUIDRef uid = new CUUID();
   CString sessionID= uid->toString();

    boxdoc = BoxDocument::Acquire(sessionID);
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() has failed\n");
        return NULL;
    }

   BoxRef box;
   if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
   {
      DEBUGL1("BoxDocument::GetBox() failed\n");
      return false;
   }

   DocumentRef doc;
    if(box->GetDocument(doc, documentname) != STATUS_OK) {
        DEBUGL1("Box::GetDocument() failed\n");
        return false;
    }

   std::vector<int> pagelist;
   char ch = 'y';
   do{
      int pagenum = 0;
      cout << "Enter the page number to delete:" << endl;
      cin >> pagenum;
      pagelist.push_back(pagenum);
      cout << "Do you want to paste another page[y/n]:" << endl;
      cin >> ch;
   }while(ch == 'y');

	
    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
   int i;
   scanf("%d",&i);

   ProgressRef progress;
   int prog;
   if(doc->DeletePage(progress,pagelist) != STATUS_OK)
   {
      DEBUGL1("Document::DeletePage() failed\n");
      return false;
   }
   do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);

   DEBUGL6("Document:: Edit succesfull\n");
   scanf("%d",&i);
	
   if(doc->Save(progress) != STATUS_OK)
   {
      DEBUGL1("Document::Save() failed\n");
      return false;
   }
   do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);
	return true;
}

bool test_CutPaste(CString boxbasepath, CString boxnumber, CString foldername, CString documentname)
{
	BoxDocumentRef boxdoc;
   CUUIDRef uid = new CUUID();
   CString sessionID= uid->toString();

    boxdoc = BoxDocument::Acquire(sessionID);
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() has failed\n");
        return NULL;
    }

   BoxRef box;
   if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
   {
      DEBUGL1("BoxDocument::GetBox() failed\n");
      return false;
   }

   DocumentRef doc;
    if(box->GetDocument(doc, documentname) != STATUS_OK) {
        DEBUGL1("Box::GetDocument() failed\n");
        return false;
    }

	std::vector<int> pagelist;
	char ch = 'y';
	do{
		int pagenum = 0;
		cout << "Enter the page number to cut and paste:" << endl;
		cin >> pagenum;
		pagelist.push_back(pagenum);
		cout << "Do you want to paste another page[y/n]:" << endl;
		cin >> ch;
	}while(ch == 'y');

	cout << "Enter the position where the pages have to be pasted:" << endl;
	int newpage = 0;
	cin >> newpage;

	
	 if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() failed\n");
        return false;
    }

   DEBUGL6("Document:: Edit succesfull\n");
   int i;
   scanf("%d",&i);

	ProgressRef progress;
	int prog;
	if(doc->CutPage(progress,pagelist) != STATUS_OK)
	{
		DEBUGL1("Document::CopyPage() failed\n");
		return false;
	}
	do
	{
		if(progress->GetProgress(prog)!=STATUS_OK)
		{
			DEBUGL1("Document::GetProgress() is failed\n");
			return false;
		}
		DEBUGL6("Document::Progress<%d>\n",prog);
	}while(prog!=100);
	
	DEBUGL6("Document:: Cut succesfull\n");
	scanf("%d", &i);
	
	if(doc->PastePage(progress, newpage) != STATUS_OK)
	{
		DEBUGL1("Document::PastePage() failed\n");
      return false;
	}
	do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);

	DEBUGL6("Document:: Paste succesfull\n");
   scanf("%d", &i);
			
	if(doc->SaveAs(progress, documentname) != STATUS_OK)
	{
		DEBUGL1("Document::Save() failed\n");
      return false;
	}
	do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);
	return true;
}

bool test_CopyPaste(CString boxbasepath, CString boxnumber, CString foldername, CString documentname)
{
	   BoxDocumentRef boxdoc;
   CUUIDRef uid = new CUUID();
   CString sessionID= uid->toString();

    boxdoc = BoxDocument::Acquire(sessionID);
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() has failed\n");
        return NULL;
    }

   BoxRef box;
   if(boxdoc->GetBox(box,boxbasepath,boxnumber)!=STATUS_OK)
   {
      DEBUGL1("BoxDocument::GetBox() failed\n");
      return false;
   }

   DocumentRef doc;
    if(box->GetDocument(doc, documentname) != STATUS_OK) {
        DEBUGL1("Box::GetDocument() failed\n");
        return false;
    }

   std::vector<int> pagelist;
   char ch = 'y';
   do{
      int pagenum = 0;
      cout << "Enter the page number to copy and paste:" << endl;
      cin >> pagenum;
      pagelist.push_back(pagenum);
      cout << "Do you want to paste another page[y/n]:" << endl;
      cin >> ch;
   }while(ch == 'y');

   cout << "Enter the position where the pages have to be pasted:" << endl;
   int newpage = 0;
   cin >> newpage;


    if(doc->Edit() != STATUS_OK) {
        DEBUGL1("Document::Edit() failed\n");
        return false;
    }
	int i;
   scanf("%d",&i);

   ProgressRef progress;
   int prog;
   if(doc->CopyPage(progress,pagelist) != STATUS_OK)
   {
      DEBUGL1("Document::CopyPage() failed\n");
      return false;
   }
   do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);

   DEBUGL6("Document:: Copy succesfull\n");
   scanf("%d", &i);

   if(doc->PastePage(progress, newpage) != STATUS_OK)
   {
      DEBUGL1("Document::PastePage() failed\n");
      return false;
   }
   do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);

   DEBUGL6("Document:: Paste succesfull\n");
   scanf("%d", &i);
	
	
   if(doc->Save(progress) != STATUS_OK)
   {
      DEBUGL1("Document::Save() failed\n");
      return false;
   }
   do
   {
      if(progress->GetProgress(prog)!=STATUS_OK)
      {
         DEBUGL1("Document::GetProgress() is failed\n");
         return false;
      }
      DEBUGL6("Document::Progress<%d>\n",prog);
   }while(prog!=100);
   return true;
}

bool test_document(CString boxbasepath, CString boxnumber, CString foldername, CString &documentname) {
    bool result;
    while(1) {
        int i = 0;
        cout << "Document: /" << boxbasepath << "/" << boxnumber << "/";
        if(foldername != "") {
            cout << foldername << "/";
        }
        cout << documentname << endl;
        cout << "1. Get Status" << endl;
        cout << "2. Status Change : EndCreating()" << endl;
        cout << "3. Status Change : Use()" << endl;
        cout << "4. Status Change : EndUsing()" << endl;
        cout << "5. Status Change : Edit()" << endl;
        cout << "6. Status Change : CancelEdit()" << endl;
        cout << "7. Get Page List" << endl;
        cout << "8. Get Page" << endl;
        cout << "9. Rename Document" << endl;
        cout << "10. Get WebDAV property" << endl;
        cout << "11. Set WebDAV property" << endl;
        cout << "12. Test EDIT and CancelEdit" << endl;
        cout << "13. Test EDIT and Save" << endl;
        cout << "14. Test EDIT and SaveAs" << endl;
        cout << "15. Copy Page" << endl;
        cout << "16. Cut  Page" << endl;
        cout << "17. Delete Pages" << endl;
        cout << "18. Cut  Pages" << endl;
        cout << "19. Copy  Pages" << endl;
        cout << "20. Replace Pages" << endl;
        cout << "21. Insert and Delete" << endl;		
        cout << "22.	test_insBlankPage" <<endl;		
        cout << "23. Copy Page with Progress" << endl;
        cout << "24. Cut  Page with Progress" << endl;
        cout << "25. Delete Pages with Progress" << endl;
        cout << "26. Cut  Pages with Progress" << endl;
        cout << "27. Copy  Pages with Progress" << endl;
        cout << "28. Get/Set Map properties" << endl;
        cout << "29. Get/Set page count" << endl;
        cout << "30. Get wep document" << endl;
        cout << "31. Status Change : Reserve()" << endl;
        cout << "32. Status Change : EndReserving()" << endl;
        cout << "33. test_insBlankPage_loireAlabama" << endl;
		  cout << "34. test_Progress" << endl;
        cout << "0. exit" << endl;
        cin >> i;
        result = false;
        switch(i) {
        case 0: return true;
        case 1: result = test_GetStatus(boxbasepath, boxnumber, foldername, documentname); break;
        case 2: result = test_EndCreating(boxbasepath, boxnumber, foldername, documentname); break;
        case 3: result = test_Use(boxbasepath, boxnumber, foldername, documentname); break;
        case 4: result = test_EndUsing(boxbasepath, boxnumber, foldername, documentname); break;
        case 5: result = test_Edit(boxbasepath, boxnumber, foldername, documentname); break;
        case 6: result = test_CancelEdit(boxbasepath, boxnumber, foldername, documentname); 
        case 7: result = test_GetPageList(boxbasepath, boxnumber, foldername, documentname); break;
        case 8: result = test_GetPage(boxbasepath, boxnumber, foldername, documentname); break;
        case 9: result = test_RenameDocument(boxbasepath, boxnumber, foldername, documentname); break;
        case 10: result = test_GetWebDAVProperty(boxbasepath, boxnumber, foldername, documentname); break;
        case 11: result = test_SetWebDAVProperty(boxbasepath, boxnumber, foldername, documentname); break;
        case 12: result = test_EditandCancelEdit(boxbasepath, boxnumber, foldername, documentname); break;
        case 13: result = test_EditandSave(boxbasepath, boxnumber, foldername, documentname); break;
        case 14: result = test_EditandSaveAs(boxbasepath, boxnumber, foldername, documentname); break;
        case 15: result = test_CopyPage(boxbasepath, boxnumber, foldername, documentname,false); break;
        case 16: result = test_CutPage(boxbasepath, boxnumber, foldername, documentname,false); break;
        case 17: result = test_DeletePage(boxbasepath, boxnumber, foldername, documentname,false); break;
        case 18: result = test_CutPages(boxbasepath, boxnumber, foldername, documentname,false); break;
        case 19: result = test_CopyPages(boxbasepath, boxnumber, foldername, documentname,false); break;
        case 20: result = test_ReplacePages(boxbasepath, boxnumber, foldername, documentname); break;
        case 21: result = test_InsertDelete(boxbasepath, boxnumber, foldername, documentname); break;
        case 22: result = test_insBlankPage(boxbasepath, boxnumber, foldername, documentname); break;		
        case 23: result = test_CopyPage(boxbasepath, boxnumber, foldername, documentname,true); break;
        case 24: result = test_CutPage(boxbasepath, boxnumber, foldername, documentname,true); break;
        case 25: result = test_DeletePage(boxbasepath, boxnumber, foldername, documentname,true); break;
        case 26: result = test_CutPages(boxbasepath, boxnumber, foldername, documentname,true); break;
		  case 27: result = test_CopyPages(boxbasepath, boxnumber, foldername, documentname,true); break;
		  case 28: result = test_GetMap(boxbasepath, boxnumber, foldername, documentname); break;	  
		  case 29: result = test_GetSetPageCount(boxbasepath, boxnumber, foldername, documentname); break;	  	
		  case 30: result = test_GetWEPDocument(boxbasepath, boxnumber, foldername, documentname); break;	  	
		  case 31: result = test_Reserve(boxbasepath, boxnumber, foldername, documentname); break;
		  case 32: result = test_EndReserving(boxbasepath, boxnumber, foldername, documentname); break;
		  case 33: result = test_insBlankPage_loireAlabama(boxbasepath, boxnumber, foldername, documentname); break;
		  case 34: result = test_Progress(boxbasepath, boxnumber, foldername, documentname);
		  } 
        cout << "result = " << result << endl;
    }
    return true;
}
