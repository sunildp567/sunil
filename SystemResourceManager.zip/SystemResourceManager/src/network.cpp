// Copyright 2008 TOSHIBA TEC CORPORATION All rights reserved //

/* TODO: A class that implements Network QoS for System Resource Manager
 * 
 * Note: Not required for CP3 and features/kind of support in Linux Kernel may impact network part of SRM design
 */
#include <network.h>	


namespace ci
{
namespace systemresourcemanager
{
	Network::Network(ci::hierarchicaldb::HierarchicalDBRef mainHDBRef, dom::DocumentRef mainDomRef)
	{
	}
	
	Network::~Network()
	{
	}
	
	
} //SystemResourceManager
} //CI

