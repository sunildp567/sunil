/* (C) Copyright TOSHIBA Corporation 1996. All Rights Reserved
　TITLE:
	comPar.h　---　DPPCシステムF/W 共通ヘッダ（ジョブパラメータテーブル）
  OUTLINE:
	ジョブパラメータテーブルに関連した定義
　HISTORY:
	1.1　J.Nakayoshi　96/04/03　original
	1.2　J.Nakayoshi　96/05/07　共通テーブル管理LIB設計仕様反映
	1.3　J.Nakayoshi　96/06/01　自己診断モード追加
	1.4　J.Nakayoshi　96/06/20　自己診断モード変更
	1.5　J.Nakayoshi　96/07/10　Paper Source項目追加
　　	1.6　T.Takahashi　96/07/19　ジョブ種別追加
						　　原稿枚数無効追加
					　　イメージリピート、ダブルコピー追加
　　　　　　　　　　　　　　　　	画像オリエンテーション追加
　　　　　　　　　　　　　　　　	サイズ決定履歴追加
　　　　　　　　　　　　　　　　	ブック開始、終了頁追加
				　　スムージング追加
　　	1.7　T.Takahashi　96/08/28　ジョブ種別に自己診断抜けを修正
									メッセージ送出関数の返り値１種(OK/NO_PROCESS/ERROR）
									フェイスアップ／ダウン追加
　　	1.8　T.Takahashi　96/09/09　ジョブ種別に自己診断各モードを追加
									サイズ決定履歴にCOM_MF_BY_APSを追加
									自己診断モード一部修正
　　	1.9　T.Takahashi　96/09/10　機能種別追加
		2.0  T.Takahashi  96/09/19	原稿入力方法（ＡＤＦ／手置き）
									画像回転角（０、９０、１８０、２７０）
		2.1  T.Takahashi  96/11/08	COM_PS_AUTOを追加
　　　　　　　　　　　　　　　　	COM_PS_XXの値をＭと合うように変更
　　　　　　　　　　　　　　　　	COM_OT_LETTER　0->2　に値変更
　　　　　　　　　　　　　　　		COM_OT_STANDARD　2->0　に値変更
　　　　　　　　　　　　　　　　	COM_PE_ADU値Ｍと合わせ　16　に変更
　　　　　　　　　　　　　　　　	COM_PE_STRAIGHT（ストレート排紙）を追加
				　　COM_PE_FINISHER（フィニッシャ排紙）を追加
		2.2  T.Takahashi  96/11/12	COM_PS_SHEETを追加
　　　　　　　　　　　　　　　　COM_PS_XXの値を元に戻す
		2.3  T.Takahashi  96/11/18	COM_LB_RECV_FAX スペルミス修正 -> COM_JB_RECV_FAX
		2.4  T.Takahashi  96/11/29	COM_JB_SEND_DSI
									COM_JB_RECV_DSI
									COM_JB_PRIVATE_DSI
									COM_JS_PRT_WAITINGを追加
		2.5  T.Takahashi  96/12/06	ジョブ種別を基本と拡張に分割（シンボル名分割）
										COM_JB_EXPPC1
										COM_JB_EXPPC2
									COM_JB_POLL_SEND_FAX2
						COM_JB_POLL_RECV_FAX1
									COM_JB_POLL_RECV_FAX2
									COM_JB_PRT_GDI1
									COM_JB_PRT_GDI2
					以下のシンボル削除
									COM_JB_RECV_GDI  ---> COM_JB_PRT_GDI1,2
		2.6  T.Takahashi  96/12/26	ジョブ種別値変更（上位１バイトへシフト）
									（注）自己診断モード値はそのまま
					COM_JB_IPPC 		1--->0x0100
					COM_JB_BPPC 		2--->0x0200
					COM_JB_EXPPC1		3--->0x0300
					COM_JB_EXPPC2		4--->0x0400
										COM_JB_SCN_FAX1 	5--->0x0500
					COM_JB_SCN_FAX2 	6--->0x0600
					COM_JB_DRC_SCN_FAX	7--->0x0700
					COM_JB_RECV_FAX 		8--->0x0800
					COM_JB_PRT_FAX1 	9--->0x0900
					COM_JB_PRT_FAX2 	10-->0x0a00
					COM_JB_POLL_SEND_FAX1	11-->0x0b00
					COM_JB_POLL_SEND_FAX2	12-->0x0c00
					COM_JB_POLL_RECV_FAX1	13-->0x0d00
					COM_JB_POLL_RECV_FAX2	14-->0x0e00
					COM_JB_DRC_PRT_FAX		15-->0x0f00
					COM_JB_LIST_PRT_FAX 16-->0x1000
					COM_JB_LIST_SEND_FAX	17-->0x1100
					COM_JB_PRT_GDI1 	18-->0x1200
					COM_JB_PRT_GDI2 	19-->0x1300
					COM_JB_PRT_GDI		20-->0x1400
					COM_JB_DRC_PRT_GDI	21-->0x1500
					COM_JB_DIG		22-->0x1600
					COM_JB_IVSAVE_PPC	23-->0x1700
					COM_JB_IVPRM_PPC	24-->0x1800
					COM_JB_IVSAVE_FAX	25-->0x1900
					COM_JB_IVPRM_FAX	26-->0x1a00
					COM_JB_JOB_UI			27-->0x1b00
					COM_JB_SEND_DSI 		28-->0x1c00
					COM_JB_RECV_DSI 		29-->0x1d00
					COM_JB_PRIVATE_DSI		30-->0x1e00
					COM_JB_UNDEF			31-->0x1f00
		2.7  T.Takahashi  97/01/28	フィニッシャ関係シンボル追加
					ステイプルモード
					#define COM_STPL_NONE	0
					#define COM_STPL_1	1
					#define COM_STPL_2	2
					#define COM_STPL_3	3
					#define COM_STPL_TEST	4
					電子ソートモード
					#define COM_ST_NOSORT	  0
					#define COM_ST_SORT   1
					#define COM_ST_GROUP	  2
					#define COM_ST_STPL   3
					#define COM_ST_JOG	 16
					#define COM_ST_JOG_SORT  17
					#define COM_ST_JOG_GROUP 18
					排紙先ビン
					#define COM_BIN_NONE	0
					#define COM_BIN_1	1
					#define COM_BIN_2	2
					#define COM_BIN_3	3
					ステイプル要求
					#define COM_STPL_ON 1
					#define COM_STPL_OFF	0
		2.8  T.Takahashi  97/04/08	自己診断関係シンボル追加
					#define COM_MODE_EASYSETUP 0x0D
		2.9  T.Takahashi  97/04/16	シンボル追加
					#define COM_SM_NEUTRAL	2
					#define COM_PS_TO_ADU  12
					#define COM_PS_ADU_UNSED 13
		2.10 T.Fujii	  97/07/02	シンボル追加
		2.11 A.Watanabe   97/09/13	シンボル追加
					#define COM_BIN_UNDEF	0
		2.12 T.Takahashi  98/01/07	シンボル追加
					#define COM_ACC_NONE	0
					#define COM_ACC_NORMAL	1
					#define COM_ACC_EXETEND 2

		5.00 ksuzuki	  98/07/06	シンボル追加
　　　　　　　　　　　　COM_JS_SUSPEND_SCAN_END  11
		5.01 ksuzuki	  98/07/08	シンボル追加
						COM_SIZE_MIXED 0
						COM_SIZE_SAME　1
		5.02 ksuzuki	  98/07/14	シンボル追加
						COM_STPL_SADDLESTITCH
		5.03 ksuzuki	  98/07/15	シンボル変更/追加
						COM_PE_ADU 16->15  Ｍとのステータス合わせ
						COM_PE_FINISHERBIN 6
		5.04 ksuzuki	  98/08/12	シンボル追加
						COM_STPL_SADDLETEST 6
						COM_BIN_SADDLETRAY	5
		5.05 ksuzuki	  98/09/24	表紙/シート挿入関連シンボル変更/追加
		5.06 ksuzuki	98/10/21　タイマー系、フォームストレージ系シンボル追加
　　　　　　　　　　　　COM_PW_DEFAULT、COM_PW_PREHEAT、COM_PW_AUTOPOWEROFF
　　　　　　　　　　　　COM_PW_WEEKLYTIMER
　　　　　　　　　　　　COM_FS_ID_MAX_NUM
		5.07 ksuzuki	ユニットリプレース（[６]＋[コピー]）,リスト出力
　　　　　　　　　　　　モード　（[９]＋[コピー]）定義追加
		5.08 ksuzuki	98/11/16  COM_AC_ID_MAX_NUM (ID登録最大数)
		5.09 ksuzuki	99/09/09  COM_JB_SCN_TNDM_CPY,COM_JB_PRT_TNDM_CPY追加
								  COM_TNDM_DISABLE	0,
								  COM_TNDM_ENABLE	1,
								  COM_TNDM_MASTER	2,
								  COM_TNDM_SLAVE	3
	---DM---
	6.00 k.kakuda	99/11/04  出力タイミング　シンボル追加
				  COM_OT_TRK_SCS	  5
				  COM_OT_TRK_FIN	  6
				  サブジョブ種別定義　シンボル追加
				  COM_JB_SUB_INPUT	  0x01
				  COM_JB_SUB_OUTPUT   0x02
				  ＳＥＩＮＥで使用されているジョブ種別
				　（Ｆコード対応）　シンボル追加
				  COM_JB_CON_REG_FAX2 0x2100
				  COM_JB_CON_GET_FAX2 0x2300
				  COM_JB_BOD_REG_FAX2 0x2500
				  COM_JB_BOD_GET_FAX2 0x2700
	6.01 k.kakuda	99/11/25  サブジョブ種別定義　シンボル追加
				  COM_JB_SUB_UNDEF	  -1
	6.02 k.kakuda	99/11/29  ステイプル要求定義　シンボル追加
				  COM_STPL_EXIT　　　2
	6.03 k.kakuda	99/12/21  ジョブ状態　シンボル追加
				　COM_JS_STOP_PRT
				　印刷状態　シンボル追加
				　COM_PRST_READY
				　COM_PRST_PRINTING
				　COM_PRST_SUSPEND
				　COM_PRST_WARMINGUP
	6.04 k.kakuda 2000/02/04  画像方向 シンボル追加
				  COM_IO_AUTO 2 自動
		6.05 k.kakuda 2000/02/08  縮小率　シンボル追加
								  MMRLib関連シンボル追加
		6.06 k.kakuda 2000/03/14  FAX関連シンボル追加
	6.07 k.kakuda 2000/04/11  特殊紙モードシンボル追加
				  COM_PT_NORMAL 0
				  COM_PT_THICK	1
				  COM_PT_OHP	2
	6.08 k.kakuda 2000/04/25  用紙残量シンボル追加
	6.09 k.kakuda 2000/05/12  主走査方向縮小率、副操作方向縮小率
				　シンボル追加／及び変更
	6.10 k.kakuda 2000/05/12  スキャナ・プリンタ状態シンボル追加
	6.11 k.kakuda 2000/05/15  パワーオフ要因シンボル追加
	6.12 k.kakuda 2000/05/25  FAX中継送信、FAX中継結果返送のシンボル
				　定義重複を修正、PC-FAXのジョブ種別追加
	6.13 k.kakuda 2000/05/29  MFP表紙／シートの片面指定、白紙指定用
				　シンボル追加
	6.14 k.kakuda 2000/06/06  部門管理関連のシンボル追加
	6.15 k.kakuda 2000/06/15  ＮＶＭカセット位置情報設定用シンボル追加
	6.16 k.kakuda 2000/10/03  縮小率追加
	---Mckinley---
	7.00 ohta(Do) 2002/06/17  Mckinleyカラー情報等のシンボル追加
	7.01 Kittaka  2002/06/21  Mckinleyワンタッチ調整パラメータ追加
	7.02 (RX)Takanashi 2002/06/26 Mckinley pmFifoRead()等のカラー情報追加
	7.03 ohta(Do) 2002/07/18  Mckinley特殊紙モードとカラー関連シンボル追加
	7.04 msei	  2002/07/18  カウンタ種別（部門管理関連）追加
	7.05 ohta(Do) 2002/08/20  タブ紙のシンボル追加
	7.06 ohta(Do) 2002/09/06  タブ紙の最大挿入枚数追加
	7.07 ohta(Do) 2002/09/10  カラー情報シンボル追加
	7.08 msei	  2002/09/20  トナー系シンボル追加
	7.09 ohta(Do) 2002/10/22  圧縮方式のシンボル追加
	7.10 ohta(Do) 2002/10/30  ２色カラー情報等のシンボル追加
	7.11 ohta(Do) 2002/10/30  parMN新規関数追加によりシンボル追加
	7.12 ohta(Do) 2002/12/25  ベージ記述言語に設定無しを追加
	7.13 ohta(Do) 2003/01/20  PRT4分割スムージング/トナーセーブ切り替えシンボル追加
	7.14 ogata	  2003/02/18  リボルバー回転シンボル追加
	7.15 ohta(Do) 2003/02/20  用紙種別のシンボル値を変更
	7.16 K.Yamada 2003/03/07  立ち上げクリアシンボル追加
	7.17 msei	  2003/03/24  部門管理関連のシンボル値変更
	7.18 ohta(Do) 2003/03/25  用紙種別のシンボル値コメント変更
	7.19 ohta(Do) 2003/04/07  スローモードのシンボル追加
	7.20 ohta(Do) 2003/04/26  ＭＦＰモードのシンボル追加
	7.21 ohta(Do) 2003/06/02  ワンタッチ種別のシンボル追加
	7.22 ohta(Do) 2003/06/04  胴内オフセット排紙のシンボル追加
	7.23 Sadakuni 2003/06/13  Box印刷シート挿入のシンボル追加
	7.24 ohta(Do) 2003/06/17  バックグラウンド時手差し継続のシンボル追加
	7.25 ohta(Do) 2003/07/31  キャリブレーション有無のシンボル追加

	【Rhone】
		ROM29	@29.00	Sato(Sky)	2004/02/23 用紙サイズ 封筒シンボル追加

	【RioGrande】
		RI000		N.Sato(Sky) 2004/06/17 オプションLCF　シンボル追加
		RI001		Fujita(Sky) 2004/06/21 ボトルエンプティ　シンボル追加
		RI002		N.Sato(Sky) 2004/08/06 インサータ対応
		RI003		Y.Yamada(TJ)2004/08/17 タブ＆インサータ対応　シンボル追加
		RI004		N.Sato(Sky) 2004/09/17 シート、タブ、インサータ 最大枚数変更(15->50)
		RI005		N.Sato(Sky) 2004/09/29 オプションLCF、インサータ　シンボル値の変更(RioGrandeのみ)
		RI006		N.Sato(Sky) 2004/10/01 McKinley オプションLCF　シンボル削除
		RI007		N.Sato(Sky) 2004/10/01 コンパイルオプションの変更
		RI008		N.Sato(Sky) 2004/10/02 オプションLCF　シンボル追加
		RI009		N.Sato(Sky) 2004/10/15 上下綴じ代 シンボルの追加
		--- β4 ---
		RI010		N.Sato(Sky) 2004/11/02 hTruecstの配列数 シンボルの追加
		RI011		C.Hara(Sky) 2004/11/09 起動モード追加([2]+[8] 製造開始モード)
		RI012		Fujita(Sky) 2004/11/17 タブ紙　シンボル追加
		--- β4.5 ---
		RI013		N.Sato(Sky) 2004/11/22 給紙情報　シンボル追加
		RI014		Fujita(Sky) 2004/11/29 ユーザ定義　両面カウンタ　シンボル追加

	【Denali】
		DN000		N.Sato(Sky) 2004/12/07 RioGrandeとの共有化
		DN001		N.Sato(Sky) 2005/04/06 コンパイルオプションの変更

	【K2】
		KK000	2005/09/28 	(Sky)N.Sato	  Item?   カラーバランス
		KK001	2005/09/28 	(Sky)N.Sato	  Item?   色相/彩度
		KK002	2005/09/28 	(Sky)N.Sato	  Item?   モノカラー
		KK003	2005/09/28 	(Sky)N.Sato	  Item?   リピート
		KK004	2005/09/28 	(Sky)N.Sato	  Item?   蛍光ペン
		KK007	2005/10/13	(Sky)N.Sato   Item88  用紙種別全12種類
		KK008	2005/10/13	(Sky)N.Sato   Item122 COPYサムネイル
		KK009	2005/10/13	(Sky)N.Sato   Item?   画質タイプ
		KK010	2005/10/13	(Sky)N.Sato   Item?   符号化方式
		KK014	2005/11/07	(Sky)N.Sato   Item?	  カラー情報、プレーン情報のシンボル追加
		KK015	2005/11/24	(Sky)K.Fujita Item?	  トナー残量 シンボル追加
		KK019	2005/11/28	(Sky)N.Sato   Item54  カウンタ改善
		KK019	2005/11/29	(Sky)K.Fujita Item54  カウンタ改善
		KK020	2005/12/02	(Sky)N.Sato   Item?   カラー情報 FAXデータ(BOX印刷) のシンボル追加
		KK019	2005/12/08	(Sky)N.Sato   Item54  カウンタ改善(シンボル名誤り)
		KK021	2005/12/20	(TIS)Fushimi  Item?   カラーモード（EJCMパラメータ用）追加
		KK022	2005/12/26	(Sky)N.Sato   Item?	  カラー情報のシンボル追加						VTK08.100
		KK023	2006/01/11	(Sky)N.Sato   Item?	  EFI PRINT対応									VTK09.000

	--- K2 RC ---
		KK024	2006/07/25	(Sky)N.Sato   		  2色カラー 白色シンボル追加					VTK19.000

	--- K2 V3.1 ---
		KK025	2006/11/14	(Sky)N.Sato   		  K2 メディアアップ (SRA3、厚紙4)				VTK31.000
		KK026	2006/11/20	(Sky)N.Sato   		  長尺対応										VTK31.000

---------------------------------------------------------------------------------------
	V2.3 (RioGrande、Denali、HudsonⅡ、RhoneⅡ)
---------------------------------------------------------------------------------------
		--- VTR26.100 ---
		RI015	2006/07/03	(Sky)N.Sato  カラーモード K2 と V2.3機種を分岐

---------------------------------------------------------------------------------------
	V3.0 (RioGrande、Denali、HudsonⅡ、RhoneⅡ)
---------------------------------------------------------------------------------------
		--- VTR33.000 ---
		RI016	2006/09/28	(Sky)N.Sato  画像合成モードのシンボル追加

	【BP、Mash】

		--- VTM00.001 ---
		BP000	2007/07/03	(Sky)N.Sato  コンパイルオプションの変更
		BP001	2006/06/28	(Sky)N.Sato  メディアアップ (普通紙1・2)
		BP007	2006/07/09	(Sky)N.Sato  コピーJPEG対応
		BP008	2006/07/06	(Sky)N.Sato  アライメントの位置
		BP010	2007/07/10	(Sky)N.Sato  合成情報設定/取得関数
		BP013	2007/07/10	(Sky)N.Sato  編集処理モード設定/取得関数
		BP014	2007/07/10	(Sky)N.Sato  ベージ記述言語設定/取得関数 パラメータシンボルの追加
		BP015	2007/07/10	(Sky)N.Sato  画質タイプ設定/取得関数 パラメータシンボルの追加
		BP016	2007/07/12	(Sky)N.Sato  BP 排紙先ビン Side Exit Tray を追加

		--- VTM01.001 ---
		BP020	2007/07/25	(Sky)N.Sato  アライメント対応

		--- VTx01.080 ---
		BP043	2007/09/21	(Sky)N.Sato  アライメントなし シンボルの追加

		--- VTx01.090 ---
		BP055	2007/10/02	(Sky)E.Sonoda	タンデムLCF用紙残量左右トレイ別途表示対応
											COM_PS_LCC_LEFT追加、現状使用はマシン管理のみ。
		--- VTx01.0A0 ---
		BP058	2007/10/11	(Sky)N.kawasaki	白紙検知の設定情報設定/取得の為の閾値シンボル設定
		BP063	2007/10/15  (Sky)N.kawasaki イメージオーバーレイ対応
		BP061   2007/10/17  (Sky)N.kawasaki サイドトレイ排紙位置のパラメタ追加

		--- VTx01.0B0 ---
		BP065	2007/10/19	(Sky)N.kawasaki 画像パラメタシンボル追加/削除対応(eB3)
		
		--- VTx02.010 ---
		BP069	2007/11/01  (Sky)N.kawasaki OmitBlankPageシンボル追加
		
		--- VTx06.050 ---
		BP097	2008/04/03  (RX)Y.Takanashi 4Plane同時伸張用のシンボル追加
		
		--- VTx08.050 ---
		BP102   2008/07/08  (Sky)n.kawasaki SubJobKind(HI型)設定取得関数用シンボル追加(eB3_SYS)
		BP104   2008/07/16  (Sky)n.kawasaki 国内ソリューション向けシンボル追加（３つ、prnからの要望）

	【Loire/FM-Rio】
		FM005	2008/08/06	(Sky)N.kawasaki 薄紙のシンボル追加(共通SRC向けに追加)

*/
#ifndef __INCcomParh
#define __INCcomParh

/*	(Func Type) */
/*　機能種別　*/
#define COM_PPC 						1		/*	複写								*/
#define COM_FAX 						2		/*	ＦＡＸ								*/
#define COM_GDI 						3		/*	ＧＤＩ								*/
#define COM_DSI 						4		/*	ＤＳＩ								*/

/*	(Job Type) */
/*　ジョブ種別　*/
#define COM_JB_IPPC 				0x0100		/*	割り込み基本複写					*/
#define COM_JB_BPPC 				0x0200		/*	基本複写							*/
#define COM_JB_EXPPC1				0x0300		/*	拡張複写（基本）					*/
#define COM_JB_EXPPC2				0x0400		/*	拡張複写（拡張）					*/
#define COM_JB_SCN_FAX1 			0x0500		/*	FAX蓄積送信（基本） 				*/
#define COM_JB_SCN_FAX2 			0x0600		/*	FAX蓄積送信（拡張） 				*/
#define COM_JB_DRC_SCN_FAX			0x0700		/*	FAXダイレクト送信					*/
#define COM_JB_RECV_FAX 			0x0800		/*	FAX受信 (使用せず)					*/
#define COM_JB_PRT_FAX1 			0x0900		/*	FAX受信印刷（基本） 				*/
#define COM_JB_PRT_FAX2 			0x0a00		/*	FAX受信印刷（拡張） 				*/
#define COM_JB_POLL_SEND_FAX1		0x0b00		/*	FAXポーリング送信（基本）			*/
#define COM_JB_POLL_SEND_FAX2		0x0c00		/*	FAXポーリング送信（拡張）			*/
#define COM_JB_POLL_RECV_FAX1		0x0d00		/*	FAXポーリング受信（基本）			*/
#define COM_JB_POLL_RECV_FAX2		0x0e00		/*	FAXポーリング受信（拡張）			*/
#define COM_JB_DRC_PRT_FAX			0x0f00		/*	FAXメモリフル逐次および受信並行印刷 */
#define COM_JB_LIST_PRT_FAX 		0x1000		/*	FAXリストレポート印刷				*/
#define COM_JB_LIST_SEND_FAX		0x1100		/*	FAXリストレポート送信				*/
#define COM_JB_PRT_GDI1 			0x1200		/*	GDI印刷（基本） 					*/
#define COM_JB_PRT_GDI2 			0x1300		/*	GDI印刷（拡張） 					*/
#define COM_JB_PRT_GDI				0x1400		/*	GDI印刷　（使用せず）				*/
#define COM_JB_DRC_PRT_GDI			0x1500		/*	ＧＤＩメモリフル逐次印刷（使用せず）*/
#define COM_JB_DIG					0x1600		/*	自己診断							*/
#define COM_JB_IVSAVE_PPC			0x1700		/*	複写フォーム登録					*/
#define COM_JB_IVPRM_PPC			0x1800		/*	複写フォーム印刷					*/
#define COM_JB_IVSAVE_FAX			0x1900		/*	FAXフォーム登録 					*/
#define COM_JB_IVPRM_FAX			0x1a00		/*	FAXフォーム印刷 					*/
#define COM_JB_JOB_UI				0x1b00		/*	ジョブ操作UI						*/
#define COM_JB_SEND_DSI 			0x1c00		/*	ＤＳＳ原稿入力と送信				*/
#define COM_JB_RECV_DSI 			0x1d00		/*	ＤＳＳ受信と印刷					*/
#define COM_JB_PRIVATE_DSI			0x1e00		/*	ＤＳＳプライベイト印刷				*/
#define COM_JB_UNDEF				0x1f00		/*	未定義								*/

												/* k.kakuda 2000/03/14					*/
#define COM_JB_CON_REG_FAX1 		0x2000		/* FAX親展登録（基本）					*/
#define COM_JB_CON_GET_FAX1 		0x2200		/* FAX親展取り出し（基本）				*/
#define COM_JB_BOD_REG_FAX1 		0x2400		/* FAX掲示板登録（基本）				*/
#define COM_JB_BOD_GET_FAX1 		0x2600		/* FAX掲示板取り出し（基本）			*/
												/* k.kakuda 2000/03/14					*/

/* F コード対応(SEINEからの移植) ジョブ種別 追加 k.kakuda 1999/11/4 Start				*/
#define COM_JB_CON_REG_FAX2 		0x2100		/* FAX親展登録（拡張）					*/
#define COM_JB_CON_GET_FAX2 		0x2300		/* FAX親展取り出し（拡張）				*/
#define COM_JB_BOD_REG_FAX2 		0x2500		/* FAX掲示板登録（拡張）				*/
#define COM_JB_BOD_GET_FAX2 		0x2700		/* FAX掲示板取り出し（拡張）			*/
												/* k.kakuda 1999/11/04 Add End			*/

												/* k.kakda 2000-03-14					*/
#define COM_JB_RELAY				0x2800		/* ＦＡＸ中継（箱のみ） 				*/
#define COM_JB_RELAY_RECV			0x2900		/* ＦＡＸ中継受信						*/

#if 1											/* 2000-5-23 add k.kakuda				*/
#define COM_JB_RELAY_SEND			0x2e00		/* ＦＡＸ中継送信						*/
#define COM_JB_LIST_RESULT_SEND		0x2f00		/* ＦＡＸ中継結果返送					*/
#else											/* 2000-5-23 add end k.kakuda			*/
//	#define COM_JB_RELAY_SEND			0x2a00	/* ＦＡＸ中継送信						*/
//	#define COM_JB_LIST_RESULT_SEND 	0x2b00	/* ＦＡＸ中継結果返送					*/
#endif
												/* k.kakuda 2000-03-14					*/

#if 1											/* 980925 ksuzuki						*/
#define COM_JB_RECV_DSI_SYNC		0x2a00		/*	ＤＳＳ受信と印刷(逐次)				*/
#define COM_JB_PRIVATE_DSI_SYNC		0x2b00		/*	ＤＳＳプライベイト印刷(逐次)		*/
#else											/* 980925 ksuzuki						*/
// #if 1  /* 980812 ksuzuki */
// #define COM_JB_RECV_DSI_SYNC    0x1d80		/*	ＤＳＳ受信と印刷(逐次)				*/
// #define COM_JB_PRIVATE_DSI_SYNC 0x1e80		/*	ＤＳＳプライベイト印刷(逐次)		*/
// #endif /* 980812 ksuzuki */
#endif											/* 980925 ksuzuki						*/

#if 1											/* 990909 ksuzuki						*/
#define COM_JB_SCN_TNDM_CPY 		0x2c00		/*	タンデムコピー（入力）				*/
#define COM_JB_PRT_TNDM_CPY 		0x2d00		/*	タンデムコピー（印刷）				*/
#endif											/* 990909 ksuzuki						*/

												/* 2000.5.23 k.kakuda add				*/
#define COM_JB_SEND_PCFAX			0x3000		/*	ＰＣ－ＦＡＸ						*/
												/* 2000.5.23 k.kakuda add end			*/

#if 1
/********************************************************************************
 *  国内ソリューション対応：出力パターン区別用サブジョブ種別の定数定義          *
 ********************************************************************************/
#define COM_SJK_LIST_ADDRESS             1      /* アドレス帳リスト                             */
#define COM_SJK_LIST_GROUP               2      /* グループ登録リスト                           */
#define COM_SJK_LIST_MLBOX_RPT           3      /* Fコードメイルボックスリスト                  */
#define COM_SJK_LIST_RESERVATION         4      /* 予約リスト                                   */
#define COM_SJK_LIST_FUNCTION            5      /* システム設定リスト                           */
#define COM_SJK_LIST_DEPARTMENT          6      /* 部門管理リスト                               */
#define COM_SJK_LIST_SELFTEST            7      /* セルフテストリスト                           */
#define COM_SJK_LIST_TX_JNL              8      /* 送信管理記録(手動)                           */
#define COM_SJK_LIST_RX_JNL              9      /* 受信管理記録(手動)                           */
#define COM_SJK_LIST_TX_RPT             10      /* 送信結果表(手動)                             */
#define COM_SJK_LIST_TX_DOC_RPT         11      /* 原稿送信結果表                               */
#define COM_SJK_LIST_TX_MEM_RPT         12      /* メモリ送信結果表(画付き/画無し)              */
#define COM_SJK_LIST_MULTI_RPT          13      /* 同報送信結果表(画付き/画無し)                */
#define COM_SJK_LIST_POL_RPT            14      /* ポーリング結果表                             */
#define COM_SJK_LIST_ML_RCPT_RPT        15      /* Fコードメイルボックス受付表                  */
#define COM_SJK_LIST_FILE_RCPT_RPT      16      /* ファイル化受付表                             */
#define COM_SJK_LIST_BOX_RCPT_RPT       17      /* BOX入力受付表                                */
#define COM_SJK_LIST_RLY_ORG_RPT        18      /* 中継親局結果表(画付き/画無し)                */
#define COM_SJK_LIST_RLY_RLY_RPT        19      /* 中継子局結果表(画付き/画無し)                */
#define COM_SJK_LIST_RLY_END_RPT        20      /* 中継孫局結果表(画付き/画無し)                */
#define COM_SJK_LIST_RLY_RPT            21      /* Fコード中継受付表                            */
#define COM_SJK_LIST_PROTOCOL1          22      /* プロトコルトレースリスト(回線1)              */
#define COM_SJK_LIST_PROTOCOL2          23      /* プロトコルトレースリスト(回線2)              */
#define COM_SJK_LIST_ERROR1             24      /* エラー集計リスト(回線1)                      */
#define COM_SJK_LIST_ERROR2             25      /* エラー集計リスト(回線2)                      */
#define COM_SJK_LIST_ERROR_IFAX         26      /* エラー集計リスト(Ifax)                       */
#define COM_SJK_LIST_ERROR_SCAN         27      /* エラー集計リスト(Scan)                       */
#define COM_SJK_LIST_FUNC_MNT           28      /* ファンクションリスト                         */
#define COM_SJK_LIST_DUMP_SYS           29      /* メモリーダンプリスト(システムボード)         */
#define COM_SJK_LIST_DUMP_FBRD          30      /* メモリーダンプリスト(Faxボード)              */
#define COM_SJK_LIST_DUMP_NIC           31      /* メモリーダンプリスト(NICボード)              */
#define COM_SJK_LIST_SUPPLY             32      /* オードサプライズオーダーリスト(自動/手動)    */
#define COM_SJK_LIST_DEAR               33      /* ディアカスタマーリスト                       */
#define COM_SJK_LIST_DEMO               34      /* デモンストレーションページ                   */
#define COM_SJK_LIST_PWR_FAIL           35      /* 停電発生リスト                               */
#define COM_SJK_LIST_05MODE             36      /* 05調整モードリスト(店舗/保守)                */
#define COM_SJK_LIST_08MODE             37      /* 08設定モードリスト(店舗/保守)                */
#define COM_SJK_LIST_PCLFNT             38      /* PCLフォントリスト                            */
#define COM_SJK_LIST_PSFNT              39      /* PSフォントリスト                             */
#define COM_SJK_LIST_NICSTS             40      /* NICステータスリスト                          */
#define COM_SJK_LIST_ERRHIS             41      /* ERROR HISTROY                                */
#define COM_SJK_LIST_PMSPCD             42      /* ＰＭサポートコードリスト                     */
#define COM_SJK_LIST_PTONEREMP          43      /* 画素カウンタ(トナーエンプティ)               */
#define COM_SJK_LIST_PSERVICE           44      /* 画素カウンタ(サービスマン)                   */
#define COM_SJK_LIST_CALI_PCL600        45      /* キャリブレーション（ＰＣＬ６００）           */
#define COM_SJK_LIST_CALI_PCL1200       46      /* キャリブレーション（ＰＣＬ１２００）         */
#define COM_SJK_LIST_CALI_PS600         47      /* キャリブレーション（ＰＳ６００）             */
#define COM_SJK_LIST_CALI_PS1200        48      /* キャリブレーション（ＰＳ１２００）           */
#define COM_SJK_LIST_CALI_PS600_CRM     49      /* キャリブレーション（ＰＳ６００）Confirm      */
#define COM_SJK_LIST_CALI_PS1200_CRM    50      /* キャリブレーション（ＰＳ１２００）Confirm    */
#define COM_SJK_LIST_TX_JNLAUTO         51      /* 送信管理記録(自動)                           */
#define COM_SJK_LIST_RX_JNLAUTO         52      /* 受信管理記録(自動)                           */
#define COM_SJK_LIST_TOTALCOUNT         53      /* トータルカウンタリスト                       */
#define COM_SJK_LIST_COUNT_TX           54      /* カウンタ送信リスト                           */
#define COM_SJK_LIST_VERSION            55      /* バージョンリスト                             */
#define COM_SJK_LIST_SSCAN_ADJUST       56      /* KCMY副走査位置調整テストパターン印刷(調整用) */
#define COM_SJK_LIST_SSCAN_COMFIRM      57      /* KCMY副走査位置調整テストパターン印刷(確認用) */
#define COM_SJK_LIST_KSFNT              58      /* KSフォントリスト                             */
#define COM_SJK_LIST_SSCAN_ADJUST2      59      /* KCMY副走査位置調整テストパターン印刷(調整用) */
#define COM_SJK_LIST_TONER_HISTORY      60      /* トナー履歴リスト                             */
#define COM_SJK_LIST_MACHINE_SETTING    61      /* マシン設置履歴情報ログリスト                 */
#define COM_SJK_LIST_LIFE_COUNTER_CLEAR 62      /* ライフカウンタログリスト                     */
#define COM_SJK_LIST_POWER_OFF_ON       63      /* 電源OFF/ONログリスト                         */
#define COM_SJK_LIST_JAM_HISTORY        64      /* ジャム履歴リスト                             */
#define COM_SJK_LIST_EFITRC_PRINT1      65      /* EFITRC印刷パターン１                         */
#define COM_SJK_LIST_EFITRC_PRINT2      66      /* EFITRC印刷パターン２                         */
#define COM_SJK_LIST_EFITRC_PRINT3      67      /* EFITRC印刷パターン３                         */
#define COM_SJK_LIST_EFITRC_PRINT4      68      /* EFITRC印刷パターン４                         */
#define COM_SJK_PROOFCOPY               100     /* お試しコピー                                 */
#define COM_SJK_PROOFPRINT              101     /* お試し印刷                                   */
#define COM_SJK_OTHER                   0       /* その他(上記に該当しないものすべて)           */

#endif												/* ↑BP102 */

/* フォアグランド／バックグランド */
#define COM_JB_FOREGROND				0		/*	フォアグランドジョブ				*/
#define COM_JB_BACKGROND				1		/*	バックグランドジョブ				*/

												/* サブジョブ種別追加 k.kakuda 1999.11.04 */
/* (sub job type) */
/* サブジョブ種別 */
#define COM_JB_SUB_INPUT			0x01		/*	入力ジョブ							*/
#define COM_JB_SUB_OUTPUT			0x02		/*	出力ジョブ							*/
												/* k.kakuda 1999.11.4 Add End			*/

												/* k.kakuda 1999.11.25					*/
#define COM_JB_SUB_UNDEF				-1		/* サブジョブ種別の削除（初期値）		*/
												/* k.kakuda 1999.11.25 Add END			*/

/*	(Job Route) */
/*　ジョブ経路　*/
#define COM_JR_CP						1		/*	原稿入力→印刷（基本複写）				*/
#define COM_JR_SCN_PM					2		/*	原稿入力→PM							*/
#define COM_JR_SCN_HD					3		/*	原稿入力→HDD							*/
#define COM_JR_MCP						4		/*	原稿入力→印刷（メモリ複写）			*/
#define COM_JR_SCN_FAX					5		/*	原稿入力→FAX送信（ダイレクト送信） 	*/
#define COM_JR_SCN_DSS					6		/*	原稿入力→DSS（ダイレクト） 			*/
#define COM_JR_FAX_PRT					7		/*	FAX受信→印刷							*/
#define COM_JR_FAX_HD					8		/*	FAX受信→HDD							*/
#define COM_JR_PM_PRT					9		/*	PM→印刷								*/
#define COM_JR_HD_PRT					10		/*	HDD→印刷								*/
#define COM_JR_DSS_PM					11		/*	DSS→PM 								*/
#define COM_JR_DSS_HD					12		/*	DSS→HDD								*/
#define COM_JR_PM_DSS					13		/*	PM→DSS 								*/
#define COM_JR_HD_DSS					14		/*	HDD→DSS								*/
#define COM_JR_DSS_PRT					15		/*	DSS→印刷（ダイレクト） 				*/
#define COM_JR_GDI_PM					16		/*	GDI→PM 								*/
#define COM_JR_GDI_HD					17		/*	GDI→HDD								*/
#define COM_JR_GDI_PRT					18		/*	GDI→印刷（ダイレクト） 				*/
#define COM_JR_GDI_FAX					19		/*	GDI→FAX送信（PC-FAX）					*/
#define COM_JR_PNL						20		/*	コンパネ確保							*/
#define COM_JR_SCN_FAXPM				21		/*	原稿入力→FAX PM						*/

/*	(Job Status) */
/*　ジョブ状態　 */
#define COM_JS_READY					1		/*	ジョブ未実施／定常						*/
#define COM_JS_OPERATING				2		/*	ジョブ操作中							*/
#define COM_JS_RUNNING					3		/*	ジョブ動作中							*/
#define COM_JS_RECVING					4		/*	受信中									*/
#define COM_JS_SCANNING 		COM_JB_RUNNING	/*	入力中									*/
#define COM_JS_SENDING					5		/*	送信中									*/
#define COM_JS_WAITING					6		/*	送信待ち								*/
#define COM_JS_PRT_WAITING				7		/*	印刷待ち								*/
#define COM_JS_PRINTING 				8		/*	印刷中									*/
#define COM_JS_PNL						9		/*	コンパネ確保中							*/
#define COM_JS_SUSPEND					10		/*	中断中（フォア／バックグランドともに）　*/
#if 1											/* 980706 ksuzuki							*/
#define COM_JS_SUSPEND_SCN_END			11		/* 手置き逐次複写時に使用					*/
												/* 次原稿ありなし画面表示中の印刷			*/
												/* 980708 SCAN->SCN 						*/
#endif											/* 980706 ksuzuki							*/
												/* @@@@ DM 1999.12.21 add k.kakuda @@@@		*/
#define COM_JS_STOP_PRT 				12		/*	印刷停止（カセットサイズ・属性設定中）	*/

/*	(Print Status) */
/*　印刷状態　　　 */
#define COM_PRST_READY					0		/* READY中									*/
#define COM_PRST_PRINTING				1		/* 印刷中									*/
#define COM_PRST_SUSPEND				2		/* 中断中（要因を参照） 					*/
#define COM_PRST_WARMINGUP				3		/* ウォームアップ中 						*/
												/* @@@@ add end k.kakuda @@@@@				*/

/*　インサータ状態　　　 */
#define COM_FST_READY					0		/* 未使用									*//* RI002 */
#define COM_FST_BUSY					1		/* 使用中									*//* RI002 */

/*	(VAlidity)						  */
/*　予熱　　　　　　　　　　　　　　　*/
/*　枠消し							　*/
/*　（秘）コピー					　*/
/*　原稿外消去						　*/
/*　ダブルコピー		  　削除	　*/
/*　置いたらコピー					　*/
/*　位置修正						　*/
/*　厚物原稿						　*/
/*　縦横交互仕分け					　*/
/*　ジョグ仕分け					　*/
/*　中折り綴じ						　*/
/*　自動両面						　*/
/*　ＡＤＦ複数回入力				　*/
/*　ページ連写						　*/
/*　メモリフル中の後詰め出力		　*/
/*　画像グラデーション				　*/
/*　背景グラデーション				　*/
/*　プリスキャン（原稿外領域矩形化）　*/
/*　プリスキャン（マーカ領域矩形化）　*/
/*	定型リピート　　　　　削除　　　  */
/*　原稿枚数無効　有効は枚数で　　　　*/
/*  白紙検知の情報設定/取得	BP058	  */
#define COM_VA_INVALID					0		/*	無効							*/
#define COM_VA_VALID					1		/*	有効							*/

/*	(DEnsity) */
/*　濃度調整　*/
#define COM_DE_AUTO 					0		/*	自動							*/
#define COM_DE_MANUAL					1		/*	手動							*/

#define	COM_UNKNOWN 				   -1		/* パラメタ設定：見つからなかった場合*/	/* ↓BP104 */
#define	COM_COMPLEX					   -2		/* パラメタ設定：超過した場合		*/	/* ↓BP104 */

/*	( DiRection )		*/
/*　日付の付加			*/
/*　時刻の付加			*/
/*　ページの付加		*/
/*	アノテーション印刷方向	990508 ksuzuki */
#define COM_OR_LONG 					1		/*　長手方向						*/
#define COM_OR_SHORT					0		/*　短手方向						*/


/*　センタリング方向　	*/
/*　コーナリング方向　	*/	/* (DO)s.Ohta 7.11 修正追加 */
#define COM_DR_NOTHING					0		/*	なし							*/
#define COM_DR_UP						1		/*	上／中央上						*/
#define COM_DR_TOP						1		/*	上中央 							*/
#define COM_DR_DOWN 					2		/*	下／中央下						*/
#define COM_DR_BOTTOM					2		/*	下中央 							*/
#define COM_DR_LEFT 					3		/*	左								*/
#define COM_DR_RIGHT					4		/*	右								*/
#define COM_DR_LEFT_UP					5		/*	左上							*/
#define COM_DR_RIGHT_UP 				6		/*	右上							*/
#define COM_DR_LEFT_DOWN				7		/*	左下							*/
#define COM_DR_RIGHT_DOWN				8		/*	右下							*/
#define COM_DR_UP_DOWN					9		/*	上下							*/
#define COM_DR_LEFT_RIGHT				10		/*	左右							*/
#define COM_DR_UDLR 					11		/*	上下左右						*/
#define COM_DR_BOTTOM_LEFT				12		/*	下辺左 							*/
#define COM_DR_BOTTOM_RIGHT 			13		/*	下辺右 							*/
#define COM_DR_TOP_LEFT 				14		/*	上辺左 							*/
#define COM_DR_TOP_RIGHT				15		/*	上辺右 							*/

/*	(Manual Fixed)		*/
/*　原稿サイズ確定履歴　*/
/*　用紙サイズ確定履歴　*/
#define COM_MF_UNFIXED					0		/*	未確定							*/
#define COM_MF_FIXED					1		/*	確定							*/
#define COM_MF_BYSIZE					2		/*	サイズキーにて確定				*/
#define COM_MF_BYCST					3		/*	カセットキーにて確定			*/
#define COM_MF_BYAPS					4		/*	ＡＰＳにて確定					*/

/*	(Original Type)   */
/*　文字／写真モード　*/
#define COM_OT_CUSTOM					6		/*	ユーザお好み設定				*/	  /* 7.21 s.ohta   2003/06/02 */
#define COM_OT_AI						5		/*	AIモード						*/	  /* 7.00 s.ohta   2002/06/17 */
#define COM_OT_MAP						4		/*	地図モード						*/	  /* 7.00 s.ohta   2002/06/17 */
#define COM_OT_HALFTONE 				3		/*	印刷／写真モード				*/	  /* 7.00 s.ohta   2002/06/17 */
#define COM_OT_LETTER					2		/*	文字モード						*/
#define COM_OT_PICTURE					1		/*	写真モード						*/
#define COM_OT_STANDARD 				0		/*	文字／写真モード				*/

/*	(Data Bit)		*/
/*　データビット数　*/
#define COM_DB_2						0		/*　２値							*/
#define COM_DB_4						1		/*　４値							*/

/*	(Paper Source)	  */
/*　給紙元　		  */
/*　表紙給紙元　	  */
/*　挿入シート給紙元　*/
#define COM_PS_SIDE 					0		/*　サイドカセット					*/
#define COM_PS_SFB						1		/*　手差し							*/
#define COM_PS_LCC						2		/*　ＬＣＣ							*/
#define COM_PS_PFD1 					3		/*　ペデスタル上段					*/
#define COM_PS_PFD2 					4		/*　ペデスタル中段					*/
#define COM_PS_PFD3 					5		/*　ペデスタル下段					*/
#define COM_PS_ADU						6		/*　ＡＤＵスタック					*/
#define COM_PS_COVER					7		/*　表紙用カセット					*/
#define COM_PS_UP						8		/*	本体カセット上					*/
#define COM_PS_DOWN 					9		/*	本体カセット下					*/

/*#if defined(MCK_ENG) || defined(HUD_ENG) || defined(RHO_ENG)	*/					/* RI007 */
/*#ifdef RIO_ENG	*/	   /* RioGrande 		   */								/* RI007 */
/*#if defined(RIO_ENG) || defined(DEN_ENG)		   */								/* DN000 *//* DN001 */
/*#ifdef eB2_SYS*/																	/* DN001 *//* BP000 */
#if 1
	#define COM_PS_OPLCC				10		/*	オプションＬＣＦ				*//* RI005 */
	#define COM_PS_INS					11		/*	インサータ						*//* RI005 */
	#define COM_PS_SHEET				12		/*	シートカセット					*//* RI005 */
	#define COM_PS_AUTO 				13		/*	自動							*//* RI005 */
	#define COM_PS_TO_ADU				14		/*	To ADU							*//* RI005 */
	#define COM_PS_ADU_UNUSED			15		/*	ADU is not used.				*//* RI005 */
#else																				/* RI005 */
	#define COM_PS_SHEET				10		/*	シートカセット 					*/
	#define COM_PS_AUTO 				11		/*	自動							*/
	#define COM_PS_TO_ADU				12		/*	To ADU							*/
	#define COM_PS_ADU_UNUSED			13		/*	ADU is not used.				*/
	#define COM_PS_OPLCC				14		/*	オプションＬＣＦ				*//* RI000 *//* RI008 */
	#define COM_PS_INS					15		/*	インサータ						*//* RI000 *//* RI008 */
#endif																				/* RI005 */

/*--------------------------------------------------*/
/*			T-LCF用紙残量左右別途表示対応			*/
/*			現状使用はマシン管理タスクのみ			*/
/*			用紙残量設定テーブルで使用				*/
/*--------------------------------------------------*/
#define COM_PS_LCC_LEFT					20		/*	T-LCF左トレイ					*//* BP055 */

/* 給紙 (部門(ユーザ)管理リミテーション対応)
*/
#define COM_FEED_NORMAL 				0		/* 通常給紙 						*//* RI013 */
#define COM_FEED_RETRY					1		/* リトライ給紙 					*//* RI013 */

/*	(Paper Exit)	*/
/*　排紙先　		*/
#define COM_PE_0						0		/*　使用せず   排紙トレイ（上）		*/
#define COM_PE_1						1		/*　使用せず   排紙トレイ（中）		*/
#define COM_PE_2						2		/*　使用せず   排紙トレイ（下）		*/
#if 1											/* 980715 ksuzuki Ｍとのステータス合わせのため */
   #define COM_PE_ADU					15		/*　ＡＤＵスタック					*/
#else
// #define COM_PE_ADU					16		/*　ＡＤＵスタック					*/
#endif											/* 980715 ksuzuki Ｍとのステータス合わせのため */
#define COM_PE_STRAIGHT 				0		/*　ストレート						*/
#define COM_PE_STRAIGHTBIN				1		/*　胴内オフセット排紙				*//* 7.22 ohta(Do) */
#if 1
#define COM_PE_SIDEEXIT					2		/* Side Exit Tray (BP)				*//* ↓BP061 */
#endif
#define COM_PE_FINISHER 				5		/*　フィニッシャ					*/
#if 1											/* 980715 ksuzuki					*/
#define COM_PE_FINISHERBIN 				6		/* フィニシャービンシフト			*/
#endif											/* 980715 ksuzuki					*/

/*	(Paper Bin)    */
/*　排紙先ビン　   */
												/* BP		  / Mash				*/
#define COM_BIN_NONE					0		/* Upper Tray / Inner Tray			*/
#define COM_BIN_1						1		/* Finisher Upper Tray				*/
#define COM_BIN_2						2		/* Finisher Lower Tray				*/
#define COM_BIN_3						3		/* 排紙ビン（下）					*//* 使われていない?	*/
#define COM_BIN_UNDEF					0		/* TRAY_UNDEF:未確定				*//* 使われていない?	*/
#if 1  																				/* 980812 ksuzuki  		*/
#define COM_BIN_SADDLETRAY				5		/* Saddle Tray						*/
#endif																				/* 980812 ksuzuki  		*/
#if 1		/* ↓BP016 */
#define COM_BIN_NONE2					6		/* Side Exit Tray (BP)				*/
#endif																				/* ↑BP016 */

/*	(aDF mode)	  */
/*　ＡＤＦモード　*/
#define COM_DF_CONT 					0		/*　連続送り						*/
#define COM_DF_ONE						1		/*　１枚送り						*/

/*	(InTerrupt mode) */
/*　割り込み　		 */
#define COM_IT_USUAL					0		/*　通常							*/
#define COM_IT_INRPT					1		/*　割り込み						*/

/*	(APs/ams mode)		  */
/*　ＡＰＳ／ＡＭＳモード　*/
/*　自動　*/
#define COM_AP_USUAL					0		/*　ＡＰＳ／ＡＭＳなし				*/
#define COM_AP_APS						1		/*　ＡＰＳモード、自動モード		*/
#define COM_AP_AMS						2		/*　ＡＭＳモード					*/

/*	(Bind Edge) */
/*　綴じしろ　	*/
#define COM_BE_NOEDGE					0		/* 綴じしろなし   					*/
#define COM_BE_RIGHT					1		/* 右綴じ		  					*/
#define COM_BE_LEFT 					2		/* 左綴じ		  					*/
#define COM_BE_BOOK 					3		/* ブック綴じ	  					*/
#define COM_BE_NOTHING					0		/* 貼り付け無し   					*/
#define COM_BE_TOP						4		/* 上綴じ		  					*/
#define COM_BE_BOTTOM					5		/* 下綴じ		  					*/

/* Amazon と同じシンボル */
#define COM_BE_UP						4		/* 上綴じ		  					*//* RI009 */
#define COM_BE_DOWN 					5		/* 下綴じ		  					*//* RI009 */


/*	(Bind Direction)  */
/*　綴じしろ方向　	  */
#define COM_BD_LONG 					0		/*　長手綴じ　						*/
#define COM_BD_SHORT					1		/*　短手綴じ　						*/
#define COM_BD_SIMPLEX					2		/*　単一　							*//* 7.11 s.ohta */
#define COM_BD_DUPLEX				    3		/*  両面					        *//* BP104 */


/*	(Book Open)   */
/*　本の開き情報　*/
/*　開始頁指定　*/
/*　終了頁指定　*/
#define COM_BO_RIGHT					0		/*　右開き　						*/
#define COM_BO_LEFT 					1		/*　左開き　						*/
#define COM_BO_HALFPG					1		/*　ハーフ（片頁）　				*/
#define COM_BO_FULLPG					0		/*　フル（両頁）　					*/


/*	(STaPLe mode)		*/
/*　ステイプルモード	*/
#define COM_STPL_NONE					0		/*　なし　							*/
#define COM_STPL_1						1		/*　機体から奥１箇所　				*/
#define COM_STPL_2						2		/*　２箇所　						*/
#define COM_STPL_3						3		/*　機体から手前１個所　			*/
#define COM_STPL_TEST					4		/*　テストステイプル　				*/
#if 1  																		/* 980714 ksuzuki */
#define COM_STPL_SADDLESTITCH			5		/*サドルステッチ 					*/
#endif																		/* 980714 ksuzuki */
#if 1  																		/* 980812 ksuzuki */
#define COM_STPL_SADDLETEST 			6	 	/* サドルテストステイプル 			*/
#endif 																		/* 980812 ksuzuki */


/*	(STaPLe ON/OFF) 		*/
/*　ステイプル要求　		*/
#define COM_STPL_ON 					1		/*　ステイプル要求あり　			*/
#define COM_STPL_OFF					0		/*　ステイプル要求なし　			*/
#define COM_STPL_EXIT					2		/* 束排出要求有り 					*/

/*	(SorT mode) 		  */
/*　排紙オプションモード　*/
/*　電子ソートモード　	  */
#define COM_ST_NOSORT					0		/*　ノンソート　					*/
#define COM_ST_SORT 					1		/*　ソート　						*/
#define COM_ST_GROUP					2		/*　グループ　						*/
#define COM_ST_STPL 					3		/*　ステイプル　					*/
#define COM_ST_JOG						16		/*　１枚シフト　					*/
#define COM_ST_JOG_SORT 				17		/*　１枚シフトソート　				*/
#define COM_ST_JOG_GROUP				18		/*　１枚シフトグループ　			*/


/*	(Both Sides mode) */
/*　両面モード　	  */
#define COM_BS_ONE_ONE					0		/*　片面→片面　					*/
#define COM_BS_ONE_BOTH 				1		/*　片面→両面　					*/
#define COM_BS_BOTH_BOTH				2		/*　両面→両面　					*/
#define COM_BS_BOTH_ONE 				3		/*　両面→片面　					*/
#define COM_BS_BOOK 					4		/*　ブック両面　					*/


/*	(SHeets)  */
/*　原稿枚数　*/
#define COM_SH_NOTHING					0		/*　無指定　						*/
#define COM_SH_EVEN 					1		/*　偶数　							*/
#define COM_SH_ODD						2		/*　奇数　							*/


/*	(SMoothing)  */
/*　スムージング　*/
#define COM_SZ_NOTHING					0		/*　無効　							*/
#define COM_SZ_LEVEL1					1		/*　レベル１　						*/
#define COM_SZ_LEVEL2					2		/*　レベル２　						*/
#define COM_SZ_LEVEL3					3		/*　レベル３　						*/


/*	(Print Direction ) */
/*　２ｉｎ１		 　*/
/*　４ｉｎ１　		   */
#define COM_PD_SIDE 					0		/*　横書き							*/
#define COM_PD_LENGTH					1		/*　縦書き							*/


/*	(Reduction - Connection ) */
/*　片面縮小連結　			  */
/*　両面縮小連結　			  */
#define COM_RC_NOTHING					0		/*　なし							*/
#define COM_RC_2IN1 					1		/*　2in1							*/
#define COM_RC_4IN1 					3		/*　4in1							*/
#define COM_RC_6IN1						6		/*	6in1							*//* KK019 */
#define COM_RC_8IN1						8		/*	8in1							*//* KK019 */
#define COM_RC_9IN1						9		/*	9in1							*//* KK019 */
#define COM_RC_16IN1				   16		/* 16in1							*//* KK019 */

/*	(ImageRepeat、DoubleCopy) */
/*　マルチリピート	 　 	  */
/*　イメージリピート		  */
/*　ダブルコピー　			  */
#define COM_IR_NOTHING					0		/*　なし							*/
#define COM_IR_2						1		/*　2、ダブル						*/
#define COM_IR_4						2		/*　4								*/


/*	(DiVision) */
/*　定型分割　 */
#define COM_DV_NOTHING					0		/*　なし							*/
#define COM_DV_ONE_1OUT2				1		/*　片面原稿1out2					*/
#define COM_DV_ONE_1OUT4				2		/*　片面原稿1out4					*/
#define COM_DV_BOTH_1OUT4				3		/*　両面原稿1out4					*/
#define COM_DV_BOTH_1OUT8				4		/*　両面原稿1out8					*/


/*	(Expansion Position)					*/
/*　ページ展開位置調整法（ページ連結時）　	*/
/*　ページ展開位置調整法（定型リピート時）　*/
/*　ページ展開位置調整法（中折り綴じ時）　	*/
#define COM_EP_CENTER					0		/*　センタリング					*/
#define COM_EP_CORNER					1		/*　コーナリング					*/


/*	(Image Composition)  */
/*　画像合成モード	   　*/
#define COM_IC_NOTHING					0		/* 合成なし							*/
#define COM_IC_OVERLAY_TESTCOPY			1		/* 画像合成テストプリント			*/	/* RI016 */
#define COM_IC_OVERLAY_COPY				2		/* 画像合成							*/	/* RI016 */
#define COM_IC_FORM_PRINT				3		/* フォーム印刷						*/	/* RI016 */
#define COM_IC_FORM_SAVE				4		/* フォーム登録						*/	/* RI016 */

#if 0																				/* RI016 */
//#define COM_IC_FIRST					1		/*　１ページ目だけに合成			*/
//#define COM_IC_ALL					2		/*　全原稿に合成					*/
#endif																				/* RI016 */

#define COM_IV_NOTHING				COM_IC_NOTHING
#if 0																				/* RI016 */
//#define COM_IV_OVERLAY			COM_IC_ALL
#else																				/* ↓RI016 */
#define COM_IV_OVERLAY					2
#endif																				/* ↑RI016 */

#define COM_IV_PRINT					3		/*　そのまま印刷					*/
#define COM_IV_SAVE 					4		/*	登録		  					*/


/*	(Image comPression)  */
/*　画像圧縮方式　		 */
#define COM_IP_NOTHING					0		/* 圧縮なし							*/
#define COM_IP_MH						1		/* MH圧縮							*/
#define COM_IP_MR						2		/* MR圧縮							*/
#define COM_IP_MMR						3		/* MMR圧縮							*/
#define COM_IP_MG3						4		/* MG3圧縮							*/
#define COM_IP_EXP						5		/* 伸張								*/

												/* k.kakuda 2000/2/8 Add Start		*/
#define COM_IP_JBIG 					6 		/* ＪＢＩＧ圧縮						*/
#define COM_IP_RECTOR					7		/* ＲＥＣＴＯＲ圧縮					*/
												/* k.kakuda 2000/2/8 Add End		*/

#define COM_IP_TIFF 					8		/* ＴＩＦＦ圧縮						*/	/* 7.09 */
#define COM_IP_JPEG 					9		/* ＪＰＥＧ圧縮						*/	/* 7.09 */
#define COM_IP_PDF						10		/* ＰＤＦ圧縮						*/	/* 7.09 */
#define COM_IP_PNG						11		/* ＰＮＧ圧縮						*/	/* 7.09 */

#define COM_IP_TJPEG					12		/* ＴＪＰＥＧ圧縮					*/	/* KK010 */

#define COM_IP_XPS						13		/* XPS圧縮 							*/
#define COM_IP_DIB						14		/* DIB（非圧縮） 					*/

#if 1			/* ↓BP007 */
#define COM_IP_CJPEG_VL					15		/* ＣＪＰＥＧ圧縮 	(可変長)					*/
#define COM_IP_RECTOR_1DS				16		/* ＲＥＣＴＯＲ圧縮								*/

#if 0																				/* BP065 削除パラメタ */
//#define COM_IP_CJPEG_FL				17		/* ＣＪＰＥＧ圧縮 	(固定長)  					071023 使われなくなった*/
//#define COM_IP_TJPEG_FL				18		/* ＴＪＰＥＧ圧縮 	(固定長)  					071023 使われなくなった*/
//#define COM_IP_TJPEG_FL_128			19		/* ＴＪＰＥＧ圧縮 フルカラー(600dpi,128Byte)用  071023 使われなくなった*/
#endif
#endif																					/* ↑BP007 */


#if 0 /* 980812 ksuzuki -> if 1-> if 0 2000.02.08 k.kakuda */
//#define COM_IP_RECTOR					6		/*　Mississippi圧縮　*/
#endif

/*	(k Parameter)  */
/*	ｋ パラメータ  */
#define COM_KP_1					1			/*　１								*/
#define COM_KP_2					2			/*　２								*/
#define COM_KP_4					4			/*　４								*/


/*	(No paper Source) */
/*　給紙元なし対応　  */
#define COM_NS_START				0			/*　強制開始						*/
#define COM_NS_NOSTART				1			/*　開始しない						*/


/*	(Multiple Size) 				  */
/*　サイズ混在対応（ページ縮小連結）　*/
/*　サイズ混在対応（両面印刷）　	  */
#if 1											/* 980708 ksuzuki					*/
#define  COM_SIZE_MIXED 			0			/* サイズ混在						*/
#define  COM_SIZE_SAME				1			/* サイズ非混在						*/
#endif											/* 980708 ksuzuki					*/

/*　DSS,FAXでの長尺ページ分割印刷方式 */
#define COM_MS_NOTHING				0			/*　そのまま						*/
#define COM_MS_PCHG 				1			/*　改ページ（用紙切替）			*/
#define COM_MS_REDUCE				2			/*　必要に応じて縮小				*/


#if 1											/* 980924 ksuzuki Missi仕様に変更 */
/*  (Cover Mode) */
/*　表紙モード　 */
/*　裏表紙モード */
/*　シート挿入　 */
#define COM_CM_NOTHING				0			/*　なし（表裏コピー）				*/
#define COM_CM_FCOPY 				2			/*　表コピー						*/
#define COM_CM_FWHITE				1			/*　表白紙 							*/
#define COM_CM_FBWHITE				3			/*　表裏白紙						*/
#define COM_CM_FCBW					4			/*　表コピー裏白紙	 				*/


/*  (Sheet Insert) */
/*　シート挿入　 */
#define COM_SI_NOTHING				0			/*　なし							*/
#define COM_SI_COPY					1			/*　コピー							*/
#define COM_SI_WHITE 				2			/*　白紙							*/
#define COM_SI_DUPLEXCOPY			3			/*　Duplex Print					*//* 7.23 Sadakuni */
#define COM_SI_DUPLICATECOPY		4			/*　Duplicate(SheetInsertion)		*//* 7.23 Sadakuni */

/* NVMカセット位置情報設定用 (Missi 新規追加定義 ) */
#define COM_SI_SHEET1	 			1			/* 無し		 						*/
#define COM_SI_SHEET2	 			2			/* シートコピー 					*/
#define COM_COVER		 			3			/* シート挿入						*/
												/* 2000.6.15 k.kakuda add			*/
#define COM_MT_SPECIAL	 			4			/* 特殊紙用カセット 				*/
#define COM_MT_SPECIALFAX 			5			/* FAX優先カセット 					*/
												/* 2000.6.15 k.kakuda add end		*/
#define COM_TAB			 			6			/* タブ紙カセット 					*/	/* RI003 */
#define COM_INSERTER 	 			7			/* インサータカセット 				*/	/* RI003 */

/* 共通	 (Missi 新規追加定義 ) */
#define COM_SI_INIT_VAL	 			1000		/* シート挿入ページ初期値			*/

/*#if defined(MCK_ENG) || defined(HUD_ENG) || defined(RHO_ENG)	*/					/* RI007 */
/*#ifdef RIO_ENG	*/																/* RI007 */
/*#if defined(RIO_ENG) || defined(DEN_ENG)						*/					/* DN000 *//* DN001 */
/*#ifdef eB2_SYS*/																	/* DN001 *//* BP000 */
#if 1		/* BP000 */
   #define COM_SI_ONE_MAX_PAGE 		50			/* 1シート挿入最大指定数			*//* RI004 */
#else																				/* RI004 */
   #define COM_SI_ONE_MAX_PAGE 		15			/* 1シート挿入最大指定数			*/
#endif																				/* RI004 */

#define COM_SI_MAX_PAGE	   			COM_SI_ONE_MAX_PAGE
#define COM_CM_FCOVER	   			1	 		/* 表紙数 										*/
#define COM_CM_BCOVER	   			1	 		/* 裏表紙数										*/
#define COM_CS_MAX_PAGE	   			COM_SI_MAX_PAGE+COM_CM_FCOVER+COM_CM_BCOVER
#define COM_PR_BKWHITE				-1	 		/* 印刷順テーブル設定用（白紙）					*/
#define COM_PR_FCOVER				-2	 		/* シート情報テーブル設定用（表表紙） 			*/
#define COM_PR_BCOVER				-3	  		/* シート情報テーブル設定用（裏表紙） 			*/
#define COM_PR_SHEET 				-4	  		/* 印刷順テーブル設定用（白紙シート） 			*/

																					/* RI003 Start */
#define COM_PR_TAB		  			-5	  		/* 印刷順テーブル設定用（タブ紙挿入） 			*/
#define COM_PR_INSERTER	  			-6	  		/* 印刷順テーブル設定用（インサータ挿入） 		*/
#define COM_PR_INSFCOVER   			-7	  		/* 印刷順テーブル設定用（インサータ表紙挿入） 	*/
#define COM_PR_INSBCOVER   			-8	  		/* 印刷順テーブル設定用（インサータ裏表紙挿入）	*/
																					/* RI003 END */

#define COM_PARA_SHEET1	  			1			/* parMN関数パラメータ（シート１）				*/
#define COM_PARA_SHEET2	  			2			/* parMN関数パラメータ（シート２）				*/
#define COM_PARA_TAB 	  			3													/* RI002 */
#define COM_PARA_INSERTER  			4													/* RI002 */

																		/* 990111 ksuzuki 1 -> 11 */
#define COM_CS_SFB_ON	  			11			/* parMN関数パラメータ（手差し有効）			*/
#define COM_CS_SFB_OFF	  			 0			/* parMN関数パラメータ（手差し無効）			*/
#define COM_PS_NONE		  			99			/* parMN関数NVM設定用（カセット無し）			*/
#define COM_PS_ERROR 	  			98			/* parMN関数（実給紙エラー）					*/

#else											/* 980924 ksuzuki Missi仕様に変更 				*/
//	 /*  (Cover Mode) */
//	 /*　表紙モード　 */
//	 /*　裏表紙モード */
//	 /*　シート挿入　 */
//	 #define COM_CM_NOTHING 0		/*　なし（表裏コピー）　*/
//	 #define COM_CM_FCOPY	1		/*　表コピー　*/
//	 #define COM_CM_FWHITE	2		/*　表白紙　*/
//	 #define COM_CM_BCOPY	3		/*　裏コピー　*/
//	 #define COM_CM_BWHITE	4		/*　裏白紙　*/
//	 #define COM_CM_WHITE	5		/*　表裏白紙　*/
//
//
//	 /*  (Sheet Insert) */
//	 /*　シート挿入　 */
//	 #define COM_SI_NOTHING 0		/*　なし　*/
//	 #define COM_SI_FCOPY	1		/*　コピー　*/
//	 #define COM_SI_FWHITE	2		/*　白紙　*/
#endif											/* 980924 ksuzuki Missi仕様に変更 				*/

												/* start 7.05 s.ohta 2002.07.18 シンボル追加	*/

/* タブ紙設定 */
#define COM_TAB_NOTHING   			0 			/* タブ紙挿入なし				*/
#define COM_TAB_COPY	  			1 			/* タブ紙挿入印刷				*/
#define COM_TAB_WHITE	  			2 			/* タブ紙挿入					*/

/* インサータ設定 */
#define COM_INS_NOTHING   			0 			/* インサータ設定なし			*/
#define COM_INS_FWHITE	  			1 			/* インサータ表紙				*/
#define COM_INS_FBWHITE   			2 			/* インサータ表紙・裏表紙		*/
#define COM_INS_INS 	  			3 			/* インサータ挿入				*/
#define COM_INS_FINS	  			4 			/* インサータ表紙＋挿入 		*/
#define COM_INS_FBINS	  			5 			/* インサータ表紙・裏表紙＋挿入 */
												/* end 7.05 s.ohta 2002.07.18 シンボル追加		*/

												/* start 7.06 s.ohta 2002.09.06 シンボル追加	*/
/*#if defined(MCK_ENG) || defined(HUD_ENG) || defined(RHO_ENG)	*/				/* RI007 */
/*#ifdef RIO_ENG	*/															/* RI007 */
/*#if defined(RIO_ENG) || defined(DEN_ENG)						*/				/* DN000 *//* DN001 */
/*#ifdef eB2_SYS*/																/* DN001 *//* BP000 */
#if 1
	#define COM_INS_MAX_PAGE 		50 			/* インサータ挿入最大枚数  */
#else																			/* RI004 */
	#define COM_INS_MAX_PAGE 		15 			/* インサータ挿入最大枚数  */
#endif																			/* RI004 */
#define COM_INS_INIT_VAL 			9999		/* インサータ挿入ページ初期値 */

/*#if defined(MCK_ENG) || defined(HUD_ENG) || defined(RHO_ENG)	*/				/* RI007 */
/*#ifdef RIO_ENG	*/															/* RI007 */
/*#if defined(RIO_ENG) || defined(DEN_ENG)						*/				/* DN000 *//* DN001 */
/*#ifdef eB2_SYS*/																/* DN001 *//* BP000 */
#if 1
	#define COM_TAB_MAX_PAGE		50 			/* タブ紙挿入最大枚数 */
#else																			/* RI004 */
	#define COM_TAB_MAX_PAGE		15 			/* タブ紙挿入最大枚数 */
#endif																			/* RI004 */
#define COM_TAB_INIT_VAL 			9999		/* タブ紙挿入ページ初期値 */

												/* end 7.06 s.ohta 2002.09.06 シンボル追加 */
																				/* ↓ RI010 */
/*#ifdef RIO_ENG	*/
/*#if defined(RIO_ENG) || defined(DEN_ENG)	*/									/* DN000 *//* DN001 */
/*#ifdef eB2_SYS*/																/* DN001 *//* BP000 */
#if 1
	#define COM_TRUECST_MAX 		5		/* hTruecstの配列数 		*/
#else
	#define COM_TRUECST_MAX 		3		/* hTruecstの配列数 		*/
#endif
																				/* ↑ RI010 */

											/* 2000.5.29 add k.kakuda			*/
#define COM_MFP_SI_DEFAULT			0		/* デフォルト 						*/
#define COM_MFP_SI_SINGLE			1		/* 片面のみを印刷 					*/
#define COM_MFP_SI_WHITE			1		/* 白紙で出力 						*/
											/* 2000.5.29 add end k.kakuda		*/

/*	(I/O order)　		*/
/*　入力頁順（手置き）　*/
/*　入力頁順（SADF）　	*/
/*　入力頁順（ADF）　	*/
/*　出力頁順（拡張複写）*/
/*　出力頁順（FAX）　	*/
/*　出力頁順（GDI）　	*/
#define COM_IO_UP					0		/*　昇順							*/
#define COM_IO_DOWN 				1		/*　降順							*/

/*	(Original Feed Method)　*/
/*	原稿入力方法 ＡＤＦ */
/*	原稿入力方法 手置き */
#define COM_SM_ADF					0		/*　ＡＤＦ							*/
#define COM_SM_MNL					1		/*　手置き							*/
#define COM_SM_NEUTRAL				2		/*　Neutral							*/

/*　出力面（GDI）　   */
#define COM_FC_UP					0		/*　フェイスアップ　				*/
#define COM_FC_DOWN 				1		/*　フェイスダウン　				*/


/*	(Output Timing) */
/*　出力タイミング　*/
#define COM_OT_SCS					0		/*　逐次							*/
#define COM_OT_FIN					1		/*　完了							*/
#if 1										/* ksuzuki 981029					*/
#define COM_OT_SCS_MNL				2		/* 手置き逐次 						*/
#define COM_OT_SCS_ONE				3		/* 片面逐次 						*/
#define COM_OT_SCS_BOTH 			4		/* 両面逐次 						*/
#endif
											/* k.kakuda 1999/11/04 start		*/
#define COM_OT_TRK_SCS				5		/*	後追い 逐次  					*/
#define COM_OT_TRK_FIN				6		/*	後追い 完了  					*/
											/* k.kakuda 1999/11/04 add end		*/

/*	(Adf Scan)	   */
/*　ADFスキャン面　*/
#define COM_AS_FRONT				0		/*　表面							*/
#define COM_AS_BACK 				1		/*　裏面							*/


/*	(SCope) 		  */
/*　イメージリピート　*/
/*　斜体範囲　		  */
/*　鏡像　　　　　　　*/
/*　白黒反転　　　　　*/
/*　トリミング		　*/
/*　マスキング		　*/
/*　センタリング　　　*/
/*　コーナリング　　　*/
/*　枠付け			　*/
/*　網編集範囲		　*/
/*　影付け範囲		　*/
/*　文字飾り範囲　	  */
#define COM_SC_NOTHING				0		/*　なし							*/
#define COM_SC_VALID				1		/*　あり							*//* KK003 */

#define COM_SC_ALL					1		/*　全面指定						*/
#define COM_SC_PART 				2		/*　部分指定						*/
#define COM_SC_MARK 				3		/*　マーカ矩形指定／マーカ自由指定	*/


/*	(TRimming　masking)  */
/*　トリミング／マスキング　*/
#define COM_TR_NOTHING				0		/*　なし　				*/
#define COM_TR_TRIMMING 			1		/*　トリミング　		*/
#define COM_TR_MASKINGE 			2		/*　マスキング　		*/


/*	(Net Editing)  */
/*　網編集		 　*/
#define COM_NE_NOTHING				0		/*　なし　				*/
#define COM_NE_AMIKAKE				1		/*　網掛け　			*/
#define COM_NE_AMINOSE				2		/*　網載せ　			*/


/*	(ShAdow)  */
/*　影モード　*/
#define COM_SA_NOTHING				0		/*	なし　				*/
#define COM_SA_2D					1		/*　影付け・平影		*/
#define COM_SA_3D					2		/*　影付け・立体影		*/
#define COM_SA_2DONLY				3		/*　影のみ・平影		*/
#define COM_SA_3DONLY				4		/*　影のみ・立体影		*/


/*	(Letter Decoration) */
/*　文字飾りモード　	*/
#define COM_LD_NOTHING				0		/*	なし				*/
#define COM_LD_BOLD 				1		/*　太字				*/
#define COM_LD_NAKANUKI 			2		/*　中抜き　			*/
#define COM_LD_RINKAKU				3		/*　輪郭				*/
#define COM_LD_NAKAUME				4		/*　中埋め　			*/


/*	(RoTation) */
/*　回転モード　	*/
#define COM_RT_NOTHING				0		/*	なし				*/
#define COM_RT_90					1		/*	右90°　			*/
#define COM_RT_180					2		/*	右180°				*/
#define COM_RT_270					3		/*	右270°				*/


/*	(ImageOrientation) */
/*　画像方向　	  */
#define COM_IO_PORTRAIT 			0		/* ポートレイト			*/
#define COM_IO_LANDSCAPE			1		/* ランドスケープ		*/
/* k.kakuda 2000.02.04	add */
#define COM_IO_AUTO 				2		/* 自動					*/
/* k.kakuda 2000.02.04	add END */


/*	(ImageCoordinate) */
/*　画像座標系	*/
#define COM_IC_0					0		/* ０度					*/
#define COM_IC_90					90		/* ９０度				*/
#define COM_IC_180					180 	/* １８０度				*/
#define COM_IC_270					270 	/* ２７０度				*/

#if 0
/* k.kakuda 2000/2/8 Add Start*/
///* 縮小率 */
//#define COM_RD_M_71	0 /*主走査方向縮小率＝　５／　７（７１％）*/
//#define COM_RD_M_84	1 /*主走査方向縮小率＝１１／１３（８４％）*/
//#define COM_RD_M_100	2 /*主走査方向縮小率＝　１／　１（１００％）*/
//#define COM_RD_S_25 0 /*副走査方向縮小率＝　１／　４（２５％）*/
//#define COM_RD_S_50 1 /*副走査方向縮小率＝　１／　２（５０％）*/
//#define COM_RD_S_75 2 /*副走査方向縮小率＝　３／　４（７５％）*/
//#define COM_RD_S_80 3 /*副走査方向縮小率＝　４／　５（８０％）*/
//#define COM_RD_S_83 4 /*副走査方向縮小率＝　５／　６（８３％）*/
//#define COM_RD_S_86 5 /*副走査方向縮小率＝　６／　７（８６％）*/
//#define COM_RD_S_90 6 /*副走査方向縮小率＝　９／１０（９０％）*/
//#define COM_RD_S_95 7 /*副走査方向縮小率＝１９／２０（９５％）*/
//#define COM_RD_S_100	8 /*副走査方向縮小率＝　１／　１（１００＄）*/
/*k.kakuda 2000/2/8 Add End */
#endif
#if 0 /* add 2000.10.3 */
/* k.kakuda 2000/5/11 Add Start*/
//#define COM_RD_M_33 0	/* 主走査方向縮小率= 1/3 (33.3%)	*/
//#define COM_RD_M_40 1	/* 主走査方向縮小率= 2/5 (40.0%)	*/
//#define COM_RD_M_50 2	/* 主走査方向縮小率= 1/2 (50.0%)	*/
//#define COM_RD_M_71 3	/* 主走査方向縮小率= 5/7 (71.4%)(リスト)*/
//#define COM_RD_M_71_LNG 4	/* 主走査方向縮小率= 5/7 (71.4%)(長尺)	*/
//#define COM_RD_M_75 5	/* 主走査方向縮小率= 3/4 (75.0%)	*/
//#define COM_RD_M_84 6	/* 主走査方向縮小率=11/13(84.6%)(リスト)*/
//#define COM_RD_M_84_LNG 7	/* 主走査方向縮小率=11/13(84.6%)(長尺)	*/
//#define COM_RD_M_90 8	/* 主走査方向縮小率= 9/10(90.0%)	*/
//#define COM_RD_M_100	9	/* 主走査方向縮小率= 1/1(100.0%)	*/

//#define COM_RD_S_16 0	/* 副走査方向縮小率= 1/6 (16.7%)	*/
//#define COM_RD_S_20 1	/* 副走査方向縮小率= 1/5 (20.0%)	*/
//#define COM_RD_S_25 2	/* 副走査方向縮小率= 1/4 (25.0%)	*/
//#define COM_RD_S_33 3	/* 副走査方向縮小率= 1/3 (33.3%)	*/
//#define COM_RD_S_40 4	/* 副走査方向縮小率= 2/5 (40.0%)	*/
//#define COM_RD_S_50 5	/* 副走査方向縮小率= 1/2 (50.0%)(リスト)*/
//#define COM_RD_S_50_LNG 6	/* 副走査方向縮小率= 1/2 (50.0%)(長尺)	*/
//#define COM_RD_S_57 7	/* 副走査方向縮小率= 4/7 (57.1%)	*/
//#define COM_RD_S_60 8	/* 副走査方向縮小率= 3/5 (60.0%)	*/
//#define COM_RD_S_66 9	/* 副走査方向縮小率= 2/3 (66.7%)	*/
//#define COM_RD_S_71 10	/* 副走査方向縮小率= 5/7 (71.4%)(リスト)*/
//#define COM_RD_S_71_LNG 11	/* 副走査方向縮小率= 5/7 (71.4%)(長尺)	*/
//#define COM_RD_S_75 12	/* 副走査方向縮小率= 3/4 (75.0%)	*/
//#define COM_RD_S_80 13	/* 副走査方向縮小率= 4/5 (80.0%)	*/
//#define COM_RD_S_83 14	/* 副走査方向縮小率= 5/6 (83.3%)	*/
//#define COM_RD_S_84 15	/* 副走査方向縮小率=11/13(84.6%)(リスト)*/
//#define COM_RD_S_84_LNG 16	/* 副走査方向縮小率=11/13(84.6%)(長尺)	*/
//#define COM_RD_S_86 17	/* 副走査方向縮小率= 6/7 (85.7%)	*/
//#define COM_RD_S_90 18	/* 副走査方向縮小率= 9/10(90.0%)	*/
//#define COM_RD_S_95 19	/* 副走査方向縮小率=19/20(95.0%)	*/
//#define COM_RD_S_100	20	/* 副走査方向縮小率= 1/1(100.0%)	*/
//#define COM_RD_S_140	21	/* 副走査方向縮小率= 7/5(140.0%)	*/
//#define COM_RD_S_166	22	/* 副走査方向縮小率= 5/3(166.7%)	*/
//#define COM_RD_S_200	23	/* 副走査方向縮小率= 2/1(200.0%)	*/
/* k.kakuda 2000/5/11 Add End */
#endif


																		/* k.kakuda 2000/10/3 Add */
#define COM_RD_M_33 					0  		/* 主走査方向縮小率= 1/3 (33.3%)(リスト)			*/
#define COM_RD_M_40 					1  		/* 主走査方向縮小率= 2/5 (40.0%)(リスト)			*/
#define COM_RD_M_50 					2  		/* 主走査方向縮小率= 1/2 (50.0%)(リスト)			*/
#define COM_RD_M_63 					3  		/* 主走査方向縮小率= 7/11(63.6%)(長尺)				*/
#define COM_RD_M_71 					4  		/* 主走査方向縮小率= 5/7 (71.4%)(リスト)			*/
#define COM_RD_M_71_LNG 				5  		/* 主走査方向縮小率= 5/7 (71.4%)(長尺)				*/
#define COM_RD_M_75 					6  		/* 主走査方向縮小率= 3/4 (75.0%)(長尺)				*/
#define COM_RD_M_80 					7  		/* 主走査方向縮小率= 4/5 (80.0%)(長尺)				*/
#define COM_RD_M_84 					8  		/* 主走査方向縮小率=11/13(84.6%)(リスト)			*/
#define COM_RD_M_84_LNG 				9  		/* 主走査方向縮小率=11/13(84.6%)(長尺)				*/
#define COM_RD_M_90 					10 		/* 主走査方向縮小率= 9/10(90.0%)(長尺)				*/
#define COM_RD_M_100					11 		/* 主走査方向縮小率= 1/1(100.0%)(長尺、リスト)		*/

#define COM_RD_S_16 					0  		/* 副走査方向縮小率= 1/6 (16.7%)(リスト)			*/
#define COM_RD_S_20 					1  		/* 副走査方向縮小率= 1/5 (20.0%)(リスト)			*/
#define COM_RD_S_25 					2  		/* 副走査方向縮小率= 1/4 (25.0%)(リスト)			*/
#define COM_RD_S_33 					3  		/* 副走査方向縮小率= 1/3 (33.3%)(リスト)			*/
#define COM_RD_S_40 					4  		/* 副走査方向縮小率= 2/5 (40.0%)(リスト)			*/
#define COM_RD_S_48 					5  		/* 副走査方向縮小率=12/25(48.0%)(リスト)			*/
#define COM_RD_S_50 					6  		/* 副走査方向縮小率= 1/2 (50.0%)(リスト)			*/
#define COM_RD_S_50_LNG 				7  		/* 副走査方向縮小率= 1/2 (50.0%)(長尺)				*/
#define COM_RD_S_55 					8  		/* 副走査方向縮小率=11/20(55.0%)(長尺)				*/
#define COM_RD_S_57 					9  		/* 副走査方向縮小率= 4/7 (57.1%)(長尺)				*/
#define COM_RD_S_60 					10 		/* 副走査方向縮小率= 3/5 (60.0%)(長尺)				*/
#define COM_RD_S_63 					11 		/* 副走査方向縮小率=16/25(64.0%)(長尺)				*/
#define COM_RD_S_66 					12 		/* 副走査方向縮小率= 2/3 (66.7%)(長尺)				*/
#define COM_RD_S_71 					13 		/* 副走査方向縮小率= 5/7 (71.4%)(リスト)			*/
#define COM_RD_S_71_LNG 				14 		/* 副走査方向縮小率= 5/7 (71.4%)(長尺)				*/
#define COM_RD_S_75 					15 		/* 副走査方向縮小率= 3/4 (75.0%)(長尺)				*/
#define COM_RD_S_80 					16 		/* 副走査方向縮小率= 4/5 (80.0%)(長尺)				*/
#define COM_RD_S_83 					17 		/* 副走査方向縮小率= 5/6 (83.3%)(長尺)				*/
#define COM_RD_S_84 					18 		/* 副走査方向縮小率=11/13(84.6%)(リスト)			*/
#define COM_RD_S_84_LNG 				19 		/* 副走査方向縮小率=11/13(84.6%)(長尺)				*/
#define COM_RD_S_86 					20 		/* 副走査方向縮小率= 6/7 (85.7%)(長尺)				*/
#define COM_RD_S_90 					21 		/* 副走査方向縮小率= 9/10(90.0%)(長尺)				*/
#define COM_RD_S_95 					22 		/* 副走査方向縮小率=19/20(95.0%)(長尺)				*/
#define COM_RD_S_100					23 		/* 副走査方向縮小率= 1/1(100.0%)(長尺、リスト)		*/
#define COM_RD_S_140					24 		/* 副走査方向縮小率= 7/5(140.0%)(リスト)			*/
#define COM_RD_S_166					25 		/* 副走査方向縮小率= 5/3(166.7%)(リスト)			*/
#define COM_RD_S_200					26 		/* 副走査方向縮小率= 2/1(200.0%)(リスト)			*/
																		/* k.kakuda 2000/10/3 Add End */

/*	(Auto Casette Change) */
/*　jidou kasetto kirikae  */
#define COM_ACC_NONE					0
#define COM_ACC_NORMAL					1
#define COM_ACC_EXETEND 				2


/*　自己診断モード　*/
#define COM_MODE_NORMAL 				0x00	/*	通常起動　　　　　（起動キーなし）			*/
#define COM_MODE_01PNLCHECK 			0x01	/*　コンパネ全点灯　　（[０]＋[１]）			*/
#define COM_MODE_02AGING				0x02	/*　エージング　　　　（[０]＋[２]）			*/
#define COM_MODE_03IOCHECK				0x03	/*　入出力チェック　　（[０]＋[３]）			*/
#define COM_MODE_04TESTPRINT			0x04	/*　テストプリント　　（[０]＋[４]）			*/
#define COM_MODE_05ADJUSTMENT			0x05	/*　調整モード	  　　（[０]＋[５]）			*/
#define COM_MODE_05ADJUSTMENT_RET		0x15	/*　調整モード復帰　　（[０]＋[５]）			*/
#define COM_MODE_06READY				0x06	/*　強制Ｒｅａｄｙ　　（[０]＋[６]）			*/
#define COM_MODE_07AGING				0x07	/*　エージング２　　　（[０]＋[７]）			*/
#define COM_MODE_08SETTING				0x08	/*　設定　　　　　　　（[０]＋[８]）			*/
#define COM_MODE_09PACKING				0x09	/*　梱包　　　　　　　（[０]＋[９]）			*/
#define COM_MODE_8CIDENTRY				0x0A	/*　ＩＤ登録　　　　　（[８]＋[コピー]）		*/
#define COM_MODE_FAXFUNCTION			0x0B	/*　ＦＡＸ機能設定　　（[  ]＋[  ]）			*/
#define COM_MODE_FAXCLEAR				0x0C	/*　ＦＡＸクリア　　　（[  ]＋[  ]）			*/
#define COM_MODE_EASYSETUP				0x0D	/*　イージセットアップ　（[  ]＋[  ]）			*/
#define COM_MODE_NORMAL_09				0x10	/*　[０]＋[９]抜け　　（[０]＋[９]）			*/
#define COM_MODE_NORMAL_AGING			0x11	/*	特殊[０]＋[９]抜け（[０]＋[９]）			*/

#if 1  																				/* 981023 */
#define COM_MODE_6CUNITREPLACE			0x20	/*　ユニットリプレース（[６]＋[コピー]）		*/
#define COM_MODE_9CLISTPRINT			0x21	/*　リスト出力モード　（[９]＋[コピー]）		*/
#endif

/*	Return Value For parMN Setting Function with Message Issue (Carrige/Indicator Motion)  		*/
#define  NOPROCESS						0x0002	/*	メッセージ送出なし							*/


												/* 97/07/02 T.Fujii シンボル追加 */
#define COM_FK_01						0x01	/* key [0] + [1]								*/
#define COM_FK_02						0x02	/* key [0] + [2]								*/
#define COM_FK_03						0x03	/* key [0] + [3]								*/
#define COM_FK_04						0x04	/* key [0] + [4]								*/
#define COM_FK_05						0x05	/* key [0] + [5]								*/
#define COM_FK_06						0x06	/* key [0] + [6]								*/
#define COM_FK_07						0x07	/* key [0] + [7]								*/
#define COM_FK_08						0x08	/* key [0] + [8]								*/
#define COM_FK_09						0x09	/* key [0] + [9]								*/
#define COM_FK_C8						0xC8	/* key [Copy] + [8]								*/
#define COM_FK_13						0x13	/* key [1] + [3]								*/
#define COM_FK_1A						0x1A	/* key [1] + [*]								*/
#if 1 																				/* 981023 */
#define COM_FK_C6						0xC6	/* key [Copy] + [6]								*/
#define COM_FK_C9						0xC9	/* key [Copy] + [9]								*/
#endif

#define COM_FK_28						0x28	/* key [2] + [8]	製造開始モード		*//* RI011 */

												/* 2003/03/10 起動モード追加 */
#define COM_FK_179						0x179	/* [1]+[7]+[9] 全エリアクリアモード 			*/
#define COM_FK_279						0x279	/* [2]+[7]+[9] USERエリアクリアモード 			*/
#define COM_FK_379						0x379	/* [3]+[7]+[9] USERエリア以外クリアモード		*/
#define COM_FK_245						0x245	/* [2]+[4]+[5] デバッグ用立ち上げモード１		*/
#define COM_FK_247						0x247	/* [2]+[4]+[7] デバッグ用立ち上げモード２		*/
#define COM_FK_249						0x249	/* [2]+[4]+[9] デバッグ用立ち上げモード３		*/

#if 1  																		/* 981021 ksuzuki */
/* タイマー（Weeklyタイマ、オートパワーオフ） */
#define COM_PW_DEFAULT					0 		/* 通常状態							*/
#define COM_PW_PREHEAT					1 		/* 予熱								*/
#define COM_PW_AUTOPOWEROFF 			2 		/* オートパワーオフ					*/
#define COM_PW_WEEKLYTIMER				3 		/* Weeklyタイマ						*/

/* 2000.5.15 k.kakuda add start */
#define COM_PW_SOFTKEYOFF				4 		/* Weeklyタイマ						*/
/* 2000.5.15 k.kakuda add end	*/

/* フォームストレージ　（FormStrage） */
#define COM_FS_ID_MAX_NUM				24 		/* Form登録用ID最大数				*/
#endif

/* ＩＤ登録　（AccessCode） */												/* 981116 ksuzuki */
#define COM_AC_ID_MAX_NUM				120		/* アクセスコード用ID最大数			*/

/* 部門管理　*/
														/* 2000.6.6 add k.kakuda */
#define COM_AC_NOAC    					-1		/* 部門管理対象外					*/
#define COM_AC_UNDEF					0		/* 部門番号初期値					*/
#define COM_AC_COPY 					1		/* コピー枚数						*/
#define COM_AC_TRANS					2		/* ＦＡＸ送信枚数					*/
#define COM_AC_RECEPT					3		/* ＦＡＸ受信枚数					*/
#define COM_AC_FAXPRN					4		/* ＦＡＸ印刷枚数					*/
#define COM_AC_PRINT					5		/* 印刷枚数							*/
#define COM_AC_SCNCPY					6		/* スキャン回数（コピー）			*/
#define COM_AC_SCNFAX					7		/* スキャン回数（ＦＡＸ）			*/
#define COM_AC_SCNDSS					8		/* スキャン回数（ＤＳＳ）			*/
#define COM_AC_SCNNET					9		/* スキャン回数（ＮＥＴ）			*//* 02/07/18 msei */
#define COM_AC_LIST 					10		/* リスト出力枚数					*//* 02/07/18 msei */
#define COM_AC_CALPRN 					11		/* キャリブレーション面数			*//* KK019 */
#define COM_AC_DEMPRN 					12		/* デモチャート面数					*//* KK019 */
#define COM_AC_OTHER					1001	/* 未定義用番号						*//* 変更 51->1001 [2.17] */
#define COM_AC_TOTAL					1002	/* 合計								*//* 変更 52->1002 [2.17] */
#define COM_AC_WAIT    					-1		/* コード入力待ち状態（初期値）		*/
													/* 2000.6.6 add end k.kakuda 	*/

/* ユーザ管理 */
#define COM_USER_OTHER					10001	/* 未定義用番号						*/

/* タンデム印刷 */									/* 990909 ksuzuki 				*/
#define COM_TNDM_DISABLE				0 		/* タンデム接続不可(default)		*/
#define COM_TNDM_ENABLE 				1 		/* タンデム接続可能					*/
#define COM_TNDM_MASTER 				2 		/* タンデム接続マスタ				*/
#define COM_TNDM_SLAVE					3 		/* タンデム接続スレーブ				*/


/* 特殊紙モード */								/* 7.03 2002.07.18 DO.ohta シンボル追加 		*/
#define COM_PT_INVALID					UNDEF	/* 未設定(TDOS)Kittaka ADD Mckinley 02/12/16	*/
												/* ↓7.14 2003.02.20 DO.ohta シンボル値変更 	*/
#if 0
//#define COM_PT_NORMAL		0		/* 普通紙 */
//#define COM_PT_THICK1		1		/* 厚紙1 */
//#define COM_PT_THICK2		2		/* 厚紙2 */
//#define COM_PT_THICK3		3		/* 厚紙3 */
//#define COM_PT_OHP		4		/* OHP */
//#define COM_PT_A3WIDE		5		/* A3ワイド */
//#define COM_PT_THIN 		6		/* 薄紙 */
#endif

#define COM_PT_THIN 					0x00	/* 普通紙						*/	/* 7.18 */
#define COM_PT_NORMAL					0x01	/* 厚紙１						*/ 	/* 7.18 */
#define COM_PT_THICK1					0x02	/* 厚紙２						*/ 	/* 7.18 */
#define COM_PT_THICK2					0x03	/* 厚紙３						*/ 	/* 7.18 */
#define COM_PT_THICK3					0x04	/* 厚紙４						*/	/* 7.18 *//* KK025 */

#define COM_PT_A3WIDE					0x05	/* A3ワイド(未使用)				*/	/* 7.18 */

#define COM_PT_PROOF1					0x06	/* 耐水紙１(表)					*/	/* KK007 */
#define COM_PT_PROOF2 					0x07	/* 耐水紙２(表)					*/	/* KK007 */
#define COM_PT_RECYCLE					0x08	/* 再生紙						*/	/* KK007 */

#define COM_PT_THIN1 					0x09	/* 普通紙１						*/	/* BP001 */
#define COM_PT_THIN2 					0x0A	/* 普通紙２						*/	/* BP001 */
#define	COM_PT_ULTRATHIN				0x0B	/* 薄紙	52-63gr					*/  /* FM005 */

#define COM_PT_OHP						0x10	/* OHP							*/	/* 7.18 */
#define COM_PT_TAB						0x11	/* タブ紙						*/	/* RI012*/
#define COM_PT_ENV						0x20	/* 封筒							*//* @29.00 Sky Sato	*/

#define COM_PT_NORMAL_B					0x81	/* 厚紙１(裏)					*/ 	/* KK025 */
#define COM_PT_THICK1B					0x82	/* 厚紙２(裏)					*/	/* KK007 */
#define COM_PT_THICK2B					0x83	/* 厚紙３(裏)					*/	/* KK007 */
#define COM_PT_THICK3B					0x84	/* 厚紙４(裏)					*/	/* KK025 */
#define COM_PT_PROOF1B					0x86	/* 耐水紙１(裏)					*/	/* KK007 */
#define COM_PT_PROOF2B					0x87	/* 耐水紙２(裏)					*/	/* KK007 */

#if 0	/* 7.03 2002.07.18 DO.ohta */
//#define COM_PT_THICK				1	/* 厚紙モード */
//#define COM_PT_OHP				2	/* OHPモード */
#endif	/* 7.03 2002.07.18 DO.ohta */

												/* 2000.4.25 add k.kakuda */
/* 用紙残量（PAPER REMain） */
/* CST or PFP */
#define COM_PAPER_REM_EMPT				0x00	/* Empty						*/
#define COM_PAPER_REM_NEMPT 			0x02	/* Near Empty					*/
#define COM_PAPER_REM_FULL				0x0f	/* Full							*/
/* Tandem LCF */
#define COM_PAPER_REM_LV0				COM_PAPER_REM_EMPT
#define COM_PAPER_REM_LV1				COM_PAPER_REM_NEMPT
#define COM_PAPER_REM_LV2				0x05
#define COM_PAPER_REM_LV3				0x08
#define COM_PAPER_REM_LV4				0x0b
#define COM_PAPER_REM_LV5				COM_PAPER_REM_FULL
												/* 2000.4.25 add end k.kakuda */

												/* 2000.5.12 add	 k.kakuda */
#define COM_MST_OFF						0		/* 使用不可(ウォームアップ開始前)	*/
#define COM_MST_WUP						1		/* ウォームアップ中					*/
#define COM_MST_READY					2		/* 使用可(ウォームアップ完了後)		*/
												/* 2000.5.12 ADD end k.kakuda */

												/* 2000.9.14 add	 k.kakuda */
/* エンジン用ジョブ種別　 */
#define COM_TYPE_PPC					0		/* PPC								*/
#define COM_TYPE_FAX					1		/* FAX								*/
#define COM_TYPE_PRT					2		/* PRT(DSS)							*/
												/* 2000.9.14 ADD end k.kakuda */

												/* start 7.00 s.ohta 2002.06.17 シンボル追加 */
												/* Mckinley カラーパラメータ */

/* ワンタッチ設定パラメータ */
#define COM_1TCH_INVALID				0		/* 無効								*/	/* 7.03 s.ohta 2002.07.18 追加 */
#define COM_1TCH_WARM					1		/* あたたかい						*/
#define COM_1TCH_COOL					2		/* つめたい							*/
#define COM_1TCH_VIVD					3		/* あざやか							*/
#define COM_1TCH_CLEA					4		/* めりはり							*/

#define COM_1TCH_FLUORESCENCE_PEN		5		/* 蛍光ペンモード					*//* KK004 */

/* カラー情報 */
/* ※下記の「シンボル定義時の注意事項」を参照のこと */
#define COM_CB_MONO 					0		/* モノクロ							*/
#define COM_CB_GRAYSCALE				1		/* グレースケール					*/
#define COM_CB_FULLCOLOR				2		/* フルカラー						*/
#define COM_CB_FULLCOLOR_PPC			3		/* フルカラー(PPC)					*/
#define COM_CB_FULLCOLOR_PRT			4		/* フルカラー(PRT)					*/
#define COM_CB_FULLCOLOR_SCN			5		/* フルカラー(SCN)					*/
#define COM_CB_FULLCOLOR_2BIT			6		/* 2Bitフルカラー					*/
#define COM_CB_TWOCOLORS				7		/* ２色カラー						*/
#define COM_CB_ACS_PPC					8		/* ＡＣＳ(PPC)						*/

#if defined(K2_ENG) || defined(BP_ENG) || defined(MASH_ENG)		/* BP000 */
/*#ifdef K2_ENG*/																	/* RI015 *//* BP000 */
/*#if 1			*/																	/* ↓KK014 *//* RI015 */
	#define COM_CB_ACS_PRT				9		/* ＡＣＳ(PRT)						*/
	#define COM_CB_ACS_SCN				10		/* ＡＣＳ(SCN)						*/
	#define COM_CB_ACS_BOX				11		/* ＡＣＳ(BOX印刷)					*/
	#define COM_CB_HQMONO_PPC			12		/* 多値モノクロ (PPC)				*//* 7.07 */
	#define COM_CB_MONOCOLOR			15		/* モノカラー						*//* KK002 */
	#define COM_CB_MONO_BOXFAX			20		/* FAXデータ(BOX印刷)				*//* KK020 */

	/*																				*/
	/* 下記の COM_CB_ACS_SCN_xxxx は、parMNSetColorMode で使用されることはない。	*/
	/* COM_CB_ACS_SCN の補足情報として、scnが設定、Jasper が参照するためのシンボル	*/
	/*																				*/
	#define COM_CB_ACS_SCN_MONO			110		/* ＡＣＳモノクロ(SCN)				*//* KK022 */
	#define COM_CB_ACS_SCN_COLOR		112		/* ＡＣＳカラー(SCN)				*//* KK022 */

#else																				/* ↑KK014 */
	#define COM_CB_ACS_SCN				9		/* ＡＣＳ(SCN)						*/
	#define COM_CB_HQMONO_PPC			10		/* 多値モノクロ (PPC)				*//* 7.07 */
/*	#define COM_CB_MONOCOLOR			11	*/	/* モノカラー						*//* KK002 *//* RI015 */
#endif																				/* KK014 */


/* カラー情報（EJCMパラメータ用） */
#define COM_CM_COLOR					0		/* カラー							*//* KK021 */
#define COM_CM_BLACK 					1		/* ブラック							*//*   |   */
#define COM_CM_ACSCOLOR					2		/* ACSカラー						*//*   |   */
#define COM_CM_ACSBLACK					3		/* ACSブラック						*//* KK021 */

/* カラー情報　シンボル定義時の注意事項 */
/* engPar.h で定義されている下記シンボル値と重複しないようにする。

#define   ENG_SKEW_PRESCAN				0x80 スキュー検知用プレスキャン
#define   ENG_COLOR_PPC_PATCH_SCAN		0x10 カラーPPC用パッチ読み取りスキャン
#define   ENG_MONO_PPC_PATCH_SCAN		0x11 モノクロPPC用パッチ読み取りスキャン
#define   ENG_GOSA_GAMMA_SCAN			0x12 Rioγ自動調整データ選択(誤差拡散用)
#define   ENG_DEZA_GAMMA_SCAN			0x13 Rioγ自動調整データ選択(ディザ用)
#define   ENG_COROR_PRT_PATCH_SCAN		0x20 カラーPRT用パッチ読み取りスキャン

*/

/* ２色カラーモード */							/* 7.10 ohta(Do) 追加 */
#define COM_2C_INVALID					0		/* 設定無し							*/
#define COM_2C_TWINCOLOR				1		/* ２色指定モード					*/
#define COM_2C_REDBLACK 				2		/* 赤黒モード						*/

/* ２色カラー情報 */
#define COM_CR_INVALID					0		/* ２色カラーでは無い				*/
#define COM_CR_BLACK					1		/* ブラック							*/
#define COM_CR_RED						2		/* レッド							*/
#define COM_CR_GREEN					3		/* グリーン							*/
#define COM_CR_BLUE 					4		/* ブルー							*/
#define COM_CR_YELLOW					5		/* イエロー							*/
#define COM_CR_MAGENTA					6		/* マゼンダ							*/
#define COM_CR_CYAN 					7		/* シアン							*/
#define COM_CR_WHITE 					8		/* ホワイト							*//* KK024 */

																		/* ↓KK002 */
/* モノカラー 10色		*/
#define COM_MC_MAGENTA					1		 /* 赤紫：マゼンタ					*/
#define COM_MC_LEMON					2		 /* 黄　：イエロー					*/
#define COM_MC_LEAFGREEN				3		 /* 黄緑：イエローグリーン			*/
#define COM_MC_CYAN						4		 /* 青緑：シアン					*/
#define COM_MC_PINK						5		 /* 桃　：ピンク					*/
#define COM_MC_RED						6		 /* 赤　：レッド					*/
#define COM_MC_ORANGE					7		 /* 黄赤：オレンジ					*/
#define COM_MC_GREEN					8		 /* 緑　：グリーン					*/
#define COM_MC_BLUE						9		 /* 青　：ブルー					*/
#define COM_MC_VIOLET				   10		 /* 紫　：パープル					*/
																		/* ↑KK002 */

#if 1		/* ↓BP010 */
#define COM_MC_BLACK				    0		/* 黒　：ブラック					*/
#define COM_MC_WHITE 				   11		/* 白　：ホワイト					*/
#endif																				/* ↑BP010 */

/* ２枚貼り付け情報 */
#define COM_TS_ONE						0		/* 一枚貼り付け						*/
#define COM_TS_TWO_ONE					1		/* 二枚貼り付けの一枚目				*/
#define COM_TS_TWO_TWO					2		/* 二枚貼り付けの二枚目				*/

/* ＡＣＳ判定結果 */
#define COM_ACS_INVALID 				0		/* 判定無し							*/	/* 7.07 */
#define COM_ACS_MONO					1		/* モノクロ							*/
#define COM_ACS_FULLCOLOR				2		/* フルカラー						*/

/* プレーン情報 */
#define COM_PR_1						1		/* １プレーン						*/
#define COM_PR_3						3		/* ３プレーン						*//* KK014 */
#define COM_PR_4						4		/* ４プレーン						*/

/* ビット情報 */

#define COM_DT_1BIT 					1		/* １ビット							*/
#define COM_DT_2BIT 					2		/* ２ビット							*/
#define COM_DT_4BIT 					4		/* ４ビット							*/
#define COM_DT_8BIT 					8		/* ８ビット							*/
#define COM_DT_16BIT					16		/* １６ビット						*/
#define COM_DT_24BIT					24		/* ２４ビット						*/
#define COM_DT_32BIT					32		/* ３２ビット						*/
#define COM_DT_48BIT					48		/* ４８ビット						*/

/* データ形式 */

#define COM_DF_RAW						0		/* ＲＡＷ							*/
#define COM_DF_FLAMMEO					1		/* Ｆｌａｍｍｅｏ					*/
#define COM_DF_YCC						2		/* ＹＣＣ							*/
#define COM_DF_RGB						3		/* ＲＧＢ							*/
#define COM_DF_MONOFLAMMEO				4		/* モノクロFlammeo					*/		/* 7.07 */
#if 1
#define COM_DF_CJPEG_FL					5		/* ＣＪＰＥＧ圧縮 	(固定長)					*//* ↓BP065 */
#define COM_DF_TJPEG_FL					6		/* ＴＪＰＥＧ圧縮 	(固定長)					*/
#define COM_DF_TJPEG_FL_128				7		/* ＴＪＰＥＧ圧縮 フルカラー(600dpi,128Byte)用	*//* ↑BP065 */
#endif

/* ＹＣＣ情報 */

#define COM_YCC_INVALID 				0		/* ＹＣＣでは無い					*/		/* 7.07 */
#define COM_YCC_411 					1		/* ＹＣＣ（４：１：１）				*/		/* 7.07 */
#define COM_YCC_422 					2		/* ＹＣＣ（４：２：２）				*/		/* 7.07 */
#define COM_YCC_444 					3		/* ＹＣＣ（４：４：４） 			*/		/* 7.07 */

												/* end 7.00 s.ohta 2002.06.17 シンボル追加 */

												/* start 7.02 (RX)Takanashi  2002.06.26 シンボル追加 */
#define COM_FO_ORDER_4PLANE				0		/* 4Plane同時伸張			BP097	*/
#define COM_FO_ORDER_Y					1		/* イエロー							*/
#define COM_FO_ORDER_M					2		/* マゼンダ							*/
#define COM_FO_ORDER_C					3		/* シアン							*/
#define COM_FO_ORDER_K					4		/* ブラック							*/
												/* end 7.00 (RX)Takanashi 2002.06.26 シンボル追加 */

																	/* ↓KK001 */
/*
 * カラー関連レベル値シンボル
 */
/* 色相（±3  ７ステップ）*/
#define COM_HUE_MINUS3					-3		/* 色相レベル -3 				*/
#define COM_HUE_MINUS2					-2		/* 色相レベル -2 				*/
#define COM_HUE_MINUS1					-1		/* 色相レベル -1 				*/
#define COM_HUE_NORMAL					 0		/* 色相レベル  0 				*/
#define COM_HUE_PLUS1					 1		/* 色相レベル +1 				*/
#define COM_HUE_PLUS2					 2		/* 色相レベル +2 				*/
#define COM_HUE_PLUS3					 3		/* 色相レベル +3 				*/

/* 彩度（±3  ７ステップ）*/
#define COM_CRM_MINUS3					-3		/* 彩度レベル -3 				*/
#define COM_CRM_MINUS2					-2		/* 彩度レベル -2 				*/
#define COM_CRM_MINUS1					-1		/* 彩度レベル -1 				*/
#define COM_CRM_NORMAL					 0		/* 彩度レベル  0 				*/
#define COM_CRM_PLUS1					 1		/* 彩度レベル +1 				*/
#define COM_CRM_PLUS2					 2		/* 彩度レベル +2 				*/
#define COM_CRM_PLUS3					 3		/* 彩度レベル +3 				*/
																	/* ↑KK001 */

																	/* ↓KK000 */
/* カラーバランス全色共通（±4	９ステップ）*/
#define COM_CB_MINUS4					-4		/* カラーバランスレベル   -4	*/
#define COM_CB_MINUS3					-3		/* カラーバランスレベル   -3	*/
#define COM_CB_MINUS2					-2		/* カラーバランスレベル   -2	*/
#define COM_CB_MINUS1					-1		/* カラーバランスレベル   -1	*/
#define COM_CB_NORMAL					 0		/* カラーバランスレベル    0	*/
#define COM_CB_PLUS1					 1		/* カラーバランスレベル   +1	*/
#define COM_CB_PLUS2					 2		/* カラーバランスレベル   +2	*/
#define COM_CB_PLUS3					 3		/* カラーバランスレベル   +3	*/
#define COM_CB_PLUS4					 4		/* カラーバランスレベル   +4	*/
																	/* ↑KK000 */

												/* start 7.03 s.ohta 2002.07.18 シンボル追加	*/

/* カラーバランスＹ（±4  ９ステップ）*/
#define COM_CBY_MINUS4					-4		/* カラーバランスＹレベル -4	*/
#define COM_CBY_MINUS3					-3		/* カラーバランスＹレベル -3	*/
#define COM_CBY_MINUS2					-2		/* カラーバランスＹレベル -2	*/
#define COM_CBY_MINUS1					-1		/* カラーバランスＹレベル -1	*/
#define COM_CBY_NORMAL					 0		/* カラーバランスＹレベル  0	*/
#define COM_CBY_PLUS1					 1		/* カラーバランスＹレベル +1	*/
#define COM_CBY_PLUS2					 2		/* カラーバランスＹレベル +2	*/
#define COM_CBY_PLUS3					 3		/* カラーバランスＹレベル +3	*/
#define COM_CBY_PLUS4					 4		/* カラーバランスＹレベル +4	*/

/* カラーバランスＭ（±4  ９ステップ）*/
#define COM_CBM_MINUS4					-4		/* カラーバランスＭレベル -4	*/
#define COM_CBM_MINUS3					-3		/* カラーバランスＭレベル -3	*/
#define COM_CBM_MINUS2					-2		/* カラーバランスＭレベル -2	*/
#define COM_CBM_MINUS1					-1		/* カラーバランスＭレベル -2	*/
#define COM_CBM_NORMAL					 0		/* カラーバランスＭレベル  0	*/
#define COM_CBM_PLUS1					 1		/* カラーバランスＭレベル +1	*/
#define COM_CBM_PLUS2					 2		/* カラーバランスＭレベル +2	*/
#define COM_CBM_PLUS3					 3		/* カラーバランスＭレベル +3	*/
#define COM_CBM_PLUS4					 4		/* カラーバランスＭレベル +4	*/

/* カラーバランスＣ（±4  ９ステップ）*/
#define COM_CBC_MINUS4					-4		/* カラーバランスＣレベル -4	*/
#define COM_CBC_MINUS3					-3		/* カラーバランスＣレベル -3	*/
#define COM_CBC_MINUS2					-2		/* カラーバランスＣレベル -2	*/
#define COM_CBC_MINUS1					-1		/* カラーバランスＣレベル -1	*/
#define COM_CBC_NORMAL					 0		/* カラーバランスＣレベル  0	*/
#define COM_CBC_PLUS1					 1		/* カラーバランスＣレベル +1	*/
#define COM_CBC_PLUS2					 2		/* カラーバランスＣレベル +2	*/
#define COM_CBC_PLUS3					 3		/* カラーバランスＣレベル +3	*/
#define COM_CBC_PLUS4					 4		/* カラーバランスＣレベル +4	*/

/* カラーバランスＢＫ（±4	９ステップ）*/
#define COM_CBBK_MINUS4 				-4		/* カラーバランスＢＫレベル -4	*/
#define COM_CBBK_MINUS3 				-3		/* カラーバランスＢＫレベル -3	*/
#define COM_CBBK_MINUS2 				-2		/* カラーバランスＢＫレベル -2	*/
#define COM_CBBK_MINUS1 				-1		/* カラーバランスＢＫレベル -1	*/
#define COM_CBBK_NORMAL 				 0		/* カラーバランスＢＫレベル  0	*/
#define COM_CBBK_PLUS1					 1		/* カラーバランスＢＫレベル +1	*/
#define COM_CBBK_PLUS2					 2		/* カラーバランスＢＫレベル +2	*/
#define COM_CBBK_PLUS3					 3		/* カラーバランスＢＫレベル +3	*/
#define COM_CBBK_PLUS4					 4		/* カラーバランスＢＫレベル +4	*/

/* 下地（±4  ９ステップ）*/
#define COM_FND_MINUS4					-4		/* 下地レベル -4				*/
#define COM_FND_MINUS3					-3		/* 下地レベル -3				*/
#define COM_FND_MINUS2					-2		/* 下地レベル -2				*/
#define COM_FND_MINUS1					-1		/* 下地レベル -1				*/
#define COM_FND_NORMAL					 0		/* 下地レベル  0				*/
#define COM_FND_PLUS1					 1		/* 下地レベル +1				*/
#define COM_FND_PLUS2					 2		/* 下地レベル +2				*/
#define COM_FND_PLUS3					 3		/* 下地レベル +3				*/
#define COM_FND_PLUS4					 4		/* 下地レベル +4				*/

/* RGB関連シンボル */
#define COM_RGB_MINUS4					-4	   /* バランスレベル -4				*/
#define COM_RGB_MINUS3					-3	   /* バランスレベル -3				*/
#define COM_RGB_MINUS2					-2	   /* バランスレベル -2				*/
#define COM_RGB_MINUS1					-1	   /* バランスレベル -1				*/
#define COM_RGB_NORMAL					 0	   /* バランスレベル  0				*/
#define COM_RGB_PLUS1					 1	   /* バランスレベル +1				*/
#define COM_RGB_PLUS2					 2	   /* バランスレベル +2				*/
#define COM_RGB_PLUS3					 3	   /* バランスレベル +3				*/
#define COM_RGB_PLUS4					 4	   /* バランスレベル +4				*/

												/* end 7.02 s.ohta 2002.07.18 シンボル追加	*/

/* シャープネス（±4  ９ステップ）*/
#define COM_SHR_MINUS4					-4		/* シャープネスレベル -4 [7.05]	*/
#define COM_SHR_MINUS3					-3		/* シャープネスレベル -3 [7.05]	*/
#define COM_SHR_MINUS2					-2		/* シャープネスレベル -2 [7.05]	*/
#define COM_SHR_MINUS1					-1		/* シャープネスレベル -1 [7.05]	*/
#define COM_SHR_NORMAL					 0		/* シャープネスレベル  0 [7.05]	*/
#define COM_SHR_PLUS1					 1		/* シャープネスレベル +1 [7.05]	*/
#define COM_SHR_PLUS2					 2		/* シャープネスレベル +2 [7.05]	*/
#define COM_SHR_PLUS3					 3		/* シャープネスレベル +3 [7.05]	*/
#define COM_SHR_PLUS4					 4		/* シャープネスレベル +4 [7.05]	*/

/* トナー系シンボル   */
														/* 02/09/20 add msei	*/
#define COM_TI_FULL 					0		/* トナー正常					*/
#define COM_TI_NREMPTY					1		/* ニアエンプティ				*/
#define COM_TI_EMPTY					2		/* エンプティ					*/
#define COM_TI_BTEMPTY					3		/* ボトルエンプティ				*/ /*RI001*/
#define COM_TI_C_EMPTY					4		/* カートリッジエンプティ		*/ /*KK015*/

/* リボルバー位置指定 */
														/* 7.14 ogata 03/02/18 シンボル追加	*/
#define COM_RP_STANDBY					0		/* リボルバー待機位置			*/
#define COM_RP_YELLOW					1		/* イエロー交換位置				*/
#define COM_RP_MAGENTA					2		/* マゼンタ交換位置				*/
#define COM_RP_CYAN 					3		/* シアン交換位置				*/

																/* start 7.10	*/
/* 原稿両面モード */
#define COM_SBS_SINGLE					1		/* 片面原稿						*/
#define COM_SBS_DUPLEXBOOK				2		/* 片面原稿						*/
#define COM_SBS_DUPLEXTABLET			3		/* 片面原稿						*/

/* ベージ記述言語 */
#define COM_PDL_INVALID 				0		/* 設定無し						*/	/* 7.12 */
#define COM_PDL_PS						1		/* ＰＳ							*/	/* 7.12 0→1 */
#define COM_PDL_PCL 					2		/* ＰＣＬ						*/	/* 7.12 1→2 */
#if 1		/* ↓BP014 */
#define COM_PDL_XPS 					3		/* ＸＰＳ						*/
#endif																				/* ↑BP014 */

/* スクリーン情報 */
#define COM_SCRN_AUTO					0		/* 自動							*/
#define COM_SCRN_DETAIL 				1		/* 細かい						*/
#define COM_SCRN_SMOOTH 				2		/* 滑らか						*/
																	/* end 7.10 */

												/* start 7.11 s.ohta 2002.12.12 シンボル追加	*/
/* 定型連結レイアウト */
#define COM_RC_NOTHING					0		/* 設定無し						*/
#define COM_RC_LR_ROW					1		/* 左上→右上→左下→右下		*/
#define COM_RC_RL_ROW					2		/* 右上→左上→右下→左下		*/
#define COM_RC_LR_CLM					3		/* 左上→左下→右上→右下		*/
#define COM_RC_RL_CLM					4		/* 右上→左下→左上→左下		*/

/* 文字の向き */
#define COM_DR_OUTER					0		/* 上向き						*/
#define COM_DR_INNER					1		/* 下向き						*/

/* センターコーナー */
#define COM_CC_CENTER					0		/* センター						*/
#define COM_CC_CORNER					1		/* コーナー						*/
												/* end 7.11 s.ohta 2002.12.12 シンボル追加		*/

/*　PRT4分割スムージング/トナーセーブ切り替え(PEACOCK)　*/	/* 7.13 */
#define COM_SM_NOTHING					0		/*　OFF							*/
#define COM_SM_4DIVISION				1		/*　４分割スムージング細線化	*/
#define COM_SM_TONERSAVE				2		/*　トナーセーブ				*/
#define COM_SM_4DIVISION_TONERSAVE		3		/*　４分割スムージング細線化スムージング+トナーセーブ	*/

/* 立ち上げクリアモード 7.16 */
#define COM_CLR_ALL 					1		/* オールクリア 				*/
#define COM_CLR_USER					2		/* ユーザーエリアクリア 		*/
#define COM_CLR_EXCEPT_USER 			3		/* ユーザーエリア以外クリア 	*/

/* スローモード 7.19 */
#define COM_SLOW_OFF					0		/* スローモードＯＦＦ			*/
#define COM_SLOW_ON 					1		/* スローモードＯＮ				*/

/* ＭＦＰモード 7.20 */
#define COM_MFP_NORMAL					0		/* 通常モード					*/
#define COM_MFP_COPY_TO_BOX 			1		/* コピーTOボックス				*/
#define COM_MFP_XX_TO_BOX				2		/* ＸＸTOボックス				*/

/* バックグラウンド時手差し継続 7.24 */
#define COM_LR_LOCAL					0		/* LOCAL						*/
#define COM_LR_REMOTE					1		/* REMOTE						*/

/* キャリブレーション有無 7.25 */
#define COM_CLB_INVALID 				0		/* 無効							*/
#define COM_CLB_VALID					1		/* 有効							*/

/* Ecoカウンタ */
#define COM_ECO_SINGLE					1
#define COM_ECO_DUPLEX					2
#define COM_ECO_1UP 					1
#define COM_ECO_2UP 					2
#define COM_ECO_4UP 					4
#define COM_ECO_6UP						6		/*	6in1						*//* KK019 */
#define COM_ECO_8UP						8		/*	8in1						*//* KK019 */
#define COM_ECO_9UP						9		/*	9in1						*//* KK019 */
#define COM_ECO_16UP				   16		/* 16in1						*//* KK019 */

/* 画質タイプ */
#define COM_IQT_GENERAL					0		/* 画質タイプ General			*//* KK009 */
#define COM_IQT_PHOTO					1		/* 画質タイプ Photo				*//* KK009 */
#define COM_IQT_PRESEN					2		/* 画質タイプ Presen			*//* KK009 */
#define COM_IQT_LINEART					3		/* 画質タイプ LineArt			*//* KK009 */
#if 1	/* ↓BP015 */
#define COM_IQT_ADVANCED				4		/* 画質タイプ Advanced			*/
#endif																			/* ↑BP015 */

/* weiss_feature crs (0.01) 2-1-4-14.    Vermilion - 20111226 */
#define COM_EIQT_INVALID            0        /* extra image quality type : Invalid (default) */

/* DF Scan Noise Reduction Setting for R-C00173-3  - 20140404 */
#define COM_DF_NOISE_REDUCTION_DISABLE  3    /*DF Scan Noise Reduction Setting: Disable (default) */
															/* 2005.11.11 add K.Fujita		*/
/* トナー残量（TONER REMain） */
#define COM_TONER_REM_EMPTY				0x00	/* Empty						*/ /* KK015 */
#define COM_TONER_REM_25 				0x80	/* 0%～25%						*/ /* KK015 */
#define COM_TONER_REM_50 				0x20	/* 25%～50%						*/ /* KK015 */
#define COM_TONER_REM_75 				0x08	/* 50%～75%						*/ /* KK015 */
#define COM_TONER_REM_FULL				0x02	/* 75%～100%					*/ /* KK015 */
															/* 2005.11.11 add end K.Fujita	*/

#define COM_EFI_INVALID					0		/* EFIでない					*//* KK023 */
#define COM_EFI_PRINT					1		/* EFIプリント					*//* KK023 */
#define COM_EFI_CALIBRATION				2		/* EFIキャリブレーション		*//* KK023 */

																					/* ↓KK026 */
/* 長尺印刷指定情報 */

#define COM_LONGPAPER_INVALID			0		/* 非長尺                       */
#define COM_LONGPAPER_460				1		/* 長尺(445.0～ 460.9 mm)       */
#define COM_LONGPAPER_800				2		/* 長尺(461.0～ 800.9 mm)       */
#define COM_LONGPAPER_1200				3		/* 長尺(801.0～1200.0 mm)       */
																					/* ↑KK026 */

/* ↓ e-Brindge3 ( BP、Mash ) での定義 */

																					/* ↓BP006 */
/* アライメントの位置		*/
#define COM_ALIGN_BEGINS				1		/* 主走査方向　書き始め					*/
#define COM_ALIGN_FINAL					2		/* 主走査方向　書き終わり				*/
#define COM_ALIGN_TIP					3		/* 副走査方向　用紙先端側				*/
#define COM_ALIGN_BACKEND				4		/* 副走査方向　用紙後端側				*/
																					/* ↑BP006 */

																					/* ↓BP020 */
/* アライメントの付加位置(主走査アライメントと副走査アライメントの交点)		*/
#define COM_ALIGN_NOTHING				0		/* アライメントなし								*//* BP043 */
#define COM_ALIGN_BEGINS_TIP			1		/* 左上 : 主走査方向書始、副走査方向用紙先端側	*/
#define COM_ALIGN_BEGINS_BACKEND		2		/* 右上 : 主走査方向書始、副走査方向用紙後端側	*/
#define COM_ALIGN_FINAL_TIP				3		/* 左下 : 主走査方向書終、副走査方向用紙先端側	*/
#define COM_ALIGN_FINAL_BACKEND			4		/* 右下 : 主走査方向書終、副走査方向用紙後端側	*/
																					/* ↑BP020 */

																					/* ↓BP010 */
/* 合成画像の透過率			*/
#define COM_TM_SUBSTITUTION				0		/* 置き換え								*/
#define COM_TM_WATERMARK_LIGHT			1		/* 透かし（淡）							*/
#define COM_TM_WATERMARK_NORMAL			2		/* 透かし（中）							*/
#define COM_TM_WATERMARK_DEEP			3		/* 透かし（濃）							*/
#define COM_TM_HSP						4		/* 地紋合成	       						*/
																					/* ↑BP010 */

																					/* ↓BP013 */
/* 編集処理モード			*/
#define COM_EPR_NOTHING					0		/* 編集処理なし							*/
#define COM_EPR_TRIMMING				1		/* トリミング有り						*/
#define COM_EPR_MASKING					2		/* マスキング有り						*/
#define COM_EPR_NIN1					3		/* Nin1有り								*/
#define COM_EPR_BOOK_CENTER_ERASE		4		/* ブック中消し有り						*/
#define COM_EPR_OUTSIDE_ERASE			5		/* 原稿外消去有り						*/
#define COM_EPR_COMBINATION				6		/* 上記5種類の編集機能の組み合わせ有り	*/
																					/* ↑BP013 */

																					/* ↓BP058 */
/* 白紙検知等で利用する閾値シンボル設定 */
#define COM_THRESHOLD_MINUS3 		   -3		/*閾値レベル -3*/
#define COM_THRESHOLD_MINUS2 		   -2		/*閾値レベル -2*/
#define COM_THRESHOLD_MINUS1 		   -1		/*閾値レベル -1*/
#define COM_THRESHOLD_NORMAL  			0		/*閾値レベル  0*/
#define COM_THRESHOLD_PLUS1   			1		/*閾値レベル  1*/
#define COM_THRESHOLD_PLUS2   			2		/*閾値レベル  2*/
#define COM_THRESHOLD_PLUS3   			3		/*閾値レベル  3*/
																					/* ↑BP058 */
																					/* ↓BP069 */
/* OmitBlankPageシンボル設定 */
#define COM_OMITBLANK_NORMAL			0		/* 通常ページ  */
#define COM_OMITBLANK_BLANK				1		/* 白紙ページ  */
#define COM_OMITBLANK_INVALID			2		/* 判定なし    */
																					/* ↑BP069 */

#define COM_PAPER_NOWIDE 				0		/* ワイド系以外*//* BP063 */
#define COM_PAPER_WIDE   				1 		/* ワイド系    *//* BP063 */

#endif /* __INCcomParh */
