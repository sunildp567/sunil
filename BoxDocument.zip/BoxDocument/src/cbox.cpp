/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cbox.cpp
 Revision: com_t#5
 File Spec: EBX:MA6030.A-DEV_SRC;com_t#5
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:27:08

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#5 (APPROVED)
     Created:  09-JAN-2009 21:27:09      CHANDRAMOHAN.PUJARI
       Changed the Debug statements.
     Updated:  09-JAN-2009 21:27:09      CHANDRAMOHAN.PUJARI
       Changed the Debug statements.
     Updated:  09-JAN-2009 21:27:09      CHANDRAMOHAN.PUJARI
       Changed the Debug statements.
     Updated:  09-JAN-2009 21:27:09      CHANDRAMOHAN.PUJARI
       Item revision com_t#5 created from revision com_t#4 with status
       $TO_BE_DEFINED
   
   Revision com_t#4 (APPROVED)
     Updated:  19-DEC-2008 21:29:43      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing
     Created:  19-DEC-2008 21:29:42      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing
     Updated:  19-DEC-2008 21:29:42      CHANDRAMOHAN.PUJARI
       Item revision com_t#4 created from revision com_t#3 with status
       $TO_BE_DEFINED
     Updated:  19-DEC-2008 21:29:42      CHANDRAMOHAN.PUJARI
       set session id property to NULL instead of removing
   
   Revision com_t#3 (APPROVED)
     Created:  08-DEC-2008 20:24:43      CHANDRAMOHAN.PUJARI
       Added Code for handling Disk Full, Scan Preview, Box Usage and
       Last Access and Modified dates
     Updated:  08-DEC-2008 20:24:43      CHANDRAMOHAN.PUJARI
       Added Code for handling Disk Full, Scan Preview, Box Usage and
       Last Access and Modified dates
     Updated:  08-DEC-2008 20:24:43      CHANDRAMOHAN.PUJARI
       Added Code for handling Disk Full, Scan Preview, Box Usage and
       Last Access and Modified dates
     Updated:  08-DEC-2008 20:24:43      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
   
   Revision com_t#2 (APPROVED)
     Created:  17-NOV-2008 21:50:21      CHANDRAMOHAN.PUJARI
       Added Implementation for new Interface API s of Box Class namely
       Box::SetWEPDocument and Box::GetWEPDocument
     Updated:  17-NOV-2008 21:50:21      CHANDRAMOHAN.PUJARI
       Added Implementation for new Interface API s of Box Class namely
       Box::SetWEPDocument and Box::GetWEPDocument
     Updated:  17-NOV-2008 21:50:21      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
     Updated:  17-NOV-2008 21:50:21      CHANDRAMOHAN.PUJARI
       Added Implementation for new Interface API s of Box Class namely
       Box::SetWEPDocument and Box::GetWEPDocument
   
   Revision com_t#1 (APPROVED)
     Created:  03-NOV-2008 19:28:58      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:28:58      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:28:58      CHANDRAMOHAN.PUJARI
       Added code for clipboard functionalities such as copy,cut and
       paste
     Updated:  03-NOV-2008 19:28:58      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.4 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.4 (APPROVED)
     Updated:  30-SEP-2008 11:38:21      13848
       Update WebDAV properties
     Created:  30-SEP-2008 11:38:21      13848
       Update WebDAV properties
     Updated:  30-SEP-2008 11:32:30      13848
       Item revision com_m#1.4 created from revision com_m#1.3 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.3 (UNIT TESTED)
     Updated:  30-SEP-2008 10:48:56      13848
       Change keys of Box property.
     Created:  30-SEP-2008 10:48:56      13848
       Change keys of Box property.
     Updated:  30-SEP-2008 10:47:55      13848
       Item revision com_m#1.3 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:57      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:32      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:12      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:15      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:35      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:06:47      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:33:02      13848
       Initial revision
========================== End of Source Header =============================*/
#include <vector>
#include <algorithm>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/cuuid.h>
#include <CI/OperatingEnvironment/file.h>
#include <CI/OperatingEnvironment/folder.h>
#include <CI/DocumentStore/documentstore.h>
#include "CI/OperatingEnvironment/cexception.h"
#include "cboxdocument.h"
#include "cbox.h"
#include "cfolder.h"
#include "cdocument.h"
#include "proputils.h"
#include "carchive.h"
#include "cextract.h"
#include "cpage.h"
#include <iomanip>
#include <sstream>
#include <cerrno>
#include <sys/stat.h>
#include<iostream>
#include<exception>
#define MAXLINESIZE 250

//using namespace ci::DocumentStore;
using namespace ci::hierarchicaldb;
using namespace std;
using namespace ci::operatingenvironment;
using namespace dom;

namespace ci {
    namespace boxdocument {

        //Define the declared static data member
        std::vector<CString> CBox::m_CutVecofDocs;

        std::vector<CString> CBox::m_CopyVecofDocs;
	std::vector<CString> CBox::m_PastedVecofDocs;
	pthread_mutex_t gbox_mutex_initializer = PTHREAD_MUTEX_INITIALIZER;

        CString CBox::m_DelDoc="";

        typedef std::map<CString, CString> pair;
        CBox::CBox(CString sessionID, CString boxbasepath,CString boxnumber):m_BoxBasePath(boxbasepath),m_BoxNumber(boxnumber)
        {
            if(CBoxDocument::incrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCBox::CBox: Failed to increment the count\n ");

            m_WebDAVProperties.insert(pair::value_type("documentType", "eFilingBox"));
            m_WebDAVProperties.insert(pair::value_type("boxName", ""));
            m_WebDAVProperties.insert(pair::value_type("boxNo", m_BoxNumber));
            m_WebDAVProperties.insert(pair::value_type("userName", ""));
            m_WebDAVProperties.insert(pair::value_type("comment", ""));
            m_WebDAVProperties.insert(pair::value_type("isPasswordProtected", "false"));
            m_WebDAVProperties.insert(pair::value_type("password", ""));
            m_WebDAVProperties.insert(pair::value_type("preservationPeriodFlag", "false"));
            m_WebDAVProperties.insert(pair::value_type("documentPreserveDays", "0"));

            m_WebDAVProperties.insert(pair::value_type("notifyBeforeDeletionOfDocument", "false"));
            m_WebDAVProperties.insert(pair::value_type("notifyOnError", "false"));
            m_WebDAVProperties.insert(pair::value_type("notifyOnJobCompletion", "false"));
            m_WebDAVProperties.insert(pair::value_type("notificationEmailAddress", ""));
            CString local = Utility::GetUnixTime();

            m_WebDAVProperties.insert(pair::value_type("creationDate", local));
            m_WebDAVProperties.insert(pair::value_type("lastModifiedDate", local));	 
            m_WebDAVProperties.insert(pair::value_type("lastAccessDate", local));	 	 
            m_WebDAVProperties.insert(pair::value_type("lastBackupDate", ""));
            m_WebDAVProperties.insert(pair::value_type("documentPrint", "OFF"));
            m_WebDAVProperties.insert(pair::value_type("relayEndReport", ""));
            m_WebDAVProperties.insert(pair::value_type("writeMode", ""));
            m_WebDAVProperties.insert(pair::value_type("transferInformation",""));
            m_WebDAVProperties.insert(pair::value_type("lastPurgeTime",""));
            m_WebDAVProperties.insert(pair::value_type("relayReportDestination",""));
            m_WebDAVProperties.insert(pair::value_type("relayReportDestinationType",""));
            m_WebDAVProperties.insert(pair::value_type("relayReportContactId",""));
            m_WebDAVProperties.insert(pair::value_type("ownerId",""));

            m_WebDAVProperties.insert(pair::value_type("BoxPageCount","0"));
            /*Added for receiving-forwarding requirement as requested by AL*/
            m_WebDAVProperties.insert(pair::value_type("fileNameFormat","1"));
            m_WebDAVProperties.insert(pair::value_type("dateFormat","0"));
            m_WebDAVProperties.insert(pair::value_type("pageNumberFormat","3"));
            m_WebDAVProperties.insert(pair::value_type("subID","0"));
            m_WebDAVProperties.insert(pair::value_type("rfComment",""));
            m_WebDAVProperties.insert(pair::value_type("totalBoxSize","0"));
            // set Last access date as webdav property.
            //Commented. Since in eB3 modified date will be set only when box is renamed.
            //CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            //std::map<CString, CString> PropertyMap;
            //PropertyMap.clear();
            //PropertyMap.insert(pair::value_type("lastModifiedDate", local.c_str()));
            //Utility::SetProperties(propertypath,"boxproperties.xml",PropertyMap);
            m_isIterFolder=false;
            m_sessionID = sessionID;
	    m_returnpastedocname = "";
            
        }

        CBox::~CBox() {
            // release member variables

	                if(CBoxDocument::decrementUserCount(m_BoxBasePath) != STATUS_OK)
                DEBUGL2("\nCBox::CBox: Failed to decrement the count\n ");
	
        }

        Status CBox::GetDocument(DocumentRef &doc, CString documentname) 
        {
            DEBUGL8("CBoxDocument::GetDocument::m_BoxBasePath  = (%s)\n",m_BoxBasePath.c_str());
            DEBUGL8("CBoxDocument::GetDocument::m_BoxNumber =(%s)\n",m_BoxNumber.c_str());

            return Utility::GetDocument(m_sessionID, doc,m_BoxBasePath,m_BoxNumber,"",documentname);
        }

        Status CBox::GetDocumentList(DocumentList &list) 
        {
            return GetDocumentList(list, 0, 65535);
        }


        Status CBox::GetDocumentList(DocumentList &list,unsigned int from, unsigned int size)
        {
            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::DeleteBoxList::Getting collection list is failed");
                return STATUS_FAILED;
            }
            CString documentname,documentPath;
            CString stsfile;
            DocumentRef pDocRef = NULL;
            Status ret;
            std::map<CString, CString>::iterator propIterator;
            std::map<CString, CString> WebDAVpropertyMap;
            typedef std::map<CString, CString> property_pair;					
            for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
            {
                documentname = vec[i];
                documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,documentname,"");
                stsfile = documentPath + "/.document";

                WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("mixpaperSize", ""));  // TBD
                WebDAVpropertyMap.insert(property_pair::value_type("mixresolution", "")); // TBD
                WebDAVpropertyMap.insert(property_pair::value_type("mixcolorMono", ""));  // TBD
                WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
                WebDAVpropertyMap.insert(property_pair::value_type("lastAccessDate", ""));	 	 						
                WebDAVpropertyMap.insert(property_pair::value_type("lastArchiveDate", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("from", ""));    
                WebDAVpropertyMap.insert(property_pair::value_type("receptionTime",""));
                WebDAVpropertyMap.insert(property_pair::value_type("receptionNumber",""));
                WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));

                if(Utility::ResourceExist(stsfile) ==true)
                {
                    DEBUGL8("CBox::GetDocumentList:document Name = %s\n",documentname.c_str());
                    //Read the properties from the xml file and update the same to local map of document class.
                    Utility::GetAllProperties(documentPath,"documentproperties.xml",WebDAVpropertyMap);
                    WebDAVpropertyMap["documentName"]=  documentname;
                }
                else
                {
                    DEBUGL8("CBox::GetDocumentList:Folder found hence skipping\n");
                    continue;
                }
                // GetDocument
                pDocRef = NULL;
                try 
                {
                    pDocRef = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"",documentname);
                    if(!pDocRef)
                    {
                        DEBUGL8("CBox::GetDocumentList: doc object is null\n");
                        return STATUS_FAILED;
                    }
                    ret = dynamic_cast<CDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBox::GetDocumentList::Loading Box is failed\n");
                        continue;
                    }
                }  
                catch(exception &e)
                {
                    DEBUGL1("CFolder::::GetDocumentList: Caught exception (%s)\n",e.what());
                    pDocRef = NULL;
                    return STATUS_FAILED;
                }
                list.push_back(pDocRef);								
            }
            DEBUGL4("CBox::GetDocumentList::Exit\n");
            return STATUS_OK;
        }
        Status CBox::GetDocumentListToDelete(DocumentList &list) 
        {
           DEBUGL4("CBoxDocument::GetDocumentListToDelete: Enter\n");
           //Now get the list of the documents inside the boxpath and then check the status of the documents.
           std::vector<CString> vec;
           std::vector<CString>::iterator dIt;
           CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
           //Now get the list of files present under the boxbasepath.
           if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
           {
              DEBUGL1("CBoxDocument::GetDocumentListToDelete::Getting collection list is failed");
              return STATUS_FAILED;
           }
           CString documentname,documentPath;
           CString stsfile;
           DocumentRef pDocRef = NULL;
           Status ret;
           std::map<CString, CString>::iterator propIterator;
           std::map<CString, CString> WebDAVpropertyMap;
           typedef std::map<CString, CString> property_pair;
           int from = 0, size = 65535;
		   CString stringArray[7] = {"documentName", "jobType", "totalSize", "totalPages", "creationDate", 
										"lastModifiedDate", "cutDocument"};
           for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
           {
              documentname = vec[i];
              documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,documentname,"");
              stsfile = documentPath + "/.document";

              WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
              WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));

              if(Utility::ResourceExist(stsfile) ==true)
              {
                 DEBUGL8("CBox::GetDocumentList:document Name = %s\n",documentname.c_str());
                 //Read the properties from the xml file and update the same to local map of document class.
                 Utility::GetPropertyMaps(documentPath,"documentproperties.xml",WebDAVpropertyMap,stringArray, 7);
                 WebDAVpropertyMap["documentName"]=  documentname;
              }
              else
              {
                 DEBUGL8("CBox::GetDocumentList:Folder found hence skipping\n");
                 continue;
              }
              // GetDocument
              pDocRef = NULL;
              try 
              {
                 pDocRef = new CViewDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"",documentname);
                 if(!pDocRef)
                 {
                    DEBUGL8("CBox::GetDocumentList: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 ret = dynamic_cast<CViewDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CBox::GetDocumentList::Loading Box is failed\n");
                    continue;
                 }
              }  
              catch(exception &e)
              {
                 DEBUGL1("CFolder::::GetDocumentList: Caught exception (%s)\n",e.what());
                 pDocRef = NULL;
                 return STATUS_FAILED;
              }
              list.push_back(pDocRef);								
           }
           DEBUGL4("CBoxDocument::GetDocumentListToDelete: Exit\n");			
           return STATUS_OK;
        }

        Status CBox::GetViewDocumentList(DocumentList &list) 
        {
            return GetViewDocumentList(list, 0, 65535);
        }

        Status CBox::GetViewDocumentList(DocumentList &list,unsigned int from, unsigned int size) 
        {
           DEBUGL4("CBox::GetViewDocumentList: Enter\n");
           //Now get the list of the documents inside the boxpath and then check the status of the documents.
           std::vector<CString> vec;
           std::vector<CString>::iterator dIt;
           CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
           //Now get the list of files present under the boxbasepath.
           if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
           {
              DEBUGL1("CBox::GetViewDocumentList::Getting collection list is failed");
              return STATUS_FAILED;
           }
           CString documentname,documentPath;
           CString stsfile;
           DocumentRef pDocRef = NULL;
           Status ret;
           std::map<CString, CString>::iterator propIterator;
           std::map<CString, CString> WebDAVpropertyMap;
           typedef std::map<CString, CString> property_pair;
           //int from = 0, size = 65535;
		   CString stringArray[9] = {"documentName", "jobType", "totalSize", "totalPages", "creationDate", 
										"lastModifiedDate", "cutDocument", "jobTypeColorMap", "paperSizeMap"};
           for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
           {
              documentname = vec[i];
              documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,documentname,"");
              stsfile = documentPath + "/.document";

              WebDAVpropertyMap.insert(property_pair::value_type("documentName", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobType", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalSize", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("totalPages", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
              WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate", ""));			
              WebDAVpropertyMap.insert(property_pair::value_type("cutDocument",""));
              WebDAVpropertyMap.insert(property_pair::value_type("jobTypeColorMap",""));
              WebDAVpropertyMap.insert(property_pair::value_type("paperSizeMap",""));        

              if(Utility::ResourceExist(stsfile) ==true)
              {
                 DEBUGL8("CBox::GetViewDocumentList:document Name = %s\n",documentname.c_str());
                 //Read the properties from the xml file and update the same to local map of document class.
                 Utility::GetPropertyMaps(documentPath,"documentproperties.xml",WebDAVpropertyMap,stringArray, 9);
                 WebDAVpropertyMap["documentName"]=  documentname;
              }
              else
              {
                 DEBUGL8("CBox::GetViewDocumentList:Folder found hence skipping\n");
                 continue;
              }
              // GetDocument
              pDocRef = NULL;
              try 
              {
                 pDocRef = new CViewDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"",documentname);
                 if(!pDocRef)
                 {
                    DEBUGL8("CBox::GetViewDocumentList: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 ret = dynamic_cast<CViewDocument*>(pDocRef.operator->())->LoadProperties(WebDAVpropertyMap);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CBox::GetViewDocumentList::Loading Box is failed\n");
                    continue;
                 }
              }  
              catch(exception &e)
              {
                 DEBUGL1("CBox::GetViewDocumentList: Caught exception (%s)\n",e.what());
                 pDocRef = NULL;
                 return STATUS_FAILED;
              }
              list.push_back(pDocRef);								
           }
           DEBUGL4("CBox::GetViewDocumentList: Exit\n");			
           return STATUS_OK;
        }


        Status CBox::CreateFolder(CString foldername)
        {
            FolderRef folder=NULL;
            return CreateFolder(folder,foldername);
        }

        Status CBox::CreateFolder(FolderRef& folder, CString foldername) 
        {
            DEBUGL4("CBox::CreateFolder::Enter\n");

            // confirm folder name is NOT empty
            if(foldername.empty()) 
            {
                DEBUGL1("CBox::CreateFolder::Folder name is empty\n");
                return STATUS_FAILED;
            }

            //Check if the folder doesnot exceed the Folder Limit
            unsigned int count = 0;
            Status rst;
            if(Utility::GetFolderCount(m_BoxBasePath,m_BoxNumber,count)!=STATUS_OK)
            {
                DEBUGL1("CBox::CreateFolder::GetFolderCount Failed\n");
                return STATUS_FAILED;		
            }
            if(count>=CBoxDocument::FOLDER_LIMIT)
            {
                DEBUGL1("CBox::CreateFolder::Folder Limit reached\n");
                return STATUS_MAX_ALLOWED_RESOURCES_REACHED;			
            }

            // confirm boxbasepath folder already exists
            CString path = "/" + m_BoxBasePath + "/";
            if(!Utility::ResourceExist(path)) 
            {
                DEBUGL1("CBox::CreateFolder::boxbasepath %s is not found\n", m_BoxBasePath.c_str());
                return STATUS_FAILED;
            }

            // confirm boxnumber folder already exists
            if(!Utility::ResourceExist(m_BoxBasePath, m_BoxNumber)) 
            {
                DEBUGL1("CBox::CreateFolder::boxnumber %s is not found\n", m_BoxNumber.c_str());
                return STATUS_FAILED;
            }

            // confirm foldername folder doesn't exist
            if(Utility::ResourceExist(m_BoxBasePath, m_BoxNumber, foldername)) 
            {
                DEBUGL1("CBox::CreateFolder::foldername %s already exists\n", foldername.c_str());
                return STATUS_RESOURCE_WITH_SAME_NAME_EXISTS;
            }

            Status ret;
	    bool bHasAvailableSize = false;
	    ret = Utility::IsStorageFull(bHasAvailableSize);
	    if(ret != STATUS_OK)
	    {
		    DEBUGL1("CBox::CreateFolder:: IsStorageFull() API failed for /storage \n");
		    return STATUS_FAILED;
	    }
	    else
	    {
		    if(!bHasAvailableSize)
		    {
			    DEBUGL1("CBox::CreateFolder:: /storage is near full return STATUS_DISK_FULL\n");
			    return STATUS_DISK_FULL;
		    }
	    }
	    ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> BoxpathPtr = NULL;
	    path = path + m_BoxNumber + "/" + foldername + "/";

		    Status ds = ci::operatingenvironment::Folder::CreateFolder(BoxpathPtr,path.c_str());	
		    if(ds != STATUS_OK)
		    {
			    rst = Utility::RemoveResource(path);
			    if(rst != STATUS_OK)
				    DEBUGL2("CBoxDocument::CreateFolder: Failed to remove half created folder\n");

			    DEBUGL1("CBoxDocument::CreateFolder::Creation of %s Failed\n", path.c_str());
			    return ds;	
		    }
		    if(!BoxpathPtr)
		    {
			    DEBUGL1("CBoxDocument::CreateBox::<%s> Folder Creation Failed\n",path.c_str());
			    return STATUS_FAILED;
		    }
		    // get folder instance
		    folder = new CFolder(m_sessionID, m_BoxBasePath, m_BoxNumber, foldername);

		    //Copy folderproperties.xml file to folder path	
		    CString origPropertyPath = Utility::GetEB2ROOTPath() + "/bin/folderproperties.xml"; 
		    DEBUGL8("CBoxDocument::CreateFolder: origPropertyPath = (%s)\n",origPropertyPath.c_str());
		    DEBUGL8("CBoxDocument::CreateFolder: toath = (%s)\n",path.c_str());
		    dom::DocumentRef domDocRef;
		    ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
		    pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
		    if (!pHDB)
		    {
			    DEBUGL1("CBoxDocument::CreateFolder: Failed to Acquire HierarchicalDB\n");
			    return STATUS_FAILED;
		    }

		    ds = pHDB->CreateDocumentFromFile(path, "folderproperties_dom", domDocRef, origPropertyPath);
		    if(ds != STATUS_OK)
		    {
			    DEBUGL1("CBoxDocument::CreateFolder::Creation of %s Failed\n", path.c_str());
			    rst = Utility::RemoveResource(path);
			    if(rst != STATUS_OK)
				    DEBUGL2("CBoxDocument::CreateFolder: Failed to remove half created folder\n");

			    return ds;	
		    }
            try
            {
                if(!folder)
                {
                    DEBUGL8("CBox::CreateFolder: folder object is null\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CFolder*>(folder.operator->())->SaveProperties();
                if (ret != STATUS_OK) {
                    DEBUGL1(" CBoxDocument::CreateFolder:: SaveProperties failed \n");
                    folder = NULL; // release
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("CBoxDocument::CreateFolder: Caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }
            if(ret != STATUS_OK) 
            {
                DEBUGL1("CBox::CreateFolder::Creating Folder is failed\n");
                folder = NULL; // release
                rst = Utility::RemoveResource(path);
                if(rst != STATUS_OK)
                    DEBUGL2("CBox::CreateFolder: Failed to remove half created folder\n");

                return ret;
            }



            std::map<CString, CString> PropertyMap;
            CString xmlfile("folderproperties.xml");
            PropertyMap.insert(pair::value_type("totalFolderSize","0"));
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            if(st!=STATUS_OK)
            {
                DEBUGL1("CBox::CreateFolder::SetProperty Failed\n");
                folder = NULL; // release		
                rst = Utility::RemoveResource(path);
                if(rst != STATUS_OK)
                    DEBUGL2("CBox::CreateFolder: Failed to remove half created folder\n");

                return st;
            }	

            DEBUGL4("CBox::CreateFolder::Exit\n");
            return STATUS_OK;
        }

        Status CBox::GetFolder(FolderRef& folder, CString foldername) 
        {
            DEBUGL4("CBox::GetFolder::Enter\n");
            // confirm folder name is NOT empty
            if(foldername.empty()) 
            {
                DEBUGL1("CBox::GetFolder::Folder name is empty\n");
                return STATUS_FAILED;
            }

            if(!Utility::ResourceExist(m_BoxBasePath, m_BoxNumber, foldername)) 
            {
                DEBUGL1("CBox::GetFolder::Folder is not found\n");
                return STATUS_RESOURCENOTFOUND;
            }

            folder = new CFolder(m_sessionID, m_BoxBasePath, m_BoxNumber, foldername);
            try
            {
                if(!folder)
                {
                    DEBUGL8("CBox::GetFolder: folder object is null\n");
                    return STATUS_FAILED;
                }
                Status ret = dynamic_cast<CFolder*>(folder.operator->())->LoadProperties();
                if(ret != STATUS_OK) 
                {
                    DEBUGL1("CBox::GetFolder::Loading Folder is failed\n");
                    folder = NULL; // release
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("CFolder::GetFolder:: Caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }
            DEBUGL4("CBox::GetFolder::Exit\n");
            return STATUS_OK;
        }

        Status CBox::GetFolderList(FolderList &list)
        {
            return GetFolderList(list, 0, 65535);
        }

        Status CBox::GetFolderList(FolderList &list,unsigned int from, unsigned int size) 
        {
            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            //Now get the list of files present under the boxbasepath.
            if(Utility::GetCollectionList(vec,path)!=STATUS_OK)
            {
                DEBUGL1("CBoxDocument::GetFolderList::Getting collection list is failed");
                return STATUS_FAILED;
            }
            CString foldername,documentPath;
            CString stsfile;
            DocumentRef pDocRef = NULL;
            std::map<CString, CString>::iterator propIterator;
            std::map<CString, CString> WebDAVpropertyMap;
            typedef std::map<CString, CString> property_pair;					
            for(unsigned int i = from,cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++)
            {
                foldername = vec[i];
                documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,foldername,"");
                stsfile = documentPath + "/.document";

                WebDAVpropertyMap.insert(property_pair::value_type("folderName", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("creationDate", ""));
                WebDAVpropertyMap.insert(property_pair::value_type("lastAccessDate",""));
                WebDAVpropertyMap.insert(property_pair::value_type("lastModifiedDate",""));
                if(Utility::ResourceExist(stsfile) !=true)
                {
                    DEBUGL8("CBox::GetDocumentList:Folder Name = %s\n",foldername.c_str());
                    //Read the properties from the xml file and update the same to local map of document class.
                    Utility::GetAllProperties(documentPath,"folderproperties.xml",WebDAVpropertyMap);
                    WebDAVpropertyMap["folderName"]=  foldername;				

                }
                else
                {
                    DEBUGL8("CBox::GetDocumentList:document found hence skipping\n");
                    continue;
                }
                // Get Folder reference
                FolderRef folder = NULL;
                folder = new CFolder(m_sessionID, m_BoxBasePath, m_BoxNumber, foldername);
                try 
                {
                    if(!folder)
                    {
                        DEBUGL8("CBox::GetDocumentList: folder object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CFolder*>(folder.operator->())->LoadProperties(WebDAVpropertyMap);
                    if(ret != STATUS_OK) 
                    {
                        DEBUGL1("CBox::GetFolderList::Loading Folder is failed\n");
                        continue;
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1(" CBox::GetFolderList Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
                list.push_back(folder);		
            }
            DEBUGL4("CBox::GetFolderList::Exit\n");
            return STATUS_OK;
        }

        Status CBox::DeleteFolder(CString foldername)
        {
            DEBUGL4("CBox::GetFolder::DeleteFolder  Enter\n");
            // confirm folder name is NOT empty
            if(foldername.empty()) 
            {
                DEBUGL1("CBox::GetFolder::DeleteFolder name is empty\n");
                return STATUS_FAILED;
            }

            CString extractfilename = "";
            if(Utility::GetUniqueFile(m_BoxBasePath+"/"+m_BoxNumber+"/"+foldername, extractfilename, ".extractisinprogress_", false) != STATUS_OK)
                DEBUGL2("CBox::DeleteFolder: Unable to get the file\n");

            DEBUGL8("CBox::DeleteFolder: extractfilename (%s)\n", extractfilename.c_str());

            if(!extractfilename.empty())
            {
                DEBUGL1("CBox::DeleteFolder: Delete folder of (%s) Folder Failed... Extraction is in progress\n",foldername.c_str());
                return STATUS_USER_USING;
            }

            CString savefilename = "";
            if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber + "/" + foldername, savefilename, ".saveisinprogress_", false) != STATUS_OK)
                DEBUGL2("CBox::DeleteFolder: Unable to get the file\n");

            DEBUGL8("CBox::DeleteFolder: savefilename (%s)\n", savefilename.c_str());

            if(!savefilename.empty())
            {
                DEBUGL1("CBox::DeleteFolder: Delete folder (%s) is Failed... Save is in progress\n",foldername.c_str());
                return STATUS_USER_USING;
            }

            //Now get the list of the documents inside the boxpath and then check the status of the documents.
            std::vector<CString> vec;
            std::vector<CString>::iterator dIt;
            CString pFolderPath= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,foldername,"");
            if(!Utility::ResourceExist(pFolderPath))
            {
                DEBUGL1("CBox::DeleteFolder::folder <%s> does not exist\n",foldername.c_str());
                return STATUS_RESOURCENOTFOUND;	
            }
            DEBUGL8("CBox::GetFolder::DeleteFolder  folder path (%s)\n",pFolderPath.c_str());	
            //Now get the list of files present under the folder.
            if(Utility::GetCollectionList(vec,pFolderPath)!=STATUS_OK)
            {
                DEBUGL1("CBox::DeleteFolder::Getting collection list is failed");
                return STATUS_FAILED;
            }

            CString documentPath;
            CString stsfile;
            for(dIt= vec.begin(); dIt != vec.end(); dIt++) 
            {
                documentPath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,foldername,(*dIt));
                DEBUGL8("CBox::GetFolder::DeleteFolder  documentPath (%s)\n",documentPath.c_str());			
                stsfile = documentPath + "/ready.sts";
                if(!Utility::ResourceExist(stsfile))
                {
                    //check if document is in editing state.
                    stsfile = documentPath + "/editing.sts";
                    if(Utility::ResourceExist(stsfile)==true)
                    {
                        DEBUGL1("CBox::DeleteFolder::Document Status is EDITING return STATUS_USER_EDITING");
                        return STATUS_USER_EDITING;				
                    }

                    //check if document is using state.
                    stsfile = documentPath + "/using.sts";
                    if(Utility::ResourceExist(stsfile)==true)
                    {
                        DEBUGL1("CBox::DeleteFolder::Document Status is USING return STATUS_USER_USING");
                        return STATUS_USER_USING;				
                    }		
                    //check if document is reserving state.
                    stsfile = documentPath + "/reserving.sts";
                    if(Utility::ResourceExist(stsfile)==true)
                    {
                        DEBUGL1("CBox::DeleteFolder::Document Status is RESERVING. return STATUS_USER_USING");
                        return STATUS_USER_USING;				
                    }		
                    DEBUGL1("CBox::DeleteFolder::Document Status is not READY");
                    return STATUS_FAILED;
                }
                CString flag;	
                //Check if document is being used by user.
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,foldername,(*dIt),"","cutDocument",flag) == STATUS_OK)
                {
                    DEBUGL8("CBox::DeleteFolder::GetProperty is passed.\n");
                    if(flag == "true"){

                        DEBUGL1("CBox::DeleteFolder::Document Status is being used by the user. return STATUS_USER_USING");
                        return STATUS_USER_USING;
                    }
                }
            }

            //Now delete the Folder
            if((ci::operatingenvironment::Folder::Remove(pFolderPath,true) != STATUS_OK))
            {
                DEBUGL1("CBox::DeleteFolder::Deleting %s folder Failed\n",foldername.c_str());
                return STATUS_FAILED;
            }
            DEBUGL4("CBox::GetFolder::DeleteFolder  Exit\n");	
            return STATUS_OK;
        }

        Status CBox::SetWebDAVProperty(CString key, CString value)
        {
            return SetProperty(key, value);
        }

        Status CBox::SetProperty(CString key, CString value) 
        {
            std::map<CString, CString> PropertyMap;
            CString xmlfile("boxproperties.xml");
            CString modifiedtime = Utility::GetUnixTime();
            m_WebDAVProperties[key] = value;
            PropertyMap.insert(pair::value_type(key.c_str(), value.c_str()));
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
	    m_WebDAVProperties["lastAccessDate"] = modifiedtime.c_str();
	    m_WebDAVProperties["lastModifiedDate"] = modifiedtime.c_str();
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            return st;
        }

        Status CBox::GetWebDAVProperty(CString key, CString &value) 
        {
            return GetProperty(key, value);
        }

        Status CBox::GetProperty(CString key, CString &value) 
        {
            value = m_WebDAVProperties[key];
            return STATUS_OK;
        }

        Status CBox::SetName(CString name)
        {
            std::map<CString, CString> PropertyMap;
            CString xmlfile("boxproperties.xml");
            CString modifiedtime = Utility::GetUnixTime();
            m_BoxName = name;
            PropertyMap.insert(pair::value_type("boxName", name));
            PropertyMap.insert(pair::value_type("lastAccessDate", modifiedtime.c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate", modifiedtime.c_str()));	
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
	    m_WebDAVProperties["lastAccessDate"] = modifiedtime.c_str();
            m_WebDAVProperties["lastModifiedDate"] = modifiedtime.c_str();
	    m_WebDAVProperties["boxName"] = name.c_str();
            Status st = Utility::SetProperties(path,xmlfile,PropertyMap);	
            return st;
        }

        Status CBox::GetName(CString &name) 
        {
            name = m_BoxName;
            return STATUS_OK;
        }

        Status CBox::GetNumber(CString &number) 
        {
            number = m_BoxNumber;
            return STATUS_OK;
        }
       
        Status CBox::CutDocument(CString docname) 
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CutDocument(documents));
        }

        Status CBox::CutDocument(std::vector<CString> documents) 
        {
            DEBUGL4("CBox::CutDocument: Enter\n");
            std::vector<CString>::iterator iter;
            std::vector<CString> vec;
            std::map<CString, CString> PropertyMap;
            CString xmlfile("documentproperties.xml");

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBox::CutDocument: Getting collection list failed");
                return STATUS_FAILED;
            }

            //Delete Clipboard documents,if any
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/"; 
            
				DEBUGL8("CBox::CutDocument: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());

		 //Check if the clipborad document is of the same user
                CString sid;		
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
                {
                    DEBUGL1("CBox::CutDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }		
                DEBUGL8("CBox::CutDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());
                if(sid!=m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CBox::DeleteFolder::Deleting %s Document Failed\n",resourceKey.c_str());
                    return STATUS_FAILED;
                }
            }

            //Refresh all the documents in the Box
            DocumentList docList;
            DocumentList::iterator doc;	
            if(GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CBox::CutDocument::Getting document list is failed\n");
                return STATUS_FAILED;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {
                    CString docName;
                    (*doc)->GetName(docName);
                    if(UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CutDocument:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        return STATUS_FAILED;			
                    }
                }
            }

            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CBox::CutDocument:Document <%s>\n",(*iter).c_str());		
                if(((*iter).empty()))
                {
                    DEBUGL1("CBox::CutDocument: Document name empty\n");
                    return STATUS_FAILED;
                }			

                //Obtain the document
                DocumentRef doc;
                GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CBox::CutDocument: Given Document does not exist\n");
                    return STATUS_RESOURCENOTFOUND;
                }
                //Fill the vector with document names.
                //In case if we find any document in edit state we have to undo all other documents.
                notEditDocuments.push_back(*iter);


                // check current status
                DocStatus st;
                doc->GetStatus(st);
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CBox::CutDocument: document is being used by another user <status: %d>\n", st);
                    return STATUS_USER_USING;
                }
                if(st != READY) 
                {
                    DEBUGL1("CBox::CutDocument: Document is NOT in READY state\n");
                    if(UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CutDocument:UndoEditDocument for Failed\n");
                        return STATUS_FAILED;			
                    }
                    return STATUS_USER_EDITING;
                }
                //Original doc path 
                CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,(*iter)) + "/";

                //Check for the user
                CString orgUserID;
                //CString cPath = from + (*iter);
                if(Utility::GetProperty(from,"documentproperties.xml","sessionID",orgUserID)!=STATUS_OK)		
                {
                    DEBUGL1("CBox::CutDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }
                if((!(orgUserID.empty()))&&(m_sessionID != orgUserID))
                {
                    DEBUGL1("CBox::CutDocument: Document being used by other user\n");
                    return STATUS_FAILED;
                }
                    PropertyMap.clear(); 
                    if(orgUserID.empty())
                {
                    //update the sessionID 
                    PropertyMap.insert(pair::value_type("sessionID",m_sessionID.c_str()));
                }
                    //update the sessionID and cutDocument flag 
                    PropertyMap.insert(pair::value_type("cutDocument","true"));
                    DEBUGL8("CBox::CutDocument:SetProperty cutDocument\n");	
                    Status sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)	
                    {	
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBox::CutDocument:SetProperty for SessionID failed because Disk is Full\n");
                            return  STATUS_DISK_FULL;
                        }
                        DEBUGL1("CBox::CutDocument:SetProperty for SessionID Failed\n");
                        return STATUS_FAILED;
                    }	

                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, "", (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CBox::CutDocument: GetProperty of WorkspaceDocName failed\n");
                    return STATUS_FAILED;
                }

                //Clipboard doc path
                Status rst;
                //CString newDocName=m_sessionID+"_"+m_BoxNumber+"_"+(*iter);
                //CString to = CLIPBOARD_PATH + newDocName + "/";
                CString newDocName = m_sessionID + "_" + WorkspaceDocName;
				ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> ClipboardpathPtr = NULL;
				CString to =CLIPBOARD_PATH + newDocName;
	            Status ds= ci::operatingenvironment::Folder::CreateFolder(ClipboardpathPtr,to.c_str());
				if(!ClipboardpathPtr)
				{
					DEBUGL1("CBoxDocument::CreateFolder::ClipboardpathPtr is NULL\n");	
				}
				if(ds != STATUS_OK)
				{
					rst = Utility::RemoveResource(to);
					if(rst != STATUS_OK)
						DEBUGL2("CBoxDocument::CreateFolder: Failed to remove half created folder\n");

					DEBUGL1("CBoxDocument::CreateFolder::Creation of %s Failed\n", to.c_str());
					return ds;	
				}
				to = to + "/";
				CString fromdocxml = from + "/documentproperties.xml";
				CString fromdocdom = from + "/documentproperties_dom";
				Status retsts = ci::operatingenvironment::File::CopyFile(fromdocxml,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CBox::CutDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CutDocument: Failed to remove half created folder\n");			

                    return retsts;
                }
		retsts = ci::operatingenvironment::File::CopyFile(fromdocdom,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CBox::CutDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CutDocument: Failed to remove half created folder\n");			

                    return retsts;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                PropertyMap.clear();
                CString docxmlfile("documentproperties.xml");
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",""));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                Status stn = Utility::SetProperties(to,docxmlfile,PropertyMap); 
                if(stn != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CutDocument: Failed to remove half created folder\n");

                    if(stn == STATUS_DISK_FULL) 
                    {
                        DEBUGL1("CBox::CutDocument:SetProperty for SessionID failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }

                    return STATUS_FAILED;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();
                CString ext;
                PageRef page;					
                if(doc->GetPage(1, page) != STATUS_OK) 
                {
                    DEBUGL1("CBox::CopyDocument: Getting page %d failed\n", strpageno.c_str());
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CutDocument: Failed to remove half created folder\n");
                    return STATUS_FAILED;
                }	
                try
                {
                    if(!page)
                    {
                        DEBUGL8("CBox::CopyDocument: page object is null\n");
                        return STATUS_FAILED;
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                }      
                catch(exception &e)
                {
                    DEBUGL1("CBox::CopyDocument: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
                CString pagePath=from+"Image/"+strpageno+ext;
                PropertyMap.clear();
                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));

                ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);			
                pagePath=from+"Subsampling/"+strpageno+ext;
                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));

                ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                pagePath=from+"Thumbnail/"+strpageno+ext;

                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));

                stn = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap); 
                if(stn != STATUS_OK)	
                {
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK) {
                        DEBUGL1("CBox::CutDocument: Failed to remove half created folder\n");
                        return rst;
                    }
                    if(stn == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::CutDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent failed because Disk is Full\n");           			
                        return STATUS_DISK_FULL; 
                    } 
                    DEBUGL1("CBox::CutDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent Failed\n");						
                    return STATUS_FAILED;
                }	

            }

            DEBUGL4("CBox::CutDocument:Exit\n");
            return STATUS_OK;
        }

        Status CBox::CopyDocument(CString docname) 
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CopyDocument(documents));
        }

        Status CBox::CopyDocument(std::vector<CString> documents) 
        {
            DEBUGL4("CBox::CopyDocument: Enter\n");
            std::vector<CString>::iterator iter;
            std::vector<CString> vec;
            CString xmlfile("documentproperties.xml");
            Status sdf;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBox::CopyDocument: Getting collection list failed");
                return STATUS_FAILED;
            }

            //Delete Clipboard documents,if any
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                CString documentname;		
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

				DEBUGL8("CBox::CopyDocument: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());

                //Check if the clipborad document is of the same user
                CString sid;		
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
                {
                    DEBUGL1("CBox::CopyDocument:GetProperty SID Failed\n");
                    return STATUS_FAILED;
                }		
                DEBUGL8("CBox::CopyDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());
                if(sid!=m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CBox::CopyDocument::Deleting %s Document Failed\n",resourceKey.c_str());
                    return STATUS_FAILED;
                }
            }

            //Refresh all the documents in the Box
            DocumentList docList;
            DocumentList::iterator doc;	
            if(GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CBox::CopyDocument::Getting document list is failed\n");
                return STATUS_FAILED;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                //To fix FR_5285, added check to verify if the document is in editing then should not
                //reset session id and cutdocument flag. 
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {
                    CString docName;
                    (*doc)->GetName(docName);
                    if(UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CopyDocument:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        return STATUS_FAILED;			
                    }
                }
            }
            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CBox::CopyDocument:Document <%s>\n",(*iter).c_str());	
                if(((*iter).empty()))
                {
                    DEBUGL1("CBox::CopyDocument: Document name empty");
                    return STATUS_FAILED;
                }			

                //Obtain the original document
                DocumentRef doc;
                GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CBox::CopyDocument: Given Document does not exist\n");
                    return STATUS_RESOURCENOTFOUND;
                }

                notEditDocuments.push_back(*iter);

                // check current status
                DocStatus st;
                doc->GetStatus(st);
                //if(!(st== READY || st==USING || st==EDITING)) 
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CBox::CopyDocument: document is being used by another user<status: %d>\n", st);			
                    return STATUS_USER_USING;
                }
                if(!(st== READY || st==EDITING)) 
                {
                    DEBUGL1("CBox::CopyDocument: Document is NOT in READY/EDITING state\n");
                    if(UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::CopyDocument:UndoEditDocument for Failed\n");
                        return STATUS_FAILED;			
                    }
                    return STATUS_FAILED;
                }
                if(st == EDITING)
                {
                    DEBUGL1("CBox::CopyDocument: Document is editing state\n");
                    return STATUS_USER_EDITING;
                }
                //Original doc path 
                CString from = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,(*iter)) + "/";

                //Set the session-ID on the orignal document
                std::map<CString,CString> PropertyMap;
                PropertyMap.clear();
                //update the sessionID and cutDocument flag 
                PropertyMap.insert(pair::value_type("sessionID",m_sessionID.c_str()));
                PropertyMap.insert(pair::value_type("cutDocument","false"));
                sdf = Utility::SetProperties(from,xmlfile,PropertyMap); 
                if(sdf != STATUS_OK)	
                {	
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::CopyDocument:SetProperty for SessionID failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::CopyDocument:SetProperty for SessionID Failed\n");
                    return STATUS_FAILED;
                }			
                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(m_BoxBasePath, m_BoxNumber, "", (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CBox::CopyDocument: GetProperty of WorkspaceDocName failed\n");
                    return STATUS_FAILED;
                }

                //Clipboard doc path
                Status rst;
                //CString newDocName=m_sessionID+"_"+m_BoxNumber+"_"+(*iter)+"/";
                //CString to = CLIPBOARD_PATH + newDocName;
                CString newDocName = m_sessionID + "_" + WorkspaceDocName;
                CString to = CLIPBOARD_PATH + newDocName;
                Status retsts = ci::operatingenvironment::Folder::CopyDir(from,to);
                if (retsts !=STATUS_OK)	
                {
                    DEBUGL1("CBox::CopyDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL2("CBox::CopyDocument: Failed to remove half created folder\n");				
                    return retsts;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                CString docxmlfile("documentproperties.xml");
                PropertyMap.clear();
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",m_BoxBasePath));
                PropertyMap.insert(pair::value_type("srcBoxNumber",m_BoxNumber));
                PropertyMap.insert(pair::value_type("srcFolderName",""));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                sdf = Utility::SetProperties(to,docxmlfile,PropertyMap); 
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL2("CBox::CopyDocument: Failed to remove half created folder\n");
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::CopyDocument:SetProperty for SessionID failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::CopyDocument:SetProperty for SessionID Failed\n");

                    return STATUS_FAILED;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();

                PageRef page;					
                if(doc->GetPage(1, page) != STATUS_OK) 
                {
                    DEBUGL1("CBox::CopyDocument: Getting page %d failed\n", strpageno.c_str());
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL2("CBox::CopyDocument: Failed to remove half created folder\n");			
                    return STATUS_FAILED;
                }	
                PropertyMap.clear();		
                CString ext;
                try
                {
                    if(!page)
                    {
                        DEBUGL8("CBox::CopyDocument: page object is null\n");
                        return STATUS_FAILED;
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                }
                catch(exception &e)
                {
                    DEBUGL1("CBox::CopyDocument: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
                CString pagePath=from+"Image/"+strpageno+ext;
                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));

                ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                pagePath=from+"Subsampling/"+strpageno+ext;
                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));

                ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                pagePath=from+"Thumbnail/"+strpageno+ext;
                if(Utility::ResourceExist(pagePath))
                    PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));

                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap); 
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL2("CBox::CopyDocument: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::CopyDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent failed because Disk is Full\n");

                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::CopyDocument:SetProperty for IsImagedataPresent/IsSubsamplingdataPresent/IsThumbnaildataPresent Failed\n");

                    return STATUS_FAILED;
                }		

            }
            DEBUGL4("CBox::CopyDocument: Exit\n");
            return STATUS_OK;
        }

		

        Status CBox::PasteDocument() 
        {

           DEBUGL4("CBox::PasteDocument: Enter - m_BoxBasePath<%s>,m_BoxNumber<%s>\n",m_BoxBasePath.c_str(),m_BoxNumber.c_str());
           CString xmlfile("documentproperties.xml");
           std::vector<CString> vec;
           Status sdf;
           //Get the List of Documents in Clipboard
           if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
           {
              DEBUGL1("CBox::PasteDocument: Getting collection list failed");
              return STATUS_FAILED;
           }
	   int err =pthread_mutex_lock(&gbox_mutex_initializer);
	   if (err != 0)
		   DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
	   m_PastedVecofDocs.clear();
	   err =pthread_mutex_unlock(&gbox_mutex_initializer);
	   if (err != 0)
		   DEBUGL2("CBox::CreateCutThread:: pthread_mutex_lock failed\n ");
           for(unsigned int i = 0;i < vec.size(); i++) 
           {
              //Get the document name
              CString fulldocumentname = vec[i];		
              CString documentname;		
              CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
              if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 return STATUS_FAILED;
              }				
              DEBUGL8("CBox::PasteDocument: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  

              //Check for limit
              unsigned int  count=0;
              Utility::GetDocumentCount(m_BoxBasePath, m_BoxNumber,"",count);
	     //check limit for pagelogbox = PAGELOGBOX_DOC_LIMIT ; other boxes limit = DOC_LIMIT
	      if((m_BoxBasePath != "/storage/box/PageLogBoxes" && count >= CBoxDocument::DOC_LIMIT) || (count >= CBoxDocument::PAGELOGBOX_DOC_LIMIT) )
              {
                 DEBUGL1("CBox::PasteDocument: The number of documents reach limit\n");

                 //Reset cutDocument flag on all the documents which are not pasted
                 std::vector<CString> vecDoc;
                 if(Utility::GetCollectionList(vecDoc,CLIPBOARD_PATH)!=STATUS_OK) 
                 {
                    DEBUGL1("CBox::PasteDocument: Getting collection list failed");
                    return STATUS_FAILED;
                 }
                 for(unsigned int i = 0;i < vecDoc.size(); i++) 
                 {
                    //Get the document name
                    CString fulldocumentname = vecDoc[i];		
                    CString documentname;		
                    CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
                    if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)		
                    {
                       DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                       return STATUS_FAILED;
                    }				
                    DEBUGL8("CBox::PasteDocument: vector<%s>, fullDocName<%s> and docName<%s>\n",vec[i].c_str(),fulldocumentname.c_str(),documentname.c_str());	  
                    CString from = CLIPBOARD_PATH + fulldocumentname+"/";
                    CString path=Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber)+"/";
                    DEBUGL8("CBox::PasteDocument: path (%s)\n", path.c_str());		
                    CString newpath = path + documentname + "/";
                    DEBUGL8("CBox::PasteDocument: path (%s)\n", newpath.c_str());		
                    //Read the properties of the original box and see if the document is cut from the same box
                    CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
                    if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
                    {
                       DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                       return STATUS_FAILED;
                    }
                    if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
                    {
                       DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                       return STATUS_FAILED;			
                    }
                    if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
                    {
                       DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                       return STATUS_FAILED;			
                    }
                    if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
                    {
                       DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                       return STATUS_FAILED;			
                    }
                    if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
                    {
                       DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                       return STATUS_FAILED;			
                    }


                    CString orgPath;
                    if(srcFolderName.empty())
                       orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
                    else
                       orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		
	                //Reset the properties on the Original document			
                    std::map<CString,CString> PropertyMap;
                    PropertyMap.clear();
                    //update the sessionID and cutDocument flag 
                    //PropertyMap.insert(pair::value_type("sessionID",""));
                    PropertyMap.insert(pair::value_type("cutDocument",""));
                    sdf = Utility::SetProperties(orgPath,xmlfile,PropertyMap); 
                    if(sdf != STATUS_OK)	
                    {	
                       Status rst = Utility::RemoveResource(resourceKey);
                       if(rst != STATUS_OK)
                          DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                       if(sdf == STATUS_DISK_FULL)
                       {
                          DEBUGL1("CBox::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

                          return STATUS_DISK_FULL;
                       }

                       DEBUGL1("CBox::PasteDocument:SetProperty for SessionID Failed\n");

                       return STATUS_FAILED;
                    }					
                 }

                 return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
              }

              //Check if the clipbaord document is of the same user
              CString sid;
              if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 return STATUS_FAILED;
              }				

              DEBUGL8("CBox::PasteDocument: SID <%s> and m_sessionID <%s>\n",sid.c_str(),m_sessionID.c_str());

			  if(sid!=m_sessionID)
			  {
				  DEBUGL2("CBox::PasteDocument:Session ID's are different hence continuing\n");
				  continue;
			  }
			  CString from = CLIPBOARD_PATH + fulldocumentname+"/";
			  CString path=Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber)+"/";
			  DEBUGL8("CBox::PasteDocument: path (%s)\n", path.c_str());		
			  CString newpath = path + documentname + "/";
			  DEBUGL8("CBox::PasteDocument: path (%s)\n", newpath.c_str());		
			  //Read the properties of the original box and see if the document is cut from the same box
			  CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
			  if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
			  {
				  DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
				  return STATUS_FAILED;
			  }
			  if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
              {
                 DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                 return STATUS_FAILED;			
              }
              if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
              {
                 DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                 return STATUS_FAILED;			
              }
              if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
              {
                 DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                 return STATUS_FAILED;			
              }
              if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
              {
                 DEBUGL1("CBox::PasteDocument: Getproperty failded\n");			
                 return STATUS_FAILED;			
              }


              CString orgPath;
              if(srcFolderName.empty())
                 orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
              else
                 orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

              DEBUGL8("CBox::PasteDocument: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
		
			  bool bSamePath = false;

			  CString truncdocname = "";
			  
              Status rst;		
              //In case of cut document and paste in different box
              //check if same resource exist and if exist increment document name
              CString NewWorkspaceDocName("");
              if(orgPath.compare(newpath) && (cutDocumentFlag == "true"))
			  {
				  if(documentname.length()>64)
				  {
					  DEBUGL8("CBox::PasteDocument:calling TruncateDocumentName() during CUT operation..document name is more than 64 characters\n");
					  rst = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
					  if(rst != STATUS_OK)
						  DEBUGL1("CBox::PasteDocument:TruncateDocumentName has not returned STATUS_OK\n");
					  documentname = truncdocname;
					  newpath = path + documentname;
				  }		
				  if(Utility::ResourceExist(newpath))
				  {
					  DEBUGL8("CBox::PasteDocument:document with the same document name is already present\n");
					  rst = Utility::LimitTo64Characters(documentname,newpath,path);
					  if(rst != STATUS_OK)
						  DEBUGL1("CBox::PasteDocument:LimitTo64Characters has not returned STATUS_OK\n");
				  }
				  if(m_returnpastedocname)
				  {
					  err =pthread_mutex_lock(&gbox_mutex_initializer);
					  if (err != 0)
						  DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
					m_PastedVecofDocs.push_back(documentname.c_str());
					err =pthread_mutex_unlock(&gbox_mutex_initializer);
					if (err != 0)
						DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
			          }
			  }
              //In case of copy operation, if same document exist increment document name
			  else if(cutDocumentFlag == "false" || cutDocumentFlag == "")
			  {
				  DEBUGL8("CBox::PasteDocument: Its a copy operation\n");
				  if(documentname.length()>64)
				  {
					  DEBUGL8("CBox::PasteDocument:calling TruncateDocumentName() during COPY operation..document name is more than 64 characters\n");
					  rst = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);			
					  if(rst != STATUS_OK)
						  DEBUGL1("CBox::PasteDocument:TruncateDocumentName has not returned STATUS_OK\n");
					  documentname = truncdocname;
					  newpath = path + documentname;

				  }
				  if(Utility::ResourceExist(newpath))
				  {
					  DEBUGL8("CBox::PasteDocument:document with the same document name is already present\n");
					  rst = Utility::LimitTo64Characters(documentname,newpath,path);
					  if(rst != STATUS_OK)
						  DEBUGL1("CBox::PasteDocument:LimitTo64Characters has not returned STATUS_OK\n");
				  }
				  NewWorkspaceDocName = CUUID().toString();
				  if(m_returnpastedocname)
				  {
					  int err =pthread_mutex_lock(&gbox_mutex_initializer);
					  if (err != 0)
						  DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
					m_PastedVecofDocs.push_back(documentname.c_str());
					err =pthread_mutex_unlock(&gbox_mutex_initializer);
					if (err != 0)
						DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");

				  }
			  }

              //In case of cut operation since the original document exist, remove it
              //and then copy the updated document from clipboard
              Status retsts;
              if(cutDocumentFlag == "true")
			  {
				  CString to = newpath;
				  if(!orgPath.compare(newpath) )
				  {
					  bSamePath = true;
				  }
				  CString pasteboxpath,pasteboxnumber,pastefoldername,pasteboxdocument;
				  if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxBasePath",pasteboxpath)!=STATUS_OK)		
				  {
					  DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
					  return STATUS_FAILED;
				  }
				  if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxNumber",pasteboxnumber)!=STATUS_OK)		
				  {
					  DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
					  return STATUS_FAILED;
				  }
				 if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcFolderName",pastefoldername)!=STATUS_OK)		
				  {
					  DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
					  return STATUS_FAILED;
				  }
				  if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcDocumentName",pasteboxdocument)!=STATUS_OK)		
				  {
					  DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
					  return STATUS_FAILED;
				  }					
				  CString orgDocumentPath = Utility::GetResourcePath(pasteboxpath,pasteboxnumber,pastefoldername,pasteboxdocument) + "/";		

				  DEBUGL8("CBox::PasteDocument:pasteboxpath (%s) pasteboxnumber (%s) pastefoldername (%s)to (%s)\n",pasteboxpath.c_str(), pasteboxnumber.c_str(),pastefoldername.c_str(),to.c_str()); 
			
				  DEBUGL8("CBox::PasteDocument:orgDocumentPath (%s)\n",orgDocumentPath.c_str()); 
	
				  //Copy it from clipboard to /storage/box..		
				  if(bSamePath == false){
					  retsts = ci::operatingenvironment::Folder::CopyDir(orgDocumentPath,to);
					  if (retsts !=STATUS_OK)	
					  {
						  rst = Utility::RemoveResource(to);
						  if(rst != STATUS_OK)
							  DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

						  DEBUGL1("CBox::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						  return retsts;
					  }
					}
					  retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties.xml",to);
					  if (retsts !=STATUS_OK)	
					  {
						  rst = Utility::RemoveResource(to);
						  if(rst != STATUS_OK)
							  DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

						  DEBUGL1("CBox::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						  return retsts;
					  }
					  retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties_dom",to);
					  if (retsts !=STATUS_OK)	
					  {
						  rst = Utility::RemoveResource(to);
						  if(rst != STATUS_OK)
							  DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

						  DEBUGL1("CBox::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						  return retsts;
					  }
					  if(bSamePath)
					  {
						  if(m_returnpastedocname)
						  {
							  int err =pthread_mutex_lock(&gbox_mutex_initializer);
							  if (err != 0)
								  DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
							  m_PastedVecofDocs.push_back(documentname.c_str());
							  err =pthread_mutex_unlock(&gbox_mutex_initializer);
							  if (err != 0)
								  DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");

						  }
					  }

			  }
              //In case of copy operation copy the new document
              else
			  {
				  CString to = newpath;
					  retsts = ci::operatingenvironment::Folder::CopyDir(from,to);
					  if (retsts !=STATUS_OK)	
					  {
						  rst = Utility::RemoveResource(to);
						  if(rst != STATUS_OK)
							  DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
						  DEBUGL1("CBox::PasteDocument: Copying document to failed with Status  %d\n",retsts);
						  return retsts;
					  }		
				  NewWorkspaceDocName = CUUID().toString();
			  }
              //Original Document Path
              CString orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName;
              resourceKey = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"",documentname) + "/";		
              if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","srcBoxBasePath",orgBoxBasePath)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }				
              if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","srcBoxNumber",orgBoxNumber)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }				
              if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","srcFolderName",orgFolderName)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }				
              if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","srcDocumentName",orgDocumentName)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }				
              //Obtain the Clipboard document
              DocumentRef clipDoc;
              CString clipPath = CLIPBOARD_PATH;
              if(Utility::GetDocument(m_sessionID, clipDoc,clipPath,"","",fulldocumentname)!=STATUS_OK)
              {
                 DEBUGL1("CBox::PasteDocument: Obtaining Clipboard Document failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }

              //Getting document properties from original document
              DEBUGL8("CBox::PasteDocument:Getting Properties\n");		
              std::map<CString,CString> webDAVProperties;
              try
              {
                 if(!clipDoc)
                 {
                    DEBUGL8("CBox::PasteDocument: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 Status ret = dynamic_cast<CDocument*>(clipDoc.operator->())->GetProperties(webDAVProperties);
                 if(ret != STATUS_OK) 
                 {
                    DEBUGL1("CBox::PasteDocument:GetProperties of OrgDoc failed\n");
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                       DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                    return ret;
                 }      
              }	
              catch(exception &e)
              {
                 DEBUGL1("CBox::PasteDocument:: Caught exception (%s)\n",e.what());
                 return STATUS_FAILED;
              }		
              std::map<CString,CString>::iterator mapIter;
              for(mapIter=webDAVProperties.begin();mapIter!=webDAVProperties.end();mapIter++)
                 DEBUGL8("CBox::PasteDocument: Key<%s> and Value<%s>\n",(mapIter->first).c_str(),(mapIter->second).c_str());

				  //Setting document properties on current document
				  DocumentRef curDoc;		
				  curDoc = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"", documentname);

				  if(!curDoc)
				  {
					  DEBUGL8("CBox::PasteDocument: doc object is null\n");
					  return STATUS_FAILED;
				  }
					//To fix STFR_11907
				  //Not needed to call SaveProperties() because the aim is to set the attributes of the 
				  //copied document i.e. /webDAVProperties should be copied to documentproperties.xml
				  //So, removed SaveProperties() call. Set WorkspaceDocName property
				  CString key = "WorkspaceDocName";
				  if(cutDocumentFlag != "true")
					  webDAVProperties[key] = NewWorkspaceDocName;
				  //Re-setting the cut flag.
				  webDAVProperties["cutDocument"] = "";
				  //Setting the new document name
				  webDAVProperties["documentName"] = documentname;
				  //Setting creation date and modified date
				  CString creatTime = Utility::GetUnixTime();  
				  webDAVProperties["creationDate"] = creatTime;
				  webDAVProperties["lastModifiedDate"] = creatTime;

				  //Saving properties of the copied document to the pasted document
				  DEBUGL8("CBox::PasteDocument:SetProperties of copied/cut document to paste document..document name = <%s>\n", documentname.c_str());
				  Status ret = dynamic_cast<CDocument*>(curDoc.operator->())->SetProperties(webDAVProperties);
				  if(ret != STATUS_OK)
				  {
                  DEBUGL1("CBox::PasteDocument:SetProperties of CurDoc failed\n");
                  curDoc = NULL; // release
                  rst = Utility::RemoveResource(resourceKey);
                  if(rst != STATUS_OK)
                      DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                  return ret;
              }

    
              //Check for the CutDocument property and delete the original document
              DocumentRef orgDoc;
              if(Utility::GetDocument(m_sessionID, orgDoc,orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)==STATUS_OK)
              {

              CString flag;
              CString dpath =Utility::GetResourcePath(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)+"/";
              std::map<CString,CString> PropertyMap;
              if(proputils::GetProperty(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName,"","cutDocument",flag)!=STATUS_OK)		
              {
                 DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                 return STATUS_FAILED;
              }				
              if(flag=="true")
              {	
                 if(!orgDoc)
                 {
                    DEBUGL1("CBox::PasteDocument: doc object is null\n");
                    return STATUS_FAILED;
                 }
                 // Start to Delete
                 if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
                 {
                    DEBUGL1("CBox::PasteDocument: Deleting document failed\n");
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                       DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                    return STATUS_FAILED;
                 }
              }	
              else
              {
                 //Reset the properties on the Original document			
                 PropertyMap.clear();
                 //update the sessionID and cutDocument flag 
                 PropertyMap.insert(pair::value_type("sessionID",""));
                 PropertyMap.insert(pair::value_type("cutDocument",""));
                 sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap); 
                 if(sdf != STATUS_OK)	
                 {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                       DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                       DEBUGL1("CBox::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

                       return STATUS_DISK_FULL;
                    }

                    DEBUGL1("CBox::PasteDocument:SetProperty for SessionID Failed\n");

                    return STATUS_FAILED;
                 }					
              }

              if(flag=="true")
              {	
                 //Clear the ClipBoard
                 if((ci::operatingenvironment::Folder::Remove(from,true) != STATUS_OK))
                 {
                    DEBUGL1("CBox::CopyDocument::Deleting %s Document Failed\n",resourceKey.c_str());
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                       DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");
                    return STATUS_FAILED;
                 }			
              }

              //Remove the properties
              path= Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"",documentname)+"/";

              //Reset the properties on the Original document
              PropertyMap.clear();
              //update the sessionID and cutDocument flag 
              PropertyMap.insert(pair::value_type("sessionID",""));
              PropertyMap.insert(pair::value_type("srcFolderName",""));
              PropertyMap.insert(pair::value_type("cutDocument",""));
              PropertyMap.insert(pair::value_type("srcBoxNumber",""));
              PropertyMap.insert(pair::value_type("srcBoxBasePath",""));
              PropertyMap.insert(pair::value_type("srcDocumentName",""));
              PropertyMap.insert(pair::value_type("IsImagedataPresent",""));
              PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent",""));
              PropertyMap.insert(pair::value_type("IsThumbnaildataPresent",""));
              sdf = Utility::SetProperties(path,xmlfile,PropertyMap); 
              if(sdf != STATUS_OK)	
              {	
                 rst = Utility::RemoveResource(resourceKey);
                 if(rst != STATUS_OK)
                    DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                 if(sdf == STATUS_DISK_FULL)
                 {
                    DEBUGL1("CBox::PasteDocument:SetProperty for SessionID failed beacause Disk is Full\n");

                    return STATUS_DISK_FULL;
                 }
                 DEBUGL1("CBox::PasteDocument:SetProperty  Failed\n");

                 return STATUS_FAILED;
              }
              try
              {
                 Status strst = dynamic_cast<CDocument*>(curDoc.operator->())->InitializeStatus();
                 if(strst !=STATUS_OK)
                 {
                    DEBUGL1("CBox::PasteDocument:Initializing Status Failed\n");
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                       DEBUGL1("CBox::PasteDocument: Failed to remove half created folder\n");

                    return strst;
                 }
              }
              catch(exception &e)
              {
                 DEBUGL1("CBox::PasteDocument: Caught exception (%s)\n",e.what());
                 return STATUS_FAILED;
              }		
           }
           }
           DEBUGL4("CBox::PasteDocument: Exit\n");
           return STATUS_OK;
        }

        Status CBox::LoadProperties() 
        {
            // get WebDAV properties.
            std::map<CString, CString>::iterator it = m_WebDAVProperties.begin();

            // clear the current values in m_WebDavProperties
            for(;it != m_WebDAVProperties.end(); it++) 
                it->second = "";

            if(proputils::GetAllBoxProperties(m_BoxBasePath,m_BoxNumber,m_WebDAVProperties)!=STATUS_OK)
            {
                DEBUGL1("CBox::LoadProperties::Loading properties is failed\n");
                return STATUS_FAILED;
            }

            m_BoxName = m_WebDAVProperties["boxName"]; 
            return STATUS_OK;
        }

        Status CBox::LoadProperties(std::map<CString, CString> WebDAVpropertyMap) 
        {
            m_WebDAVProperties = WebDAVpropertyMap;
            m_BoxName = WebDAVpropertyMap["boxName"]; 
            return STATUS_OK;	
        }


        Status CBox::SaveProperties() 
        {   
            //write the properties in to boxproperties dom document.
            Status sdf = proputils::SetBoxProperties(m_BoxBasePath,m_BoxNumber,m_WebDAVProperties);
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::SaveProperties::setting properties to dom failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::SaveProperties::setting properties to dom failed\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CBox::GetSize(uint64 &size)
        {
            size=0;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            if(Utility::ResourceSize(m_sessionID, m_BoxBasePath,m_BoxNumber,"","","",size)!=STATUS_OK)		
            {
                DEBUGL1("CBox::PasteDocument:ResourceSize Failed\n");
                return STATUS_FAILED;
            }								
            DEBUGL8("CBox::GetSize:: Full Size of Box is %lld\n", size);

#if 0
            CString val;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize",val)!=STATUS_OK)		
            {
                DEBUGL1("CBox::PasteDocument:GetProperty Failed\n");
                return STATUS_FAILED;
            }								
            DEBUGL8("CBox::GetSize:: Full Size of Box is %s\n", val.c_str());
            size = atoi(val.c_str());
#endif
            return STATUS_OK;	
        }

        Status CBox::SetWEPDocument(dom::NodeRef node)
        {
            if(!node)
            {
                DEBUGL1("CBox::SetWEPDocument::dom Node argument is invalid(NULL)\n");
                return STATUS_FAILED;
            }

            // WEP must be set using WebDAV for file permission
            // serialize hdb document in temporary folder
            CString weppath = Utility::GetHDBROOTPath();
            weppath += WEP_FILENAME;
            try {
                HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                if(!hdb)
                {
                    DEBUGL1("CBox::SetWEPDocument: failed get hdb\n");
                    return STATUS_FAILED;
                }
                if(hdb->SerializeToFile(node, weppath)!= STATUS_OK)
                {
                    DEBUGL1("CBox::SetWEPDocument: settting wep document failed\n");
                    return STATUS_FAILED;
                }
            }
            catch(CException & except)
            {
                DEBUGL1("\nCBox::SetWEPDocument: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCBox::SetWEPDocument: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            // put WEP to document folder
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+ "/";
            path += WEP_FILENAME;
            DEBUGL8("CBox::PasteDocument: Copy wep file to (%s)\n",path.c_str());
            Status retsts = ci::operatingenvironment::File::CopyFile(weppath,path);
            if (retsts !=STATUS_OK)	
            {
                DEBUGL1("CBox::PasteDocument: Copying document to ClipBoard failed with Status  %d\n",retsts);
                return retsts;
            }
            struct stat weppath_buf;
            bool wepsize = true;
            if(stat(weppath.c_str(), &weppath_buf) != 0)
            {
                DEBUGL2("CBox::SetWEPDocument:: Cannot stat wep file, setting size as 0\n");
                wepsize = false;
            }
            CString val;
            CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize",val)!=STATUS_OK)		
            {
                DEBUGL1("CBox::SetWEPDocument:GetProperty Failed\n");
                return STATUS_FAILED;
            }		

            DEBUGL8("CBox::SetWEPDocument:: Full Size of Box is %s\n", val.c_str());
            uint64 size = val.length()? atoi(val.c_str()): 0;
            size += (wepsize ? weppath_buf.st_size : 0);
            std::ostringstream boxsize;
            boxsize << size;

            //Reset the properties on the Original document			
            std::map<CString,CString> PropertyMap;
            PropertyMap.clear();
            CString xmlfile("boxproperties.xml");
            //update the sessionID and cutDocument flag 
            PropertyMap.insert(pair::value_type("totalBoxSize",boxsize.str()));
            PropertyMap.insert(pair::value_type("lastAccessDate",(Utility::GetUnixTime()).c_str()));
            PropertyMap.insert(pair::value_type("lastModifiedDate",(Utility::GetUnixTime()).c_str()));	
            Status sdf = Utility::SetProperties(propertypath,xmlfile,PropertyMap); 
            if(sdf != STATUS_OK)	
            {	
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::SetWEPDocument:SetProperty for totalBoxSize failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::SetWEPDocument:SetProperty for totalBoxSize Failed\n");
                return STATUS_FAILED;
            }						
            File::DeleteFile(weppath);	
            return STATUS_OK;
        }

        Status CBox::GetWEPDocument(CString& documentID)
        {
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+"/";
            path += WEP_FILENAME;
            DEBUGL8("CBox::GetWEPDocument::path =%s\n",path.c_str());

            try {
                // Create HDB Document
                dom::DocumentRef doc;
                HierarchicalDBRef hdb = hierarchicaldb::HierarchicalDB::Acquire(NULL);
                std::ostringstream oss;
                Ref<CUUID> uuid = new CUUID();
                oss << "WEP_" << uuid->toString();
                documentID = oss.str();

                CString folderpath = Utility::GetHDBROOTPath();
                Status st = hdb->CreateDocumentFromFile(folderpath, documentID, doc, path);
                if((st != STATUS_OK)||(!doc)) {
                    DEBUGL1("CBox::GetWEPDocument::opening WEP.XML failed\n");
                    return STATUS_FAILED;
                }
            }
            catch(CException & except)
            {
                DEBUGL1("\nCBox::GetWEPDocument: Caught HDB exception\n");
                return STATUS_FAILED;
            }
            catch(DOMException except)
            {
                DEBUGL1("\nCBox::GetWEPDocument: Failed due to DOM Exception\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }


        /**
         * create archive
         * @param[out] archiver - created Archiver object.
         * @param[in] target - archive file path / file name
         * @param[in] documentname - document name to be archived
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CreateArchive(ArchiverRef &archiver, CString target, CString documentname)
        {
            std::vector<CString> documentlist;
            documentlist.clear();
            documentlist.push_back(documentname);
            return (CreateArchive(archiver,target,documentlist));
        }

        /**
         * create archive
         * @param[out] archiver - created Archiver object.
         * @param[in] target - archive file path / file name
         * @param[in] documentlist - list of document name to be archived
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CreateArchive(ArchiverRef &archiver, CString target, std::vector<CString> documentlist)
        {
            DEBUGL4("CBox::CreateArchive::Createarchive Enter\n");
            CString path = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"","")+"/";
            CString archivedocpath("");
            CString folderName("");
            std::vector<CString>::iterator it;
            DocumentRef docRef;
            DocStatus docSts;
            Status pRet;
            std::vector<CString> documentpaths;

            //Validate the input Parameters.
            if(target.compare("")==0)
            {
                DEBUGL1("CBox::CreateArchive::target Name is empty\n");
                return STATUS_FAILED;
            }

            for(it=documentlist.begin();it !=documentlist.end();it++)
            {
                docRef=NULL;
                archivedocpath=path+(*it);
                DEBUGL8("CBox::CreateArchive::archive Document path =%s\n",path.c_str());

                if(!(Utility::ResourceExist(archivedocpath)))
                {
                    DEBUGL1("CBox::CreateArchive::DocumentName %s does not exist \n",it->c_str());
                    return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
                }
                //Read the status of the Document. if its not READY/USING then return failed.
                pRet=GetDocument(docRef,(*it));
                if((pRet !=STATUS_OK)||(docRef == static_cast<void*>(NULL)))
                {
                    DEBUGL1("CBox::CreateArchive::Could not Obtain DocRef. GetDocument Failed\n");
                    return pRet;
                }
                if(docRef->GetStatus(docSts) != STATUS_OK) 
                {
                    DEBUGL1("CBox::CreateArchive::Getting document status is failed for document %s\n",it->c_str());
                    return STATUS_FAILED;
                }
                // if NOT (READY or USING)
                if(!((docSts == READY) || (docSts == USING))) //RESERVING is not used in Archiving(EFilingBoxes)
                {
                    DEBUGL1("CBox::CreateArchive::Document Status is not READY or USING\n");
                    return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
                }
				Status stat = docRef->Use();
                if(stat != STATUS_OK) 
				{
					if(stat == STATUS_DISK_FULL) {
						DEBUGL1("CBox::CreateArchive::Changing document status to USING failed because of DISK FULL %s\n",it->c_str());
						return stat;
					}
					else {		
						DEBUGL1("CBox::CreateArchive::Changing document status to USING failed for document %s\n",it->c_str());
						return STATUS_CREATE_IMPOSSIBLE_ARCHIVE;
					}
                }
            }
            //Create a vector of document paths and document list so as to send it to Archive class
            documentpaths.clear();
            documentpaths.push_back(m_BoxBasePath);
            documentpaths.push_back(m_BoxNumber);
            documentpaths.push_back(folderName);
            Ref<CArchiver> carchiver;

            //Now create a Archiver Object and set the required parameters.
            carchiver = new CArchiver(m_sessionID, target,documentpaths,documentlist);
            if(!carchiver)
            {
                DEBUGL1("CBox::CreateArchive::Creating archive object Failed\n");
                return STATUS_FAILED;
            }	
            //create a Thread and start the actual Operation
            pRet = carchiver->CreateArchiveThread();
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CBox::CreateArchive::Could not Create a Thread\n");
                return pRet;
            }

            archiver=carchiver;

            DEBUGL4("CBox::CreateArchive::Createarchive Exit\n");
            return STATUS_OK;
        }

        /**
         * extract archive
         * @param[out] extractor - created Extractor object
         * @param[in] archiverpath - path of the archive to be extracted
         * @param[in] extractorpath - path to which the archived files needs to extracted
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::ExtractArchive(operatingenvironment::Ref<Extractor> &extractor,CString archiverpath,CString extractorpath)
        {
            CString folderName("");
            Status pRet;
            std::vector<CString> documentpaths;
            DocumentRef docRef=NULL;

            DEBUGL4("CBox::ExtractArchive:: Enter\n");
            //Validate the input Parameters.
            if((extractorpath.compare("")==0) ||(archiverpath.compare("")==0))
            {
                DEBUGL1("CBox::ExtractArchive::archiverpath or  extractorpath's are empty\n");
                return STATUS_FAILED;
            }	
            //Create a vector of document paths and document list so as to send it to Archive class
            documentpaths.clear();
            documentpaths.push_back(m_BoxBasePath);
            documentpaths.push_back(m_BoxNumber);
            documentpaths.push_back(folderName);
            Ref<CExtractor> cextractor;

            //Now create a Archiver Object and set the required parameters.
            extractorpath = BOXPATH + extractorpath;
            cextractor = new CExtractor(m_sessionID, archiverpath,documentpaths,extractorpath);
            if(!cextractor)
            {
                DEBUGL1("CBox::ExtractArchive::Creating extractor object Failed\n");
                return STATUS_FAILED;
            }	

            //create a Thread and start the actual Operation
            pRet = cextractor->CreateExtractThread();
            if(pRet !=STATUS_OK)
            {
                DEBUGL1("CBox::ExtractArchive::Could not Create a Thread\n");		
                return pRet;
            }

            extractor=cextractor;
            DEBUGL4("CBox::ExtractArchive:: Exit\n");
            return STATUS_OK;
        }

        /**
         * Delete Archive 
         * @param[in] archivepath - path of the archive file that needs to be deleted
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         */
        Status CBox::DeleteArchive(CString archivepath)
        {
            DEBUGL4("CBox::DeleteArchive:Enter - DeletePath<%s>\n",archivepath.c_str());	 
            //Now delete the Box
            if((ci::operatingenvironment::File::DeleteFile(archivepath) != STATUS_OK))
            {
                DEBUGL1("CBox::DeleteArchive::Deleting %s Document Failed\n",archivepath.c_str());
                return STATUS_FAILED;
            }
            DEBUGL4("CBox::DeleteArchive: Exit\n");	
            return STATUS_OK;
        }


       	/**
         * cut the documents to clipboard
         * if document status is NOT READY, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] docname - source document name
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CutDocument(ProgressRef& progress, CString docname)
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CutDocument(progress, documents));
        }

        /**
         * cut the documents to clipboard
         * if document status is NOT READY, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] documents - source document names
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CutDocument(ProgressRef& progress, std::vector<CString> documents)
        {
            DEBUGL4("CBox::CutDocument-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString cutProgShmName = "boxCut_" + CUUID().toString(); 
            m_CutErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(cutProgShmName,m_CutErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,"",".cutDiskFullBox_", ".cutResourceNotFound_");
            if(!m_cprogress)
            {
                DEBUGL1("CBox::CutDocument-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_CutProgShmName = cutProgShmName;

            //Create shared memory to store progress of cut operation
            m_prgShmid = SharedMemory::Create(cutProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);  
            if(!m_prgShmid)
            {
                DEBUGL1("CBox::CutDocument-- Creating shared memory failed.. \n");
                return STATUS_FAILED;
            }            
            pRetValue = CreateCutThread(this,documents);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1("CBox::CutDocument-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }

        /**
         * copy the documents to clipboard
         * if document status is NOT READY or USING or EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] docname - source document name
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CopyDocument(ProgressRef& progress, CString docname)
        {
            std::vector<CString> documents;
            documents.push_back(docname);
            return(CopyDocument(progress, documents));
        }

        /**
         * copy the documents to clipboard
         * if document status is NOT READY or USING or EDITING, it will fail.
         * @param[out] progress - user can get operation progress from this.
         * @param[in] documents - source document names
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::CopyDocument(ProgressRef& progress, std::vector<CString> documents)
        {
            DEBUGL4("CBox::CopyDocument-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString copyProgShmName = "boxCopy_"+CUUID().toString(); 
            m_CopyErrfile = CUUID().toString(); 

            //Create an instance of CProgress
            m_cprogress = new CProgress(copyProgShmName,m_CopyErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,"",".copyDiskFullBox_", ".copyResourceNotFound_");
            if(!m_cprogress)
            {
                DEBUGL1("CBox::CopyDocument-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_CopyProgShmName = copyProgShmName;

				
				//Create the shared memory to store the progress of copy operation
				m_prgShmid=SharedMemory::Create(copyProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!m_prgShmid)
				{
					 DEBUGL1("CBox::CopyDocument-- Creating shared memory failed \n");
					 return STATUS_FAILED;
				}
            pRetValue = CreateCopyThread(this,documents);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1("CBox::CopyDocument-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }

	Status CBox::PasteDocument(std::vector<CString> &documentnames) 
	{
		Status st;
		documentnames.clear();
		DEBUGL4("CBox::PasteDocument: Enter\n");
		m_returnpastedocname = true;
		if((st = PasteDocument())!= STATUS_OK)
		{
			DEBUGL4("CBox::PasteDocument with document names: Failed\n");
			m_returnpastedocname = false;
			return st;
		}
		std::vector<CString>::iterator it;
		DEBUGL8("CBox::PasteDocument m_PastedVecofDocs - size() = [%d]\n",m_PastedVecofDocs.size());
		it = documentnames.begin();
		int err =pthread_mutex_lock(&gbox_mutex_initializer);
		if (err != 0)
			DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
		documentnames.insert(it, m_PastedVecofDocs.begin(), m_PastedVecofDocs.end());
		err =pthread_mutex_unlock(&gbox_mutex_initializer);
		if (err != 0)
			DEBUGL2("CBox::PasteDocument:: pthread_mutex_lock failed\n ");
		if(documentnames.empty())
			DEBUGL1("CBox::PasteDocument: No entry found for document names in vector documentnames\n");
		m_returnpastedocname = false;
		DEBUGL4("CBox::PasteDocument: Exit\n");
		return STATUS_OK;
	}
        /**
         * paste the document from clipboard
         * @param[out] progress - user can get operation progress from this.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure,
         *         STATUS_DISK_FULL if there is not enough space on the disk.
         */
        Status CBox::PasteDocument(ProgressRef& progress)
        {
            DEBUGL4("CBox::PasteDocument-- Entered for Progress \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString pasteProgShmName ="boxPaste_"+ CUUID().toString(); 
            m_PasteErrfile = CUUID().toString(); 

            //Status sdf;
            //Create an instance of CProgress
            m_cprogress = new CProgress(pasteProgShmName,m_PasteErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,"",".pasteDiskFullBox_");
            if(!m_cprogress)
            {
                DEBUGL1("CBox::PasteDocument-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_PasteProgShmName = pasteProgShmName;

				//Create a shared memory to store the progress report
				m_prgShmid=SharedMemory::Create(pasteProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!m_prgShmid)
				{
					DEBUGL1("CBox::PasteDocument-- Creating shared memory failed\n");
					return STATUS_FAILED;
				}
	
            pRetValue = CreatePasteThread(this);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1("CBox::PasteDocument-- Creating Paste thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;
        }

        Status CBox::CreateCutThread(CBox* cutBoxObj, std::vector<CString> documents)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingcutboxthread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreateCutThread-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;		
            }
            //Push the vector of pages into its respective static variable
            std::vector<CString>::iterator it;
            for(it = documents.begin();it!=documents.end();it++)
                m_CutVecofDocs.push_back(*it);
			pRetVal = CreateThread(StartCutThread,reinterpret_cast<void*>(cutBoxObj),m_ThreadID);
	
            if(pRetVal !=STATUS_OK)
                DEBUGL1("CBox::CreateCutThread::Could not Create a Thread\n");
            else
                DEBUGL8("CBox::CreateCutThread:: Creation of thread Initiated\n");

            //exit critical section
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreateCutThread()--Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;		
            }
            return pRetVal;

        }

        Status CBox::CreateCopyThread(CBox* copyBoxObj, std::vector<CString> documents)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingcopyboxthread";
            GlobalMutexRef threadMutex = NULL;

            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreateCopyThread-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;		
            }
            //Push the vector of pages into its respective static variable
            std::vector<CString>::iterator it;
            for(it = documents.begin();it!=documents.end();it++)
                m_CopyVecofDocs.push_back(*it);


            pRetVal = CreateThread(StartCopyThread,reinterpret_cast<void*>(copyBoxObj),m_ThreadID);
            if(pRetVal !=STATUS_OK)
                DEBUGL1("CBox::CreateCopyThread::Could not Create a Thread\n");
            else
                DEBUGL8("CBox::CreateCopyThread:: Creation of thread Initiated\n");

            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreateCopyThread()--Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;		
            }
            return pRetVal;
        }


        Status CBox::CreatePasteThread(CBox* pasteBoxobj)
        {
            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingpasteboxthread";
            GlobalMutexRef threadMutex = NULL;
            // enter critical section
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreatePasteThread-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;		
            }


            pRetVal = CreateThread(StartPasteThread,reinterpret_cast<void*>(pasteBoxobj),m_ThreadID);
            if(pRetVal !=STATUS_OK)
                DEBUGL1("CBox::CreatePasteThread::Could not Create a Thread\n");
            else
                DEBUGL8("CBox::CreatePasteThread:: Creation of thread Initiated\n");

            //Once local variable copied Flag is set to 0 and loop ends
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1("CBox::CreatePasteThread()--Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;		
            }
            return pRetVal;

        }

        Status CBox::CreateThread(ThreadFun funcName,ThreadArg funcArgument,Ref<Thread> threadID)
        {
            if(!(threadID = Thread::Create(funcName)))
            {
                DEBUGL1("CBox::CreateThread: --Unable to create the thread\n");
                return STATUS_FAILED;
            }
            else
            {
                m_ThreadID = threadID;
                DEBUGL8("CBox::CreateThread: -Thread created successfully\n");

                if(threadID->Start(funcArgument)!=STATUS_OK)
                {
                    DEBUGL1("CBox::CreateThread: -Unable to start the Thread!!!\n");
                    return STATUS_FAILED;
                }
                else
			DEBUGL8("CBox::CreateThread: -Thread started successfully\n");

		if(threadID->Detach()!=STATUS_OK)
		{
			DEBUGL1("CBox::CreateThread: -Unable to detach the Thread!!!\n");
			return STATUS_FAILED;
		}
		else
			DEBUGL8("CBox::CreateThread: -Thread detached successfully\n");

	    }

            return STATUS_OK;
        }

        void* CBox::StartCopyThread(void *arg)
        {
            DEBUGL4("CBox::StartCopyThread-- Started \n");
            //Status retStatus;
            Status sdf;
            //unique name given for locking the resource
            CString threadlockpath ="lockingstartCopyBoxthread";
            //Copy the passed instance of the invoking object into a local variable 
            CBox* boxobj = (CBox*)arg;
            //Enter Critical section
            //Copy the pages from static variable to a local variable
            std::vector<CString>::iterator itr;
            std::vector<CString> documents;
            for(itr=m_CopyVecofDocs.begin();itr!=m_CopyVecofDocs.end();itr++)
                documents.push_back(*itr);	

            m_CopyVecofDocs.clear();

            //Create Shared memory used for writing the updted progress in it
            void *pCopyMapAddr;
            if(!boxobj->m_prgShmid)
            {
                DEBUGL1("CBox::StartCopyThread: -- Failed to Create Shared Memory for Cut Progress Name \n ");
                boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
               // m_CopyFlag = FLAG_RESET;
                return NULL;
            }
            else
            {
                int iShmPidSize = boxobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                boxobj->m_prgShmid->Map(pCopyMapAddr);
                if(pCopyMapAddr!=NULL)
                {
                    memset(pCopyMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("CBox::StartCopyThread: -- Mapping Failed for Cut Progress Name\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                   // m_CopyFlag = FLAG_RESET;
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
            }


            //set the initial value of Cut Document progress as 1% . The Start Cut 
            //thread will update it as and when the operation progresses
            *((int*)pCopyMapAddr) = 1;

            std::vector<CString>::iterator iter;
            std::vector<CString> vec;
            vec.clear();
            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBox::StartCopyThread: Getting collection list failed");
                boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                boxobj->m_prgShmid = NULL;
                return NULL;
            }
            //Delete Clipboard documents,if any
            CString fulldocumentname("");
            CString documentname("");		
            CString resourceKey("");	
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                fulldocumentname = vec[i];
                CString documentname;		
                resourceKey= CLIPBOARD_PATH+fulldocumentname+"/";

				DEBUGL8("CBox::StartCopyThread: vector<%s>, fullDocName<%s>\n",vec[i].c_str(),fulldocumentname.c_str());
                //Check if the clipborad document is of the same user
                CString sid;		
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
                {
                    DEBUGL1("CBox::StartCopyThread:GetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                DEBUGL8("CBox::StartCopyThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),boxobj->m_sessionID.c_str());

                if(sid!=boxobj->m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CBox::StartCopyThread:: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
            }

            //Refresh all the documents in the Box
            DocumentList docList;
            DocumentList::iterator doc;	
            if(boxobj->GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CBox::StartCopyThread::Getting document list is failed\n");
                boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                boxobj->m_prgShmid = NULL;
                return NULL;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                //To fix FR_5285, added check to verify if the document is in editing then should not
                //reset session id and cutdocument flag. 
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {	
                    CString docName;
                    (*doc)->GetName(docName);
                    if(boxobj->UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::StartCopyThread:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                }
            }

            //Progress initialization
            int curProg =0;
            int count =1;
            uint totalCnt = documents.size();
            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CBox::StartCopyThread:Document <%s>\n",(*iter).c_str());	
                if(((*iter).empty()))
                {
                    DEBUGL1("CBox::StartCopyThread: Document name empty");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }			
                //Original doc path 
                CString from = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,(*iter)) + "/";
                CString copypath = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber) + "/";
                //Set the session-ID on the orignal document


                //Obtain the original document
                DocumentRef doc;
                boxobj->GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CBox::StartCopyThread: Given Document does not exist\n");
                    if(Utility::CreateUniqueFile(copypath, ".copyResourceNotFound_" + boxobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");

                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                notEditDocuments.push_back(*iter);
                // check current status
                DocStatus st;
                doc->GetStatus(st);
                //if(!(st== READY || st==USING || st==EDITING)) 
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CBox::StartCopyThread:UndoEditDocument for Failed. Document is USING or RESERVING\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;			
                }
                if(!(st== READY || st==EDITING)) 			
                {
                    DEBUGL1("CBox::StartCopyThread: Document is NOT in READY/EDITING state\n");
                    if(boxobj->UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::StartCopyThread:UndoEditDocument for Failed\n");
                        boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }			
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                if(st == EDITING)
                {
                    DEBUGL1("CBox::StartCopyThread: Document is in editing state\n");
                    CString copypath = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber) + "/";
                    if(Utility::CreateUniqueFile(copypath, ".copypage2ndsession_" + boxobj->m_sessionID) != STATUS_OK)
                       DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");
		    sdf = boxobj->m_prgShmid->Destroy();
		    if(sdf != STATUS_OK)
		    {
			DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    }
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                std::map<CString,CString> PropertyMap;
                CString xmlfile("documentproperties.xml");
                PropertyMap.clear();
                //update the sessionID and cutDocument flag on the original document
                PropertyMap.insert(pair::value_type("sessionID",boxobj->m_sessionID.c_str()));
                PropertyMap.insert(pair::value_type("cutDocument","false"));
                sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                if(sdf != STATUS_OK)		
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCopyThread:SetProperty failed because Disk is Full\n");
                        DEBUGL8("CBox::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                        if(Utility::CreateUniqueFile(copypath, ".copyDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");

		    	sdf = boxobj->m_prgShmid->Destroy();
		    	if(sdf != STATUS_OK)
		    	{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    	}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCopyThread:SetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;

                    return NULL;
                }		
                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(boxobj->m_BoxBasePath, boxobj->m_BoxNumber, "", (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CBox::StartCopyThread: GetProperty of WorkspaceDocName failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }

                //Clipboard doc path
                Status rst;		
                //CString newDocName=boxobj->m_sessionID+"_"+boxobj.m_BoxNumber+"_"+(*iter)+"/";
                //CString to = CLIPBOARD_PATH + newDocName;
                CString newDocName = boxobj->m_sessionID + "_" + WorkspaceDocName;
                CString to = CLIPBOARD_PATH + newDocName;
                Status retsts = ci::operatingenvironment::Folder::CopyDir(from,to);
                if (retsts !=STATUS_OK)	
                {
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCopyThread: Failed to remove half created folder\n");

                    if(retsts==STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCopyThread: Copying document to ClipBoard failed because disk is FULL\n");
                        if(Utility::CreateUniqueFile(copypath, ".copyDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");

		    	sdf = boxobj->m_prgShmid->Destroy();
		    	if(sdf != STATUS_OK)
		    	{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    	}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCopyThread: Copying document to ClipBoard failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;

                    return NULL;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                PropertyMap.clear();
                CString docxmlfile("documentproperties.xml");
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",boxobj->m_BoxBasePath.c_str()));
                PropertyMap.insert(pair::value_type("srcBoxNumber",boxobj->m_BoxNumber.c_str()));
                PropertyMap.insert(pair::value_type("srcFolderName",""));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                sdf = Utility::SetProperties(to,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCopyThread: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCopyThread:SetProperty failed because Disk is Full\n");
                        DEBUGL8("CBox::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                        if(Utility::CreateUniqueFile(copypath, ".copyDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");
		    	sdf = boxobj->m_prgShmid->Destroy();
		    	if(sdf != STATUS_OK)
		    	{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    	}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }

                    DEBUGL1("CBox::CopyDocument:SetProperty for SessionID Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;

                    return NULL;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();

                PageRef page;					
                if(doc->GetPage(1, page) != STATUS_OK) 
                {
                    DEBUGL1("CBox::StartCopyThread: Getting page %d failed\n", strpageno.c_str());
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCopyThread: Failed to remove half created folder\n");			
		    sdf = boxobj->m_prgShmid->Destroy();
		    if(sdf != STATUS_OK)
		    {
			DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    }
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }	
                PropertyMap.clear();
                try
                {
                    if(!page)
                    {
                        DEBUGL1("CBox::StartCopyThread: page object is null\n");
                        boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CBox::StartCopyThread: Failed to remove half created folder\n");			
		    	sdf = boxobj->m_prgShmid->Destroy();
		    	if(sdf != STATUS_OK)
		    	{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    	}
                        boxobj->m_prgShmid = NULL;

                        return NULL;
                    }
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                    CString pagePath=from+"Image/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));		
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                    pagePath=from+"Subsampling/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));		
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                    pagePath=from+"Thumbnail/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CBox::StartCopyThread: Caught exception (%s)\n",e.what());
		    sdf = boxobj->m_prgShmid->Destroy();
		    if(sdf != STATUS_OK)
		    {
			DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    }
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)			
                {
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCopyThread: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCopyThread:SetProperty failed because Disk is Full\n");
                        DEBUGL8("CBox::StartCopyThread::savepath = (%s)\n", copypath.c_str());
                        if(Utility::CreateUniqueFile(copypath, ".copyDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCopyThread: Unable to create the file\n");

		    	sdf = boxobj->m_prgShmid->Destroy();
		    	if(sdf != STATUS_OK)
		    	{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
		    	}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCopyThread:SetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CopyErrfile,boxobj->m_prgShmid);
                    boxobj->m_prgShmid = NULL;

                    return NULL;
                }

		//Progress updation
		curProg = (int)((((float)count++)/((float)totalCnt))*100);
		if(curProg != 100)
		{
			*((int*)pCopyMapAddr) = curProg;				
			DEBUGL8("CBox::StartCopyThread::Current Progress<%d>\n",curProg);
		}
	    }
	    *((int*)pCopyMapAddr) = PROGRESS_COMPLETED;				
	    sdf = boxobj->m_prgShmid->Destroy();
	    if(sdf != STATUS_OK)
	    {
		DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    }
            boxobj->m_prgShmid = NULL;
            //sharedmemory will be destroyed by GetProgress if progress is 100%.
            DEBUGL4("CBox::StartCopyThread: Exit\n");		

            return NULL;	

        }

       	void* CBox::StartCutThread(void *arg)
        {
            DEBUGL4("CBox::StartCutThread-- Started \n");
            //Status retStatus;
            Status rst;
            Status sdf;
            //unique name given for locking the resource
            CString threadlockpath ="lockingstartCutBoxthread";
            //Copy the passed instance of the invoking object into a local variable 
            CBox* boxobj = (CBox*)arg;
            //Enter Critical section
            //Copy the pages from static variable to a local variable
            std::vector<CString>::iterator itr;
            std::vector<CString> documents;
            for(itr=m_CutVecofDocs.begin();itr!=m_CutVecofDocs.end();itr++)
                documents.push_back(*itr);	

            m_CutVecofDocs.clear();

            //Create Shared memory used for writing the updted progress in it
            void *pCutMapAddr;
            if(!boxobj->m_prgShmid)
            {
                DEBUGL1("CBox::StartCutThread: -- Failed to Create Shared Memory for Cut Progress Name \n ");
                boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
                //m_CutFlag = FLAG_RESET;
                return NULL;
            }
            else
            {
                int iShmPidSize = boxobj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                boxobj->m_prgShmid->Map(pCutMapAddr);
                if(pCutMapAddr!=NULL)
                {
                    memset(pCutMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1("CBox::StartCutThread: -- Mapping Failed for Cut Progress Name\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
                    //m_CutFlag = FLAG_RESET;
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
            }


            //set the initial value of Cut Document progress as 1% . The Start Cut 
            //thread will update it as and when the operation progresses
            *((int*)pCutMapAddr) = 1;

            std::vector<CString>::iterator iter;
            std::vector<CString> vec;

            //Get the List of Documents in Clipboard
            if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
            {
                DEBUGL1("CBox::StartCutThread: Getting collection list failed");
                boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	boxobj->m_prgShmid = NULL;
                return NULL;
            }
            //Delete Clipboard documents,if any
            for(unsigned int i = 0;i < vec.size(); i++) 
            {
                CString fulldocumentname = vec[i];
                CString documentname;
                CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";

				DEBUGL8("CBox::StartCutThread: vector<%s>, fullDocName<%s> \n",vec[i].c_str(),fulldocumentname.c_str());

                //Check if the clipborad document is of the same user
                CString sid;
                if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
                {	
                    DEBUGL1("CBox::StartCutThread:GetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }		
                DEBUGL8("CBox::StartCutThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),boxobj->m_sessionID.c_str());
                if(sid!=boxobj->m_sessionID)
                    continue;

                //Now delete the Box
                if((ci::operatingenvironment::Folder::Remove(resourceKey,true) != STATUS_OK))
                {
                    DEBUGL1("CBox::StartCutThread:: DeleteResource <%s> is failed\n", resourceKey.c_str());
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
            }

            //Refresh all the documents in the Box
            DocumentList docList;
            DocumentList::iterator doc;	
            if(boxobj->GetDocumentList(docList) != STATUS_OK) 
            {
                DEBUGL1("CBox::StartCutThread::Getting document list is failed\n");
                boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	boxobj->m_prgShmid = NULL;
                return NULL;
            }
            for(doc=docList.begin();doc!=docList.end();doc++)
            {
                // check current status
                DocStatus st;
                (*doc)->GetStatus(st);
                if(!(st==EDITING)) 
                {	
                    CString docName;
                    (*doc)->GetName(docName);
                    if(boxobj->UndoEditDocument(docName)!=STATUS_OK)
                    {
                        DEBUGL1("CBox::StartCutThread:UndoEditDocument for <%s> Failed\n",docName.c_str());
                        boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            		boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                }
            }

            //Progress initialization
            int curProg =0;
            int count =1;
            uint totalCnt = documents.size();
            DEBUGL8("CBox::StartCutThread:Number_of_Docs = <%d>\n",totalCnt);
            std::map<CString,CString> PropertyMap;
            CString xmlfile("documentproperties.xml");
            std::vector<CString> notEditDocuments;
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                DEBUGL8("CBox::StartCutThread:Document <%s>\n",(*iter).c_str());		
                if(((*iter).empty()))
                {
                    DEBUGL1("CBox::StartCutThread: Document name empty\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }			
                //Original doc path 
                CString from = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,(*iter)) + "/";
                CString cutpath = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber) + "/";

                //Obtain the document
                DocumentRef doc;
                boxobj->GetDocument(doc,(*iter));
                if(!(doc))
                {
                    DEBUGL1("CBox::StartCutThread: Given Document does not exist\n");
                    if(Utility::CreateUniqueFile(cutpath, ".cutResourceNotFound_" + boxobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");


                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                notEditDocuments.push_back(*iter);
                // check current status
                DocStatus st;
                doc->GetStatus(st);
                if(st == USING || st == RESERVING)
                {
                    DEBUGL1("CBox::StartCutThread:Document is being used by another user <status: %d>\n", st);
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                if(st != READY) 
                {
                    DEBUGL1("CBox::StartCutThread: Document is NOT in READY state\n");
                    if(boxobj->UndoEditDocument(notEditDocuments)!=STATUS_OK)
                    {
                       DEBUGL1("CBox::StartCutThread:UndoEditDocument for Failed\n");
                       boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	       boxobj->m_prgShmid = NULL;
                       return NULL;
                    }		

                    if(Utility::CreateUniqueFile(cutpath, ".copypage2ndsession_" + boxobj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");

	    	    sdf = boxobj->m_prgShmid->Destroy();
	       	    if(sdf != STATUS_OK)
	    	    {
			DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    	    }
                    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                //Check for the user
                CString orgUserID;
                if(Utility::GetProperty(from,"documentproperties.xml","sessionID",orgUserID)!=STATUS_OK)
                {
                    DEBUGL1("CBox::StartCutThread:GetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                if((!(orgUserID.empty()))&&(boxobj->m_sessionID != orgUserID))
                {
                    DEBUGL1("CBox::StartCutThread:org SessionID not same as Current Session ID\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }

                if(orgUserID.empty())
                {
                    PropertyMap.clear();
                    //update the sessionID and cutDocument flag 
                    PropertyMap.insert(pair::value_type("sessionID",boxobj->m_sessionID.c_str()));
                    PropertyMap.insert(pair::value_type("cutDocument","true"));
                    sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)	
                    {	
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBox::StartCutThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CBox::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                            if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");
	    		    sdf = boxobj->m_prgShmid->Destroy();
	    		    if(sdf != STATUS_OK)
	    		    {
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		    }

                            boxobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CBox::StartCutThread:SetProperty for SessionID Failed\n");
                        boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);

            		boxobj->m_prgShmid = NULL;
                        return NULL;
                    }	
                }
                else
                {	
                    PropertyMap.clear();
                    //update the sessionID and cutDocument flag 
                    PropertyMap.insert(pair::value_type("cutDocument","true"));
                    sdf = Utility::SetProperties(from,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBox::StartCutThread:SetProperty failed because Disk is Full\n");
                            DEBUGL8("CBox::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                            if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                                DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");

	    		    sdf = boxobj->m_prgShmid->Destroy();
	  		    if(sdf != STATUS_OK)
	 		    {
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		    }
                            boxobj->m_prgShmid = NULL;
                            return NULL;
                        }
                        DEBUGL1("CBox::StartCutThread: Document being used by other user\n");
                        boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            		boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                }		
                /*Read the UUID from documentproperties.xml*/
                CString WorkspaceDocName("");
                if(proputils::GetProperty(boxobj->m_BoxBasePath, boxobj->m_BoxNumber, "", (*iter).c_str(), "", "WorkspaceDocName", WorkspaceDocName) != STATUS_OK)
                {
                    DEBUGL1("CBox::StartCutThread: GetProperty of WorkspaceDocName failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }

                //Clipboard doc path
                //CString newDocName=boxobj.m_sessionID+"_"+boxobj.m_BoxNumber+"_"+(*iter);
                //CString to =CLIPBOARD_PATH + newDocName + "/";
                CString newDocName = boxobj->m_sessionID + "_" + WorkspaceDocName;
				ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> ClipboardpathPtr = NULL;
                CString to =CLIPBOARD_PATH + newDocName;
				Status ds= ci::operatingenvironment::Folder::CreateFolder(ClipboardpathPtr,to.c_str());
				if(!ClipboardpathPtr)
				{
					DEBUGL1("CBoxDocument::CreateFolder::ClipboardpathPtr is NULL\n");	
				}
				if(ds != STATUS_OK)
				{
					rst = Utility::RemoveResource(to);
					if(rst != STATUS_OK)
						DEBUGL2("CBoxDocument::CreateFolder: Failed to remove half created folder\n");
					DEBUGL1("CBoxDocument::CreateFolder::Creation of %s Failed\n", to.c_str());
					boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
					boxobj->m_prgShmid = NULL;
	                		return NULL;
					
	
				}
				to = to + "/";
				CString fromdocxml = from + "/documentproperties.xml";
				CString fromdocdom = from + "/documentproperties_dom";
				Status retsts = ci::operatingenvironment::File::CopyFile(fromdocxml,to);
                if (retsts !=STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");
                    if(retsts==::STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCutThread: Copying document to ClipBoard failed because disk is FULL\n");
                        if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");
	    		sdf = boxobj->m_prgShmid->Destroy();
	    		if(sdf != STATUS_OK)
	   		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCutThread: Copying document to ClipBoard failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
	            boxobj->m_prgShmid = NULL;
	            return NULL;
                }
		retsts = ci::operatingenvironment::File::CopyFile(fromdocdom,to);
                if (retsts !=STATUS_OK)	
                {	
                    rst = Utility::RemoveResource(to);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");
                    if(retsts==::STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCutThread: Copying document to ClipBoard failed because disk is FULL\n");
                        if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");
	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCutThread: Copying document to ClipBoard failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
		    boxobj->m_prgShmid = NULL;
	            return NULL;
                }

                //Set the properties
                CString resourceKey = CLIPBOARD_PATH+newDocName+"/";
                PropertyMap.clear();
                CString docxmlfile("documentproperties.xml");		
                //update the other properties 
                PropertyMap.insert(pair::value_type("srcBoxBasePath",boxobj->m_BoxBasePath.c_str()));
                PropertyMap.insert(pair::value_type("srcBoxNumber",boxobj->m_BoxNumber.c_str()));
                PropertyMap.insert(pair::value_type("srcFolderName",""));
                PropertyMap.insert(pair::value_type("srcDocumentName",(*iter).c_str()));
                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)
                {	
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCutThread:SetProperty failed because Disk is Full\n");

                        if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");

	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCutThread: Setting properties on document failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);

            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }	

                //Set Page Properties
                CString strpageno;
                std::ostringstream str;
                // convert int page no to str page no
                str << std::setfill('0') << std::setw(3) << 1;
                strpageno= str.str();

                PageRef page;					
                if(doc->GetPage(1, page) != STATUS_OK) 
                {
                    DEBUGL1("CBox::StartCutThread: Getting page %d failed\n", strpageno.c_str());
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");			
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }	
                PropertyMap.clear();
                try
                {
                    if(!page)
                    {
                        DEBUGL1("CBox::StartCutThread: page object is null\n");
                        boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);
                        rst = Utility::RemoveResource(resourceKey);
                        if(rst != STATUS_OK)
                            DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");			

	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
            		boxobj->m_prgShmid = NULL;
                        return NULL;          
                    }
                    CString ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(IMAGEPAGETYPE);	
                    CString pagePath=from+"Image/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsImagedataPresent","true"));
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(SUBSAMPLINGPAGETYPE);
                    pagePath=from+"Subsampling/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent","true"));
                    }
                    ext = dynamic_cast<CPage*>(page.operator->())->GetExtension(THUMBNAILPAGETYPE);	
                    pagePath=from+"Thumbnail/"+strpageno+ext;
                    if(Utility::ResourceExist(pagePath))
                    {
                        PropertyMap.insert(pair::value_type("IsThumbnaildataPresent","true"));		
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CBox::StartCopyThread: Caught exception (%s)\n",e.what());
	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }
                sdf = Utility::SetProperties(resourceKey,docxmlfile,PropertyMap);
                if(sdf != STATUS_OK)			
                {
                    rst = Utility::RemoveResource(resourceKey);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::StartCutThread: Failed to remove half created folder\n");

                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::StartCutThread:SetProperty failed because Disk is Full\n");
                        DEBUGL8("CBox::StartCutThread::savepath = (%s)\n", cutpath.c_str());
                        if(Utility::CreateUniqueFile(cutpath, ".cutDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
                            DEBUGL2(" CBox::StartCutThread: Unable to create the file\n");

	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
                        boxobj->m_prgShmid = NULL;
                        return NULL;
                    }
                    DEBUGL1("CBox::StartCutThread:SetProperty Failed\n");
                    boxobj->ErrorFileCreation(boxobj->m_CutErrfile,boxobj->m_prgShmid);

            	    boxobj->m_prgShmid = NULL;
                    return NULL;
                }

		//Progress updation
		curProg = (int)((((float)count++)/((float)totalCnt))*100);
		if(curProg!= 100)
		{
			*((int*)pCutMapAddr) = curProg;				
			DEBUGL8("CBox::StartCutThread::Current Progress<%d>\n",curProg);
		}
            }
			*((int*)pCutMapAddr) = PROGRESS_COMPLETED;				

	    		sdf = boxobj->m_prgShmid->Destroy();
	   		if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
	    		}
			boxobj->m_prgShmid = NULL;
			DEBUGL4("CBox::StartCutThread: Exit\n");			
			return NULL;	
        }

        void* CBox::StartPasteThread(void *arg)
		{

			DEBUGL4("CBox::StartPasteThread-- Started \n");
			//Status retStatus;
			Status rst;
			Status sdf;
			CString xmlfile("documentproperties.xml");
			//Copy the passed instance of the invoking object into a local variable 
			CBox* boxobj = (CBox*)arg;
			//unique name given for locking the resource
			CString threadlockpath ="lockingstartPasteBoxthread";

			void *pPasteMapAddr;
			if(!boxobj->m_prgShmid)
			{
				DEBUGL1("CBox::StartPasteThread: -- Failed to Create Shared Memory for Paste Progress Name \n ");
				boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            			boxobj->m_prgShmid = NULL;
				return NULL;
			}
			else
			{
				int iShmPidSize = boxobj->m_prgShmid->getSize();
				//Map the Created Segment to another address
				boxobj->m_prgShmid->Map(pPasteMapAddr);
				if(pPasteMapAddr!=NULL)
				{
					memset(pPasteMapAddr,0,iShmPidSize);
				}
				else
				{
					DEBUGL1("CBox::StartPasteThread: -- Mapping Failed for Paste Progress Name\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					//   m_PasteFlag= FLAG_RESET;
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
			}

			//set the initial value of Paste Document progress as 1% . The Start Paste 
			//thread will update it as and when the operation progresses
			*((int*)pPasteMapAddr) = 1;


			DEBUGL4("CBox::StartPasteThread: Enter - m_BoxBasePath<%s>,m_BoxNumber<%s>\n",boxobj->m_BoxBasePath.c_str(),boxobj->m_BoxNumber.c_str());

			std::vector<CString> vec;
			vec.clear();
			//Get the List of Documents in Clipboard
			if(Utility::GetCollectionList(vec,CLIPBOARD_PATH)!=STATUS_OK) 
			{
				DEBUGL1("CBox::StartPasteThread: Getting collection list failed");
				boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            			boxobj->m_prgShmid = NULL;
				return NULL;
			}

			//Progress initialization
			int curProg =0;
			unsigned int count=0, pCount = 0;
			uint totalCnt = vec.size();
			std::map<CString,CString> PropertyMap;
			std::vector<CString>::iterator iVec;
			for(iVec = vec.begin();iVec != vec.end(); iVec++) 
			{
				//get the Documentname.The content of the vec will be delimited by "/".
				CString fulldocumentname = *iVec;
				CString documentname;		
				CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
				if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}

				DEBUGL8("CBox::StartPasteThread: vector<%s>, fullDocName<%s> and docName<%s>\n",(*iVec).c_str(),fulldocumentname.c_str(),documentname.c_str());

				//Check for limit
				count=0;
				Utility::GetDocumentCount(boxobj->m_BoxBasePath, boxobj->m_BoxNumber,"",count);
				if(boxobj->m_BoxBasePath != "/storage/box/ITUTBoxes" && count >= CBoxDocument::DOC_LIMIT) 
				{
					DEBUGL1("CBox::StartPasteThread: The number of documents reach limit\n");
					std::vector<CString> vecDoc;
					vecDoc.clear();
					//Get the List of Documents in Clipboard
					if(Utility::GetCollectionList(vecDoc,CLIPBOARD_PATH)!=STATUS_OK) 
					{
						DEBUGL1("CBox::StartPasteThread: Getting collection list failed");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            					boxobj->m_prgShmid = NULL;
						return NULL;
					}

					for(iVec = vecDoc.begin();iVec != vecDoc.end(); iVec++) 
					{
						//get the Documentname.The content of the vec will be delimited by "/".
						CString fulldocumentname = *iVec;
						CString documentname;		
						CString resourceKey=CLIPBOARD_PATH+fulldocumentname+"/";
						if(Utility::GetProperty(resourceKey,"documentproperties.xml","documentName",documentname)!=STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}

						DEBUGL8("CBox::StartPasteThread: vector<%s>, fullDocName<%s> and docName<%s>\n",(*iVec).c_str(),fulldocumentname.c_str(),documentname.c_str());
						CString from = CLIPBOARD_PATH + fulldocumentname+"/";
						CString path=Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber)+"/";
						CString newpath = path + documentname + "/";
						CString pastepath = path;

						//Read the properties of the original box and see if the document is cut from the same box
						CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
						if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}
						if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}


						CString orgPath;
						if(srcFolderName.empty())
							orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
						else
							orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

						DEBUGL8("CBox::StartPasteThread: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
						PropertyMap.clear();
						//update the sessionID and cutDocument flag 
						//PropertyMap.insert(pair::value_type("sessionID",""));
						PropertyMap.insert(pair::value_type("cutDocument",""));
						sdf = Utility::SetProperties(orgPath,xmlfile,PropertyMap);
						if(sdf != STATUS_OK)	
						{	
							rst = Utility::RemoveResource(resourceKey);
							if(rst != STATUS_OK)
								DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

							if(sdf == STATUS_DISK_FULL)
							{
								DEBUGL1("CBox::StartPasteThread:SetProperty failed because Disk is Full\n");
								DEBUGL8("CBox::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
								if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CBox::StartPasteThread: Unable to create the file\n");

	    							sdf = boxobj->m_prgShmid->Destroy();
	   							if(sdf != STATUS_OK)
	    							{
									DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
					    			}
								boxobj->m_prgShmid = NULL;
								return NULL;
							}
							DEBUGL1("CBox::StartPasteThread:SetProperty Failed\n");
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            						boxobj->m_prgShmid = NULL;
							return NULL;
						}		
					}					
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}

				//Check if the clipborad document is of the same user
				CString sid;
				if(Utility::GetProperty(resourceKey,"documentproperties.xml","sessionID",sid)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				DEBUGL8("CBox::StartPasteThread: SID <%s> and m_sessionID <%s>\n",sid.c_str(),boxobj->m_sessionID.c_str());

				if(sid!= boxobj->m_sessionID)
				{
					DEBUGL2("CBox::StartPasteThread:Session ID's are different hence continuing\n");
					continue;
				}

				CString from = CLIPBOARD_PATH + fulldocumentname+"/";
				CString path=Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber)+"/";
				CString newpath = path + documentname + "/";
				CString pastepath = path;

				//Read the properties of the original box and see if the document is cut from the same box
				CString srcBasePath, srcBoxNumber, srcFolderName, srcDocumentName, cutDocumentFlag;
				if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxBasePath", srcBasePath) != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcBoxNumber", srcBoxNumber) != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcFolderName", srcFolderName) != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "srcDocumentName", srcDocumentName) != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(Utility::GetProperty(from, "documentproperties.xml", "cutDocument", cutDocumentFlag) != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Getproperty failded\n");			
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}


				CString orgPath;
				if(srcFolderName.empty())
					orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcDocumentName + "/";
				else
					orgPath = srcBasePath + "/" + srcBoxNumber + "/" + srcFolderName + "/" +  srcDocumentName + "/";		

				DEBUGL8("CBox::StartPasteThread: orgPath (%s) newpath (%s)\n",orgPath.c_str(), newpath.c_str());
				DEBUGL8("CBox::StartPasteThread: cutDocumentFlag = (%s)\n",cutDocumentFlag.c_str());

				bool bSamePath = false;
				Status retStatus,retsts;
				CString truncdocname = "";
				//In case of cut document and paste in different box
				//check if same resource exist and if exist increment document name
				CString NewWorkspaceDocName("");
				if(orgPath.compare(newpath) && (cutDocumentFlag == "true"))
				{
					if(documentname.length()>64)
					{
						DEBUGL8("CBox::StartPasteThread:calling TruncateDocumentName for 64 characters as the document name isof more than 64 characters\n");
						retsts = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);				
						if(retsts != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread::TruncateDocumentName() has not returned STATUS_OK\n");	
						documentname = truncdocname;
						newpath = path + documentname;
					}		
					if(Utility::ResourceExist(newpath))
					{
						DEBUGL8("CBox::StartPasteThread:Document with same document name is already present in the destination path\n");
						retsts = Utility::LimitTo64Characters(documentname,newpath,path);
						if(retsts != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread:LimitTo64Characters() has not returned STATUS_OK\n");	

					}
				}
              //In case of copy operation, if same document exist increment document name
			  else if(cutDocumentFlag == "false" || cutDocumentFlag == "")
			  {
				  if(documentname.length()>64)
				  {
					  DEBUGL8("CBox::StartPasteThread:calling TruncateDocumentName for 64 characters as the document name isof more than 64 characters\n");
					  retsts = Utility::TruncateDocumentName(documentname.c_str(),truncdocname,64);			
					  if(retsts != STATUS_OK)
						  DEBUGL1("CBox::StartPasteThread::TruncateDocumentName() has not returned STATUS_OK\n");	
					  documentname = truncdocname;
					  newpath = path + documentname;
				  }
				  if(Utility::ResourceExist(newpath))
				  {
					  DEBUGL8("CBox::StartPasteThread:Document with same document name is already present in the destination path\n");
					  retsts =  Utility::LimitTo64Characters(documentname,newpath,path);
					  if(retsts != STATUS_OK)
						  DEBUGL1("CBox::StartPasteThread:LimitTo64Characters() has not returned STATUS_OK\n");	

				  }
				  NewWorkspaceDocName = CUUID().toString();
			  }

				//In case of cut operation and boxbasepaht are same
				//remove the original document and paste the updated document
				if(cutDocumentFlag == "true")
				{
					CString to = newpath;
					if(!orgPath.compare(newpath) )
					{
						bSamePath = true;
					}
					CString pasteboxpath,pasteboxnumber,pastefoldername,pasteboxdocument;
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxBasePath",pasteboxpath)!=STATUS_OK)		
					{
						DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						boxobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcBoxNumber",pasteboxnumber)!=STATUS_OK)		
					{
						DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						boxobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcFolderName",pastefoldername)!=STATUS_OK)		
					{
						DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						boxobj->m_prgShmid = NULL;
						return NULL;
					}
					if(Utility::GetProperty(resourceKey,"documentproperties.xml","srcDocumentName",pasteboxdocument)!=STATUS_OK)		
					{
						DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						boxobj->m_prgShmid = NULL;
						return NULL;
					}					
					CString orgDocumentPath = Utility::GetResourcePath(pasteboxpath,pasteboxnumber,pastefoldername,pasteboxdocument) + "/";		

					DEBUGL1("CBox::StartPasteThread:pasteboxpath (%s) pasteboxnumber (%s)pastefoldername(%s) to (%s)\n",pasteboxpath.c_str(), pasteboxnumber.c_str(),pastefoldername.c_str(),to.c_str()); 
					if(bSamePath == false){
						retStatus = ci::operatingenvironment::Folder::CopyDir(orgDocumentPath,to);
						if(retStatus !=STATUS_OK)
						{
							DEBUGL1("CBox::StartPasteThread: Copying document to ClipBoard failed\n");
							rst = Utility::RemoveResource(to);
							if(rst != STATUS_OK)
								DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

							if(retStatus == STATUS_DISK_FULL)
							{
								if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
									DEBUGL2(" CBox::StartPasteThread: Unable to create the file\n");
	    							sdf = boxobj->m_prgShmid->Destroy();
						   		if(sdf != STATUS_OK)
						    		{
									DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
						    		}
								boxobj->m_prgShmid = NULL;
								return NULL;
							}
							boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
							boxobj->m_prgShmid = NULL;
							return NULL;
						}
					}
					retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties.xml",to);
					if (retsts !=STATUS_OK)	
					{
						Status rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

						DEBUGL1("CBox::StartPasteThread: Copying document to failed with Status  %d\n",retsts);
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						boxobj->m_prgShmid = NULL;
						return NULL;
					}
					retsts = ci::operatingenvironment::File::CopyFile(from + "/documentproperties_dom",to);
					if (retsts !=STATUS_OK)	
					{
						Status rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

						DEBUGL1("CBox::StartPasteThread: Copying document to failed with Status  %d\n",retsts);
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            					boxobj->m_prgShmid = NULL;
						return NULL;
					}

				}
				//In case of copy operation copy the dir to original document
				else
				{
					CString to = newpath;
					retStatus = ci::operatingenvironment::Folder::CopyDir(from,to);
					if(retStatus !=STATUS_OK)
					{
						rst = Utility::RemoveResource(to);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

						DEBUGL1("CBox::StartPasteThread: Copying document to ClipBoard failed\n");
						if(retStatus == STATUS_DISK_FULL)
						{
							if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CBox::StartPasteThread: Unable to create the file\n");

	    						sdf = boxobj->m_prgShmid->Destroy();
					   		if(sdf != STATUS_OK)
					    		{
								DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
							}
							boxobj->m_prgShmid = NULL; 
							return NULL;
						}
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            					boxobj->m_prgShmid = NULL;
						return NULL;
					}
					NewWorkspaceDocName = CUUID().toString();
				}

				//Original Document Path
				CString orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName;
				resourceKey = Utility::GetResourcePath(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,"",documentname) + "/";		
				if(proputils::GetProperty(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,"",documentname,"","srcBoxBasePath",orgBoxBasePath)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

	    				sdf = boxobj->m_prgShmid->Destroy();
			   		if(sdf != STATUS_OK)
	    				{
						DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
			    		}
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(proputils::GetProperty(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,"",documentname,"","srcBoxNumber",orgBoxNumber)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				if(proputils::GetProperty(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,"",documentname,"","srcFolderName",orgFolderName)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}		
				if(proputils::GetProperty(boxobj->m_BoxBasePath,boxobj->m_BoxNumber,"",documentname,"","srcDocumentName",orgDocumentName)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}

				//Obtain the Clipboard document
				DocumentRef clipDoc;
				CString clipPath = CLIPBOARD_PATH;
              if(Utility::GetDocument(boxobj->m_sessionID, clipDoc,clipPath,"","",fulldocumentname)==STATUS_OK)
              {
				//Getting document properties from original document
				DEBUGL8("CBox::StartPasteThread:Getting Properties\n");		
				std::map<CString,CString> webDAVProperties;
				try
				{
					if(!clipDoc)
					{
						DEBUGL1("CBox::StartPasteThread: doc object is null\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");
						boxobj->m_prgShmid = NULL;
						return NULL;         
					}
					Status ret = dynamic_cast<CDocument*>(clipDoc.operator->())->GetProperties(webDAVProperties);
					if(ret != STATUS_OK) 
					{
						DEBUGL1("CBox::StartPasteThread:GetProperties of OrgDoc failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            					boxobj->m_prgShmid = NULL;
						return NULL;
					}
				}		
				catch(exception &e)
				{
					DEBUGL1("CBox::StartPasteThread: Caught exception (%s)\n",e.what());
	    				sdf = boxobj->m_prgShmid->Destroy();
			   		if(sdf != STATUS_OK)
	    				{
						DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
			    		}
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}		
				std::map<CString,CString>::iterator mapIter;
				for(mapIter=webDAVProperties.begin();mapIter!=webDAVProperties.end();mapIter++)
				{
					DEBUGL8("CBox::StartPasteThread: Key<%s> and Value<%s>\n",(mapIter->first).c_str(),(mapIter->second).c_str());
				}

				//Setting document properties on current document
				DocumentRef curDoc;		
				curDoc = new CDocument(boxobj->m_sessionID, boxobj->m_BoxBasePath, boxobj->m_BoxNumber,"", documentname);

				if(!curDoc)
				{
					DEBUGL1("CBox::StartPasteThread: doc object is null\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;          
				}
				//Setting WorkspaceDocName property
				CString key = "WorkspaceDocName";
				if(cutDocumentFlag != "true")
					webDAVProperties[key] = NewWorkspaceDocName;
				//Re-setting the cut flag
				webDAVProperties["cutDocument"] = "";
				//Setting the new document name
				webDAVProperties["documentName"] = documentname;
				//Setting the creation date and modified date
				CString creatTime = Utility::GetUnixTime();
				webDAVProperties["creationDate"] = creatTime;
				webDAVProperties["lastModifiedDate"] = creatTime;

				//Write the properties of the copied/cut document to documentproperties.xml of the paste document
				Status ret = dynamic_cast<CDocument*>(curDoc.operator->())->SetProperties(webDAVProperties);
				if(ret != STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:SetProperties of CurDoc failed\n");
					curDoc = NULL; // release
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);

					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}
				DEBUGL8("CBox::StartPasteThread:SetProperties of cut/copied document to paste document..\n");

				//Check for the CutDocument property and delete the original document
				DocumentRef orgDoc;
				if(Utility::GetDocument(boxobj->m_sessionID, orgDoc,orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread: Obtaining Original Document failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}

				CString flag;
				CString dpath =Utility::GetResourcePath(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName)+"/";
				if(proputils::GetProperty(orgBoxBasePath,orgBoxNumber,orgFolderName,orgDocumentName,"","cutDocument",flag)!=STATUS_OK)			
				{
					DEBUGL1("CBox::StartPasteThread:GetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;
				}

				if(flag=="true")
				{	
					if(!orgDoc)
					{
						DEBUGL1("CBox::StartPasteThread: doc object is null\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            					boxobj->m_prgShmid = NULL;
						return NULL;
					}
					// Start to Delete
					if(dynamic_cast<CDocument*>(orgDoc.operator->())->Delete() != STATUS_OK) 
					{
						DEBUGL1("CBox::StartPasteThread: Deleting document failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            					boxobj->m_prgShmid = NULL;
						return NULL;
					}
				}	
				else
				{
					//Reset the properties on the Original document			
					PropertyMap.clear();
					//update the sessionID and cutDocument flag 
					PropertyMap.insert(pair::value_type("sessionID",""));
					PropertyMap.insert(pair::value_type("cutDocument",""));
					sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap);
					if(sdf != STATUS_OK)	
					{	
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

						if(sdf == STATUS_DISK_FULL)
						{
							DEBUGL1("CBox::StartPasteThread:SetProperty failed because Disk is Full\n");
							DEBUGL8("CBox::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
							if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
								DEBUGL2(" CBox::StartPasteThread: Unable to create the file\n");
	    						sdf = boxobj->m_prgShmid->Destroy();
					   		if(sdf != STATUS_OK)
			    				{
								DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
			    				}

							boxobj->m_prgShmid = NULL;
							return NULL;
						}
						DEBUGL1("CBox::StartPasteThread:SetProperty Failed\n");
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            					boxobj->m_prgShmid = NULL;
						return NULL;
					}									
				}

				if(flag=="true")
				{	
					//Clear the ClipBoard
					if((ci::operatingenvironment::Folder::Remove(from,true) != STATUS_OK))
					{
						DEBUGL1("CBox::StartPasteThread: DeleteResource %s is failed\n", from.c_str());
						boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
						rst = Utility::RemoveResource(resourceKey);
						if(rst != STATUS_OK)
							DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            					boxobj->m_prgShmid = NULL;
						return NULL;
					}	
				}

				//Reset the properties on the Original document
				PropertyMap.clear();

				//CString docxmlfile("documentproperties.xml");
				PropertyMap.insert(pair::value_type("srcBoxNumber",""));
				PropertyMap.insert(pair::value_type("srcBoxBasePath",""));
				PropertyMap.insert(pair::value_type("srcDocumentName",""));
				PropertyMap.insert(pair::value_type("IsImagedataPresent",""));
				PropertyMap.insert(pair::value_type("IsSubsamplingdataPresent",""));
				PropertyMap.insert(pair::value_type("IsThumbnaildataPresent",""));
				//update the sessionID and cutDocument flag 
				PropertyMap.insert(pair::value_type("sessionID",""));
				PropertyMap.insert(pair::value_type("cutDocument",""));

				sdf = Utility::SetProperties((path + documentname + "/"),xmlfile,PropertyMap);
				if(sdf != STATUS_OK)	
				{	
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");
					if(sdf == STATUS_DISK_FULL)
					{
						DEBUGL1("CBox::StartPasteThread:SetProperty failed because Disk is Full\n");
						DEBUGL8("CBox::StartPasteThread::savepath = (%s)\n", pastepath.c_str());
						if(Utility::CreateUniqueFile(pastepath, ".pasteDiskFullBox_" + boxobj->m_sessionID) != STATUS_OK)
							DEBUGL2(" CBox::StartPasteThread: Unable to create the file\n");

	    					sdf = boxobj->m_prgShmid->Destroy();
				   		if(sdf != STATUS_OK)
		    				{
							DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
				    		}
						boxobj->m_prgShmid = NULL;
						return NULL;
					}
					DEBUGL1("CBox::StartPasteThread:SetProperty Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
            				boxobj->m_prgShmid = NULL;
					return NULL;
				}							
				if(dynamic_cast<CDocument*>(curDoc.operator->())->InitializeStatus()!=STATUS_OK)
				{
					DEBUGL1("CBox::StartPasteThread:Initializing Status Failed\n");
					boxobj->ErrorFileCreation(boxobj->m_PasteErrfile,boxobj->m_prgShmid);
					rst = Utility::RemoveResource(resourceKey);
					if(rst != STATUS_OK)
						DEBUGL1("CBox::StartPasteThread: Failed to remove half created folder\n");

            				boxobj->m_prgShmid = NULL;
					return NULL;

				}		
				//Progress updation
				pCount++;
				DEBUGL8("CBox::StartPasteThread::pCount = (%u), totalCount = (%u)\n",pCount,totalCnt);
				curProg = (int)((((float)pCount)/((float)totalCnt))*100);

				if(curProg != 100)
				{	
					*((int*)pPasteMapAddr) = curProg;				
					DEBUGL8("CBox::StartPasteThread::Current Progress<%d>\n",curProg);				
				}
	      }
			}
			*((int*)pPasteMapAddr) = PROGRESS_COMPLETED;				
	    		sdf = boxobj->m_prgShmid->Destroy();
			if(sdf != STATUS_OK)
	    		{
				DEBUGL1("CBox::StartCopyThread:: Unable to destroy shared memory\n");
			}
			boxobj->m_prgShmid = NULL;

			DEBUGL4("CBox::StartPasteThread: Exit\n");
			return NULL;

		}

        void CBox::ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid)
        {
            DEBUGL1("CBox::ErrorFileCreation: Entered \n");
            Status retStatus;
            CString sCurrDirPath = Utility::GetTmpPath(); 
            FilePtr fPtr = NULL;
            ci::operatingenvironment::Ref<ci::operatingenvironment::Folder> binFolder = NULL;

            //Create a file indicating the Status to be not Status Ok
            binFolder= ci::operatingenvironment::Folder::Bind(sCurrDirPath);
            if(!binFolder)
                DEBUGL2("CBox::ErrorFileCreation::Folder Binding Failed\n");
            fPtr = File::CreateFile(filename,binFolder,"w");
            if(fPtr)
                DEBUGL8("CBox::ErrorFileCreation::File Created Successfully\n");
            if(shmpid) {	
                retStatus = shmpid->Destroy();
                if(retStatus!=STATUS_OK)
                    DEBUGL2("CBox::ErrorFileCreation: Failed to Destroy Shared Segment Cut Prog Name \n");
            }
        }

		
        Status CBox::CreateDocument(DocumentRef& doc, CString &documentname)
        {
            Status rst; 
            Status sdf;
            doc = NULL;
            DEBUGL4("CBox::CreateDocument::Enter - documentname<%s>\n",documentname.c_str());		
            // confirm documentname is NOT empty
            if(documentname == "") 
            {
                DEBUGL1("CBox::CreateDocument::Document name is empty\n");
                return STATUS_FAILED;
	    }
	    bool bHasAvailableSize = false;
	    Status ret = Utility::IsStorageFull(bHasAvailableSize);
	    if(ret != STATUS_OK)
	    {
		    DEBUGL1("CBox::CreateDocument:: IsStorageFull() API failed for /storage \n");
		    return STATUS_FAILED;
	    }
	    else
	    {		
		    if(!bHasAvailableSize)
		    {
			    DEBUGL1("CBox::CreateDocument:: /storage is near full return STATUS_DISK_FULL\n");
			    return STATUS_DISK_FULL;
		    }
	    }
            // confirm documentname folder exists
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber) + "/";
            unsigned int count=0;
            // RAII to enter Critical Section
            CString uniqFileName;
            if(Utility::GetUniqueFile(path,uniqFileName) != STATUS_OK)
            {
                DEBUGL1("CBox::CreateDocument:: GetUniqueFile failed\n");
                return STATUS_FAILED;		
            }

            CriticalSectionRef cs = new CriticalSection(uniqFileName);

            ret = Utility::GetDocumentCount(m_BoxBasePath, m_BoxNumber,"",count);
            if(ret!=STATUS_OK)
            {
                DEBUGL1("CBox::CreateDocument::GetDocument Count failed\n");
                return STATUS_FAILED;
            }
			if(m_BoxBasePath == "/storage/box/PageLogBoxes" && count >= CBoxDocument::PAGELOGBOX_DOC_LIMIT) 
			{
				DEBUGL1("CBox::CreateDocument:: The number of documents reached max limit for PageLogBoxes\n");
				return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
			}
	    if ((m_BoxBasePath == "/storage/box/FaxRxPreviewBoxes") && (count >= CBoxDocument::FAXRXPREVIEWBOX_DOC_LIMIT))
	    {
		    DEBUGL1("CBox::CreateDocument:: The number of documents reached max limit for %s\n",m_BoxBasePath.c_str());
		    return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
	    }
	    if ((m_BoxBasePath != "/storage/box/ITUTBoxes")&&(m_BoxBasePath != "/storage/box/PageLogBoxes") && (m_BoxBasePath != "/storage/box/FaxRxPreviewBoxes") && (count >= CBoxDocument::DOC_LIMIT) )
			{
				DEBUGL1("CBox::CreateDocument:: The number of documents reached max limit for %s\n",m_BoxBasePath.c_str());
				return STATUS_MAX_ALLOWED_RESOURCES_REACHED;
			}

			
            //DEBUGL8("CBox::CreateDocument::CREATEDOC_PERF 2\n");

            CString newpath =  path + documentname + "/";
            if(Utility::ResourceExist(newpath)) 
            {
                // if the document name already exists get the next available document Number
                uint docnum = 1;
                std::ostringstream strm;
                // if documentname folder exist, add suffix to path
                while(true) 
                {
                    strm.str("");
                    strm << std::setfill('0') << std::setw(3) << docnum;
                    newpath = path + documentname + "-" + strm.str() + "/";
                    if(!Utility::ResourceExist(newpath)) 
                    {
                        documentname = documentname + "-" + strm.str();
                        break;
                    }
                    docnum++;
                }
            }

            doc = new CDocument(m_sessionID, m_BoxBasePath, m_BoxNumber,"", documentname);

            //DEBUGL8("CBox::CreateDocument::CREATEDOC_PERF 3\n");
            // create document folders and status file
            try
            {  
                if(!doc)
                {
                    DEBUGL1("CBox::CreateDocument: doc object is null\n");
                    return STATUS_FAILED;
                }
                ret = dynamic_cast<CDocument*>(doc.operator->())->Initialize();
                if(ret != STATUS_OK) 
                {
                    DEBUGL1("CBox::CreateDocument::Document initialization is failed\n");
                    doc = NULL; // release
                    rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CreateDocument: Failed to remove half created document\n");
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("CBox::CreateDocument: Caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }

            //DEBUGL8("CBox::CreateDocument::CREATEDOC_PERF 4\n");
            //Copy documentproperties.xml file to doc path	
	    dom::DocumentRef domDocRef;
	    ci::hierarchicaldb::HierarchicalDBRef pHDB = NULL;
	    pHDB = ci::hierarchicaldb::HierarchicalDB::Acquire(NULL);
	    if (!pHDB)
	    {
		    DEBUGL1("CBoxDocument::CreateDocument: Failed to Acquire HierarchicalDB\n");
		    return STATUS_FAILED;
	    }

	    Status ds = pHDB->CreateDocumentFromFile(path+"/"+documentname, "documentproperties_dom", domDocRef, Utility::GetEB2ROOTPath() + "/bin/documentproperties.xml");
            if(ds != STATUS_OK)
            {
                DEBUGL1("CBox::CreateDocument::Creation of %s Failed\n", path.c_str());
                doc = NULL;
                rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
                if(rst != STATUS_OK)
                    DEBUGL1("CBox::CreateDocument: Failed to remove half created document\n");
                return ds;	
            }

            //DEBUGL8("CBox::CreateDocument::CREATEDOC_PERF 5\n");
            // Save WebDAV properties
            try
            {
                ret = dynamic_cast<CDocument*>(doc.operator->())->SaveProperties();
                if(ret != STATUS_OK) 
                {
                    DEBUGL1("CBox::CreateDocument::SaveProperties failed\n");
                    doc = NULL; // release
                    rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
                    if(rst != STATUS_OK)
                        DEBUGL1("CBox::CreateDocument: Failed to remove half created document\n");		
                    return ret;
                }
            }
            catch(exception &e)
            {
                DEBUGL1("CBox::CreateDocument: Caught exception (%s)\n",e.what());
                return STATUS_FAILED;
            }
            //DEBUGL8("CBox::CreateDocument::CREATEDOC_PERF 6\n");
            sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","totalDocSize", "0");
            if(sdf != STATUS_OK)
            {
                rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
                if(rst != STATUS_OK)
                    DEBUGL1("CBoxDocument::CreateDocument: Failed to remove half created document\n");

                doc = NULL; // release
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::CreateDocument : Failed to set the property because disk is Full\n");

                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::CreateDocument : Failed to set the property\n");		
                return STATUS_FAILED;
            }
            /*Generate UUID and save it in documentproperties.xml.This UUID can be used as the name of the Document in Workspace/Clipboard.*/
            CString WorkspaceDocName = CUUID().toString();
            sdf = proputils::SetProperty(m_BoxBasePath, m_BoxNumber, "", documentname, "", "WorkspaceDocName", WorkspaceDocName);
            if(sdf != STATUS_OK)
            {
                rst = Utility::RemoveResource(m_BoxBasePath + "/" + m_BoxNumber + "/"  + documentname);
                if(rst != STATUS_OK)
                    DEBUGL1("CBoxDocument::CreateDocument: Failed to remove half created document\n");

                doc = NULL; //release
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::CreateDocument : Failed to set the property because disk is full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::CreateDocument : Failed to set the property\n");
                return STATUS_FAILED;
            }

            DEBUGL4("CBox::CreateDocument::Exit\n");		
            return STATUS_OK;
        }

        Status CBox::DeleteDocument(CString documentname)
        {
            DEBUGL4("CBox::DeleteDocument::Enter\n");		

            CString Path = m_BoxBasePath + "/" + m_BoxNumber + "/" + documentname + "/";
            if(!Utility::ResourceExist(Path))
            {
                DEBUGL2("CBox::DeleteDocument::Document<%s> not found.!\n",documentname.c_str());
                return STATUS_RESOURCENOTFOUND;
            }
                
            // Check Document Status
            DocStatus st;
            if(Utility::GetStatus(m_BoxBasePath, m_BoxNumber, "", documentname, st)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get document status\n");
                return STATUS_FAILED;							
            }


            CString session;
            if(Utility::GetProperty(m_BoxBasePath  + "/" + m_BoxNumber + "/" + documentname, "documentproperties.xml", "sessionID", session)!=STATUS_OK)
            {
                DEBUGL1("CBox::DeleteDocument: Obtaining session id failed\n");
                //Check if save is in progress.. if so return STATUS_USER_USING
                CString savefilenam = "";
                if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                    DEBUGL2("CBox::DeleteDocument: Unable to get the file\n");

                DEBUGL8("CBox::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                if(!savefilenam.empty())
                {
                    DEBUGL1("CBox::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                    return STATUS_USER_USING;
                } 
                return STATUS_FAILED;
            }
            DEBUGL8("CBox::DeleteDocument:: document sessionid (%s) current session id (%s)\n", session.c_str(), m_sessionID.c_str());			

            //If document sessionid and current session id are same then allow editing document to delete.
            //If both are in different, then dont allow editing document to delete
            if(session == m_sessionID)
            {
                // if NOT (READY or EDITING or CREATING)
                if(!((st == READY) || (st == EDITING) || (st == CREATING))) 
                {
                    DEBUGL1("CBox::DeleteDocument::Document Status is not READY, EDITING\n");
                    return STATUS_FAILED;
                }
            } 
            else if(session != m_sessionID) 
            {
                // if NOT (READY)
                if(!(st == READY))
                {
                    DEBUGL1("CBox::DeleteDocument::Document Status is not READY\n");
                    if(st == EDITING) {
                        DEBUGL1("CBox::DeleteDocument: document is in editing state. return STATUS_USER_EDITING\n");				
                        return STATUS_USER_EDITING;
                    }
                    else if(st == USING || st == RESERVING) {
                        DEBUGL1("CBox::DeleteDocument: document is in using/reserving<%d> state. return STATUS_USER_USING\n", st);				
                        return STATUS_USER_USING;
                    }
                    else  {
                        DEBUGL1("CBox::DeleteDocument::return STATUS_FAILED\n");				
                        return STATUS_FAILED;
                    }
                }
                else 
                {
                    CString savefilenam = "";
                    if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                        DEBUGL2("CBox::DeleteDocument: Unable to get the file\n");

                    DEBUGL8("CBox::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                    if(!savefilenam.empty())
                    {
                        DEBUGL1("CBox::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                        return STATUS_USER_USING;
                    } 
                }
            }  

            Status ds;
            if(st!=DELETING)
            {	
                if(Utility::ChangeStatus(m_BoxBasePath, m_BoxNumber, "", documentname, DELETING) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                    return STATUS_FAILED;
                }
            }	

            CString path = Utility::GetResourcePath(m_BoxBasePath, 
                    m_BoxNumber,
                    "",
                    documentname) + "/";
            uint64 tempsize = 0;
            CString val;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"",documentname,"","totalDocSize", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                return STATUS_FAILED;
            }
            tempsize = val.length()? atoi(val.c_str()): 0;
            uint32 count,docpgcount;
            int pos;
            CString boxbasepath_new("");
            pos = m_BoxBasePath.rfind("/");
            boxbasepath_new =  m_BoxBasePath.substr(pos+1);
            CString resourceKey("");
            CString resourcedocKey("");
            CString doctype("");
            CString pagecnt("");
            CString docpagecnt("");
            resourceKey = m_BoxBasePath+ "/" + m_BoxNumber +"/";
            resourcedocKey = m_BoxBasePath+ "/" + m_BoxNumber +"/"+documentname+"/";
            if(boxbasepath_new == "ITUTBoxes")
            {
                if(Utility::GetProperty(resourceKey,"boxproperties.xml","documentType",doctype) != STATUS_OK)
                {
                    DEBUGL1("CBox::Delete::Getting documentType property failed\n");

                    return STATUS_FAILED;
                }
                if(doctype == "Confidential" || doctype == "BulletinBoard")
                {
                    if(Utility::GetProperty(resourceKey,"boxproperties.xml","BoxPageCount",pagecnt) != STATUS_OK)

                    {
                        DEBUGL1("CBox::Delete::Getting confidentialPageCount property failed\n");
                        return STATUS_FAILED;
                    }
                    std::istringstream totalPageSizeStr(pagecnt);
                    totalPageSizeStr >> count;
                    if(Utility::GetProperty(resourcedocKey,"documentproperties.xml","totalPages",docpagecnt) != STATUS_OK)
                    {
                        DEBUGL1("CBox::Delete::Getting confidentialPageCount property failed\n");
                        return STATUS_FAILED;
                    }
                    std::istringstream totalPageSizeStr1(docpagecnt);
                    totalPageSizeStr1 >> docpgcount;
		    //Fix for EBX_STFR_15778: BoxPageCount is updated with 0 for BulleinBoard ITUTBoxes as only one document can exist
		    //at a time in the BulletinBoard ITUTBoxes
		    if(doctype == "BulletinBoard")
		    {
			    DEBUGL8("\nCBox::DeleteDocument::Box is BulleinBoard ITUTBoxes. Updating BoxPageCount with 0\n");
			    count = 0;
		    }
		    else
			    count = count-docpgcount;

                    std::map<CString,CString> PropertyMap;
                    typedef  std::map<CString, CString> pair;
                    PropertyMap.clear();
                    CString xmlfile("boxproperties.xml");
                    std::ostringstream oss;
                    oss << count;
                    PropertyMap.insert(pair::value_type("BoxPageCount",oss.str()));

                    Status sdf = Utility::SetProperties(resourceKey,xmlfile,PropertyMap);
                    if(sdf != STATUS_OK)
                    {
                        if(sdf == STATUS_DISK_FULL)
                        {
                            DEBUGL1("CBox::Delete::SetProperty failed because Disk is Full\n");
                            return STATUS_DISK_FULL;
                        }
                        DEBUGL1("CBox::Delete::SetProperty Failed\n");
                        return STATUS_FAILED;
                    }
                }

            }

            //***********************fix for dtfr-8232*******
            //Create unique file to indicate name of document that is being deleted.
            //This unique file is checked for each time boxdocument is initialized.
            //If the unique file is present then the partially deleted document(document 
            //that was being deleted before machine was turned off) is deleted.
            //***********************************************
	    CString uniqueFileId = ".delete_" + documentname + "_";
            if(Utility::CreateUniqueFile(m_BoxBasePath + "/" + m_BoxNumber + "/", &uniqueFileId) != STATUS_OK)  //fix for EBX_DTFR_17238
                DEBUGL2("CBox::Delete: Unable to create the unique file\n"); 

            // delete whole folder
            ds = ci::operatingenvironment::Folder::Remove(path.c_str(),true);
            if(ds != STATUS_OK) {
                DEBUGL1("CDocument::Delete : DeleteResource %s is failed\n", path.c_str());
                return ds;
            }
	    if(ds==STATUS_OK)
	    {
		// When CreateUniqueFile is called(Line No: 4617) , "uniqueFileId" is updated with the absolute path of the document that has to be deleted 
		// Deletion of UniqueFile is called immediately after Folder::Remove so as to ensure that Unique file is deleted even incase of abrupt shutdown
	    	if((ci::operatingenvironment::File::DeleteFile(uniqueFileId))!=STATUS_OK)
		    DEBUGL2("CBox::Delete: Unable to delete the %s unique file\n",uniqueFileId.c_str());
	    }
            uint64 size;
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", val) != STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get the property\n");
                return STATUS_FAILED;							
            }
            size = val.length()? atoi(val.c_str()): 0;
            size -= tempsize;
            std::ostringstream boxsize;
            boxsize << size;
            Status sdf = proputils::SetProperty(m_BoxBasePath,m_BoxNumber,"","","","totalBoxSize", boxsize.str()); 
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CDocument::Delete : Failed to set the property because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CDocument::Delete : Failed to set the property\n");								
                return STATUS_FAILED;							
            }
           DEBUGL4("CBox::DeleteDocument::Exit\n");		
            return STATUS_OK;
        }

        Status CBox::DeleteDocument(ProgressRef& progress,CString documentname)
        {
            DEBUGL4(" CBox::DeleteDocument()-- Entered Progress Updation \n ");

            Status pRetValue = STATUS_OK;
            //Generate a name for creating Shared memory
            CString deletedocProgShmName ="boxDelete_"+ CUUID().toString(); 
            m_DeleteDocErrfile = CUUID().toString();

            // Check Document Status
            DocStatus st;
            if(Utility::GetStatus(m_BoxBasePath, m_BoxNumber, "", documentname, st)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get document status\n");
                return STATUS_FAILED;							
            }
            CString session;
            if(Utility::GetProperty(m_BoxBasePath + "/" + m_BoxNumber + "/" + documentname, "documentproperties.xml", "sessionID", session)!=STATUS_OK)
            {
                DEBUGL1("CBox::DeleteDocument: Obtaining session id failed\n");
                //Check if save is in progress.. if so return STATUS_USER_USING
                CString savefilenam = "";
                if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                    DEBUGL2("CBox::DeleteDocument: Unable to get the file\n");

                DEBUGL8("CBox::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                if(!savefilenam.empty())
                {
                    DEBUGL1("CBox::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                    return STATUS_USER_USING;
                } 
                return STATUS_FAILED;
            }
            DEBUGL8("CBox::DeleteDocument:: document sessionid (%s) current session id (%s)\n", session.c_str(), m_sessionID.c_str());			

            //If document sessionid and current session id are same then allow editing document to delete.
            //If both are in different, then dont allow editing document to delete
            if(session == m_sessionID)
            {
                // if NOT (READY or EDITING)
                if(!((st == READY) || (st == EDITING) || (st == CREATING))) 
                {
                    DEBUGL1("CBox::DeleteDocument::Document Status is not READY, EDITING\n");
                    return STATUS_FAILED;
                }
            } else if(session != m_sessionID) {
                // if NOT (READY)
                if(!(st == READY)) 
                {
                    DEBUGL1("CBox::DeleteDocument::Document Status is not READY\n");
                    if(st == EDITING)				
                        return STATUS_USER_EDITING;
                    else if(st == USING || st == RESERVING)
                        return STATUS_USER_USING;
                    else 
                        return STATUS_FAILED;
                }
                else
                {
                    CString savefilenam = "";
                    if(Utility::GetUniqueFile(m_BoxBasePath + "/" + m_BoxNumber, savefilenam, ".saveisinprogress_", false) != STATUS_OK)
                        DEBUGL2("CBox::DeleteDocument: Unable to get the file\n");

                    DEBUGL8("CBox::DeleteDocument: savefilename (%s)\n", savefilenam.c_str());
                    if(!savefilenam.empty())
                    {
                        DEBUGL1("CBox::DeleteDocument: Delete Document (%s) is Failed... Save is in progress\n",documentname.c_str());
                        return STATUS_USER_USING;
                    }
                }
            }
            if(st!=DELETING)
            {	
                if(Utility::ChangeStatus(m_BoxBasePath, m_BoxNumber, "", documentname, DELETING) != STATUS_OK) 
                {
                    DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                    return STATUS_FAILED;
                }
            }	

            //Create an instance of CProgress	
            m_cprogress = new CProgress(deletedocProgShmName,m_DeleteDocErrfile,m_sessionID,m_BoxBasePath,m_BoxNumber,"",".deleteDiskFullBox_");
            if(!m_cprogress)
            {
                DEBUGL1(" CBox::DeleteDocument()-- Creating an instance of Progress failed \n");
                return STATUS_FAILED;
            }
            m_DelDocProgShmName = deletedocProgShmName;

				//Create shared memory to store the progress report
				m_prgShmid=SharedMemory::Create(deletedocProgShmName.c_str(),UUID_CONTENT_LENGTH,false,false);
				if(!m_prgShmid)
				{
					DEBUGL1("CBox::DeleteDocument()-- Creating shared memory failed\n");
					return STATUS_FAILED;
				}

            pRetValue = CreateDeleteDocumentThread(this,documentname);
            if(pRetValue!=STATUS_OK)
            {
                DEBUGL1(" CBox::DeleteDocument()-- Creating Cut thread Failed \n");
                return pRetValue;
            }

            progress = m_cprogress;
            return STATUS_OK;

        }

        Status CBox::CreateDeleteDocumentThread(CBox* docelemObj,
                CString documentname )
        {

            Status pRetVal;
            m_ThreadID = NULL;
            //unique name given for locking the resource
            CString lockpath="lockingBoxDocumentDeleteDocthread";

            // enter critical section
            GlobalMutexRef threadMutex = NULL;	
            pRetVal = Utility::EnterCriticalSection(threadMutex, lockpath);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1(" CBox::CreateDeleteDocumentThread()-- User has Locked the resource please retry...\n ");
                return STATUS_FAILED;

            }
            //Copy the input parameter into their respective static variable
            m_DelDoc= documentname;
            //Flag set to 1 untill the inputs are copied into local variables in the Started Thread		
            pRetVal = CreateThread(StartDeleteDocumentThread,reinterpret_cast<void*>(docelemObj),m_ThreadID);

            if(pRetVal !=STATUS_OK)
                DEBUGL1(" CBox::CreateDeleteDocumentThread()-- Could not Create a Thread\n");
            else
                DEBUGL8(" CBox::CreateDeleteDocumentThread()-- Creation of thread Initiated\n");
            pRetVal = Utility::LeaveCriticalSection(threadMutex);
            if(pRetVal !=STATUS_OK)
            {
                DEBUGL1(" CBox::CreateDeleteDocumentThread()--Releasing the Locked Resource Failed\n ");
                return STATUS_FAILED;

            }
            return pRetVal;
        }

        void* CBox::StartDeleteDocumentThread(void *arg)
        {
            DEBUGL4(" CBox::StartDeleteDocumentThread()-- Started \n");
            //Status retStatus;
            Status sdf;
            //Copy the passed instance of the invoking object into a local variable 
            CBox* deldocObj = ((CBox*)arg);
            //unique name given for locking the resource
            CString threadlockpath ="lockingBoxDocStartDeleteDocThread";
            CString documentname = m_DelDoc;
            //Create Shared memory used for writing the updated progress in it
            void *pDeleteDocumentMapAddr;
            if(!deldocObj->m_prgShmid)
            {
                DEBUGL1(" CBox::StartDeleteDocumentThread()  -- Failed to Create Shared Memory for Delete Document Progress Name \n ");
                deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                return NULL;
            }
            else
            {
                int iShmPidSize = deldocObj->m_prgShmid->getSize();
                //Map the Created Segment to another address
                deldocObj->m_prgShmid->Map(pDeleteDocumentMapAddr);
                if(pDeleteDocumentMapAddr!=NULL)
                {
                    memset(pDeleteDocumentMapAddr,0,iShmPidSize);
                }
                else
                {
                    DEBUGL1(" CBox::StartDeleteDocumentThread() -- Mapping Failed for Delete Document Progress Name\n");
                    deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                    return NULL;
                }
            }
            //Set the Flage to 0 so the while() loop in the CreateDeleteDocumentThread would end.
            //set the initial value of DeleteDocument progress as 1% . The Start DeleteDocument 
            //thread will update it as and when the operation progresses 
            *((int*)pDeleteDocumentMapAddr) = 1;	

            // Start to Delete
            int count=1;
            int numRes = 1;

            CString path = Utility::GetResourcePath(deldocObj->m_BoxBasePath, 
                    deldocObj->m_BoxNumber,
                    "",
                    documentname) + "/";
            CString deletepath = Utility::GetResourcePath(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber) + "/";

            uint64 tempsize = 0;
            CString val;
            if(proputils::GetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,"",documentname,"","totalDocSize", val)!=STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to change document status to DELETING\n");
                //Create a file indicating the Status to be not Status Ok			
                deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);		
                return NULL;
            }
            tempsize = val.length()? atoi(val.c_str()): 0;

            //Create unique file to indicate name of document that is being deleted.This unique file is checked for each time boxdocument is initialized.If the unique file is present then the partially deleted document(document that was being deleted before machine was turned off) is deleted.
            /***************************************************fix for dtfr-8232**************************************************/
	    CString uniqueFileId = ".delete_" + documentname + "_";
            if(Utility::CreateUniqueFile(deldocObj->m_BoxBasePath + "/" + deldocObj->m_BoxNumber + "/", &uniqueFileId) != STATUS_OK) //fix for EBX_DTFR_17238
                DEBUGL2("CBox::StartDeleteDocumentThread: Unable to create the unique file\n");

            // delete whole folder
            Status ds = ci::operatingenvironment::Folder::Remove(path.c_str(),true);
            if(ds != STATUS_OK) {
                DEBUGL1("CDocument::Delete : DeleteResource %s is failed\n", path.c_str());
                //Create a file indicating the Status to be not Status Ok			
                deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);					
                return NULL;
            }
            if(ds == STATUS_OK)
	    {
		    // When CreateUniqueFile is called(Line No: 4867) , "uniqueFileId" is updated with the absolute path of the document that has to be deleted 
		    // Deletion of UniqueFile is called immediately after Folder::Remove so as to ensure that Unique file is deleted even incase of abrupt shutdown
		    if((ci::operatingenvironment::File::DeleteFile(uniqueFileId))!=STATUS_OK)
			    DEBUGL2("CBox::Delete: Unable to delete the %s unique file\n",uniqueFileId.c_str());
	    }


            uint64 size;
            if(proputils::GetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,"","","","totalBoxSize", val) != STATUS_OK)
            {
                DEBUGL1("CDocument::Delete : Failed to get the property\n");
                //Create a file indicating the Status to be not Status Ok			
                deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);				
                return NULL;							
            }
            size = val.length()? atoi(val.c_str()): 0;
            size -= tempsize;
            std::ostringstream boxsize;
            boxsize << size;
            sdf = proputils::SetProperty(deldocObj->m_BoxBasePath,deldocObj->m_BoxNumber,"","","","totalBoxSize", boxsize.str());
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::Delete : Failed to set the property because Disk is Full\n");
                    DEBUGL8("CBox::Delete : savepath = (%s)\n", deletepath.c_str());
                    if(Utility::CreateUniqueFile(deletepath, ".deleteDiskFullBox_" + deldocObj->m_sessionID) != STATUS_OK)
                        DEBUGL2(" CBox::StartDeleteDocumentThread: Unable to create the file\n");

                    deldocObj->m_prgShmid = NULL;
                    return NULL;                                       
                }
                DEBUGL1("CDocument::Delete : Failed to set the property\n");								
                //Create a file indicating the Status to be not Status Ok			
                deldocObj->ErrorFileCreation(deldocObj->m_DeleteDocErrfile,deldocObj->m_prgShmid);				
                return NULL;							
            }

            //Update Progress
            int curProg = (int)((((float)count++)/((float)numRes))*100);
		    *((int*)pDeleteDocumentMapAddr) = curProg;				
		    DEBUGL8("CBox::StartDeleteDocumentThread::Current Progress<%d>\n",curProg);
            *((int*)pDeleteDocumentMapAddr) = PROGRESS_COMPLETED;				
            deldocObj->m_prgShmid = NULL;


            DEBUGL4("\n CBox::StartDeleteDocumentThread: Exit\n");	
            return NULL;
        }

        /**
         * confirm the box.is protected or not.
         * @return true if the box is protected.
         *         false if NOT.
         */
        bool CBox::IsPasswordProtected()
        {
            CString key = "isPasswordProtected";
            CString val("");
            this->GetProperty(key,val);
            if(val=="false") 
                return false;
            else
                return true;
        }

        /**
         * get document preserve days
         * @param[out] days - document preserve days
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CBox::GetDocumentPreserveDays(CString &days)
        {
            return GetProperty("documentPreserveDays",days);
		}

		/**
		 * get document preserve flag
		 * @param[out] days - document preserve flag
		 * @return STATUS_OK on success,
		 *         STATUS_FAILED on failure.
		 */
		Status CBox::GetPreservationPeriodFlag(CString &flag)
		{
			return GetProperty("preservationPeriodFlag",flag);
		}


        /**
         * get last modified date
         * @param[out] date - last modified date of the box
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CBox::GetLastModifiedDate(CString &date)
        {
            return GetProperty("lastModifiedDate",date);
        }

        /**
         * change box password
         * @param[in] boxpassword - new box password. If empty, remove protection 
         *                          for the box.
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         */
        Status CBox::ChangePassword(CString boxpassword)
        {
            DEBUGL4("CBox::ChangePassword::Enter\n");
            Status sdf;

            //Set the password and other authentication related properties
            if(boxpassword.empty())		
            {
                DEBUGL8("CBox::ChangePassword::Unprotected Box\n");
                sdf = SetProperty("password",""); 
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of password failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of password Failed\n");
                    return STATUS_FAILED;		
                }	
                sdf = SetProperty("isPasswordProtected","false"); 
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of isPasswordProtected failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of isPasswordProtected Failed\n");
                    return STATUS_FAILED;		
                }
                std::map<CString,CString> PropertyMap;
                //Remove the properties
                PropertyMap.clear();
                CString xmlfile("boxproperties.xml");
                CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber);
                //update the sessionID and cutDocument flag 
                PropertyMap.insert(pair::value_type(AUTH_FAILURE_COUNT,""));
                PropertyMap.insert(pair::value_type(AUTH_STATE,""));
                PropertyMap.insert(pair::value_type(AUTH_TIMER,""));
                sdf = Utility::SetProperties(path,xmlfile,PropertyMap); 
                if(sdf != STATUS_OK)	
                {	
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetProperty failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetProperty Failed\n");
                    return STATUS_FAILED;
                }							
            }
            else
            {	
                DEBUGL8("CBox::ChangePassword::Protected Box\n");
                sdf = SetProperty("password",boxpassword);
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of password failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of password Failed\n");
                    return STATUS_FAILED;		
                }
                sdf = SetProperty("isPasswordProtected","true");
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of isPasswordProtected failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetWebDAVProperty of isPasswordProtected Failed\n");
                    return STATUS_FAILED;		
                }
                sdf = SetProperty(AUTH_STATE,"IDLE"); 
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetProperty of authState failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetProperty of authState Failed\n");
                    return STATUS_FAILED;
                }
                sdf = SetProperty(AUTH_FAILURE_COUNT,"0");
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetProperty of authFailureCount failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetProperty of authFailureCount Failed\n");
                    return STATUS_FAILED;
                }
                sdf = SetProperty(AUTH_TIMER,"0");
                if(sdf != STATUS_OK)
                {
                    if(sdf == STATUS_DISK_FULL)
                    {
                        DEBUGL1("CBox::ChangePassword::SetProperty of authTimer failed because Disk is Full\n");
                        return STATUS_DISK_FULL;
                    }
                    DEBUGL1("CBox::ChangePassword::SetProperty of authTimer Failed\n");
                    return STATUS_FAILED;
                }									
            }

            DEBUGL4("CBox::ChangePassword::Exit\n");
            return STATUS_OK;
        }

        /**
         * confirm Folder exists or not
         * @param[in] foldername - folder name.
         * @return true if folder exists
         *         false if folder doesn't exist.
         */
        bool CBox::FolderExist(CString foldername)
        {
            return Utility::ResourceExist(m_BoxBasePath,m_BoxNumber,foldername);
        }

        /**
         * unlock box
         * @return STATUS_OK on success
         */
        Status CBox::Unlock()
        {
            DEBUGL4("CBox::Unlock::Enter\n");
            Status sdf;
            //Change state to IDLE
            sdf = SetProperty(AUTH_STATE,"IDLE");
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::Unlock::SetProperty of authState failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::Unlock::SetProperty of authState Failed\n");
                return STATUS_FAILED;
            }
            sdf = SetProperty(AUTH_TIMER,"0");
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::Unlock::SetProperty of authTimer failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::Unlock::SetProperty of authTimer Failed\n");
                return STATUS_FAILED;
            }					
            sdf = SetProperty(AUTH_FAILURE_COUNT,"0");
            if(sdf != STATUS_OK)
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::Unlock::SetProperty of authFailure count failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::Unlock::SetProperty of authFailure count Failed\n");
                return STATUS_FAILED;
            }					

            DEBUGL4("CBox::Unlock::Exit\n");	
            return STATUS_OK;
        }


        /**
         *Undo the cut/copy document operation
         *@param[in] docname - source document name
         *@return STATUS_OK on success,
         *STATUS_FAILED on failure,
         **/
        Status CBox::UndoEditDocument(CString docname)
        {
            DEBUGL8("CBox::UndoEditDocument: Enter and Document Name is <%s>\n",docname.c_str());
            CString xmlfile = "documentproperties.xml";
            std::map<CString, CString> PropertyMap;
            PropertyMap.insert(pair::value_type("sessionID",""));
            PropertyMap.insert(pair::value_type("cutDocument",""));	
            Status sdf;
            //Get the resource path.
            CString dpath =Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber,"",docname)+"/";	
            //clear the flags that are set during cut or Copy document operation
            sdf = Utility::SetProperties(dpath,xmlfile,PropertyMap);
            if(sdf != STATUS_OK)
            {  
                if(sdf == STATUS_DISK_FULL)
                {
                    DEBUGL1("CBox::UndoEditDocument:SetProperties failed because Disk is Full\n");
                    return STATUS_DISK_FULL;
                }
                DEBUGL1("CBox::UndoEditDocument:SetProperties Failed\n");
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         *Undo the cut/copy document operation
         *@param[in] documents - source document names     
         *@return STATUS_OK on success,
         *STATUS_FAILED on failure,
         **/
        Status CBox::UndoEditDocument(std::vector<CString> documents)
        {
            CString dpath;
            CString docname;
            std::vector<CString>::iterator iter;
            //clear the flags that are set during cut or Copy document operation
            for(iter=documents.begin();iter!=documents.end();iter++)
            {
                docname = (*iter);
                if(UndoEditDocument(docname)!=STATUS_OK)
                {
                    DEBUGL1("CBox::UndoEditDocument:Failed for Document <%s>\n",docname.c_str());
                    return STATUS_FAILED;
                }
                else
                    DEBUGL8("CBox::UndoEditDocument:Document <%s> properties Reset sucessfully\n",docname.c_str());

            } 
            return STATUS_OK;
        }
        Status CBox::GetBoxType(CString &boxtype)
        {
            return GetProperty("documentType",boxtype);
        }

        Status CBox::SetUserName(CString username)
        {
            Status sdf = SetProperty("userName", username);
            if(sdf != STATUS_OK) 
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CBox::GetUserName(CString &username)
        {
            return GetProperty("userName",username);
        }

        Status CBox::SetComment(CString comment)
        {
            Status sdf;
            sdf = SetProperty("comment", comment);
            if(sdf != STATUS_OK) 
            {
                if(sdf == STATUS_DISK_FULL)
                {
                    return STATUS_DISK_FULL;
                }
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        Status CBox::GetComment(CString &comment)
        {
            return GetProperty("comment",comment);
        }

        bool CBox::IsLocked()
        {
            CString boxState("");
            GetProperty(AUTH_STATE,boxState);
            if(boxState=="ACCOUNT_LOCKED")
                return true;
            else
                return false;
        }

        Status CBox::GetDocumentPropertiesList(DocumentPropertiesList &list)
        {
            return GetDocumentPropertiesList(list, 0, 65535);
        }
        Status CBox::GetDocumentPropertiesList(DocumentPropertiesList &list, 
                unsigned int from, unsigned int size)
        {
            DEBUGL4("CBox::GetDocumentPropertiesList::Enter\n");

            std::vector<CString> vec;
            CString path = Utility::GetResourcePath(m_BoxBasePath, m_BoxNumber) + "/";
            if(Utility::GetCollectionList(vec, path)!=STATUS_OK)
            {
                DEBUGL1("CBox::GetDocumentPropertiesList::Getting collection list is failed");
                return STATUS_FAILED;
            }
            list.clear();
            for(unsigned int i = from, cnt = 0; (i < vec.size()) && (cnt < size); i++, cnt++) 
            {
                int last = vec[i].rfind("/");
                int pre = vec[i].rfind("/", last - 1);
                CString docName = vec[i].substr(pre + 1, last - (pre + 1));
                DEBUGL8("CBox::GetDocumentPropertiesList:: docName = (%s)\n",docName.c_str());

                // GetDocument
                DocumentPropertiesRef document = NULL;
                document = new CDocumentProperties(m_BoxBasePath, m_BoxNumber,"",docName);
                DocStatus st;
                try
                {
                    if(!document)
                    {
                        DEBUGL1("CBox::GetDocumentPropertiesList: doc object is null\n");
                        return STATUS_FAILED;
                    }
                    Status ret = dynamic_cast<CDocumentProperties*>(document.operator->())->GetStatus(st);
                    if( ret != STATUS_OK || st == DELETING) 
                    {
                        DEBUGL2("CBox::GetDocumentPropertiesList::Getting document status failed or document is deleting\n");
                        continue;
                    }
                }
                catch(exception &e)
                {
                    DEBUGL1("CBox::GetDocumentPropertiesList: Caught exception (%s)\n",e.what());
                    return STATUS_FAILED;
                }
                list.push_back(document);								
            }

            DEBUGL4("CBox::GetDocumentPropertiesList::Exit\n");
            return STATUS_OK;
        }

        Status CBox::GetRelayReportDestination(CString &destination)
        {
            return GetWebDAVProperty("relayReportDestination",destination);
        }

        Status CBox::GetRelayReportDestinationType(CString &dsttype)
        {
            return GetWebDAVProperty("relayReportDestinationType",dsttype);
        }

        Status CBox::GetRelayReportContactId(CString &id)
        {
            return GetWebDAVProperty("relayReportContactId",id);
        }
        Status CBox::SetLastBackupDate(CString date)
        {  
            Status sdf;
            sdf = SetProperty("lastBackupDate", date);
            if(sdf != STATUS_OK)
            {  
                if(sdf == STATUS_DISK_FULL)
                    return  STATUS_DISK_FULL;
                return STATUS_FAILED;
            }
            return STATUS_OK;
        }
        Status CBox::GetLastBackupDate(CString &date)
        {
            return GetWebDAVProperty("lastBackupDate",date);
        }
        /**
         * get a password of the mail box
         * @param[out] password - a number of the box
         * @return STATUS_OK on success,
         *         STATUS_FAILED on invalid box base path.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::GetPassword(CString &password)
        {
            DEBUGL4("CBox::GetPassword: Enter\n");
            if((m_BoxBasePath != "/storage/box/ITUTBoxes") && (m_BoxBasePath != "/storage/box/PollingBoxes"))
            {
                DEBUGL1("CBox::GetPassword::Invalid BoxbasePath\n");
                return STATUS_FAILED;
            }
            else
            {
                password ="";
                CString propertypath = Utility::GetResourcePath(m_BoxBasePath,m_BoxNumber) + "/";
                if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","password", password)!= STATUS_OK)
                {
                    DEBUGL1("CBox::GetPassword::failed to get the Password property\n");
                    return STATUS_FAILED;
                }
            }
            DEBUGL4("CBox::GetPassword: Exit");
            return STATUS_OK;	
        }

        /*
         * get the boxcreation date
         * @param[out] date - creation date of the box
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::GetCreationDate(CString &date)
        {
            date="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","creationDate",date)!=STATUS_OK)		
            {
                DEBUGL1("CBox::GetCreationDate::GetProperty Failed\n");
                return STATUS_FAILED;
            }			

            return STATUS_OK;	
        }

        /**
         * get the notification email id
         * @param[out] emailId - get the nofication email id
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::GetNotificationEmailId(CString &emailId)
        {
            emailId="";
            if(proputils::GetProperty(m_BoxBasePath,m_BoxNumber,"","","","notificationEmailAddress",emailId)!=STATUS_OK)		
            {
                DEBUGL1("CBox::GetNotificationEmailId::GetProperty Failed\n");
                return STATUS_FAILED;
            }			
            if(emailId.empty())
                DEBUGL2("CViewBox::GetNotificationEmailId: email id is not present in boxproperties.xml file\n");

            return STATUS_OK;	
        }
        /**
         * get the number of document present inside a box
         * @param[out] numDoc - get the number of documents in a box
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::GetDocumentCount(uint &numDoc)
        {
            numDoc = 0;
            if(Utility::GetDocumentCount(m_BoxBasePath, m_BoxNumber, "", numDoc, true) != STATUS_OK)
            {
                DEBUGL1("CBox::GetDocumentCount::GetProperty Failed\n");
                return STATUS_FAILED;
            }
            else {
                DEBUGL8("CBox::GetDocumentCount:: number of documents = (%u)\n", numDoc);
                return STATUS_OK;
            }
        }
        /**
         * get the number of folder inside a box
         * @param[out] numFolder - get the number of folder in a box
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::GetFolderCount(uint &numFolder)
        {
            numFolder = 0;
            if(Utility::GetFolderCount(m_BoxBasePath, m_BoxNumber, numFolder) != STATUS_OK)
            {
                DEBUGL1("CBox::GetFolderCount::GetProperty Failed\n");
                return STATUS_FAILED;
            }
            else {
                DEBUGL8("CBox::GetFolderCount:: number of folder = (%u)\n", numFolder);
                return STATUS_OK;
            }
        }

        /**
         * set the file name format for the received forwarding
         * @param[in] fnf - set the file name for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *         STATUS_DISK_FULL if there is not enough space in the partition.
         * @NOTE - It is available via GetBoxList
         */
        Status CBox::SetFileNameFormat(RFFileNameFormat fnf)
        {
            std::ostringstream name;
            CString nameFormat("");
            name << fnf;
            nameFormat = name.str();
            DEBUGL8("CBox::SetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str());
            Status ret = STATUS_OK;
            ret = SetProperty("fileNameFormat", nameFormat);
            if(ret != STATUS_OK)
            {  
               if(ret == STATUS_DISK_FULL)
               {
                  DEBUGL1("CBox::SetFileNameFormat::SetProperty of fileNameFormat failed because Disk is Full..\n");
                  return STATUS_DISK_FULL;
               }                   
               DEBUGL1("CBox::SetFileNameFormat::SetProperty of fileNameFormat failed..\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
        }

        /**
         * get the file name format for the received forwarding
         * @param[out] fnf - get the file name for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::GetFileNameFormat(RFFileNameFormat &fnf)
         {
            std::istringstream name;
            CString nameFormat = "";
            Status ret = STATUS_OK;
            ret = GetProperty("fileNameFormat", nameFormat);
            name.str(nameFormat);
            int val = 0;
            name >> val;
            fnf = (RFFileNameFormat)val;
            DEBUGL8("CBox::GetFileNameFormat::File name format:as int = <%d> as str = (%s)\n", fnf, nameFormat.c_str());                   
            return ret;
         }

        /**
         * set the date format for the received forwarding
         * @param[in] df - get the date for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *        STATUS_DISK_FULL if there is not enough space in the partition.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::SetDateFormat(RFDateFormat df)
         {
            std::ostringstream date;
            CString dateFormat("");
            date << df;
            dateFormat = date.str();
            DEBUGL8("CBox::SetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());   
            Status ret = STATUS_OK;
            ret = SetProperty("dateFormat", dateFormat);
            if(ret != STATUS_OK)
            {
               if(ret == STATUS_DISK_FULL)
               {
                  DEBUGL1("CBox::SetDateFormat::SetProperty of dateFormat failed because Disk is Full..\n");
                  return STATUS_DISK_FULL;
               }
               DEBUGL1("CBox::SetDateFormat::SetProperty of dateFormat failed..\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
         }
         
        /**
         * get the date format for the received forwarding
         * @param[out] df - get the date for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::GetDateFormat(RFDateFormat &df)
         {
            std::istringstream date;
            CString dateFormat = "";
            Status ret = STATUS_OK;
            ret = GetProperty("dateFormat",dateFormat);
            date.str(dateFormat);
            int val = 0;
            date >> val;
            df = (RFDateFormat)val;
            DEBUGL8("CBox::GetDateFormat::Date format:as int = <%d> as str = (%s)\n", df, dateFormat.c_str());
            return ret;        
         }

        /**
         * set the page number format for the received forwarding
         * @param[in] pnf - get the page number format for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *        STATUS_DISK_FULL if there is not enough space in the partition.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::SetPageNumberFormat(RFPageNumberFormat pnf)
         {
            std::ostringstream pagenum;
            CString pageNumber("");
            pagenum << pnf;
            pageNumber = pagenum.str();
            DEBUGL8("CBox::SetPageNumberFormat::Page number format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
            Status ret = STATUS_OK;
            ret = SetProperty("pageNumberFormat", pageNumber);
            if(ret != STATUS_OK)
            {
               if(ret == STATUS_DISK_FULL)
               {
                  DEBUGL1("CBox::SetPageNumberFormat::SetProperty of pageNumberFormat failed because Disk is Full..\n");
                  return STATUS_DISK_FULL;
               }
               DEBUGL1("CBox::SetPageNumberFormat::SetProperty of pageNumberFormat failed..\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
         }

        /**
         * get the page number format for the received forwarding
         * @param[out] pnf - get the page number format for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */ 
         Status CBox::GetPageNumberFormat(RFPageNumberFormat &pnf)
         {
            std::istringstream pagenum;
            CString pageNumber("");
            Status ret = STATUS_OK;
            ret = GetProperty("pageNumberFormat", pageNumber);
            pagenum.str(pageNumber);
            int val = 0;
            pagenum >> val;
            pnf = (RFPageNumberFormat)val;
            DEBUGL8("CBox::GetDateFormat::Date format:as int = <%d> as str = (%s)\n", pnf, pageNumber.c_str());
            return ret;
         }        

        /**
         * set the sub ID for the received forwarding
         * @param[in] sid - get the Sub ID for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *        STATUS_DISK_FULL if there is not enough space in the partition.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::SetSubID(RFSubID sid)
         {
            std::ostringstream sub;
            CString subid("");
            sub << sid;
            subid = sub.str();
            DEBUGL8("CBox::SetSubID::SubId:as int = <%d> as str = (%s)\n", sid, subid.c_str());
            Status ret = STATUS_OK;
            ret = SetProperty("subID", subid);
            if(ret != STATUS_OK)
            {
               if(ret == STATUS_DISK_FULL)
               {
                  DEBUGL1("CBox::SetSubID::SetProperty of subID failed because Disk is Full..\n");
                  return STATUS_DISK_FULL;
               }
               DEBUGL1("CBox::SetPageNumberFormat::SetProperty of subID failed..\n");
               return STATUS_FAILED;
            }
            return STATUS_OK;
         }

        /**
         * get the sub ID for the received forwarding
         * @param[out] sid - get the sub ID for the received forwarding
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::GetSubID(RFSubID &sid)
         {
            std::istringstream sub;
            CString subid("");
            Status ret = STATUS_OK;
            ret = GetProperty("subID", subid);
            sub.str(subid);
            int val = 0;
            sub >> val;
            sid = (RFSubID)val;
            DEBUGL8("CBox::GetSubID::subID:as int = <%d> as str = (%s)\n", sid, subid.c_str());
            return ret;
         }
      
        /**
         * set comment for the received forwarding. 
         * @param[in] comment - comment to be set
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         *        STATUS_DISK_FULL if there is not enough space in the partition.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::SetRFComment(CString comment)
         {
            Status ret = STATUS_OK;
            ret = SetProperty("rfComment",comment);
            if(ret != STATUS_OK)
            {
               if(ret == STATUS_DISK_FULL)
               {
                  DEBUGL1("CBox::SetRFComment::SetProperty of rfComment failed because Disk is Full..\n");
                  return STATUS_DISK_FULL;
               }
               DEBUGL1("CBox::SetRFComment::SetProperty of rfComment failed..\n");
               return STATUS_FAILED;
            }            
            return STATUS_OK;
         }

        /**
         * get comment for the received forwarding.. 
         * @param[out] comment - return the comment
         * @return STATUS_OK on success,
         *         STATUS_FAILED on failure.
         * @NOTE - It is available via GetBoxList
         */
         Status CBox::GetRFComment(CString &comment)
         {
            return GetProperty("rfComment",comment);
         }       

    }; // namespace boxdocument
}; // namespace ci

