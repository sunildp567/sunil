#include <iostream>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/document.h>
#include <CI/BoxDocument/page.h>

#include <CI/OperatingEnvironment/cstring.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/SoftwareDiagnostics/softwarediagnostics.h>
#include <CI/HierarchicalDB/DOM/node.h>

using namespace std;
using namespace ci::operatingenvironment;
using namespace ci::boxdocument;

// test case of BoxOut

bool test_boxout_AL(CString BoxBasePath, 
                    CString &BoxNumber, 
                    CString &FolderName, 
                    CString &DocumentName) 
{
    // AL knowledge
    
    // 1: get an instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // 1.1: get list of boxes
    BoxList boxlist;
    if(boxdoc->GetBoxList(boxlist, BoxBasePath) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBoxList() is failed\n");
        return false;
    }
    
    for(BoxList::iterator it = boxlist.begin(); it != boxlist.end(); it++) {
        (*it)->GetNumber(BoxNumber);
        DEBUGL6("BOX Number - %s\n", BoxNumber.c_str());
    }
    
    
    // 1.2: get box instance
    BoxRef box;
    cout << "Enter Box Number" << endl;
    cin >> BoxNumber;
    if(boxdoc->GetBox(box, BoxBasePath, BoxNumber) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetBox() is failed\n");
        return false;
    }
    FolderName = ""; // skip folder selection
    
    // 1.3: get list of documents
    DocumentList doclist;
    if(box->GetDocumentList(doclist) != STATUS_OK) {
        DEBUGL1("Container::GetDocumentList() is failed\n");
        return false;
    }
    for(DocumentList::iterator it = doclist.begin(); it != doclist.end(); it++) {
        (*it)->GetName(DocumentName);
        DEBUGL6("Document Name - %s\n", DocumentName.c_str());
    }
    
    // 1.5: get document instance
    DocumentRef doc;
    cout << "Enter Document Name" << endl;
    cin >> DocumentName;
    if(box->GetDocument(doc, DocumentName)) {
        DEBUGL1("Container::GetDocument() is failed\n");
        return false;
    }
    // 1.6: get document properties
    CString key = "jobType";
    CString value;
    doc->GetWebDAVProperty(key, value);
    DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    
    // 1.7: get WEP DOM object
    DOM::NodeRef node;
    if(doc->GetWEPDocument(node) != STATUS_OK) {
        DEBUGL1("Document::GetWEPDocument() is failed\n");
        return false;
    }
    node = node->getFirstChild();
    while (node != static_cast<void *> (NULL)) {
        DEBUGL6("node : %s\n",(node->getNodeName()).c_str());
        node = node->getNextSibling();
    }
    
    // 2.1: Lock Document
    if(doc->Use() != STATUS_OK) {
        DEBUGL1("Document::Use() is failed\n");
        return false;
    }
    return true;
}

bool test_boxout_SL(CString BoxBasePath, 
                    CString BoxNumber, 
                    CString FolderName, 
                    CString DocumentName)
{
    // 6.1 : get an instance of BoxDocument 
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // 6.2 : get an instance of Document
    DocumentRef doc;
    if(boxdoc->GetDocument(doc, BoxBasePath, 
                                BoxNumber, 
                                FolderName, 
                                DocumentName) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetDocument() is failed\n");
        return false;
    }
    
    // 6.3: Unlock Document
    if(doc->EndUsing() != STATUS_OK) {
        DEBUGL1("Document::EndUsing() is failed\n");
        return false;
    }
    return true;
}

bool test_boxout_DL(CString BoxBasePath, 
                    CString BoxNumber, 
                    CString FolderName, 
                    CString DocumentName) 
{
    // 4: get an instance of BoxDocument
    BoxDocumentRef boxdoc;
    boxdoc = BoxDocument::Acquire();
    if(boxdoc == static_cast<void *> (NULL)) {
        DEBUGL1("BoxDocument::Acquire() is failed\n");
        return false;
    }
    
    // 4.1: get an instance of Document
    DocumentRef doc;
    if(boxdoc->GetDocument(doc, BoxBasePath, 
                                BoxNumber, 
                                FolderName, 
                                DocumentName) != STATUS_OK) {
        DEBUGL1("BoxDocument::GetDocument() is failed\n");
        return false;
    }
    
    // 4.2: Get System File
    CString path;
    if(doc->GetSystemFile(path) != STATUS_OK) {
        DEBUGL1("Document::GetSystemFile() is failed\n");
        return false;
    }
    DEBUGL6("System file path : %s\n", path.c_str());
    
    PageList list;
    if(doc->GetPageList(list) != STATUS_OK) {
        DEBUGL1("getting page list is failed\n");
        return false;
    }
    // 5.1: get instance of Page
    for(PageList::iterator it = list.begin(); it != list.end(); it++) {
        // 5.2: Get Page Image
        CString imagepath;
        if((*it)->GetImage(imagepath) != STATUS_OK) {
            DEBUGL1("Page::GetImage() is failed\n");
            return false;
        }
        DEBUGL6("image file path : %s\n", imagepath.c_str());
        // 5.4: get page properties
        CString key = "jobType";
        CString value;
        (*it)->GetWebDAVProperty(key, value);
        DEBUGL6("key[%s] -> value[%s]\n", key.c_str(), value.c_str());
    }
    
    return true;
}

bool test_boxout() {
    CString BoxBasePath = "EFilingBoxes";
    CString BoxNumber;
    CString FolderName;
    CString DocumentName;
    
    return test_boxout_AL(BoxBasePath, BoxNumber, FolderName, DocumentName) &&
           test_boxout_DL(BoxBasePath, BoxNumber, FolderName, DocumentName) &&
           test_boxout_SL(BoxBasePath, BoxNumber, FolderName, DocumentName);
}
