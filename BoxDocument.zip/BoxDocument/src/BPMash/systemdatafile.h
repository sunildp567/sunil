/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2006   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: %PM%
 Revision: %PR%
 File Spec: %PID%
 Originator: %PO%
 Last Changed: %PRT%
 Outline[by EA]: */
 /**
 * @version 1.0
 * @created 09-Feb-2007 23:13:42
 */
/*----------------------------------------------------------------------------
 Related Change Documents:
   %PIRC%
------------------------------------------------------------------------------
 Related Baselines:
   %PIRB%
------------------------------------------------------------------------------
 History:
   %PL%
========================== End of Source Header =============================*/


#ifndef __CI_SYSTEMDATAFILE_H__
#define __CI_SYSTEMDATAFILE_H__

#include "systemdatafile_page.h"

    #define FL_PAGE_MAX_COUNT  1000
    /*************************************************/
    /*  構造体  ボリューム毎情報 (FL_VOLUME_ATR)     */
    /*           使途番号：siVolMtd                  */
    /*************************************************/
    #define     FL_ID_USING_SPD           0x0101
    #define     FL_ID_USING_DSE           0x0201
    #define     FL_ID_USING_FXS           0x0202
    #define     FL_ID_USING_AGN           0x0203
    #define     FL_ID_USING_FXF           0x0204
    #define     FL_ID_USING_PDL           0x0301
    #define     FL_ID_USING_BOX           0x0401
    #define     FL_ID_USING_DSP           0x0501
    #define     FL_ID_USING_SHA           0x0601
    #define     FL_ID_USING_BAK           0x0701
    #define     FL_ID_USING_UTD           0x0801
    #define     FL_ID_USING_TAT           0x0901
    #define     FL_ID_USING_SPL           0x0a01
    #define     FL_ID_USING_WR1           0x0b01
    #define     FL_ID_USING_WR2           0x0c01
    #define     FL_ID_USING_UTW           0x0d01
    #define     FL_ID_USING_SMW           0x0e01
    #define     FL_ID_USING_TLT           0x0f01
    #define     FL_ID_USING_UIW           0x1001

    #define     FL_CONST_UNDEFINE              0          /* 未定義定数                          */

    /*----------------------------------------------*/
    /* ＦＡＸ原稿情報                ５１２ＢＹＴＥ */
    /*                                              */
    /* int は４バイト境界、shortは２バイト境界      */
    /* 全体サイズは４の倍数にする事                 */
    /*----------------------------------------------*/
    typedef struct FU_FAX_ORG_INF{              /* ＦＡＸ固有原稿情報                   */
        time_t  sT             ;                /* 送信指定日付時刻                     */
        time_t  sFaxStart      ;                /* 通信開始日付時刻                     */
        time_t  sFaxEnd        ;                /* 通信終了日付時刻                     */
        time_t  sDocKeep       ;                /* 原稿保持日付時刻                     */
        int16      hTopPageIdx    ;                /* 先頭頁情報インデックス番号           */
        int16      hEndPageIdx    ;                /* 最終頁情報インデックス番号           */
        int16      hAdrIdx        ;                /* 宛先情報インデックス番号             */
        int16      hScanType      ;                /* 入力方法[0:ＡＤＦ 1:原稿台]          */
        uint8      uaSendOrder    ;                /* 送信順                               */
                                                /* 0:スキャン１ページ目から             */
                                                /* 1:スキャン最終ページから             */
        uint8      uaPrintOrder   ;                /* 印刷順                               */
                                                /* COM_PS_UP                            */
                                                /* COM_PS_DOWN                          */
        int16      hPageCount     ;                /* 原稿枚数                             */
        int16      hComPageCount  ;                /* 通信ページ数                         */
        int16      hAddressCnt    ;                /* 宛先数                               */
        int16      hAddressEnd    ;                /* 通信終了宛先数                       */
        int16      hRemainPage    ;                /* 残ページ数/送信済みページ数          */
        int16      hStartPageIdx  ;                /* 通信開始頁情報インデックス番号       */
        int8       aPwdSid[21]    ;                /* ＰＷＤ／ＳＩＤ情報[無効時ＮＵＬＬ]   */
        int8       aSubSep[21]    ;                /* ＳＵＢ／ＳＥＰ情報[無効時ＮＵＬＬ]   */
        int8       aTsi[21]       ;                /* 受信時ＴＳＩ又は変換名称             */
        int8       aRelaySnd[257] ;                /* 中継結果返送先                       */
        int16      hDirectAddress ;                /* 直接宛先数                           */
        int16      hOrgInf        ;                /* 各種情報                             */
        int16      hBoxId         ;                /* 箱グローバル番号[1～100]             */
        int16      hBoxReceptCnt  ;                /* 箱受付表数                           */
        int16      hBoxReceptEnd  ;                /* 箱受付表出力済み数                   */
        int16      hSndChNo       ;                /* 送信回線番号[0:指定無]               */
        int16      hClass         ;                /* 部門番号                             */
        int16      hRelaySndKind  ;                /* 中継結果返送種別                     */
                                                /* 上位４ビット                         */
                                                /* 0:無                                 */
                                                /* 1:ＩＤ                               */
                                                /* 3:直接ダイヤル                       */
                                                /* 4:直接Ｅ－Ｍａｉｌ                   */
                                                /* 下位１２ビット                       */
                                                /* ＩＤ                                 */
        int16      hTsbOrgPwd     ;                /* 東芝独自パスワード                   */
        int16      hDssCnt        ;                /* ＤＳＳ宛先数                         */
        int16      hDssEnd        ;                /* ＤＳＳ終了宛先数                     */
        int16      hClientPC      ;                /* クライアントＰＣ結果返送有無         */
        int16      hDssRtyCount   ;                /* In-Bound Fax 転送リトライ回数        */
        int8       aComTsi[21]    ;                /* 通信ＴＳＩ               GL1010 V1.2 */
        int8       aYobiGL1010[1] ;                /* 偶数バイト合わせ              MckR26 */
        uint8      uaBoxKind      ;                /* Ｆコード  箱種別              MckR25 */
        uint8      uaHard         ;                /* Ｆコード  ハードコピー        MckR25 */
        int16     siDiscard      ;                /* 切り捨て  長さ(13-375)        MckR26 */
        int16     siDiscardOnOff ;                /* 切り捨て  記録(13-378)        MckR26 */
        int8       aAux[100]      ;                /* 予備  １００ＢＹＴＥ          MckR26 */
    }FU_FAX_ORG_INF;
    
    /********************************************/
    /* 頁管理テーブルヘッダ                     */
    /********************************************/
    typedef struct FL_PAGE_HEADER{
        int16      hPageTableCnt;                  /* 頁管理テーブルの個数         */
        int16      hPageTableSize;                 /* 頁管理テーブルのサイズ       */
        
    } FL_PAGE_HEADER;

    /********************************************/
    /* 頁グループ情報                           */
    /********************************************/
    typedef struct FL_PAGE_GROUP{
        int8       sPartName[6];                   /* パーティション名称           */
                                                /*    1:"/SPD",2:"/SP2",3:"/SP3",4:"/SP4",5:"/SP5",6:"" */
        int16      hReserveMByte;                  /* 先行入力予約容量(単位：MByte)*/
        int16      hFromPageNo;                    /* 保存開始頁番号               */
        int16      hToPageNo;                      /* 保存終了頁番号               */
    } FL_PAGE_GROUP;

    /********************************************/
    /* 頁パーティション情報                     */
    /********************************************/
    typedef struct FL_PART_MAN{
        int16              hCurrentVolNo;          /* 規定保存パーティション番号 */
        int16              hRfu;                   /* 未使用                   */
        FL_PAGE_GROUP   sPageGroup[6];          /* 頁グループ情報           */
    } FL_PART_MAN;


    /********************************************/
    /* flBlockRead():複数タスクREAD情報         */
    /********************************************/
    typedef struct FL_MULT_READ{
        int32     iTaskId;                        /* タスクＩＤ                                   */
        int32     iFd;  /* eB3 Porting to Linux -- changed iDosFd to iFd */
        FILE    *fp;                            /* ファイルディスクリプタ                       */
        uint32     liReadSize;                     /* 読み込み完了サイズ                           */
    } FL_MULT_READ;
    
    /********************************************/
    /* flBlockRead():複数タスク制御テーブル     */
    /********************************************/
    /* flParL.h より取得                        */
    #define        FL_MULT_READ_MAX_CNT     5   /* flBlockRead 同時アクセス最大値               */
    typedef struct FL_MULT_READ_CTL{
        int16              hFdCnt;
        FL_MULT_READ    sflMultRead[FL_MULT_READ_MAX_CNT];
    } FL_MULT_READ_CTL;

    /********************************************/
    /* 頁管理情報                               */
    /********************************************/
    typedef struct FL_PAGE_MAN{
        int8       aPgStr[6];                      /* ファイル名拡張子（頁番号文字列）         */
        uint32     liPgDataSize;                   /* 画像データサイズ(ファイル管理で更新)     */
        FL_MULT_READ_CTL *pflMultRCtl;          /* flBlockRead():複数タスク対応制御テーブル */
        int16      hPgStsFlag;                     /* 上位８Bit：頁アクセス状態               */
                                              /*    FL_PAGE_ACCESS_USELESS     :未使用    */
                                              /*    FL_PAGE_ACCESS_READY       :レディ中  */
                                              /*    FL_PAGE_ACCESS_READ        :読込み中  */
                                              /*    FL_PAGE_ACCESS_WRITE       :書込み中  */
                                              /*    FL_PAGE_ACCESS_DELETE      :削除頁    */
                                              /*    FL_PAGE_ACCESS_DELETE_BEGIN:削除移行中*/
                                              /* 下位８Bit：画像モード                   */
                                              /* FL_MEMORYFULL_PAGE:メモリフル発生頁     */
                                              /* FL_NORMAL_PAGE    :通常頁               */
        uint32     fl4PlaneSize[4];                /* 4プレーンサイズ *//* ROM8.1 */
        int16      hVolNo;                         /* 画像を保存したパーティション番号（拡張複写時に有効）  */
        int16      h4PlaneWriteSet;                /* 4プレーン書き込みフラグ *//* M003 */
        int16      h4PlaneReadSet;                 /* 4プレーン読み込みフラグ */
        int16      hThumFile;                      /* サムネイルファイル有無 */
        uint32     liThumDataKSize;                /* サムネイル画像データサイズ(1プレーン時のサイズ or ブラック) *//* K001 */
        uint32     liThumDataCSize;                /* サムネイル画像データサイズ(シアン)   *//* K001 */
        uint32     liThumDataMSize;                /* サムネイル画像データサイズ(マゼンダ) *//* K001 */
        uint32     liThumDataYSize;                /* サムネイル画像データサイズ(イエロー) *//* K001 */
//        int16      hPagePutJasperFlag;             /* flPagePut時Jasper圧縮フラグ *//* K001 */
//        int16      hPageGetJasperFlag;             /* flPageGet時Jasper圧縮フラグ *//* K001 */
//        int16      hPagePutSamplingFlag;           /* flPagePut時Sampling画像作成フラグ */
//        int16      hPageGet4PlaneReadFlag;         /* flPageGet時4Plane読出しフラグ     *//* MA003 */
//        int16      hPageGetEnd4PlaneReturn[4];     /* flPageGetEnd時4Plane読み出し完了チェック *//* MA003 */
        int16      hDeleteRequestedCount;              /* count of requested page deletion *//* Add  eBX L4.0 Weiss SSD. support for page deletion. -20120302 */
        int16      hReserve[7];                  /* 上記4つの属性を予約化しhDeleteRequestedCountを追加 */
    } FL_PAGE_MAN;

    /************************************************/
    /* 頁管理テーブル(実体はFL_PAGE_MAX_COUNT個定義)*/
    /************************************************/
    typedef struct FL_PAGE_MAN_TBL{
        FL_PAGE_MAN         sPageMan;           /* 頁管理情報                   */
        FL_PAGE_COM_ATR     sPageComAtr;        /* 頁入力結果情報               */
        FL_PAGE_IN_ATR      sPageInAtr;         /* 入力情報                     */
        FL_PAGE_OUT_ATR     sPageOutAtr;        /* 出力情報                     */
    } FL_PAGE_MAN_TBL;

    /********************************************/
    /* ファイル属性ファイル(HD形式) 共通用      */
    /********************************************/
    typedef struct FL_FILE_MAN_FILE{
        FL_FILE_STATUS   sFileMan;           /* ファイル管理部                   */
        FL_FILE_COM_ATR  sFileComAtr;        /* 入力結果情報                     */
        FL_FILE_IN_ATR   sFileInAtr;         /* 入力情報                         */
        FL_FILE_OUT_ATR  sFileOutAtr;        /* 出力情報                         */
        FU_FAX_ORG_INF   sFaxOrgInf;         /* ＦＡＸ固有オリジナル属性         */
        FL_PAGE_HEADER   sPageHeader;        /* 頁属性共通ヘッダ                 */
        FL_PART_MAN      sPartMan;           /* 頁パーティション情報             */
        FL_PAGE_MAN_TBL  sPageManTbl[FL_PAGE_MAX_COUNT]; /* 頁管理テーブル情報   */
        
    } FL_FILE_MAN_FILE;

#endif // __CI_SYSTEMDATAFILE_H__
