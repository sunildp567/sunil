/*****************************************************************************/
/*  (C) Copyright  TOSHIBA TEC CORPORATION 2008   All Rights Reserved        */
/*****************************************************************************
============================== Source Header =================================
 Filename: cfolder.h
 Revision: com_t#3
 File Spec: EBX:MA6037.A-DEV_SRC;com_t#3
 Originator: LOCHANA.LINGEGOWDA
 Last Changed: 09-JAN-2009 21:45:58

  Outline : 

*/
/*----------------------------------------------------------------------------
 Related Change Documents:
   Not related to any Change Document
------------------------------------------------------------------------------
 Related Baselines:
   1:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1935"
   	Creation Date: 13-JAN-2009 19:36:02
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1935.AAAA
   
   2:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1759"
   	Creation Date: 13-JAN-2009 18:00:09
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1759.AAAA
   
   3:
   	Baseline:      "EBX:SCI_PHASE4_V2247_20090113_1513"
   	Creation Date: 13-JAN-2009 15:14:46
   	Description:   Baseline SCI_PHASE4_V2247_20090113_1513.AAAA
   
------------------------------------------------------------------------------
 History:
   Revision com_t#3 (APPROVED)
     Created:  09-JAN-2009 21:45:58      CHANDRAMOHAN.PUJARI
       Added code for Image extension support and Archive related API's
     Updated:  09-JAN-2009 21:45:58      CHANDRAMOHAN.PUJARI
       Added code for Image extension support and Archive related API's
     Updated:  09-JAN-2009 21:45:58      CHANDRAMOHAN.PUJARI
       Added code for Image extension support and Archive related API's
     Updated:  09-JAN-2009 21:45:58      CHANDRAMOHAN.PUJARI
       Item revision com_t#3 created from revision com_t#2 with status
       $TO_BE_DEFINED
   
   Revision com_t#2 (APPROVED)
     Updated:  19-DEC-2008 22:20:03      CHANDRAMOHAN.PUJARI
       Code Indentation Done
     Created:  19-DEC-2008 22:19:58      CHANDRAMOHAN.PUJARI
       Code Indentation Done
     Updated:  19-DEC-2008 22:19:58      CHANDRAMOHAN.PUJARI
       Code Indentation Done
     Updated:  19-DEC-2008 22:19:58      CHANDRAMOHAN.PUJARI
       Item revision com_t#2 created from revision com_t#1 with status
       $TO_BE_DEFINED
   
   Revision com_t#1 (APPROVED)
     Created:  17-NOV-2008 21:59:23      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s of Folder class
     Updated:  17-NOV-2008 21:59:23      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s of Folder class
     Updated:  17-NOV-2008 21:59:23      CHANDRAMOHAN.PUJARI
       Added derived functions for New Interface API s of Folder class
     Updated:  17-NOV-2008 21:59:23      CHANDRAMOHAN.PUJARI
       Item revision com_t#1 created from revision com_m#1.2 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.2 (APPROVED)
     Updated:  01-SEP-2008 17:15:58      13848
       Updated attribute(s)
     Created:  01-SEP-2008 17:14:34      13848
       Update for Ph3.5 1st build
     Updated:  01-SEP-2008 17:13:14      13848
       Item revision com_m#1.2 created from revision com_m#1.1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1.1 (UNIT TESTED)
     Updated:  01-SEP-2008 16:51:17      13848
       Updated attribute(s)
     Created:  25-AUG-2008 20:11:39      13848
       BoxDocument 2nd release
     Updated:  25-AUG-2008 20:07:59      13848
       Item revision com_m#1.1 created from revision com_m#1 with
       status $TO_BE_DEFINED
   
   Revision com_m#1 (UNDER WORK)
     Created:  19-AUG-2008 14:34:21      13848
       Initial revision
========================== End of Source Header =============================*/

#ifndef __CI_CFOLDER_H__
#define __CI_CFOLDER_H__

#include <map>
#include <status.h>
#include <CI/OperatingEnvironment/ref.h>
#include <CI/OperatingEnvironment/cstring.h>
#include <CI/DocumentStore/documentstore.h>
#include <CI/BoxDocument/boxdocument.h>
#include <CI/BoxDocument/box.h>
#include "carchive.h"
#include "cextract.h"
namespace ci {
namespace boxdocument {

using namespace operatingenvironment;

class CFolder : public Folder
{
private:
    CString m_BoxBasePath;
    CString m_BoxNumber;
    CString m_FolderName;
    std::map<CString, CString> m_WebDAVProperties;

	Ref<Thread> m_ThreadID;
	static std::vector<CString> m_CutVecofDocs;
	CString m_CutProgShmName;
	CString m_CutErrfile;

	static std::vector<CString> m_CopyVecofDocs;
	CString m_CopyProgShmName;
	CString m_CopyErrfile;

	CString m_PasteProgShmName;
	CString m_PasteErrfile;	

	static CString m_DelDoc;
	CString m_DelDocProgShmName;
	CString m_DeleteDocErrfile;
	CString m_sessionID;	 
   Ref<CProgress> m_cprogress;
   //Shared memory ref to handle the shm for cut,copy,paste,etc., progress
   Ref<SharedMemory> m_prgShmid;
   static std::vector<CString> m_PastedVecofDocs;
   bool m_returnpastedocname;
public:
    /**
     * constructor
     */
    CFolder(CString sessionID, CString boxbasepath, 
              CString boxnumber,
              CString foldername);
    
    // destructor
    virtual ~CFolder();
    
    /**
     * get document instance in the container.
     * @param[out] doc - instance of Document class
     * @param[in] documentname - serial number from "00000".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetDocument(DocumentRef &doc, CString documentname);
    
    /**
     * get a list of document
     * @param[out] list - list of documents. 
     *                     This list have snapshot of each documents instances.
     *                     the snapshot is independent from original documents
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetDocumentList(DocumentList &list);
    
    /**
     * get a list of document
     * @param[out] list - list of documents. 
     *                     This list have snapshot of each documents instances.
     *                     the snapshot is independent from original documents
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @param[in] from - return list from this value.
     * @param[in] size - list size, if "from" + "size" is bigger than the 
     *                    number of all documents, return list size will be 
     *                    smaller than "size".
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status GetDocumentList(DocumentList &list, 
                                    unsigned int from, unsigned int size);
	/**
	 * get a list of document. Using these document objects user can access the following
	 * document properties.
	 * documentName
	 * jobType
	 * totalPages
	 * creationDate
	 * lastModifiedDate
	 * Size
	 * thumbnail
	 * cutDocument
	 * document status
	 * jobTypeColorMap
	 * paperSizeMap
	 *
	 * @param[out] list - list of documents.
	 *                     This list have snapshot of each documents instances.
	 *                     the snapshot is independent from original documents
	 *                     it means you can read properties only through the
	 *                     snapshot. if you call other methods to the snapshot,
	 *                     it will fail.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status GetViewDocumentList(DocumentList &list);

	/**
	 * get a list of document. Using these document objects user can access the following
	 * document properties.
	 * documentName
	 * jobType
	 * totalPages
	 * creationDate
	 * lastModifiedDate
	 * Size
	 * thumbnail
	 * cutDocument
	 * document status
	 * jobTypeColorMap
	 * paperSizeMap
	 * @param[out] list - list of documents.
	 *                     This list have snapshot of each documents instances.
	 *                     the snapshot is independent from original documents
	 *                     it means you can read properties only through the
	 *                     snapshot. if you call other methods to the snapshot,
	 *                     it will fail.
	 * @param[in] from - return list from this value.
	 * @param[in] size - list size, if "from" + "size" is bigger than the
	 *                    number of all documents, return list size will be
	 *                    smaller than "size".
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure.
	 */
	Status GetViewDocumentList(DocumentList &list,unsigned int from, unsigned int size);
    /**
     * Get a list of document. This returns the CViewDocument class object to the user.
     * Using this documentRef, user can access only name of the document. 
     * @param[out] list - list of documents. 
     * This list have snapshot of each documents instances.
     * @return STATUS_OK on success,
     * STATUS_FAILED on failure.
     **/
    Status GetDocumentListToDelete(DocumentList &list);

    /**
     * create new folder
     * if Folder object call this function, it will fail.
     * @param[in] foldername - new folder name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the disk.
     *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if total files reached MAx number.          
     */
    Status CreateFolder(CString foldername);

    /**
     * create new folder
     * if Folder object call this function, it will fail.
     * @param[out] folder - instance of Folder class     
     * @param[in] foldername - new folder name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the disk.
     *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if total files reached MAx number.          
     */
	Status CreateFolder(FolderRef& folder, CString foldername);
    
    /**
     * get folder instance by folder name
     * @param[out] folder - reference to folder instance
     * @param[in] foldername - target folder name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFolder(FolderRef& folder, CString foldername);
    
    /**
     * get a list of folder
     * @param[out] list - list of folders. 
     *                     this list have snapshot of each folder instances.
     *                     the snapshot is independent from original folders.
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFolderList(FolderList &list);
    
    /**
     * get a list of folder
     * @param[out] list - list of folders. 
     *                     this list have snapshot of each folder instances.
     *                     the snapshot is independent from original folders.
     *                     it means you can read properties only through the
     *                     snapshot. if you call other methods to the snapshot,
     *                     it will fail.
     * @param[in] from - return list from this value.
     * @param[in] size - list size, if "from" + "size" is bigger than the 
     *                    number of all lists, return list size will be smaller
     *                    than "size".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetFolderList(FolderList &list,
                                  unsigned int from, unsigned int size);
    
    /**
     * delete the folder
     * if documents in the box is using, it will fail(some documents are 
     *  deleted).
     * @param[in] foldername - target folder name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status DeleteFolder(CString foldername);
    
    /**
     * set box property
     * @param[in] key - the property name to be set
     * @param[in] value - the property value to be set
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetWebDAVProperty(CString key, CString value);
    
    /**
     * get box/folder property
     * @param[in] key - the property name to be set
     * @param[out] value - the property value
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetWebDAVProperty(CString key, CString &value);
    
    /**
     * set a name of the container
     * @param[in] name - a name to be set
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SetName(CString name);
    
    /**
     * get a name of the container
     * @param[out] name - a name of the container
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status GetName(CString &name);

	Status CreateThread(ThreadFun funcName,ThreadArg funcArgument,Ref<Thread> threadID);
	
    /**
     * cut the documents to clipboard
     * if document status is NOT READY, it will fail.
     * @param[in] docname - source document name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CutDocument(CString docname);
    
    /**
     * cut the documents to clipboard
     * if document status is NOT READY, it will fail.
     * @param[in] documents - source document names
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CutDocument(std::vector<CString> documents);

	/**
	 * cut the documents to clipboard
	 * if document status is NOT READY, it will fail.
	 * @param[out] progress - user can get operation progress from this.
	 * @param[in] docname - source document name
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure,
	 *         STATUS_DISK_FULL if there is not enough space on the disk.
	 */
	Status CutDocument(ProgressRef& progress, CString docname);

	/**
	 * cut the documents to clipboard
	 * if document status is NOT READY, it will fail.
	 * @param[out] progress - user can get operation progress from this.
	 * @param[in] documents - source document names
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure,
	 *         STATUS_DISK_FULL if there is not enough space on the disk.
	 */
	Status CutDocument(ProgressRef& progress, std::vector<CString> documents);	

	Status CreateCutThread(CFolder* cutFolderObj, std::vector<CString> documents);

	/**
	* Launch or Start a new thread for Cut operation 
	*/
	static void* StartCutThread(void *arg);	
    /**
     * copy the documents to clipboard
     * if document status is NOT READY or USING 
     *   or RESERVING or EDITING, it will fail.
     * @param[in] docname - source document name
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CopyDocument(CString docname);
    
    /**
     * copy the documents to clipboard
     * if document status is NOT READY or USING 
     *   or RESERVING or EDITING, it will fail.
     * @param[in] documents - source document names
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status CopyDocument(std::vector<CString> documents);
	
	/**
	 * copy the documents to clipboard
	 * if document status is NOT READY or USING 
    *    or RESERVING or EDITING, it will fail.
	 * @param[out] progress - user can get operation progress from this.
	 * @param[in] docname - source document name
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure,
	 *         STATUS_DISK_FULL if there is not enough space on the disk.
	 */
	Status CopyDocument(ProgressRef& progress, CString docname);    

	/**
	 * copy the documents to clipboard
	 * if document status is NOT READY or USING 
    *    or RESERVING or EDITING, it will fail.
	 * @param[out] progress - user can get operation progress from this.
	 * @param[in] documents - source document names
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure,
	 *         STATUS_DISK_FULL if there is not enough space on the disk.
	 */
	Status CopyDocument(ProgressRef& progress, std::vector<CString> documents);


	Status CreateCopyThread(CFolder* copyBoxObj, std::vector<CString> documents);

	/**
	* Launch or Start a new thread for Cut operation 
	*/
	static void* StartCopyThread(void *arg);	
	
	Status CreatePasteThread(CFolder* pasteBoxObj);

	/**
	* Launch or Start a new thread for Cut operation 
	*/
	static void* StartPasteThread(void *arg);	
	
    /**
     * paste the document from clipboard
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure,
     *         STATUS_DISK_FULL if there is not enough space on the partition. 
     */
    Status PasteDocument();
	
	/**
	 * paste the document from clipboard
	 * @param[out] progress - user can get operation progress from this.
	 * @return STATUS_OK on success,
	 *         STATUS_FAILED on failure,
	 *         STATUS_DISK_FULL if there is not enough space on the disk.
	 */
	Status PasteDocument(ProgressRef& progress);
	
    // CFolder methods
    
    /**
     * load properties from WebDAV
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status LoadProperties();

    /**
     * load properties from WebDAV
     * @param[in] WebDAVpropertyMap - webDav property map     
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
	Status LoadProperties(std::map<CString, CString> WebDAVpropertyMap);
	
    /**
     * save properties to WebDAV
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     */
    Status SaveProperties();

	/**
	* get size of the containers
	* It includes the size of all files that compose Document.
	* @param[out] total - total size (byte) of the container
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure.
	**/
	Status GetSize(uint64 &size);

/**
* create archive
* @param[out] archiver - created Archiver object.
* @param[in] target - archive file path / file name
* @param[in] documentname - document name to be archived
* @return STATUS_OK on success,
*         STATUS_FAILED on failure,
*         STATUS_DISK_FULL if there is not enough space on the disk.
*/
Status CreateArchive(ArchiverRef &archiver, CString target, CString documentname);
/**
* create archive
* @param[out] archiver - created Archiver object.
* @param[in] target - archive file path / file name
* @param[in] documentlist - list of document name to be archived
* @return STATUS_OK on success,
*         STATUS_FAILED on failure,
*         STATUS_DISK_FULL if there is not enough space on the disk.
*/
Status CreateArchive(ArchiverRef &archiver, CString target, std::vector<CString> documentlist);

/**
* extract archive
* @param[out] extractor - created Extractor object
* @param[in] archiverpath - path of the archive to be extracted
* @param[in] extractorpath - path to which the archived files needs to extracted  
* @return STATUS_OK on success,
*         STATUS_FAILED on failure,
*         STATUS_DISK_FULL if there is not enough space on the disk.
*/
Status ExtractArchive(ExtractorRef &extractor,CString archiverpath,CString extractorpath);

/**
* Delete Archive 
* @param[in] archivepath - path of the archive file that needs to be deleted
* @return STATUS_OK on success,
*         STATUS_FAILED on failure,
*/
Status DeleteArchive(CString archivepath);

void ErrorFileCreation(CString filename, Ref<SharedMemory> shmpid);

 /**
  * create document instance on the container
  * the name of document is least number of non-exist documents. 
  * @param[out] doc - instance of Document class 
  * @param[in/out] documentname - on input, it is document name expected by 
  *                                users. on output, it's created document 
  *                                name. if document has the same name
  *                                exists, suffix will be added.
  * @return STATUS_OK on success,
  *         STATUS_FAILED on failure,
  *         STATUS_DISK_FULL if there is not enough space on the disk.
  *         STATUS_MAX_ALLOWED_RESOURCES_REACHED if the resource limit is reached
  */
 Status CreateDocument(DocumentRef& doc, 
                               CString &documentname);

 /**
  * delete document
  * document status will be changed to DELETING. after that, document will
  * be deleted. 
  * if document status is NOT READY or EDITING, it will fail.
  * @param[in] documentname - serial number from "00000".
  * @return STATUS_OK on success,
  *         STATUS_FAILED on failure.
  */
 Status DeleteDocument(CString documentname);
 
 /**
  * delete document
  * document status will be changed to DELETING. after that, document will
  * be deleted. 
  * if document status is NOT READY or EDITING, it will fail.
  * @param[out] progress - user can get operation progress from this.
  * @param[in] documentname - serial number from "00000".
  * @return STATUS_OK on success,
  *         STATUS_FAILED on failure.
  */
 Status DeleteDocument(ProgressRef& progress,
 									CString documentname);

 /**
  * Undo the cut/copy document operation
  * @param[in] docname - source document name
  * @return STATUS_OK on success,
  *         STATUS_FAILED on failure,
  */
 Status UndoEditDocument(CString docname);
 
 /**
  * Undo the cut/copy document operation
  * @param[in] documents - source document names     
  * @return STATUS_OK on success,
  *         STATUS_FAILED on failure,
  */
 Status UndoEditDocument(std::vector<CString> documents);	

	/**
	* Creating the thread for Delete operation i.e. to Delete page.
	* @param[in] docObj - Instance of the CBoxDocument Class.
	* @param[in] documentname - serial number from "00000".
	* @return STATUS_OK on success,
	*         STATUS_FAILED on failure
	*/
	Status CreateDeleteDocumentThread(CFolder* docelemObj,CString documentname);

	/**
	* Launch or Start a new thread for Delete Document operation 
	*/
	static void* StartDeleteDocumentThread(void* arg);

    /**
     * get a list of document properties
     * @param[out] list - list of document properties. 
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * @NOTE - It is available via GetBoxList
     */
    Status GetDocumentPropertiesList(DocumentPropertiesList &list);
    
    /**
     * get a list of document
     * @param[out] list - list of document properties. 
     * @param[in] from - return list from this value. (0-origin)
     * @param[in] size - list size, if "from" + "size" is bigger than the 
     *                    number of all documents, return size will be 
     *                    smaller than "size".
     * @return STATUS_OK on success,
     *         STATUS_FAILED on failure.
     * @NOTE - It is available via GetBoxList
     */
    Status GetDocumentPropertiesList(DocumentPropertiesList &list, 
                                    unsigned int from, unsigned int size);
    // support for ebx_rcr_235 : start
    /**
     * paste the document from clipboard to the box or to the folder present under the box	
     * @param[out] documentnames - names of the documents that's been pasted
     * @return status_ok on success,
     *         status_failed on failure,
     *         status_disk_full if there is not enough space on the disk.
     *         status_max_allowed_resources_reached if the resource limit is reached.
     **/
    Status PasteDocument(std::vector<CString> &documentnames);
    // Support for EBX_RCR_235 : End
	}; // class CFolder

}; // end of namespace boxdocument
}; // end of namespace ci

#endif // __CI_CFOLDER_H__
